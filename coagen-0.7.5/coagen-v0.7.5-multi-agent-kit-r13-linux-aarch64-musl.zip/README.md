# Coagen 安装套件 r13（客户端 / Skill 0.7.5）

一个套件对应一个平台。客户端、MCP Server、会话 helper、CLI、完整 Skill、全部锁定依赖、内置 pip 和安装器都在包内；**不含 Python 本体、Agent 软件或任何凭据**。

## 选对文件

| 你的电脑 | 下载 |
|---|---|
| Linux x86_64（Ubuntu/Debian/Fedora/RHEL 等，glibc ≥ 2.17） | `coagen-v0.7.5-multi-agent-kit-r13-linux-x86_64-glibc.zip` |
| Linux ARM64（glibc ≥ 2.17） | `…-linux-aarch64-glibc.zip` |
| Alpine 等 musl Linux（musl ≥ 1.2） | `…-linux-x86_64-musl.zip` / `…-linux-aarch64-musl.zip` |
| macOS Apple Silicon（macOS 11+） | `…-macos-arm64.zip` |
| Windows 10/11 x64 | `…-windows-x86_64.zip` |
| 任意受支持平台、可以访问 PyPI | `…-online.zip`（按同一哈希锁在线下载依赖） |

需要已有 64 位普通 CPython **3.11–3.14**。Intel Mac、Windows ARM64 原生 Python 暂不支持，原因与替代办法见 `INSTALL_FOR_AGENT.md`。拿错包时安装器在任何写入之前报告 `KIT_PLATFORM_MISMATCH` 并给出正确文件名。

## 普通用户：两条命令

Linux / macOS：

```sh
sha256sum -c coagen-v0.7.5-multi-agent-kit-r13-linux-x86_64-glibc.zip.sha256   # macOS: shasum -a 256 -c …
python3 -m zipfile -e coagen-v0.7.5-multi-agent-kit-r13-linux-x86_64-glibc.zip ~/CoagenKits/r13 && sh ~/CoagenKits/r13/install.sh install --host auto --workspace ~/CoagenWork --apply
```

Windows（CMD）：先核对 `.sha256`，完整解压，然后运行 `INSTALL.cmd install --host auto --workspace "%USERPROFILE%\CoagenWork" --apply`。

`~/CoagenWork` 需事先存在（`mkdir -p ~/CoagenWork`），它是 Coagen 读取附件和导出文件的固定根目录。去掉 `--apply` 只预览，不写入任何文件。

## 交给 Agent 的一句话

> 读取我提供的 Coagen r13 安装包中的 INSTALL_FOR_AGENT.md，按其中的标准流程为当前 Agent 安装或升级 Coagen 0.7.5：核对平台、预览、应用、doctor，按宿主公开入口登记 MCP 并加载 Skill，最后原生调用 coagen_prepare，分层报告结果。不要重复安装或猜测私有配置。

## 结果的六层含义

安装报告中的 `acceptance` 分层给出，前一层成功不代表后一层成功：

1. `1_components_and_dependencies`：runtime、依赖、MCP 自检通过；
2. `2_mcp_configuration`：已知宿主配置已合并（`merged_on_disk`），或通用描述符已导出待登记（`exported_not_registered`）；
3. `3_skill_files_installed`：Skill 已写入；宿主是否发现由宿主确认；
4. 宿主原生加载并调用 `coagen_prepare`：只能在宿主内验收；
5. `5_hub_network`：`doctor --check-hub` 才检查；
6. 加密协作：需要真实房间或隔离测试 Hub。

## 位置

| 内容 | Linux | macOS | Windows |
|---|---|---|---|
| runtime | `~/.local/share/coagen/runtimes/0.7.5`（或 `$XDG_DATA_HOME/coagen/…`） | `~/Library/Application Support/Coagen/runtimes/0.7.5` | `%LOCALAPPDATA%\Coagen\runtimes\0.7.5` |
| 公共 Skill | `~/.agents/skills/coagen` | 同左 | `%USERPROFILE%\.agents\skills\coagen` |
| 报告、备份、回执 | `~/.coagen-setup/`（权限 0700） | 同左 | `%USERPROFILE%\.coagen-setup\` |
| 会话状态 | `~/.local/state/Coagen` | 同左 | `%LOCALAPPDATA%\Coagen` |

旧版本 runtime 保留；升级创建新版本目录，回滚只恢复配置和 Skill，不删除 runtime。

## 升级与回滚

```sh
sh install.sh install --host auto --workspace ~/CoagenWork            # 预览
sh install.sh install --host auto --workspace ~/CoagenWork --apply    # 应用（沿用原来的稳定目录）
sh install.sh rollback --report ~/.coagen-setup/reports/<id>/report.json            # 预览回滚
sh install.sh rollback --report ~/.coagen-setup/reports/<id>/report.json --apply    # 恢复配置与 Skill
```

完整流程、错误码与有界恢复见 `INSTALL_FOR_AGENT.md`。不能运行 `install.sh` / `INSTALL.cmd` 的环境见 `MANUAL_INSTALL.md`：直接用 Python 运行安装器，或按步骤手工安装（只用标准库 Python，三个系统相同）。
