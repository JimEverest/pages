#!/bin/sh
# Coagen kit entry for Linux and macOS: sh install.sh install --host auto [--apply]
# Selects an existing 64-bit CPython 3.11-3.14 and runs the kit installer in
# isolated UTF-8 mode. It never installs Python, uses sudo, or edits shell files.
set -u
rejected=''
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1

fail() {
  # $1 code, $2 next action (plain ASCII text without double quotes)
  printf '{"ok":false,"status":"failed","code":"%s","stage":"bootstrap","retry_allowed":false,"native_mcp_verified":false,"rejected_interpreters":"%s","next_action":"%s"}\n' "$1" "${rejected:-}" "$2"
  exit 1
}

if [ ! -f "$here/coagen_install.py" ] || [ ! -f "$here/kit-manifest.json" ]; then
  fail INSTALLATION_FILES_MISSING 'Extract the complete trusted kit ZIP after checking its .sha256, then run sh install.sh from the extracted directory. Do not assemble files from the source tree.'
fi

probe='import platform,struct,sys,sysconfig; assert platform.python_implementation()=="CPython" and (3,11)<=sys.version_info[:2]<=(3,14) and struct.calcsize("P")==8 and not sysconfig.get_config_var("Py_GIL_DISABLED")'
usable() { [ -x "$1" ] && "$1" -I -X utf8 -c "$probe" >/dev/null 2>&1; }
rejected=''

if [ -n "${COAGEN_INSTALL_PYTHON:-}" ]; then
  # An explicit choice is authoritative; never fall through to another Python.
  if usable "$COAGEN_INSTALL_PYTHON"; then
    exec "$COAGEN_INSTALL_PYTHON" -I -X utf8 "$here/coagen_install.py" "$@"
  fi
  rejected='COAGEN_INSTALL_PYTHON'
  fail PYTHON_SELECTED_UNSUPPORTED 'COAGEN_INSTALL_PYTHON must name an existing 64-bit standard CPython 3.11-3.14 executable. Run it with --version to check, or unset the variable to use automatic discovery.'
fi

for name in python3 python3.14 python3.13 python3.12 python3.11; do
  path=$(command -v "$name" 2>/dev/null) || continue
  if usable "$path"; then
    exec "$path" -I -X utf8 "$here/coagen_install.py" "$@"
  fi
  rejected="$rejected $name"
done

# A previously installed Coagen runtime is a valid interpreter of last resort.
for base in "${XDG_DATA_HOME:-$HOME/.local/share}/coagen/runtimes" "$HOME/Library/Application Support/Coagen/runtimes"; do
  for path in "$base"/*/bin/python; do
    if usable "$path"; then
      exec "$path" -I -X utf8 "$here/coagen_install.py" "$@"
    fi
  done
done

case "$(uname -s 2>/dev/null)" in
  Darwin) hint='macOS: install CPython 3.13 from python.org or run brew install python@3.13, then rerun.' ;;
  Linux)
    id=''
    [ -r /etc/os-release ] && id=$(. /etc/os-release 2>/dev/null; printf '%s %s' "${ID:-}" "${ID_LIKE:-}")
    case "$id" in
      *alpine*) hint='Alpine: apk add python3 (3.11 or newer), then rerun.' ;;
      *debian*|*ubuntu*) hint='Debian/Ubuntu: sudo apt install python3 (needs 3.11 or newer; Ubuntu 24.04 and Debian 12 qualify). Older releases: use a newer CPython such as uv python install 3.13, then set COAGEN_INSTALL_PYTHON.' ;;
      *fedora*|*rhel*|*centos*|*suse*) hint='Fedora/RHEL/SUSE: install python3.11 or newer with the system package manager, then rerun.' ;;
      *) hint='Install CPython 3.11-3.14 with the system package manager or uv python install 3.13, then rerun.' ;;
    esac ;;
  *) hint='Install a 64-bit CPython 3.11-3.14, then rerun.' ;;
esac
if [ -n "$rejected" ]; then
  fail PYTHON_VERSION_UNSUPPORTED "Found Python, but not a 64-bit standard CPython 3.11-3.14. $hint Or set COAGEN_INSTALL_PYTHON=/path/to/python3.x. The installer did not change the system."
fi
fail PYTHON_UNAVAILABLE "No python3 was found on PATH. $hint Or set COAGEN_INSTALL_PYTHON=/path/to/python3.x. The installer did not change the system."
