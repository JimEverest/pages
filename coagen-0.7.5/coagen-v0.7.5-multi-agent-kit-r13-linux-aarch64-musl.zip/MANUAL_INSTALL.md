# Coagen 0.7.5 手工安装（不依赖 install.sh / INSTALL.cmd）

适用于无法运行 `install.sh` 或 `INSTALL.cmd` 的环境：Agent 只能执行 Python、shell 被沙箱禁用、执行策略限制、系统没有 `sh` 等。**按顺序执行，不跳步、不改写步骤、不自行发挥。** 每一步结束都打印一行 JSON：`"ok": true` 才继续；`"ok": false` 时按其中的 `next_action` 处理，修正一个已确认原因后最多重试一次，再失败就停止并报告。

最低前提（任何方式都不能绕过）：

- 本机已有 64 位标准 CPython **3.11–3.14**。Coagen 的 MCP Server 本身是 Python 程序，没有合格的 Python 就无法运行 Coagen，本文也无法解决。
- 宿主能启动本地 stdio MCP 子进程，并允许它再启动子进程、使用 127.0.0.1 回环通信、访问 Hub 的 HTTPS。
- 已取得与本机平台对应的完整套件 ZIP 并核对 `.sha256`（见 `INSTALL_FOR_AGENT.md` 第 1 节）。只有本文档、没有套件时：从发布页下载 `…-online.zip`（约 2 MB），依赖会从 PyPI 按同一哈希锁下载，**需要联网**。客户端 wheel 不在 PyPI 上，必须来自发布页。

## 第 1 层：直接运行安装器（首选）

`install.sh` / `INSTALL.cmd` 只负责找到 Python。能运行 Python 就能直接运行同一个安装器，全部安全机制（校验、预览、备份回执、并发锁、中断恢复、报告、回滚）都保留。把 `PYTHON`、`KIT`、`WORKSPACE` 换成实际绝对路径，路径含空格时按所在 shell 的规则加引号：

<!-- coagen-step: direct -->
```text
PYTHON -I -X utf8 KIT/coagen_install.py install --host auto --workspace WORKSPACE
PYTHON -I -X utf8 KIT/coagen_install.py install --host auto --workspace WORKSPACE --apply
PYTHON -I -X utf8 KIT/coagen_install.py doctor --host auto --workspace WORKSPACE --check-hub
```

之后按 `INSTALL_FOR_AGENT.md` 第 4–7 节登记、验收、升级或回滚（把其中的 `ENTRY` 换成 `PYTHON -I -X utf8 KIT/coagen_install.py`）。**只有第 1 层本身报错且原因不是你能修正的输入问题时**，才使用下面的第 2 层。

## 第 2 层：逐步手工安装

每一步是一段只用标准库的 Python 代码，在 Windows、Linux、macOS 上完全相同。运行方式任选其一：保存为文件后 `PYTHON -I -X utf8 文件.py`，或通过宿主的 Python 执行工具运行。第 1 步需要两个值：

- `COAGEN_KIT`：套件解压目录的绝对路径；
- `COAGEN_WORKSPACE`：已存在的稳定协作目录（未指定时先创建并使用用户目录下的 `CoagenWork`，不要用临时聊天目录）。

可以设置成同名环境变量，也可以直接改写第 1 步开头两行的占位符。之后各步从 `~/.coagen-setup/manual/state.json` 读取第 1 步记录的结果，不需要再填写。可选：`COAGEN_SOURCE=online` 改用在线依赖；`COAGEN_MANUAL_HOST=claude` 让第 5 步直接合并 Claude Code 的 `~/.claude.json`（默认 `print`，只输出登记片段）。

与第 1 层相比，手工流程**没有**并发锁、自动中断恢复和失败计数。报告结果时说明“手工安装”。产物位置与安装器完全相同，之后可以用第 1 层的 `doctor` 检查，也可以直接用安装器升级。

### 第 1 步：检查（只写入 state.json）

<!-- coagen-step: preflight -->
```python
import hashlib, json, os, platform, struct, sys, sysconfig
from pathlib import Path

KIT = os.environ.get('COAGEN_KIT') or r'<套件解压目录的绝对路径>'
WORKSPACE = os.environ.get('COAGEN_WORKSPACE') or r'<稳定协作目录的绝对路径>'
SOURCE = os.environ.get('COAGEN_SOURCE', 'auto')


def stop(code, next_action, **extra):
    print(json.dumps({'ok': False, 'step': 'preflight', 'code': code, 'next_action': next_action, **extra}, ensure_ascii=False))
    raise SystemExit(1)


kit, workspace = Path(KIT), Path(WORKSPACE)
if '<' in KIT or not kit.is_absolute() or not (kit / 'kit-manifest.json').is_file():
    stop('KIT_PATH_INVALID', 'Set COAGEN_KIT to the absolute path of the completely extracted kit.')
if '<' in WORKSPACE or not workspace.is_absolute() or not workspace.is_dir():
    stop('WORKSPACE_MISSING', 'Create the stable workspace directory first and set COAGEN_WORKSPACE to its absolute path.')
if (platform.python_implementation() != 'CPython' or not (3, 11) <= sys.version_info[:2] <= (3, 14)
        or struct.calcsize('P') != 8 or sysconfig.get_config_var('Py_GIL_DISABLED')):
    stop('PYTHON_VERSION_UNSUPPORTED', 'Run this step with a 64-bit standard CPython 3.11-3.14. The steps do not install Python.',
         detected=platform.python_version())

manifest = json.loads((kit / 'kit-manifest.json').read_text(encoding='utf-8-sig'))
for name, digest in manifest['files'].items():
    path = kit / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        stop('KIT_CHECKSUM_MISMATCH', 'The kit is incomplete or altered. Obtain the trusted release again and verify its .sha256.', file=name)

system = 'windows' if sys.platform == 'win32' else 'macos' if sys.platform == 'darwin' else 'linux'
if system == 'windows':
    arch = {'win-amd64': 'x86_64', 'win-arm64': 'arm64'}.get(sysconfig.get_platform(), sysconfig.get_platform())
    target = 'windows-' + arch
else:
    machine = platform.machine().lower()
    arch = {'amd64': 'x86_64', 'x86_64': 'x86_64', 'arm64': 'arm64', 'aarch64': 'aarch64'}.get(machine, machine)
    if system == 'linux':
        try:
            glibc = os.confstr('CS_GNU_LIBC_VERSION') or ''
        except (ValueError, OSError):
            glibc = ''
        target = 'linux-%s-%s' % (arch, 'glibc' if glibc.startswith('glibc') else 'musl')
    else:
        target = 'macos-' + arch
targets = manifest.get('targets', [])
source = SOURCE if SOURCE in ('offline', 'online') else ('offline' if targets else 'online')
if source == 'offline' and target not in targets:
    stop('KIT_PLATFORM_MISMATCH', 'Use coagen-v%s-%s-%s.zip, or set COAGEN_SOURCE=online on a machine that may reach PyPI.'
         % (manifest['client_version'], manifest['kit_version'], target), detected=target, kit_targets=targets)

home = Path.home()
if system == 'windows':
    base = Path(os.environ.get('LOCALAPPDATA') or home / 'AppData/Local') / 'Coagen/runtimes'
elif system == 'macos':
    base = home / 'Library/Application Support/Coagen/runtimes'
else:
    data = os.environ.get('XDG_DATA_HOME')
    base = (Path(data) if data and Path(data).is_absolute() else home / '.local/share') / 'coagen/runtimes'
runtime = base / manifest['client_version']
python = runtime / ('Scripts/python.exe' if system == 'windows' else 'bin/python')
reuse = False
if os.path.lexists(runtime):
    probe = None
    if python.is_file():
        import subprocess
        probe = subprocess.run([str(python), '-I', '-c', 'import coagen_client;print(coagen_client.__version__)'],
                               capture_output=True, text=True, timeout=60)
    if probe is None or probe.returncode or probe.stdout.strip() != manifest['client_version']:
        stop('RUNTIME_BROKEN', 'The runtime directory exists but does not run Coagen %s. Move it into %s (do not delete it), then rerun this step once.'
             % (manifest['client_version'], base / '.coagen-retired'), runtime=str(runtime))
    reuse = True

state_path = home / '.coagen-setup/manual/state.json'
state_path.parent.mkdir(parents=True, exist_ok=True)
state = {'format': 1, 'kit': str(kit), 'workspace': str(workspace), 'version': manifest['client_version'],
         'kit_version': manifest['kit_version'], 'target': target, 'source': source, 'runtime': str(runtime),
         'python': str(python), 'base_python': getattr(sys, '_base_executable', sys.executable), 'reuse_runtime': reuse}
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'ok': True, 'step': 'preflight', **state, 'state': str(state_path)}, ensure_ascii=False))
```

成功时记下输出中的 `runtime`、`source`、`reuse_runtime`。离线套件默认 `source=offline`：后续不访问任何包索引。

### 第 2 步：创建 runtime 并安装依赖

<!-- coagen-step: runtime -->
```python
import json, os, subprocess, sys, tempfile
from pathlib import Path

state = json.loads((Path.home() / '.coagen-setup/manual/state.json').read_text(encoding='utf-8'))
kit, runtime, python = Path(state['kit']), Path(state['runtime']), Path(state['python'])
client = kit / 'client'


def stop(code, next_action, detail=None):
    print(json.dumps({'ok': False, 'step': 'runtime', 'code': code, 'next_action': next_action, 'detail': detail}, ensure_ascii=False))
    raise SystemExit(1)


def run(command, code, next_action, timeout=600):
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith('PIP_') and k.upper() not in ('PYTHONPATH', 'PYTHONHOME')}
    if state['source'] == 'offline':
        env = {k: v for k, v in env.items() if not k.lower().endswith('_proxy')}
        env['PIP_NO_INDEX'] = '1'
    env.update(PIP_CONFIG_FILE=os.devnull, PIP_DISABLE_PIP_VERSION_CHECK='1', PYTHONUTF8='1')
    result = subprocess.run([str(x) for x in command], capture_output=True, timeout=timeout, env=env, stdin=subprocess.DEVNULL)
    if result.returncode:
        stop(code, next_action, result.stderr.decode('utf-8', 'replace').strip().splitlines()[-6:])


if state['reuse_runtime']:
    print(json.dumps({'ok': True, 'step': 'runtime', 'action': 'reused', 'runtime': str(runtime)}))
    raise SystemExit(0)

pip = next((client / 'tools').glob('pip-*-py3-none-any.whl')) / 'pip'
install = ['-I', '-X', 'utf8', pip, '--isolated', '--disable-pip-version-check', '--no-input', 'install', '--no-cache-dir',
           '--only-binary=:all:', '--require-hashes', '--no-warn-script-location',
           *(['--no-index'] if state['source'] == 'offline' else []),
           '--find-links', client / 'wheels', '-r', client / 'requirements-lock.txt']
# Resolve the whole lock for this interpreter before writing anything (--target is never created).
with tempfile.TemporaryDirectory() as scratch:
    run([sys.executable, *install, '--dry-run', '--ignore-installed', '--target', Path(scratch) / 'unused'],
        'DEPENDENCY_RESOLUTION_FAILED', 'The locked wheels do not fit this Python or platform. Use the kit for the reported target or a supported Python.')
runtime.mkdir(parents=True)
marker = runtime / '.coagen-runtime.json'
record = {'format': 1, 'client_version': state['version'], 'source': state['source'], 'target': state['target'],
          'installed_by': 'manual'}
marker.write_text(json.dumps({**record, 'state': 'installing'}), encoding='utf-8')
recover = 'Move %s into %s (do not delete it), then restart from step 1 once.' % (runtime, runtime.parent / '.coagen-retired')
run([sys.executable, '-I', '-X', 'utf8', '-m', 'venv', '--without-pip', runtime], 'PYTHON_VENV_FAILED', recover)
run([python, *install], 'DEPENDENCY_INSTALL_FAILED', recover)
run([python, '-I', '-X', 'utf8', pip, '--isolated', 'check'], 'DEPENDENCY_CHECK_FAILED', recover)
marker.write_text(json.dumps({**record, 'state': 'ready'}), encoding='utf-8')
print(json.dumps({'ok': True, 'step': 'runtime', 'action': 'created', 'runtime': str(runtime),
                  'network_used': state['source'] == 'online'}))
```

### 第 3 步：本机 MCP 自检

<!-- coagen-step: smoke -->
```python
import json, subprocess, tempfile, os
from pathlib import Path

state = json.loads((Path.home() / '.coagen-setup/manual/state.json').read_text(encoding='utf-8'))
requests = [
    {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2024-11-05', 'capabilities': {},
                                                                     'clientInfo': {'name': 'coagen-manual-check', 'version': '1'}}},
    {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
    {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'},
    {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'coagen_prepare', 'arguments': {}}},
]
with tempfile.TemporaryDirectory() as scratch:   # keeps the check's journal out of real session state
    result = subprocess.run([state['python'], '-I', '-X', 'utf8', '-m', 'coagen_client', 'mcp', '--workspace', state['workspace']],
                            input=''.join(json.dumps(r) + '\n' for r in requests), capture_output=True, text=True,
                            encoding='utf-8', timeout=60, env=dict(os.environ, LOCALAPPDATA=scratch, PYTHONUTF8='1'))
replies = {r['id']: r['result'] for r in map(json.loads, result.stdout.splitlines()) if 'id' in r}
prepared = json.loads(replies[3]['content'][0]['text']) if 3 in replies else {}
tools = {t['name'] for t in replies.get(2, {}).get('tools', [])}
ok = (result.returncode == 0 and prepared.get('version') == state['version'] and prepared.get('binding_scope') == 'mcp_instance'
      and Path(prepared.get('workspace', '')) == Path(state['workspace']).resolve() and 'coagen_prepare' in tools)
print(json.dumps({'ok': ok, 'step': 'smoke', 'version': prepared.get('version'), 'workspace': prepared.get('workspace'),
                  'binding_scope': prepared.get('binding_scope'), 'tools': len(tools),
                  **({} if ok else {'next_action': 'Stop. Preserve the runtime and this output; repeat step 2 only after moving the runtime aside.'})}))
raise SystemExit(0 if ok else 1)
```

### 第 4 步：安装 Skill（先备份已有副本）

<!-- coagen-step: skill -->
```python
import hashlib, json, os, shutil, time
from pathlib import Path

state_path = Path.home() / '.coagen-setup/manual/state.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
source = Path(state['kit']) / 'client/skills/coagen'
host = os.environ.get('COAGEN_MANUAL_HOST', 'print')
targets = [Path.home() / '.agents/skills/coagen']
if host == 'claude':
    targets.append(Path.home() / '.claude/skills/coagen')


def tree(path):
    return {p.relative_to(path).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}


expected, records = tree(source), []
fingerprint = hashlib.sha256(json.dumps(expected, sort_keys=True).encode()).hexdigest()
for target in targets:
    if target.is_symlink() or target.parent.is_symlink():
        print(json.dumps({'ok': False, 'step': 'skill', 'code': 'LINKED_PATH', 'target': str(target),
                          'next_action': 'The skill path is a symbolic link; review it with the user instead of writing through it.'}))
        raise SystemExit(1)
    if target.is_dir() and tree(target) == expected:
        records.append({'target': str(target), 'action': 'unchanged'})
        continue
    backup = None
    if target.exists():
        backup = Path.home() / '.coagen-setup/manual/backups' / str(time.time_ns()) / target.parent.parent.name.lstrip('.')
        backup.parent.mkdir(parents=True, exist_ok=True)
        target.rename(backup)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, target)
    records.append({'target': str(target), 'action': 'replaced' if backup else 'created',
                    'backup': str(backup) if backup else None, 'installed_sha256': fingerprint})
state['skills'] = state.get('skills', []) + [r for r in records if r['action'] != 'unchanged']
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'ok': True, 'step': 'skill', 'skills': records}, ensure_ascii=False))
```

### 第 5 步：登记 MCP

默认只输出登记内容并保存描述符，不修改任何宿主配置：按宿主**公开文档**的用户级 MCP 入口登记输出的 `mcpServers` 片段，并让宿主加载 `skill_path`。不要猜私有配置文件。设置 `COAGEN_MANUAL_HOST=claude` 时，本步只在 Claude Code 的 `~/.claude.json` 中合并 `mcpServers.coagen` 一项，先备份原文件，保留其他内容。

<!-- coagen-step: register -->
```python
import hashlib, json, os, time
from pathlib import Path

state_path = Path.home() / '.coagen-setup/manual/state.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
entry = {'type': 'stdio', 'command': state['python'],
         'args': ['-I', '-X', 'utf8', '-m', 'coagen_client', 'mcp', '--workspace', state['workspace']],
         'env': {'PYTHONUTF8': '1'}}
host = os.environ.get('COAGEN_MANUAL_HOST', 'print')
descriptor = Path.home() / '.coagen-setup/manual/coagen-mcp.json'
descriptor.write_text(json.dumps({**entry, 'skill_path': str(Path.home() / '.agents/skills/coagen')}, ensure_ascii=False, indent=2), encoding='utf-8')
result = {'ok': True, 'step': 'register', 'host': host, 'descriptor': str(descriptor),
          'mcpServers_json': {'mcpServers': {'coagen': entry}}, 'skill_path': str(Path.home() / '.agents/skills/coagen')}
if host == 'claude':
    config = Path.home() / '.claude.json'
    if config.is_symlink():
        print(json.dumps({'ok': False, 'step': 'register', 'code': 'CONFIG_UNSAFE_PATH', 'next_action': 'Review the linked ~/.claude.json with the user.'}))
        raise SystemExit(1)
    original = config.read_bytes() if config.exists() else None
    try:
        value = json.loads(original.decode('utf-8-sig')) if original else {}
        assert isinstance(value, dict) and isinstance(value.get('mcpServers', {}), dict)
    except (ValueError, AssertionError):
        print(json.dumps({'ok': False, 'step': 'register', 'code': 'CONFIG_INVALID', 'next_action': 'Nothing was written. Ask the user to repair ~/.claude.json.'}))
        raise SystemExit(1)
    if value.get('mcpServers', {}).get('coagen') == entry:
        result['config'] = {'path': str(config), 'action': 'unchanged'}
    else:
        backup = Path.home() / '.coagen-setup/manual/backups' / str(time.time_ns()) / 'claude.json'
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_bytes(original or b'')
        value.setdefault('mcpServers', {})['coagen'] = entry
        data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
        if (config.read_bytes() if config.exists() else None) != original:
            print(json.dumps({'ok': False, 'step': 'register', 'code': 'CONFIG_CHANGED_DURING_WRITE', 'next_action': 'Rerun this step once.'}))
            raise SystemExit(1)
        stage = config.with_name('.claude.json.coagen-manual.tmp')
        stage.write_bytes(data)
        os.replace(stage, config)
        assert config.read_bytes() == data
        state['config'] = {'path': str(config), 'existed': original is not None, 'backup': str(backup),
                           'written_sha256': hashlib.sha256(data).hexdigest()}
        result['config'] = {'path': str(config), 'action': 'merged', 'backup': str(backup)}
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
```

### 第 6 步：验收

1. 让宿主正常重新加载（多数宿主在新会话或重启时才读取 MCP 配置；先保存活动协作成果）。
2. 在新会话中原生调用 `coagen_prepare`，核对 `version = 0.7.5`、`workspace` 等于第 1 步的 workspace、`binding_scope = mcp_instance`，并确认宿主列出 `coagen` Skill。终端里的第 3 步自检不能代替这一步。
3. 能运行 Python 时，可以再用安装器只读检查：`PYTHON -I -X utf8 KIT/coagen_install.py doctor --host claude --workspace WORKSPACE --check-hub`（未合并宿主配置时用 `--host generic`，此时 config 一项会显示未登记，属正常）。

分开报告：组件与依赖（第 2–3 步）、MCP 配置（第 5 步）、Skill 发现、原生 prepare、Hub 网络、加密协作。

### 回滚手工安装

只恢复本流程写入、之后未被修改的配置与 Skill；runtime 不删除。

<!-- coagen-step: rollback -->
```python
import hashlib, json, shutil, time
from pathlib import Path

state_path = Path.home() / '.coagen-setup/manual/state.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
done = []
config = state.get('config')
if config:
    path = Path(config['path'])
    current = path.read_bytes() if path.exists() else None
    if current is None or hashlib.sha256(current).hexdigest() != config['written_sha256']:
        done.append({'config': str(path), 'action': 'skipped_changed_since_install'})
    else:
        original = Path(config['backup']).read_bytes()
        if config['existed']:
            path.write_bytes(original)
        else:
            path.unlink()
        done.append({'config': str(path), 'action': 'restored'})
def tree(path):
    return {p.relative_to(path).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}


kept = []
for record in reversed(state.get('skills', [])):
    target = Path(record['target'])
    if target.is_dir() and hashlib.sha256(json.dumps(tree(target), sort_keys=True).encode()).hexdigest() != record['installed_sha256']:
        done.append({'skill': str(target), 'action': 'skipped_changed_since_install'})
        kept.append(record)
        continue
    if target.is_dir():
        aside = Path.home() / '.coagen-setup/manual/rolled-back' / str(time.time_ns()) / target.parent.parent.name.lstrip('.')
        aside.parent.mkdir(parents=True, exist_ok=True)
        target.rename(aside)
    if record.get('backup') and Path(record['backup']).exists():
        Path(record['backup']).rename(target)
    done.append({'skill': str(target), 'action': 'restored' if record.get('backup') else 'removed'})
if not any(d.get('config') and d['action'] == 'skipped_changed_since_install' for d in done):
    state.pop('config', None)
state['skills'] = kept[::-1]  # records left for a later, user-reviewed rollback
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'ok': all(d['action'] != 'skipped_changed_since_install' for d in done), 'step': 'rollback',
                  'actions': done, 'runtime': 'retained'}, ensure_ascii=False))
```

升级：用新版本套件从第 1 步重新开始（会创建新版本 runtime，旧版保留）。之后重新加载宿主并原生验收。
