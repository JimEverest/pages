@echo off
setlocal DisableDelayedExpansion
rem Coagen kit r13 Windows entry (Linux/macOS: sh install.sh). Complete extracted kit only; never runs PowerShell.
if not exist "%~dp0coagen_install.py" goto installation_files_missing
set "coagenBootstrapEntryAttributes="
for %%F in ("%~dp0coagen_install.py") do set "coagenBootstrapEntryAttributes=%%~aF"
if not defined coagenBootstrapEntryAttributes goto installation_files_missing
if /i "%coagenBootstrapEntryAttributes:~0,1%"=="d" goto installation_files_missing
set "coagenBootstrapPython="
set "coagenBootstrapVersion="
if defined COAGEN_INSTALL_PYTHON (
  set "coagenBootstrapPython=%COAGEN_INSTALL_PYTHON%"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.7.5\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.7.5\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.7.4\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.7.4\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.7.3\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.7.3\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.7.2\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.7.2\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.7.1\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.7.1\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.7.0\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.7.0\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.6.0\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.6.0\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.5.0\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.5.0\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.4.2\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.4.2\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.4.1\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.4.1\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.4.0\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.4.0\Scripts\python.exe"
  goto probe
)
if exist "%LOCALAPPDATA%\Coagen\runtimes\0.3.1\Scripts\python.exe" (
  set "coagenBootstrapPython=%LOCALAPPDATA%\Coagen\runtimes\0.3.1\Scripts\python.exe"
  goto probe
)
for %%V in (3.14 3.13 3.12 3.11) do (
  py -%%V -I -X utf8 -c "import platform,struct,sys,sysconfig; assert platform.python_implementation()=='CPython' and struct.calcsize('P')==8 and sysconfig.get_platform()=='win-amd64' and not sysconfig.get_config_var('Py_GIL_DISABLED')" >nul 2>nul
  if not errorlevel 1 (
    set "coagenBootstrapVersion=%%V"
    goto launcher
  )
)
goto unavailable
:probe
if not exist "%coagenBootstrapPython%" goto unavailable
"%coagenBootstrapPython%" -I -X utf8 -c "import platform,struct,sys,sysconfig; assert platform.python_implementation()=='CPython' and (3,11)<=sys.version_info[:2]<=(3,14) and struct.calcsize('P')==8 and sysconfig.get_platform()=='win-amd64' and not sysconfig.get_config_var('Py_GIL_DISABLED')" >nul 2>nul
if errorlevel 1 goto unavailable
"%coagenBootstrapPython%" -I -X utf8 "%~dp0coagen_install.py" %*
exit /b %errorlevel%
:launcher
py -%coagenBootstrapVersion% -I -X utf8 "%~dp0coagen_install.py" %*
exit /b %errorlevel%
:unavailable
echo {"ok":false,"code":"PYTHON_UNAVAILABLE","stage":"bootstrap","retry_allowed":false,"next_action":"Select an existing Windows x64 CPython 3.11-3.14 using COAGEN_INSTALL_PYTHON, or run its python.exe -I -X utf8 coagen_install.py directly from the complete trusted kit. No policy was changed."}
exit /b 1
:installation_files_missing
echo {"ok":false,"status":"failed","code":"INSTALLATION_FILES_MISSING","stage":"bootstrap","retry_allowed":false,"next_action":"Verify the complete trusted release manifest and file inventory. Review normal security software notifications if files disappeared; do not infer malware or a false positive, re-extract, disable protection, or bypass security controls."}
exit /b 1
