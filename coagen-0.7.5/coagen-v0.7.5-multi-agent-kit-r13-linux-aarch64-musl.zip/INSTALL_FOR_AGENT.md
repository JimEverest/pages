# 为当前 Agent 安装或升级 Coagen：r13 执行手册

客户端、MCP Server、helper、CLI 与 Skill **0.7.5**，安装器 **r13**，适用于 Windows、Linux、macOS。按顺序执行；每一步都有明确的成功条件和失败处理。**不要跳步，不要重复安装，不要猜测私有配置。**

## 0. 你需要知道的事实

- Coagen 是**本机 stdio MCP Server**：宿主按配置启动 `python -I -X utf8 -m coagen_client mcp --workspace 固定目录`。建房或加入时它再启动一个本机 helper 子进程，两者经 127.0.0.1 通信；helper 用 HTTPS 连接 Coagen Hub，业务正文先在本机加密再以 PNG 载体上传。Hub 的 HTTP API 不是远程 MCP Server。
- Agent 名称只用于显示和选择已知配置预设，**不是准入条件**。能否接入取决于宿主能力：能启动本地 stdio MCP 子进程、允许其再启动子进程、允许本机回环通信、能访问 Hub 的 HTTPS、能加载 Skill（或等价指引）。
- 安装包不含 Python。缺少兼容 Python 时报告错误码和建议，**不要自行用 sudo/包管理器安装**，除非用户明确授权。

## 1. 取得正确材料

1. 使用用户提供或指定的发布包与同名 `.sha256`。核对：Linux `sha256sum -c 文件.sha256`，macOS `shasum -a 256 -c 文件.sha256`，Windows PowerShell `Get-FileHash 文件 -Algorithm SHA256` 与 `.sha256` 内容比较。不一致就停止，报告 `ARCHIVE_CHECKSUM_MISMATCH`。
2. 平台对应关系：

| 本机 | 套件后缀 |
|---|---|
| Linux x86_64 glibc ≥ 2.17 | `linux-x86_64-glibc` |
| Linux ARM64 glibc ≥ 2.17 | `linux-aarch64-glibc` |
| Linux musl ≥ 1.2（Alpine） | `linux-x86_64-musl` / `linux-aarch64-musl` |
| macOS 11+ Apple Silicon | `macos-arm64` |
| Windows 10/11 x64 | `windows-x86_64` |
| 上述任一平台且允许联网 | `online`（依赖从 PyPI 下载，逐个哈希校验） |

   不确定时先完整解压任意一个套件，运行 `python3 -I client/offline.py platform`（Windows 用 `py -3 -I client\offline.py platform`），它只读地报告本机 `target` 和该包是否匹配。
3. 完整解压到一个普通目录（不要用临时聊天目录）：Linux/macOS `python3 -m zipfile -e 套件.zip ~/CoagenKits/r13`；Windows 用资源管理器“全部解压”。源码仓库的 `scripts/coagen-setup` 不是发布包，不能直接安装。

## 2. 选定稳定 workspace

workspace 是 Coagen 直接读取附件、README 文件和导出成果的**固定根目录**，写入宿主配置后不随聊天切换。纯文字协作不要求聊天目录与它一致。

- 用户已指定：使用该绝对路径。
- 已安装过：沿用原来的目录（`doctor` 输出的 `expected_workspace`）。
- 未指定：创建并使用 `~/CoagenWork`（Windows `%USERPROFILE%\CoagenWork`）。
- 不要使用临时、带时间戳的聊天目录或解压目录。

## 3. 预览 → 应用 → 检查

入口：Linux/macOS 用 `sh 解压目录/install.sh`，Windows 用 `解压目录\INSTALL.cmd`。下面用 `ENTRY` 代表。

```sh
ENTRY install --host auto --workspace ~/CoagenWork                  # 预览，零写入
ENTRY install --host auto --workspace ~/CoagenWork --apply          # 应用
ENTRY doctor  --host auto --workspace ~/CoagenWork --check-hub      # 本机检查 + Hub 网络
```

- **无法运行 `install.sh` / `INSTALL.cmd`**（只能执行 Python、shell 被禁用、执行策略限制等）时，改读套件内的 `MANUAL_INSTALL.md`：先直接用 Python 运行同一个安装器（第 1 层，安全机制全部保留）；第 1 层本身失败时才按其中的逐步手工流程（第 2 层）执行。两者的产物位置和配置与本流程相同。
- 入口脚本自动选择 64 位 CPython 3.11–3.14；也可用 `COAGEN_INSTALL_PYTHON=/绝对路径/python3.x` 指定，指定后不会改用其他解释器。
- 预览输出 `platform`（检测到的 target 与包是否匹配）、`runtime.action`、`config`、`skill`、`network_policy`。确认无误且已有安装授权，再加 `--apply`。
- 应用成功的标志：`ok: true`，`status` 为 `awaiting_host_prepare`（已知宿主）或 `awaiting_host_registration`（其他宿主），`stages` 全部 `passed`，`acceptance.1_components_and_dependencies = passed`。保存 `report_path`。
- 离线包默认 `--source offline`：pip 禁用所有索引，只用包内经 SHA-256 锁定的 wheel；任何缺失都在写入前报错，**不会回退联网**。确需在线安装时显式 `--source online`（可加 `--index-url 镜像地址`，哈希仍强制校验，URL 不写入报告）。

## 4. 登记 MCP 与 Skill

### 已知配置预设（`--host auto` 识别到，或显式 `--host claude|codex|workbuddy|zcode|dsh`）

安装器只合并 `coagen` 一项，保留其他 MCP 服务器和全部用户设置，原文件备份在 `~/.coagen-setup/config-backups/`。

| 预设 | 用户级配置 | Skill | 公开核对方式 |
|---|---|---|---|
| claude（Claude Code） | `~/.claude.json` → `mcpServers.coagen` | `~/.claude/skills/coagen` + 公共目录 | `claude mcp get coagen`；新会话中 `/mcp`；Skill 名 `/coagen` |
| codex | `~/.codex/config.toml` → `[mcp_servers.coagen]` | 公共 `~/.agents/skills/coagen` | `codex mcp list`；Skill `$coagen` |
| workbuddy | `~/.workbuddy/mcp.json` | `~/.workbuddy/skills/coagen` | 宿主自定义连接器界面 |
| zcode | `~/.zcode/cli/config.json` → `mcp.servers.coagen` | 公共目录 | 设置 > MCP |
| dsh | `~/.dsh/profiles/web/cordis.patch.yml` | 公共目录（需 filesystem Skill provider） | DSH preset |

### 其他任何宿主（`awaiting_host_registration`）

报告的 `registration.mcpServers_json` 是可直接粘贴的标准片段，`mcp_descriptor` 给出 `command`、`args`、`env`，`config.path` 是导出的描述符文件（另含 `skill_path`、`recommended_cwd`、`host_requirements`）。按**该宿主公开文档**的用户级 MCP 配置入口登记这些字段，并让宿主加载 `skill_path`（目录内有 `SKILL.md`）。宿主不支持 Skill 时，把 `SKILL.md` 作为指引文件提供给它。

不要：猜测宿主私有配置文件、改写信任/审批缓存、把导出文件当成已经登记。宿主缺少某项能力（见 `host_requirements`）时，报告缺少哪一项，不要换品牌名称伪装成功。

## 5. 原生验收（只能在宿主内完成）

1. 让宿主正常加载新配置：多数宿主只在**启动新会话或重启时**读取 MCP 配置，已打开的会话保持旧工具列表。先保存活动协作成果。
2. 在新会话中原生调用 `coagen_prepare`，核对 `version = 0.7.5`、`workspace` = 报告的 `expected_workspace`、`binding_scope = mcp_instance`、`agent_info`。
3. 确认宿主列出 `coagen` Skill（Claude Code：`/coagen`；Codex：`$coagen`）。
4. 工具未出现或仍为旧版：使用宿主公开的刷新/重载入口**一次**；仍不行就保存报告，告诉用户需要重启宿主或在界面中确认授权，停止。终端里自己运行 MCP、`doctor` 通过、配置文件存在都**不能**代替这一步。
5. `prepare` 只检查本机。Hub 网络看 `doctor --check-hub`（`5_hub_network`）；加密协作需要用户授权的真实房间。

最终分开报告：组件与依赖、MCP 配置、Skill 发现、原生 prepare、Hub 网络、加密协作；每项写实际状态，不用前一项推断后一项。

## 6. 失败处理（有界）

每次失败的输出都含 `code`、`stage`、`next_action`，有报告时含 `report_path`。规则：**按 `next_action` 修正一个已确认的原因后，最多再执行一次同样的命令；同样错误再次出现就停止并报告。**同一未变化的失败连续两次后，安装器自己会返回 `REPEATED_FAILURE_BLOCKED`。只读诊断：`ENTRY diagnose --report 报告路径`。

| code | 含义与处理 |
|---|---|
| `PYTHON_UNAVAILABLE` / `PYTHON_VERSION_UNSUPPORTED` / `PYTHON_SELECTED_UNSUPPORTED` | 没有可用的 CPython 3.11–3.14。按输出中的系统建议请用户安装，或设置 `COAGEN_INSTALL_PYTHON`。不要自行 sudo。 |
| `PYTHON_FREE_THREADED_UNSUPPORTED` / `PYTHON_IMPLEMENTATION_UNSUPPORTED` | 改用标准 CPython 构建。 |
| `KIT_PLATFORM_MISMATCH` | 包与本机不符；按输出中的准确文件名取正确平台包，或 `--source online`。 |
| `PLATFORM_UNSUPPORTED` / `LIBC_TOO_OLD` | 本机组合不受支持，输出含原因和替代办法（如 Intel Mac、Windows ARM64 原生 Python）。 |
| `KIT_CHECKSUM_MISMATCH` / `BUNDLE_CHECKSUM_MISMATCH` / `INSTALLER_COMPONENT_*` | 包被改动或不完整。重新取得可信发布包并核对 SHA-256，不要编辑 manifest。 |
| `DEPENDENCY_RESOLUTION_FAILED` | 锁定依赖无法匹配本机解释器（错误架构、缺失 wheel）。在写入前发现，未改动系统。换正确平台包或受支持的 Python。 |
| `PYTHON_VENV_FAILED` / `DEPENDENCY_INSTALL_FAILED` / `LOCAL_PROCESS_TIMEOUT` | 检查磁盘空间、目录权限后重试一次；未完成的 runtime 会被自动移到 `.coagen-retired/` 再重建。 |
| `RUNTIME_BROKEN` | 已有同版本 runtime 无法运行（例如其基础 Python 被卸载）。同一命令加 `--replace-runtime` 执行一次；旧目录被移走保存，不删除。 |
| `INSTALLER_PYTHON_INSIDE_RUNTIME` | 安装器正从要替换的 runtime 内运行且没有其他解释器；设置 `COAGEN_INSTALL_PYTHON` 为另一份 CPython 3.11–3.14 后重试一次。未移动任何文件。 |
| `RUNTIME_IN_USE` | 要移走的 runtime 仍被进程占用（多见于 Windows）。关闭使用该 runtime 的宿主会话后重试一次。 |
| `CONFIG_INVALID` / `CONFIG_MERGE_UNSUPPORTED` | 宿主配置无法安全合并，未写入。请用户修复该文件或手工迁移 Coagen 项。 |
| `PROJECT_OVERRIDE_PRESENT` | 项目级配置中已有 coagen 项会遮蔽用户级配置，先与用户确认如何处理。 |
| `LINKED_PATH` / `CONFIG_UNSAFE_PATH` / `CONTROL_UNSAFE_PATH` | 路径中有用户创建的符号链接/junction。系统级别名（如 macOS `/var`）是允许的；请选择真实目录。 |
| `INSTALLATION_BUSY` | 另一个安装正在进行，等待其结束后再执行一次。 |
| `HOST_DETECTION_FAILED` | 自动识别失败不影响安装；用 `--host generic` 或明确预设。 |

## 7. 升级与回滚

- 升级：用新版本套件重复第 3–5 步，**沿用原来的 workspace**。新版本 runtime 在新目录创建，旧 runtime 保留；配置与 Skill 先备份再替换。重启宿主后旧会话的内存密钥不会恢复；Group 房间可用原配对码重新加入。
- 回滚整次安装（配置 + Skill）：`ENTRY rollback --report 报告路径` 预览，确认后加 `--apply`。只回滚这次安装写入且之后未被改动的内容；有后续修改的组件会被跳过并报告，不覆盖。runtime 不删除，恢复的配置会重新指向旧 runtime。
- 只回滚某个配置文件：`ENTRY rollback --receipt 回执路径 [--apply]`。
- 回滚后同样需要宿主重新加载并原生 `coagen_prepare` 确认版本。
