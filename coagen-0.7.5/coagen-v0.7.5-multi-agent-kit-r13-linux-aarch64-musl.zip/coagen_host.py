"""Versioned stdio host adapter for the Coagen 0.7.5 client.

Run with an isolated interpreter: python -I -X utf8 ABS/coagen_host.py ...
The owner is a validated native ancestor process, never an arbitrary node/shell.
One adapter instance has one collaboration context; host process scope is not
per-chat isolation. This file never terminates the host or operates a room.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import threading

try:
    import psutil
except ImportError:
    psutil = None

VERSION = 'r13'
CLIENT_VERSION = '0.7.5'
HOST_NAMES = {'workbuddy': 'workbuddy.exe', 'zcode': 'zcode.exe'}
ERRORS = {
    'INVALID_ARGUMENT': ('Invalid adapter arguments.', 'regenerate_host_configuration'),
    'INVALID_HOST_EXECUTABLE': ('Host executable identity is invalid.', 'verify_host_installation_path'),
    'INVALID_WORKSPACE': ('An existing absolute workspace is required.', 'select_authorized_workspace'),
    'ISOLATION_REQUIRED': ('The adapter requires -I -X utf8.', 'regenerate_host_configuration'),
    'RUNTIME_UNAVAILABLE': ('Required installed runtime dependencies are unavailable.', 'repair_versioned_runtime'),
    'CLIENT_VERSION_MISMATCH': ('The adapter requires Coagen client 0.7.5.', 'select_versioned_runtime'),
    'OWNER_NOT_FOUND': ('No matching native host ancestor was found.', 'start_mcp_from_configured_host'),
    'OWNER_AMBIGUOUS': ('More than one native owner matches this profile.', 'stop_and_review_host_profile'),
    'OWNER_UNVERIFIABLE': ('The native process ancestry cannot be verified.', 'stop_and_review_host_profile'),
    'OWNER_CHANGED': ('The captured host process exited or changed identity.', 'restart_from_host'),
    'ADAPTER_FAILED': ('The host adapter could not complete startup or protocol service.', 'inspect_adapter_and_runtime_versions'),
}


class AdapterError(ValueError):
    def __init__(self, code):
        self.code = code if code in ERRORS else 'ADAPTER_FAILED'
        super().__init__(ERRORS[self.code][0])

    def to_dict(self):
        message, action = ERRORS[self.code]
        return {'ok': False, 'source': 'coagen_host_adapter', 'adapter_version': VERSION,
                'code': self.code, 'message': message, 'action': action,
                'retryable': False}


def _path(value):
    return os.path.normcase(str(Path(value).resolve()))


@dataclass(frozen=True)
class OwnerIdentity:
    host: str
    pid: int
    started_at: float
    executable: str
    selection: str

    def alive(self):
        try:
            process = psutil.Process(self.pid)
            return (process.is_running() and process.status() not in ('zombie', 'dead')
                    and abs(process.create_time() - self.started_at) < 0.001
                    and _path(process.exe()) == _path(self.executable))
        except (psutil.Error, OSError, ValueError):
            return False

    def metadata(self):
        return {'version': VERSION, 'host': self.host, 'owner_scope': 'host_process',
                'owner_pid': self.pid, 'owner_started_at': self.started_at,
                'selection': self.selection}


def _engine_marker(host, executable, argv):
    """Match shipped entrypoints; never log argv or trust a script basename."""
    resources = Path(executable).parent / 'resources'
    if host == 'zcode':
        scripts = [resources / 'glm/zcode.cjs']
        if 'app-server' not in argv or '--stdio' not in argv:
            return False
    else:
        scripts = [resources / archive / suffix
                   for archive in ('app.asar', 'app.asar.unpacked')
                   for suffix in ('cli/bin/codebuddy', 'cli/dist/codebuddy-lite-wb.mjs',
                                  'cli/dist/codebuddy-headless.js')]
    allowed = {_path(item) for item in scripts}
    return any(isinstance(arg, str) and Path(arg).is_absolute() and _path(arg) in allowed
               for arg in argv)


def _controller_marker(host, executable, argv):
    """Match WorkBuddy's installed stdio daemon used by its MCP probe."""
    if host != 'workbuddy' or '--stdio' not in argv or len(argv) < 2:
        return False
    resources = Path(executable).parent / 'resources'
    allowed = {_path(resources / archive / 'main/daemon-app-server-entry.js')
               for archive in ('app.asar', 'app.asar.unpacked')}
    entrypoint = argv[1]
    return (isinstance(entrypoint, str) and Path(entrypoint).is_absolute()
            and _path(entrypoint) in allowed)


def resolve_owner(host, host_exe, *, start_pid=None):
    if psutil is None:
        raise AdapterError('RUNTIME_UNAVAILABLE')
    path = Path(host_exe)
    try:
        if not path.is_absolute() or not path.is_file():
            raise AdapterError('INVALID_HOST_EXECUTABLE')
        path = path.resolve(strict=True)
        if host not in HOST_NAMES or path.name.lower() != HOST_NAMES[host]:
            raise AdapterError('INVALID_HOST_EXECUTABLE')
    except OSError:
        raise AdapterError('INVALID_HOST_EXECUTABLE') from None
    pid = os.getpid() if start_pid is None else start_pid
    seen, chain, candidates = set(), [], []
    child_started = None
    try:
        while pid:
            if pid in seen or len(chain) >= 64:
                raise AdapterError('OWNER_UNVERIFIABLE')
            seen.add(pid)
            try:
                process = psutil.Process(pid)
                started, parent = process.create_time(), process.ppid()
            except psutil.NoSuchProcess:
                break  # An exited ancestor above the selected host is not its owner.
            if not process.is_running() or process.status() in ('zombie', 'dead'):
                raise AdapterError('OWNER_CHANGED')
            if child_started is not None and started > child_started + 0.001:
                break  # The saved PPID was reused; never cross this boundary.
            chain.append((pid, started, parent))
            if len(chain) > 1:
                try:
                    matching = _path(process.exe()) == _path(path)
                except psutil.AccessDenied:
                    matching = False
                if matching:
                    argv = process.cmdline()
                    selection = ('native_engine' if _engine_marker(host, path, argv)
                                 else 'native_controller' if _controller_marker(host, path, argv)
                                 else 'native_host')
                    candidates.append(OwnerIdentity(host, pid, started, str(path), selection))
            child_started, pid = started, parent
        engines = [item for item in candidates if item.selection == 'native_engine']
        controllers = [item for item in candidates if item.selection == 'native_controller']
        choices = engines or controllers or candidates
        if not choices:
            raise AdapterError('OWNER_NOT_FOUND')
        if len(choices) != 1:
            raise AdapterError('OWNER_AMBIGUOUS')
        owner = choices[0]
        # Recheck the complete path from this adapter to the selected owner.
        # A race must not turn a stale/reused PID into a valid new process.
        for pid, started, parent in chain:
            process = psutil.Process(pid)
            if (not process.is_running() or process.ppid() != parent
                    or abs(process.create_time() - started) >= 0.001):
                raise AdapterError('OWNER_CHANGED')
            if pid == owner.pid:
                break
        if not owner.alive():
            raise AdapterError('OWNER_CHANGED')
        return owner
    except psutil.NoSuchProcess:
        raise AdapterError('OWNER_CHANGED') from None
    except (psutil.Error, OSError, ValueError) as error:
        if isinstance(error, AdapterError):
            raise
        raise AdapterError('OWNER_UNVERIFIABLE') from None


def _client():
    try:
        if importlib.metadata.version('coagen-client') != CLIENT_VERSION:
            raise AdapterError('CLIENT_VERSION_MISMATCH')
        from coagen_client import mcp
        if mcp.cli.__version__ != CLIENT_VERSION:
            raise AdapterError('CLIENT_VERSION_MISMATCH')
        return mcp
    except ImportError:
        raise AdapterError('RUNTIME_UNAVAILABLE') from None
    except importlib.metadata.PackageNotFoundError:
        raise AdapterError('RUNTIME_UNAVAILABLE') from None


class HostServer:
    """Reuse the installed bridge, initializing its local storage lazily."""
    def __init__(self, owner, workspace, mcp):
        self.owner, self.workspace, self.mcp = owner, workspace, mcp
        self._server = None

    def _get_server(self):
        if not self.owner.alive():
            raise AdapterError('OWNER_CHANGED')
        if self._server is None:
            self._server = self.mcp.McpServer(workspace=self.workspace, owner_pid=self.owner.pid)
        return self._server

    @property
    def diagnostics(self):
        return self._get_server().diagnostics

    @property
    def minimum_log_level(self):
        return self._server.minimum_log_level if self._server is not None else 'notice'

    def poll_notifications(self):
        # Poll only an already initialized bridge. The owner watchdog exits this
        # adapter on owner loss; no helper or room is created by notification polling.
        if self._server is None or not self.owner.alive():
            return []
        return self._server.poll_notifications()

    def close(self):
        # EOF must reach the inner bridge's bounded helper cleanup even after
        # the external owner has exited. Do not initialize an unused bridge.
        if self._server is not None:
            self._server.close()

    def handle(self, request):
        if not self.owner.alive():
            return {'jsonrpc': '2.0', 'id': request.get('id'),
                    'error': {'code': -32000, 'message': ERRORS['OWNER_CHANGED'][0],
                              'data': AdapterError('OWNER_CHANGED').to_dict()}}
        # initialize, notifications/initialized and logging/setLevel now share
        # state with tool calls and notification polling in the same bridge.
        result = self._get_server().handle(request)
        if (request.get('method') == 'tools/call' and request.get('params', {}).get('name') == 'coagen_prepare'
                and result.get('result') and not result['result'].get('isError')):
            content = result['result']['content'][0]
            value = json.loads(content['text'])
            value['host_adapter'] = self.owner.metadata()
            content['text'] = json.dumps(value, ensure_ascii=False)
        return result


def _stderr(error):
    wire = (json.dumps(error.to_dict(), ensure_ascii=True) + '\n').encode('utf-8')
    if hasattr(sys.stderr, 'buffer'):
        sys.stderr.buffer.write(wire); sys.stderr.buffer.flush()
    else:
        sys.stderr.write(wire.decode('utf-8')); sys.stderr.flush()


def serve_bound(owner, workspace):
    mcp = _client()
    if not owner.alive():
        raise AdapterError('OWNER_CHANGED')
    done = threading.Event()

    def watchdog():
        while not done.wait(0.25):
            if not owner.alive():
                try:
                    _stderr(AdapterError('OWNER_CHANGED'))
                finally:
                    # Only this adapter exits. Avoid an uninterruptible stdin or
                    # network call keeping it alive after its real owner is gone.
                    # The existing session helper independently watches this owner.
                    os._exit(3)

    thread = threading.Thread(target=watchdog, daemon=True)
    thread.start()
    try:
        mcp.serve_stdio(HostServer(owner, workspace, mcp))
    finally:
        done.set()
        thread.join(timeout=1)


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise AdapterError('INVALID_ARGUMENT')


def main(argv=None):
    try:
        parser = Parser(description=__doc__)
        parser.add_argument('--host', required=True, choices=tuple(HOST_NAMES))
        parser.add_argument('--host-exe', required=True)
        parser.add_argument('--workspace', required=True)
        parser.add_argument('--diagnose', action='store_true')
        args = parser.parse_args(argv)
        if not sys.flags.isolated or not sys.flags.utf8_mode:
            raise AdapterError('ISOLATION_REQUIRED')
        workspace = Path(args.workspace)
        if not workspace.is_absolute() or not workspace.is_dir():
            raise AdapterError('INVALID_WORKSPACE')
        _client()
        owner = resolve_owner(args.host, args.host_exe)
        if args.diagnose:
            print(json.dumps({'ok': True, 'client_version': CLIENT_VERSION,
                              'host_adapter': owner.metadata()}, ensure_ascii=True))
        else:
            serve_bound(owner, workspace.resolve())
        return 0
    except AdapterError as error:
        _stderr(error)
        return 2
    except Exception:
        _stderr(AdapterError('ADAPTER_FAILED'))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
