"""Bounded installer coordination and metadata-only durable progress."""
from contextlib import contextmanager, ExitStack
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import uuid


def _load_platform():
    """Load the adjacent, manifest-verified platform module once."""
    import importlib.util
    module = sys.modules.get('coagen_platform')
    if module is None:
        spec = importlib.util.spec_from_file_location('coagen_platform', Path(__file__).resolve().parent / 'coagen_platform.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules['coagen_platform'] = module
    return module


platforms = _load_platform()


class ControlError(Exception):
    def __init__(self, code, **detail):
        self.report = {'ok': False, 'code': code, **detail}


def safe(path):
    for item in (*path.parents, path):
        if platforms.untrusted_link(item):
            raise ControlError('CONTROL_UNSAFE_PATH')
    if path.is_file() and path.stat().st_nlink != 1:
        raise ControlError('CONTROL_UNSAFE_PATH')


def _bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def _replace_report(stage, path):
    os.replace(stage, path)


def _save(path, value):
    safe(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    data = _bytes(value)
    stage = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    safe(stage)
    with stage.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    _replace_report(stage, path)
    if not path.is_file() or path.read_bytes() != data:
        raise ControlError('REPORT_WRITE_VERIFY_FAILED', preserved_stage=str(stage) if stage.exists() else None,
                           next_action='Stop this run and preserve the report directory; do not retry writes through private helpers.')


@contextmanager
def _file_lock(path, deadline):
    safe(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    acquired = False
    try:
        if os.fstat(fd).st_size == 0:
            os.write(fd, b'0')
        while True:
            os.lseek(fd, 0, os.SEEK_SET)
            try:
                if sys.platform == 'win32':
                    import msvcrt
                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise ControlError('INSTALLATION_BUSY', stage='lock',
                                       next_action='Another installer owns a shared resource. Wait for its report, then resume once; do not delete lock files.') from None
                time.sleep(min(0.1, max(0.001, deadline - time.monotonic())))
        yield
    finally:
        if acquired:
            os.lseek(fd, 0, os.SEEK_SET)
            if sys.platform == 'win32':
                import msvcrt
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


@contextmanager
def installation_lock(home, runtime=None, timeout=5):
    deadline = time.monotonic() + timeout
    paths = [Path(home) / '.coagen-setup/install.lock']
    if runtime is not None:
        runtime = Path(os.path.abspath(runtime))
        digest = hashlib.sha256(str(runtime).casefold().encode('utf-8')).hexdigest()[:24]
        paths.append(runtime.parent / ('.coagen-runtime-' + digest + '.lock'))
    with ExitStack() as stack:
        for path in paths:
            stack.enter_context(_file_lock(path, deadline))
        yield


def _failure_path(home, key):
    name = hashlib.sha256(key.encode('utf-8')).hexdigest() + '.json'
    return Path(home) / '.coagen-setup/failures' / name


def failure_state(home, key):
    path = _failure_path(home, key)
    safe(path)
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        if (not isinstance(value, dict) or type(value.get('attempts')) is not int or
                not 1 <= value['attempts'] <= 2 or not isinstance(value.get('fingerprint'), str)):
            raise ValueError()
        return value
    except (ValueError, OSError):
        raise ControlError('FAILURE_RECORD_INVALID', stage='recovery',
                           next_action='Preserve the malformed failure record and request installer maintenance; no write retry was allowed.') from None


def check_retry(home, key, fingerprint):
    value = failure_state(home, key)
    if value and value['fingerprint'] == fingerprint and value['attempts'] >= 2:
        raise ControlError('REPEATED_FAILURE_BLOCKED', stage='recovery', previous_code=value.get('code'),
                           previous_report=value.get('report_path'), retry_allowed=False,
                           next_action='The same unchanged installation failed twice. Run diagnose and stop; a confirmed local correction or a repaired kit is required.')


def record_failure(home, key, fingerprint, code, report_path):
    old = failure_state(home, key)
    count = min(2, old['attempts'] + 1) if old and old['fingerprint'] == fingerprint else 1
    value = {'fingerprint': fingerprint, 'attempts': count, 'code': code, 'report_path': str(report_path)}
    _save(_failure_path(home, key), value)
    return value


def clear_failure(home, key):
    path = _failure_path(home, key)
    safe(path)
    path.unlink(missing_ok=True)
    if path.exists():
        raise ControlError('FAILURE_RECORD_CLEAR_FAILED')


class RunReport:
    def __init__(self, home, initial):
        self.path = Path(home) / '.coagen-setup/reports' / uuid.uuid4().hex / 'report.json'
        self.started = time.monotonic()
        self.stage_started = None
        self.value = {**initial, 'report_path': str(self.path), 'stages': [],
                      'started_at': datetime.now(timezone.utc).isoformat()}
        self.save()

    def save(self):
        self.value['elapsed_ms'] = round((time.monotonic() - self.started) * 1000)
        _save(self.path, self.value)

    def begin(self, stage):
        self.stage_started = time.monotonic()
        event = {'stage': stage, 'status': 'running', 'started_at': datetime.now(timezone.utc).isoformat()}
        self.value['stages'].append(event)
        self.save()
        print(json.dumps({'event': 'stage', **event, 'report_path': str(self.path)}), file=sys.stderr, flush=True)

    def end(self, status, code=None):
        event = self.value['stages'][-1]
        event.update(status=status, elapsed_ms=round((time.monotonic() - self.stage_started) * 1000))
        if code:
            event['code'] = code
        self.save()
        print(json.dumps({'event': 'stage', **event}), file=sys.stderr, flush=True)

    def finish(self, result):
        self.value.update(result)
        self.save()
        return dict(self.value)
