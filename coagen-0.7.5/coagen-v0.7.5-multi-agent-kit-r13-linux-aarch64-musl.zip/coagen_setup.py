"""Inspect Coagen metadata, generate reviewable profiles, or install only its skill.

Python 3.11+, standard library only. No runtime installation, registration or rooms.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tomllib
import uuid
import unicodedata


def _load_platform():
    """Load the adjacent, manifest-verified platform module once."""
    import importlib.util
    module = sys.modules.get('coagen_platform')
    if module is None:
        spec = importlib.util.spec_from_file_location('coagen_platform', Path(__file__).resolve().parent / 'coagen_platform.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules['coagen_platform'] = module
    return module


platforms = _load_platform()

VERSION = '0.7.5'
AGENTS = ('codex', 'claude', 'workbuddy', 'zcode', 'dsh')  # Configuration presets, not an admission list.
OVERRIDES = ('CODEX_HOME', 'CLAUDE_CONFIG_DIR', 'WORKBUDDY_CONFIG_DIR', 'WORKBUDDY_INSTANCE_ID',
             'DSH_HOME', 'DSH_APPDATA', 'DSH_AGENTS_HOME', 'HOME')


class SetupError(Exception):
    def __init__(self, code, **details):
        self.report = {'ok': False, 'code': code, **details}


def require(condition, code):
    if not condition:
        raise SetupError(code)


def absolute(value):
    path = Path(value).expanduser()
    require(path.is_absolute(), 'ABSOLUTE_PATH_REQUIRED')
    return Path(os.path.abspath(path))


def linked(path):
    """Links and reparse points are refused, except root-owned system aliases."""
    return platforms.untrusted_link(path)


def safe(path, include_leaf=True):
    for item in (*path.parents, *((path,) if include_leaf else ())):
        require(not linked(item), 'LINKED_PATH')
    if include_leaf and path.is_file():
        require(path.stat().st_nlink == 1, 'LINKED_PATH')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def inventory(root):
    safe(root)
    require(root.is_dir(), 'EXPECTED_DIRECTORY')
    result = {}
    for base, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(base) / name
            safe(path)
            if name in files:
                require(path.is_file(), 'UNSUPPORTED_FILE')
                result[path.relative_to(root).as_posix()] = digest(path)
    return result


def verify(bundle):
    safe(bundle / 'manifest.json')
    manifest = json.loads((bundle / 'manifest.json').read_text(encoding='utf-8'))
    require(isinstance(manifest, dict) and manifest.get('version') == VERSION, 'BUNDLE_VERSION_MISMATCH')
    files = manifest.get('files')
    require(isinstance(files, dict) and files, 'INVALID_MANIFEST')
    seen = set()
    for name, expected in files.items():
        require(isinstance(name, str) and '\\' not in name and ':' not in name and
                not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and
                str(PurePosixPath(name)) == name and name not in ('', '.'), 'INVALID_MANIFEST_PATH')
        require(name.casefold() not in seen, 'INVALID_MANIFEST_PATH')
        seen.add(name.casefold())
        path = bundle / name
        safe(path)
        require(path.is_file(), 'BUNDLE_FILE_MISSING')
        require(isinstance(expected, str) and re.fullmatch('[a-f0-9]{64}', expected) is not None and
                digest(path) == expected, 'BUNDLE_CHECKSUM_MISMATCH')
    source = bundle / 'skills/coagen'
    contents = inventory(source)
    require('SKILL.md' in contents, 'SKILL_MISSING')
    require(all('skills/coagen/' + name in files for name in contents), 'UNLISTED_SKILL_FILE')
    return source, contents


def configs(home, workspace=None):
    paths = [('codex', home / '.codex/config.toml', 'mcp_servers'),
             ('claude', home / '.claude.json', 'mcpServers'),
             ('workbuddy', home / '.workbuddy/mcp.json', 'mcpServers'),
             ('zcode', home / '.zcode/cli/config.json', 'mcp.servers'),
             ('agents', home / '.agents/mcp.json', 'mcpServers'),
             ('dsh', home / '.dsh/cordis.patch.yml', None),
             ('dsh-web', home / '.dsh/profiles/web/cordis.patch.yml', None)]
    if workspace:
        paths += [('codex-project', workspace / '.codex/config.toml', 'mcp_servers'),
                  ('claude-project', workspace / '.mcp.json', 'mcpServers'),
                  ('claude-local', home / '.claude.json', 'mcpServers'),
                  ('workbuddy-project', workspace / '.workbuddy/mcp.json', 'mcpServers'),
                  ('zcode-project', workspace / '.zcode/config.json', 'mcp.servers'),
                  ('zcode-project-legacy', workspace / 'zcode.json', 'mcp.servers'),
                  ('agents-project', workspace / '.agents/mcp.json', 'mcpServers')]
    return paths


def override_names():
    return [key for key in OVERRIDES if os.environ.get(key) and (key != 'HOME' or sys.platform == 'win32')]


def blocking_overrides(home, agents):
    expected = {'CODEX_HOME': ('codex', home / '.codex'), 'CLAUDE_CONFIG_DIR': ('claude', home / '.claude'),
                'WORKBUDDY_CONFIG_DIR': ('workbuddy', home / '.workbuddy'),
                'WORKBUDDY_INSTANCE_ID': ('workbuddy', None), 'DSH_HOME': ('dsh', home / '.dsh'),
                'DSH_APPDATA': ('dsh', None), 'DSH_AGENTS_HOME': ('dsh', home / '.agents'), 'HOME': (None, home)}
    return [key for key in override_names() if (expected[key][0] is None or expected[key][0] in agents) and
            (expected[key][1] is None or Path(os.path.abspath(os.environ[key])) != expected[key][1])]


def inspect(home, workspace):
    result = {'ok': True, 'skills': [], 'configs': [], 'root_overrides': override_names()}
    canonical = home / '.agents/skills/coagen'
    for root in ('.agents', '.claude', '.workbuddy', '.zcode', '.codex', '.dsh'):
        path = home / root / 'skills/coagen'
        row = {'path': str(path), 'exists': path.exists() or linked(path), 'linked': linked(path)}
        try:
            safe(path, include_leaf=False)
            actual = path
            if linked(path):
                row['target'] = str(path.resolve())
                safe(canonical)
                require(path != canonical and path.resolve() == canonical.resolve(), 'LINKED_PATH')
                actual = canonical
                row['status'] = 'linked_to_canonical'
            safe(actual)
            if actual.exists():
                files = inventory(actual)
                row['sha256'] = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
                with (actual / 'SKILL.md').open(encoding='utf-8') as stream:
                    match = re.search(r'(?<!\d)\d+\.\d+\.\d+(?!\d)', stream.read(16384))
                row['version'] = match.group() if match else None
        except (SetupError, OSError, ValueError):
            row['status'] = 'not_read_unsafe_or_invalid'
        result['skills'].append(row)
    for agent, path, key in configs(home, workspace):
        row = {'agent': agent, 'path': str(path), 'exists': path.exists() or linked(path), 'coagen_present': None}
        try:
            safe(path)
            if path.exists() and key:
                value = tomllib.loads(path.read_text(encoding='utf-8')) if path.suffix == '.toml' else json.loads(path.read_text(encoding='utf-8-sig'))
                if agent == 'claude-local':
                    projects = value.get('projects', {}) if isinstance(value, dict) else {}
                    matches = [projects.get(name, {}) for name in (str(workspace), workspace.as_posix())] if isinstance(projects, dict) else []
                    row['coagen_present'] = any(isinstance(item, dict) and isinstance(item.get('mcpServers'), dict)
                                               and 'coagen' in item['mcpServers'] for item in matches)
                    result['configs'].append(row)
                    continue
                for part in key.split('.'):
                    value = value.get(part, {}) if isinstance(value, dict) else {}
                row['coagen_present'] = isinstance(value, dict) and 'coagen' in value
            elif path.exists():
                row['status'] = 'yaml_opaque_not_evaluated'
        except (SetupError, OSError, ValueError):
            row['status'] = 'not_read_unsafe_or_invalid'
        result['configs'].append(row)
    return result


def json_text(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def dsh_fragment(base, workspace):
    lines = ['- insert:', '    - id: mcp-coagen', '      name: "@deepseek-ai/dsh-mcp-client"',
             '      config:', '        serverName: coagen', '        transport: stdio',
             '        command: ' + json.dumps(base['command'], ensure_ascii=False), '        args:']
    lines += ['          - ' + json.dumps(x, ensure_ascii=False) for x in base['args']]
    if base.get('env'):
        lines += ['        env:']
        lines += ['          ' + json.dumps(key) + ': ' + json.dumps(value, ensure_ascii=False)
                  for key, value in base['env'].items()]
    lines += ['        cwd: ' + json.dumps(str(workspace), ensure_ascii=False),
              '        toolCallTimeoutMs: 90000', '        failOnStartupError: true',
              '        reconnect:', '          enabled: false']
    return '\n'.join(lines) + '\n'


def plan(args):
    base = {'type': 'stdio', 'command': str(args.python), 'args': ['-I', '-X', 'utf8', '-m', 'coagen_client', 'mcp', '--workspace', str(args.workspace)]}
    result = {'ok': True, 'version': VERSION, 'profiles': {}, 'registration_performed': False,
              'root_overrides': override_names()}
    targets = {agent: str(path) for agent, path, _ in configs(args.home)}
    targets['dsh'] = str(args.home / '.dsh/profiles/web/cordis.patch.yml')
    outputs = {}
    for agent in args.agents:
        known = agent in AGENTS
        name = agent + '.mcp.json' if known else 'generic-' + hashlib.sha256(agent.encode('utf-8')).hexdigest()[:24] + '.mcp.json'
        profile = {'status': 'candidate_pending_host_acceptance', 'merge_target': targets.get(agent)}
        if agent == 'codex':
            name = 'codex.mcp.toml'
            outputs[name] = '[mcp_servers.coagen]\ncommand = ' + json.dumps(base['command'], ensure_ascii=False) + '\nargs = ' + json.dumps(base['args'], ensure_ascii=False) + '\nstartup_timeout_sec = 20\ntool_timeout_sec = 90\n'
        elif agent == 'dsh':
            name = 'coagen.dsh.patch.yml'
            profile.update(status='candidate_pending_host_acceptance',
                           context_isolation='one_context_per_mcp_instance',
                           skill_provider='standard_or_ptc; minimal_requires_explicit_provider')
            outputs[name] = dsh_fragment(base, args.workspace)
        elif agent == 'zcode':
            outputs[name] = json_text({'mcp': {'servers': {'coagen': {**base, 'enabled': False, 'timeoutMs': 90000, 'protocolVersion': 'legacy'}}}})
        elif known:
            outputs[name] = json_text({'mcpServers': {'coagen': base}})
        else:
            profile['status'] = 'exported_pending_registration'
            outputs[name] = json_text({**base, 'env': {'COAGEN_AGENT_NAME': agent},
                                      'skill_path': str(args.home / '.agents/skills/coagen'),
                                      'registration': 'not_performed'})
        profile['fragment'] = name
        result['profiles'][agent] = profile
    outputs['plan.json'] = json_text(result)
    safe(args.out)
    for name, content in outputs.items():
        path = args.out / name
        safe(path)
        require(not path.exists() or path.read_text(encoding='utf-8') == content, 'OUTPUT_ALREADY_EXISTS')
    args.out.mkdir(parents=True, exist_ok=True)
    for name, content in outputs.items():
        (args.out / name).write_text(content, encoding='utf-8')
    return result


def junction(source, target):
    require(sys.platform == 'win32', 'JUNCTION_UNAVAILABLE_USE_COPY_EXPLICITLY')
    safe(source)
    env = dict(os.environ, COAGEN_SETUP_LINK=str(target), COAGEN_SETUP_TARGET=str(source))
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
        'New-Item -ItemType Junction -Path $env:COAGEN_SETUP_LINK -Target $env:COAGEN_SETUP_TARGET -ErrorAction Stop | Out-Null'],
        env=env, capture_output=True, timeout=20, creationflags=subprocess.CREATE_NO_WINDOW)
    require(result.returncode == 0 and linked(target) and target.resolve() == source.resolve(), 'JUNCTION_FAILED_USE_COPY_EXPLICITLY')


def skills(args):
    source, expected = verify(args.bundle)
    require(not blocking_overrides(args.home, args.agents), 'ROOT_OVERRIDE_REQUIRES_EXPLICIT_ADAPTER')
    require(args.mode != 'junction' or sys.platform == 'win32', 'JUNCTION_UNAVAILABLE_USE_COPY_EXPLICITLY')
    canonical = args.home / '.agents/skills/coagen'
    targets = [canonical]
    targets += [args.home / ('.' + agent) / 'skills/coagen' for agent in ('claude', 'workbuddy') if agent in args.agents]
    targets += [args.home / ('.' + agent) / 'skills/coagen' for agent in ('codex', 'zcode', 'dsh')
                if agent in args.agents and os.path.lexists(args.home / ('.' + agent) / 'skills/coagen')]
    storage = args.home / '.coagen-setup'
    for name in ('backups', 'staging'):
        safe(storage / name)
    actions = []
    for target in targets:
        safe(target, include_leaf=False)
        mode = 'copy' if target == canonical else args.mode
        link = linked(target)
        require(not link or (target != canonical and target.resolve() == canonical.resolve()), 'LINKED_PATH')
        same = link and mode == 'junction'
        if target.exists() and not link:
            same = inventory(target) == expected and mode == 'copy'
        actions.append({'target': str(target), 'mode': mode, 'status': 'unchanged' if same else 'pending',
                        'action': 'unchanged' if same else 'replace' if os.path.lexists(target) else 'create'})
    result = {'ok': True, 'version': VERSION, 'verified': True, 'applied': args.apply, 'actions': actions}
    if not args.apply:
        return result
    for action in actions:
        if action['action'] == 'unchanged':
            continue
        target = Path(action['target'])
        identity = uuid.uuid4().hex
        host = target.relative_to(args.home).parts[0].lstrip('.')
        stage = storage / 'staging' / identity / host / 'coagen'
        backup = None
        try:
            safe(target, include_leaf=not linked(target))
            safe(stage)
            target.parent.mkdir(parents=True, exist_ok=True)
            stage.parent.mkdir(parents=True, exist_ok=True)
            if action['mode'] == 'copy':
                shutil.copytree(source, stage)
                require(inventory(stage) == expected, 'STAGED_COPY_MISMATCH')
            else:
                junction(canonical, stage)
            if os.path.lexists(target):
                backup = storage / 'backups' / identity / host / 'coagen'
                safe(backup)
                backup.parent.mkdir(parents=True, exist_ok=True)
                target.rename(backup)
            stage.rename(target)
            action['status'] = 'applied'
            if backup:
                action['backup'] = str(backup)
        except (OSError, SetupError, subprocess.SubprocessError):
            action['status'] = 'failed'
            if backup and not os.path.lexists(target):
                action['backup'] = str(backup)
                try:
                    backup.rename(target)
                    action['restored'] = True
                except OSError:
                    action['restored'] = False
            raise SetupError('SKILL_APPLY_FAILED', actions=actions, failed_target=str(target), preserved_stage=str(stage)) from None
    return result


def agent_names(value):
    names = list(dict.fromkeys(x.strip() for x in value.split(',')))
    require(names and all(0 < len(x) <= 128 and all(unicodedata.category(ch) not in ('Cc', 'Cs') for ch in x)
                         for x in names), 'INVALID_AGENT_NAME')
    names = [x.lower() if x.lower() in AGENTS else x for x in names]
    return names


def main(argv=None):
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('inspect', 'plan', 'skills'):
        sub = commands.add_parser(name)
        sub.add_argument('--home', type=absolute, default=Path.home() if name == 'inspect' else None, required=name != 'inspect')
        if name != 'skills':
            sub.add_argument('--workspace', type=absolute, required=name == 'plan')
        if name != 'inspect':
            sub.add_argument('--agents', type=agent_names, required=True)
        if name == 'plan':
            sub.add_argument('--python', type=absolute, required=True)
            sub.add_argument('--out', type=absolute, required=True)
        if name == 'skills':
            sub.add_argument('--bundle', type=absolute, required=True)
            sub.add_argument('--mode', choices=('copy', 'junction'), default='copy')
            sub.add_argument('--apply', action='store_true')
    try:
        args = parser.parse_args(argv)
        result = inspect(args.home, args.workspace) if args.command == 'inspect' else plan(args) if args.command == 'plan' else skills(args)
    except SetupError as error:
        result = error.report
    except (OSError, ValueError, subprocess.SubprocessError):
        result = {'ok': False, 'code': 'LOCAL_INPUT_OR_IO_ERROR'}
    print(json_text(result), end='')
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
