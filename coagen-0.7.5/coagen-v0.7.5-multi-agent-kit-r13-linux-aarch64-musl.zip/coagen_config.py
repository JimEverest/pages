"""Controlled MCP config merges. Pure stdlib; never evaluates YAML or prints values."""
import copy
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tomllib
import uuid


def _load_platform():
    """Load the adjacent, manifest-verified platform module once."""
    import importlib.util
    module = sys.modules.get('coagen_platform')
    if module is None:
        spec = importlib.util.spec_from_file_location('coagen_platform', Path(__file__).resolve().parent / 'coagen_platform.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules['coagen_platform'] = module
    return module


platforms = _load_platform()

PATHS = {'codex': '.codex/config.toml', 'claude': '.claude.json',
         'workbuddy': '.workbuddy/mcp.json', 'zcode': '.zcode/cli/config.json',
         'dsh': '.dsh/profiles/web/cordis.patch.yml'}
BEGIN = '# BEGIN COAGEN MANAGED MCP'
END = '# END COAGEN MANAGED MCP'


class ConfigError(Exception):
    def __init__(self, code, action='Resolve the reported local condition, then generate a new preview.'):
        self.report = {'ok': False, 'code': code, 'next_action': action}


def _require(condition, code, action=None):
    if not condition:
        raise ConfigError(code, action) if action else ConfigError(code)


def config_path(home: Path, host: str) -> Path:
    home = Path(home)
    export = isinstance(host, str) and re.fullmatch(r'export-[0-9a-f]{64}', host) is not None
    _require(home.is_absolute() and (host in PATHS or export), 'CONFIG_ARGUMENT_INVALID')
    if export:
        return Path(os.path.abspath(home)) / '.coagen-setup/exports/r9' / host[7:] / 'coagen-mcp.json'
    return Path(os.path.abspath(home)) / PATHS[host]


def _linked(path):
    return platforms.untrusted_link(path)


def _safe(path):
    for item in (*path.parents, path):
        _require(not _linked(item), 'CONFIG_UNSAFE_PATH')
    if path.exists():
        _require(path.is_file() and path.stat().st_nlink == 1, 'CONFIG_UNSAFE_PATH')


def _hash(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def _read(path):
    _safe(path)
    return path.read_bytes() if path.exists() else None


def _object(pairs):
    result = {}
    for key, value in pairs:
        _require(key not in result, 'CONFIG_DUPLICATE_KEY')
        result[key] = value
    return result


def _json(data):
    def invalid(_):
        raise ConfigError('CONFIG_INVALID')
    return json.loads(data, object_pairs_hook=_object, parse_constant=invalid)


def _json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def _toml_value(value):
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, int) or isinstance(value, float) and math.isfinite(value):
        return repr(value)
    if isinstance(value, list):
        return '[' + ', '.join(_toml_value(item) for item in value) + ']'
    if isinstance(value, dict) and all(isinstance(k, str) for k in value):
        return '{' + ', '.join(_toml_value(k) + ' = ' + _toml_value(v) for k, v in value.items()) + '}'
    raise ConfigError('CONFIG_ENTRY_INVALID')


def _without_coagen(value):
    value = copy.deepcopy(value)
    servers = value.get('mcp_servers', {})
    _require(isinstance(servers, dict), 'CONFIG_MERGE_UNSUPPORTED')
    servers.pop('coagen', None)
    if not servers:
        value.pop('mcp_servers', None)
    return value


def _section_path(line):
    probe = tomllib.loads(line + '\n__coagen_probe__ = true\n')
    parts = []
    while isinstance(probe, dict) and len(probe) == 1:
        key, probe = next(iter(probe.items()))
        if key == '__coagen_probe__':
            return tuple(parts)
        parts.append(key)
    return None


def _merge_toml(text, entry):
    before = tomllib.loads(text)
    _without_coagen(before)
    if before.get('mcp_servers', {}).get('coagen') == entry:
        return text
    lines = text.splitlines(keepends=True)
    headers = []
    for index, line in enumerate(lines):
        if re.match(r'^\s*\[.+\]\s*(?:#.*)?$', line.rstrip('\r\n')):
            headers.append((index, _section_path(line.rstrip('\r\n'))))
    spans = {start: headers[i + 1][0] if i + 1 < len(headers) else len(lines)
             for i, (start, parts) in enumerate(headers) if parts and parts[:2] == ('mcp_servers', 'coagen')}
    _require(spans or 'coagen' not in before.get('mcp_servers', {}), 'CONFIG_MERGE_UNSUPPORTED',
             'Convert only the Coagen inline or dotted definition to an explicit [mcp_servers.coagen] table, then retry.')
    newline = '\r\n' if '\r\n' in text else '\n'
    replacement = '[mcp_servers.coagen]' + newline + ''.join(
        _toml_value(key) + ' = ' + _toml_value(value) + newline for key, value in entry.items())
    pieces, index, inserted = [], 0, False
    while index < len(lines):
        if index in spans:
            if not inserted:
                pieces.append(replacement)
                inserted = True
            pieces.extend(line for line in lines[index + 1:spans[index]] if not line.strip() or line.lstrip().startswith('#'))
            index = spans[index]
        else:
            pieces.append(lines[index])
            index += 1
    if not inserted:
        pieces.extend([newline if text and not text.endswith(('\r', '\n')) else '', newline, replacement])
    merged = ''.join(pieces)
    after = tomllib.loads(merged)
    _require(after.get('mcp_servers', {}).get('coagen') == entry and
             _without_coagen(after) == _without_coagen(before), 'CONFIG_MERGE_UNSUPPORTED')
    return merged


def _merge_yaml(text, entry):
    patch = entry.get('patch')
    _require(isinstance(patch, str) and patch.lstrip().startswith('- insert:') and
             BEGIN not in patch and END not in patch and '\0' not in patch, 'CONFIG_ENTRY_INVALID')
    newline = '\r\n' if '\r\n' in text else '\n'
    body = patch.replace('\r\n', '\n').rstrip('\n').replace('\n', newline)
    block = BEGIN + newline + body + newline + END + newline
    lines = text.splitlines(keepends=True)
    starts = [i for i, line in enumerate(lines) if line.rstrip('\r\n') == BEGIN]
    ends = [i for i, line in enumerate(lines) if line.rstrip('\r\n') == END]
    if starts or ends:
        _require(len(starts) == len(ends) == 1 and starts[0] < ends[0], 'CONFIG_MERGE_UNSUPPORTED')
        return ''.join(lines[:starts[0]]) + block + ''.join(lines[ends[0] + 1:])
    material = ''.join(line.strip() for line in lines if line.strip() and not line.lstrip().startswith('#'))
    _require(material in ('', '[]'), 'CONFIG_MERGE_UNSUPPORTED',
             'Use an empty or [] DSH Web profile patch file, or manually migrate the existing YAML and add the reviewed Coagen marker block; no YAML was evaluated or rewritten.')
    comments = ''.join(line for line in lines if line.lstrip().startswith('#'))
    return comments + (newline if comments and not comments.endswith(('\r', '\n')) else '') + block


def _merge(host, old, entry):
    _require(isinstance(entry, dict) and entry and all(isinstance(k, str) for k in entry), 'CONFIG_ENTRY_INVALID')
    _json_bytes(entry)
    text = (old or b'').decode('utf-8-sig')
    if host.startswith('export-'):
        # Only installer-owned hashed export paths use whole-document writes.
        # This never guesses or overwrites an unknown Agent's configuration.
        return _json_bytes(entry)
    bom = b'\xef\xbb\xbf' if old and old.startswith(b'\xef\xbb\xbf') else b''
    if host == 'codex':
        return bom + _merge_toml(text, entry).encode('utf-8')
    if host == 'dsh':
        return bom + _merge_yaml(text, entry).encode('utf-8')
    value = _json(text) if old is not None else {}
    _require(isinstance(value, dict), 'CONFIG_INVALID')
    root = value
    for key in (('mcp', 'servers') if host == 'zcode' else ('mcpServers',)):
        root = root.setdefault(key, {})
        _require(isinstance(root, dict), 'CONFIG_MERGE_UNSUPPORTED')
    if root.get('coagen') == entry:
        return old
    root['coagen'] = copy.deepcopy(entry)
    return bom + _json_bytes(value)


def _write_exclusive(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def _observation(path, expected, previous):
    result = {'expected_sha256': expected, 'observed_sha256': None}
    try:
        data = _read(path)
    except (ConfigError, OSError) as error:
        return {**result, 'observed_state': 'unsafe' if isinstance(error, ConfigError) else 'unreadable',
                'write_state': 'unknown'}
    actual = _hash(data)
    state = 'verified' if actual == expected else 'unchanged' if actual == previous else 'unexpected'
    return {**result, 'observed_sha256': actual, 'observed_state': 'absent' if data is None else 'present',
            'write_state': state}


def _verify(path, expected, previous, stage, code='CONFIG_WRITE_VERIFY_FAILED'):
    observed = _observation(path, expected, previous)
    if observed['write_state'] != 'verified':
        error = ConfigError('CONFIG_WRITE_VERIFY_UNAVAILABLE' if observed['write_state'] == 'unknown' else code,
                            'Stop this stage. Preserve the receipt and staged evidence; review the reported hashes and local file access. Do not retry or switch write methods automatically.')
        error.report.update(observed, stage=stage)
        raise error
    return observed


def _io_error(stage, error):
    result = ConfigError('CONFIG_ATOMIC_WRITE_FAILED',
                         'Stop this stage and preserve the receipt and staged evidence. Review local file access; no fallback write was attempted.')
    result.report['stage'] = stage
    if isinstance(getattr(error, 'winerror', None), int):
        result.report['win32_error'] = error.winerror
    elif isinstance(getattr(error, 'errno', None), int):
        result.report['os_error'] = error.errno
    return result


def _preserve_stage(stage, data, report):
    """Keep evidence in the already private run directory, never at the target."""
    try:
        _safe(stage)
        if not stage.exists():
            _write_exclusive(stage, data)
        # Retain corrupted stages too: their bytes are useful evidence, not a retry payload.
        if stage.exists():
            _safe(stage)
            report['preserved_stage'] = str(stage)
            report['preserved_stage_sha256'] = _hash(_read(stage))
        else:
            report['evidence_preservation_failed'] = True
    except (OSError, ConfigError):
        report['evidence_preservation_failed'] = True


def _state_fields(state, restored=False):
    value = True if state == 'verified' else False if state in ('not_attempted', 'unchanged') else None
    return {'configuration_restored' if restored else 'configuration_written': value,
            'configuration_restore_state' if restored else 'configuration_write_state': state}


def _private_directory(path):
    for parent in (*path.parents, path):
        _require(not _linked(parent), 'CONFIG_UNSAFE_PATH')
    path.mkdir(parents=True, mode=0o700)
    if sys.platform != 'win32':
        path.chmod(0o700)
        return
    system = Path(os.environ.get('SystemRoot', 'C:/Windows')) / 'System32'
    flags = {'capture_output': True, 'timeout': 15, 'creationflags': subprocess.CREATE_NO_WINDOW}
    identity = subprocess.run([str(system / 'whoami.exe'), '/user', '/fo', 'csv', '/nh'], **flags)
    sid = re.search(rb'S-1-5-(?:\d+-)*\d+', identity.stdout)
    _require(identity.returncode == 0 and sid is not None, 'CONFIG_BACKUP_PERMISSION_FAILED')
    grants = [f'*{sid.group().decode()}:(OI)(CI)F', '*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F']
    secured = subprocess.run([str(system / 'icacls.exe'), str(path), '/inheritance:r', '/grant:r', *grants], **flags)
    _require(secured.returncode == 0, 'CONFIG_BACKUP_PERMISSION_FAILED')


def _backup(home, host, path, old, new):
    run = home / '.coagen-setup/config-backups' / uuid.uuid4().hex
    backup = run / 'original.bin' if old is not None else None
    receipt = run / 'receipt.json'
    metadata = {'format': 1, 'host': host, 'config_path': str(path), 'existed': old is not None,
                'original_sha256': _hash(old), 'written_sha256': _hash(new),
                'backup_file': str(backup) if backup else None, 'status': 'prepared'}
    stage = 'backup_prepare_write'
    try:
        _private_directory(run)
        if backup:
            _write_exclusive(backup, old)
            _verify(backup, _hash(old), None, 'backup_prepare_verify')
        stage = 'receipt_prepare_write'
        content = _json_bytes(metadata)
        _write_exclusive(receipt, content)
        _verify(receipt, _hash(content), None, 'receipt_prepare_verify')
    except (ConfigError, OSError) as error:
        error = error if isinstance(error, ConfigError) else _io_error(stage, error)
        error.report.setdefault('stage', stage)
        error.report['receipt'] = str(receipt)
        raise error
    return receipt, metadata


def _win_require(success, code, operation):
    if not success:
        error = ConfigError(code, 'Stop this stage and preserve the receipt. Review the Windows error code and file permissions; no fallback was attempted.')
        error.report.update(win32_operation=operation, win32_error=ctypes.get_last_error())
        raise error


def _windows_replace(path, stage):
    security = ctypes.WinDLL('advapi32', use_last_error=True)
    get = security.GetFileSecurityW
    get.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong,
                    ctypes.POINTER(ctypes.c_ulong)]
    get.restype = ctypes.c_int
    size = ctypes.c_ulong()
    get(str(path), 4, None, 0, ctypes.byref(size))
    _win_require(size.value > 0, 'CONFIG_PERMISSION_READ_FAILED', 'GetFileSecurityW')
    original = ctypes.create_string_buffer(size.value)
    _win_require(bool(get(str(path), 4, original, size, ctypes.byref(size))), 'CONFIG_PERMISSION_READ_FAILED', 'GetFileSecurityW')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    replace = kernel.ReplaceFileW
    replace.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p,
                        ctypes.c_ulong, ctypes.c_void_p, ctypes.c_void_p]
    replace.restype = ctypes.c_int
    _win_require(bool(replace(str(path), str(stage), None, 0, None, None)), 'CONFIG_ATOMIC_REPLACE_FAILED', 'ReplaceFileW')
    # ReplaceFile can add inherited staging ACEs. Restore the exact original DACL.
    restore = security.SetFileSecurityW
    restore.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_void_p]
    restore.restype = ctypes.c_int
    _win_require(bool(restore(str(path), 4, original)), 'CONFIG_PERMISSION_RESTORE_FAILED', 'SetFileSecurityW')


def _posix_replace(path, stage):
    """Replace path with stage, keeping the original permission bits."""
    stage.chmod(stat.S_IMODE(path.stat().st_mode))
    os.replace(stage, path)


def _atomic(path, data, expected, conflict='CONFIG_CHANGED_DURING_WRITE', stage_dir=None, label='config'):
    _safe(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    stage = (stage_dir or path.parent) / ('.' + path.name + '.coagen-' + uuid.uuid4().hex + '.tmp')
    _safe(stage)
    attempted = False
    phase = label + '_stage_write'
    try:
        _write_exclusive(stage, data)
        _verify(stage, _hash(data), None, label + '_stage_verify', 'CONFIG_STAGE_VERIFY_FAILED')
        phase = label + '_write'
        _require(_hash(_read(path)) == expected, conflict)
        attempted = True
        if expected is None:
            try:
                os.link(stage, path)
            except FileExistsError:
                raise ConfigError(conflict) from None
            # A newly linked destination temporarily has two links. Remove only
            # our own same-file stage before the normal anti-hardlink read check.
            if path.exists() and stage.exists() and not _linked(path) and not _linked(stage) and os.path.samestat(path.stat(), stage.stat()):
                stage.unlink()
        elif sys.platform == 'win32':
            _windows_replace(path, stage)
        else:
            _posix_replace(path, stage)
        phase = label + '_verify'
        observed = _verify(path, _hash(data), expected, phase)
        if stage.exists() and not _linked(stage):
            stage.unlink()
        return observed
    except (ConfigError, OSError) as error:
        error = error if isinstance(error, ConfigError) else _io_error(phase, error)
        error.report.setdefault('stage', phase)
        if attempted:
            if 'observed_state' not in error.report:
                error.report.update(_observation(path, _hash(data), expected))
        else:
            if 'observed_state' not in error.report:
                error.report.update(_observation(path, _hash(data), expected))
            error.report['write_state'] = 'not_attempted'
        error.report['write_attempted'] = attempted
        _preserve_stage(stage, data, error.report)
        raise error


def _remove(path, expected):
    attempted = False
    phase = 'rollback_write'
    try:
        _require(_hash(_read(path)) == expected, 'CONFIG_CHANGED_SINCE_WRITE')
        attempted = True
        path.unlink()
        phase = 'rollback_verify'
        return _verify(path, None, expected, phase)
    except (ConfigError, OSError) as error:
        error = error if isinstance(error, ConfigError) else _io_error(phase, error)
        error.report.setdefault('stage', phase)
        if attempted and 'observed_state' not in error.report:
            error.report.update(_observation(path, None, expected))
        elif not attempted:
            error.report.update(_observation(path, None, expected))
            error.report['write_state'] = 'not_attempted'
        error.report['write_attempted'] = attempted
        raise error


def configure(home: Path, host: str, entry: dict, apply=False) -> dict:
    receipt = None
    state = 'not_attempted'
    phase = 'preflight'
    try:
        path = config_path(home, host)
        home = Path(os.path.abspath(home))
        old = _read(path)
        new = _merge(host, old, entry)
        result = {'ok': True, 'host': host, 'path': str(path), 'status': 'unchanged' if old == new else 'planned',
                  'original_sha256': _hash(old), 'written_sha256': _hash(new)}
        if old == new or not apply:
            return result
        receipt, metadata = _backup(home, host, path, old, new)
        phase = 'config_write'
        _atomic(path, new, _hash(old), stage_dir=receipt.parent)
        state = 'verified'
        phase = 'receipt_write'
        saved = _json_bytes(metadata)
        metadata['status'] = 'applied'
        _atomic(receipt, _json_bytes(metadata), _hash(saved), label='receipt')
        return {**result, 'status': 'applied', 'receipt': str(receipt), **_state_fields(state)}
    except ConfigError as error:
        if phase == 'config_write':
            state = error.report.get('write_state', 'unknown')
        return {**error.report, 'stage': error.report.get('stage', phase), **_state_fields(state),
                **({'receipt': str(receipt)} if receipt else {})}
    except (OSError, ValueError, TypeError, subprocess.SubprocessError):
        return {'ok': False, 'code': 'CONFIG_INVALID_OR_IO_ERROR',
                'next_action': 'Check file syntax, permissions and the reviewed profile; existing backups are retained.',
                'stage': phase, **_state_fields('unknown' if phase == 'config_write' else state),
                **({'receipt': str(receipt)} if receipt else {})}


def rollback(home: Path, receipt: Path, apply=False) -> dict:
    state = 'not_attempted'
    phase = 'preflight'
    try:
        home, receipt = Path(os.path.abspath(home)), Path(receipt)
        base = home / '.coagen-setup/config-backups'
        _require(receipt.is_absolute() and receipt.name == 'receipt.json' and receipt.parent.parent == base and
                 re.fullmatch('[0-9a-f]{32}', receipt.parent.name) is not None, 'CONFIG_RECEIPT_INVALID')
        raw = _read(receipt)
        _require(raw is not None, 'CONFIG_RECEIPT_INVALID')
        value = _json(raw.decode('utf-8'))
        _require(isinstance(value, dict) and value.get('format') == 1 and type(value.get('existed')) is bool,
                 'CONFIG_RECEIPT_INVALID')
        _require(isinstance(value.get('written_sha256'), str) and re.fullmatch('[0-9a-f]{64}', value['written_sha256']) is not None
                 and value.get('status') in ('prepared', 'applied', 'rolled_back'), 'CONFIG_RECEIPT_INVALID')
        original_hash = value.get('original_sha256')
        _require((isinstance(original_hash, str) and re.fullmatch('[0-9a-f]{64}', original_hash) is not None)
                 if value['existed'] else original_hash is None, 'CONFIG_RECEIPT_INVALID')
        path = config_path(home, value.get('host'))
        _require(value.get('config_path') == str(path), 'CONFIG_RECEIPT_INVALID')
        backup = receipt.parent / 'original.bin'
        _require(value.get('backup_file') == (str(backup) if value['existed'] else None), 'CONFIG_RECEIPT_INVALID')
        old = _read(backup) if value['existed'] else None
        _require(_hash(old) == value.get('original_sha256'), 'BACKUP_CHECKSUM_MISMATCH')
        current = _read(path)
        if value.get('status') == 'rolled_back' and _hash(current) == _hash(old):
            return {'ok': True, 'status': 'unchanged', 'path': str(path)}
        _require(_hash(current) == value.get('written_sha256'), 'CONFIG_CHANGED_SINCE_WRITE',
                 'The config has later edits. Review the backup and merge manually; rollback did not overwrite them.')
        if not apply:
            return {'ok': True, 'status': 'planned', 'path': str(path), 'operation': 'restore' if value['existed'] else 'remove'}
        phase = 'rollback_write'
        if value['existed']:
            _atomic(path, old, _hash(current), 'CONFIG_CHANGED_SINCE_WRITE', stage_dir=receipt.parent, label='rollback')
        else:
            _remove(path, value['written_sha256'])
        state = 'verified'
        phase = 'rollback_receipt_write'
        value['status'] = 'rolled_back'
        _atomic(receipt, _json_bytes(value), _hash(raw), label='rollback_receipt')
        return {'ok': True, 'status': 'rolled_back', 'path': str(path), 'receipt': str(receipt), **_state_fields(state, True)}
    except ConfigError as error:
        if phase == 'rollback_write':
            state = error.report.get('write_state', 'unknown')
        return {**error.report, 'stage': error.report.get('stage', phase), **_state_fields(state, True), 'receipt': str(receipt)}
    except (OSError, ValueError, TypeError, subprocess.SubprocessError):
        return {'ok': False, 'code': 'CONFIG_RECEIPT_OR_IO_ERROR',
                'next_action': 'Check receipt and backup integrity and local permissions; no forced rollback is available.',
                'stage': phase, **_state_fields('unknown' if phase == 'rollback_write' else state, True), 'receipt': str(receipt)}
