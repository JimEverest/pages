"""Coagen r13 host-neutral, cross-platform installer. Dry-run unless --apply is supplied."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import unicodedata
import uuid
from types import SimpleNamespace

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CLIENT_VERSION = '0.7.5'
KIT_VERSION = 'multi-agent-kit-r13'
ADAPTER_VERSION = 'r13'
NATIVE_NAMES = {'workbuddy': 'workbuddy.exe', 'zcode': 'zcode.exe'}
RUNTIME_MARKER = '.coagen-runtime.json'
DEFAULT_HUB = 'https://json-formatter.centralindia.cloudapp.azure.com/coagen'
MODULES = ('coagen_setup.py', 'coagen_config.py', 'coagen_control.py', 'coagen_platform.py')


def check_bootstrap_components():
    """The packaged CLI verifies adjacent executable modules before importing them."""
    try:
        if not (HERE / 'kit-manifest.json').is_file():
            return 'SOURCE_TREE_NOT_INSTALLABLE' if (HERE / 'acceptance_kit.py').is_file() else 'KIT_MANIFEST_MISSING'
        value = json.loads((HERE / 'kit-manifest.json').read_text(encoding='utf-8-sig'))
        if not isinstance(value, dict) or not isinstance(value.get('files'), dict):
            return 'KIT_MANIFEST_INVALID'
        for name in MODULES:
            path = HERE / name
            if not path.is_file():
                return 'INSTALLER_COMPONENT_MISSING'
            if hashlib.sha256(path.read_bytes()).hexdigest() != value['files'].get(name):
                return 'INSTALLER_COMPONENT_CHECKSUM_MISMATCH'
    except (OSError, ValueError):
        return 'KIT_MANIFEST_INVALID'
    return None


if __name__ == '__main__' and not (3, 11) <= sys.version_info[:2] <= (3, 14):
    # Before importing modules that need 3.11 (tomllib): a fixed, readable failure.
    print(json.dumps({'ok': False, 'status': 'failed', 'stage': 'preflight', 'code': 'PYTHON_VERSION_UNSUPPORTED',
                      'detected_python': '%d.%d.%d' % sys.version_info[:3], 'native_mcp_verified': False,
                      'retry_allowed': False,
                      'next_action': 'Run the kit with an existing 64-bit CPython 3.11-3.14 (install.sh/INSTALL.cmd select one automatically, or set COAGEN_INSTALL_PYTHON). The installer does not install Python.'}))
    sys.exit(1)


if __name__ == '__main__':
    bootstrap_error = check_bootstrap_components()
    if bootstrap_error:
        print(json.dumps({'ok': False, 'status': 'failed', 'stage': 'preflight', 'code': bootstrap_error,
                          'native_mcp_verified': False, 'retry_allowed': False,
                          'missing_files': [name for name in ('kit-manifest.json', 'client/manifest.json') if not (HERE / name).is_file()],
                          'next_action': 'Use the complete released r13 kit ZIP for this platform and its trusted SHA-256. Extract it and run install.sh (Linux/macOS) or INSTALL.cmd (Windows) from that directory. Do not build a kit, search the disk, or patch source files to install.'}))
        sys.exit(1)


def load_local(name):
    spec = importlib.util.spec_from_file_location(name, HERE / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


platforms = load_local('coagen_platform')
setup = load_local('coagen_setup')
config = load_local('coagen_config')
control = load_local('coagen_control')


class InstallError(Exception):
    def __init__(self, code, stage='preflight', **details):
        self.report = {'ok': False, 'status': 'failed', 'code': code, 'stage': stage,
                       'native_mcp_verified': False, 'retry_allowed': False,
                       'next_action': 'Run diagnose with the same host and workspace, preserve its metadata, and follow the reported correction once. Do not call private write helpers.', **details}


def require(condition, code, **details):
    if not condition:
        raise InstallError(code, **details)


def verify_kit(kit):
    setup.safe(kit / 'kit-manifest.json')
    manifest = json.loads((kit / 'kit-manifest.json').read_text(encoding='utf-8-sig'))
    require(isinstance(manifest, dict), 'KIT_MANIFEST_INVALID')
    require(manifest.get('kit_version') == KIT_VERSION and manifest.get('client_version') == CLIENT_VERSION,
            'KIT_VERSION_MISMATCH')
    files = manifest.get('files')
    require(isinstance(files, dict) and bool(files), 'KIT_MANIFEST_INVALID')
    seen = set()
    for name, expected in files.items():
        require(isinstance(name, str) and '\\' not in name and ':' not in name and
                not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and
                str(PurePosixPath(name)) == name and name not in ('', '.') and
                name.casefold() not in seen, 'KIT_MANIFEST_PATH_INVALID')
        seen.add(name.casefold())
        path = kit / name
        setup.safe(path)
        require(path.is_file() and setup.digest(path) == expected, 'KIT_CHECKSUM_MISMATCH')
    require('coagen_host.py' in files and 'client/manifest.json' in files, 'KIT_INCOMPLETE')
    setup.verify(kit / 'client')
    return manifest


def host_candidates():
    """Read only ancestor identity; never return raw process command lines."""
    if sys.platform != 'win32':
        try:
            return platforms.posix_host_candidates()
        except (OSError, ValueError, subprocess.SubprocessError):
            raise InstallError('HOST_DETECTION_FAILED', next_action='Specify --host with a known preset, or --host generic.') from None
    script = r'''
$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$currentPid = [int]$env:COAGEN_INSTALL_PARENT_PID
$rows = @()
$seen = @{}
for ($step = 0; $step -lt 32 -and $currentPid -gt 0; $step++) {
  if ($seen.ContainsKey($currentPid)) { break }
  $seen[$currentPid] = $true
  $p = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $currentPid) -ErrorAction Stop
  if (-not $p) { break }
  $kind = switch ($p.Name.ToLowerInvariant()) {
    'workbuddy.exe' { 'workbuddy' }
    'zcode.exe' { 'zcode' }
    'codex.exe' { 'codex' }
    'claude.exe' { 'claude' }
    'node.exe' { if ($p.CommandLine -match '[/\\]@deepseek-ai[/\\]dsh[/\\].*bin\.js') { 'dsh' } }
  }
  if ($kind -and $p.ExecutablePath) { $rows += @{ host=$kind; executable=$p.ExecutablePath } }
  $currentPid = [int]$p.ParentProcessId
}
ConvertTo-Json -InputObject @($rows) -Compress
'''
    env = dict(os.environ, COAGEN_INSTALL_PARENT_PID=str(os.getppid()))
    try:
        result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
                                capture_output=True, timeout=15, env=env,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        require(result.returncode == 0, 'HOST_DETECTION_FAILED')
        value = json.loads(result.stdout.decode('utf-8-sig'))
        require(isinstance(value, list), 'HOST_DETECTION_FAILED')
        return value
    except (OSError, ValueError, subprocess.SubprocessError):
        raise InstallError('HOST_DETECTION_FAILED', next_action='Specify --host and, for native adapters, --host-exe.') from None


def resolve_host(args):
    args.host_adapter = getattr(args, 'host_adapter', False)
    args.agent_name = getattr(args, 'agent_name', None)
    args.agent_version = getattr(args, 'agent_version', None)
    require(isinstance(args.host, str) and bool(args.host.strip()), 'HOST_NAME_INVALID')
    requested = args.host
    args.host = requested.lower() if requested.lower() in (*setup.AGENTS, 'auto', 'generic') else 'generic'
    if args.host == 'generic' and requested.lower() != 'generic' and args.agent_name is None:
        args.agent_name = requested
    for key, limit in (('agent_name', 128), ('agent_version', 64)):
        value = getattr(args, key)
        require(value is None or (isinstance(value, str) and 0 < len(value) <= limit and
                all(unicodedata.category(char) not in ('Cc', 'Cs') for char in value)),
                'AGENT_METADATA_INVALID', field=key,
                next_action='Use optional self-reported name/version text within the stated limits, without control characters. Metadata is not an authorization credential.')
    if args.host == 'auto':
        try:
            candidates = host_candidates()
        except InstallError as error:
            candidates = []
            args.host_detection = error.report['code']
        args.host = candidates[0]['host'] if candidates else 'generic'
        if args.host_adapter and candidates and args.host in NATIVE_NAMES:
            args.host_exe = Path(candidates[0]['executable']).resolve()
    if args.host_adapter:
        require(args.host in NATIVE_NAMES, 'OPTIONAL_ADAPTER_UNAVAILABLE',
                next_action='Omit --host-adapter to use standard MCP instance ownership; no branded adapter is required.')
        if not args.host_exe:
            choices = [item for item in host_candidates() if item['host'] == args.host]
            require(bool(choices), 'HOST_EXECUTABLE_MISSING')
            args.host_exe = Path(choices[0]['executable']).resolve()
        require(args.host_exe is not None and args.host_exe.is_absolute() and
                args.host_exe.name.lower() == NATIVE_NAMES[args.host], 'HOST_EXECUTABLE_MISMATCH')
        setup.safe(args.host_exe)
        require(args.host_exe.is_file(), 'HOST_EXECUTABLE_MISSING')
    return args


def python_path(args):
    return platforms.venv_python(args.runtime)


def default_runtime(home):
    real = Path(os.path.abspath(home)) == Path(os.path.abspath(Path.home()))
    return platforms.runtime_base(home, real_home=real) / CLIENT_VERSION


def adapter_path(args):
    return args.home / '.coagen-setup/adapters' / ADAPTER_VERSION / 'coagen_host.py'


def make_entry(args):
    arguments = ['-I', '-X', 'utf8']
    if getattr(args, 'host_adapter', False):
        arguments += [str(adapter_path(args)), '--host', args.host, '--host-exe', str(args.host_exe),
                      '--workspace', str(args.workspace)]
    else:
        arguments += ['-m', 'coagen_client', 'mcp', '--workspace', str(args.workspace)]
    env = {'PYTHONUTF8': '1'}
    for field, key in (('agent_name', 'COAGEN_AGENT_NAME'), ('agent_version', 'COAGEN_AGENT_VERSION')):
        value = getattr(args, field, None)
        if value is not None:
            env[key] = value
    entry = {'type': 'stdio', 'command': str(python_path(args)), 'args': arguments, 'env': env}
    return entry


def config_entry(args):
    entry = make_entry(args)
    if args.host == 'codex':
        entry.pop('type')
        entry.update(startup_timeout_sec=20, tool_timeout_sec=90)
    elif args.host == 'zcode':
        entry.update(enabled=True, timeoutMs=90000, protocolVersion='legacy')
    elif args.host == 'dsh':
        entry = {'patch': setup.dsh_fragment(entry, args.workspace)}
    elif args.host == 'generic':
        entry.update(schema_version=1, skill_path=str(args.home / '.agents/skills/coagen'),
                     registration='not_performed', binding_scope='mcp_instance',
                     agent_info={'name': args.agent_name, 'version': args.agent_version},
                     recommended_cwd=str(args.workspace), server_name='coagen',
                     host_requirements=HOST_REQUIREMENTS)
    return entry


# Capability checklist for any host; brand names never decide admission.
HOST_REQUIREMENTS = {
    'stdio_mcp': 'The host can launch a local stdio MCP server from command, args and env.',
    'subprocess': 'The server may start a background Python helper for create/join and keeps it as its child.',
    'loopback': 'The server and helper talk over 127.0.0.1 HTTP with a random control token.',
    'hub_https': 'The helper needs outbound HTTPS to the Coagen Hub (default json-formatter.centralindia.cloudapp.azure.com:443).',
    'skill_or_instructions': 'The host loads skill_path (a SKILL.md directory) or an equivalent instruction file.',
}


def registration_snippets(args):
    """Ready-to-paste forms for hosts that accept the common mcpServers shape."""
    entry = make_entry(args)
    server = {key: entry[key] for key in ('type', 'command', 'args', 'env')}
    return {'mcpServers_json': {'mcpServers': {'coagen': server}},
            'note': 'Paste into the host configuration file or UI it documents for user-level MCP servers; merge with existing servers. Do not guess private files.'}


def config_host(args):
    if args.host != 'generic':
        return args.host
    identity = [str(args.workspace), str(args.runtime), args.agent_name, args.agent_version]
    return 'export-' + hashlib.sha256(json.dumps(identity, ensure_ascii=False).encode('utf-8')).hexdigest()


def configure(args, apply=False):
    result = config.configure(args.home, config_host(args), config_entry(args), apply=apply)
    result['kind'] = 'stdio_export' if args.host == 'generic' else 'host_configuration'
    return result


RUNTIME_ACTIONS = {
    'PYTHON_VENV_FAILED': 'python -m venv failed for the selected interpreter. Check that it is a complete CPython install (not a stripped embedded copy) and that the runtime parent directory is writable; then rerun install once.',
    'DEPENDENCY_RESOLUTION_FAILED': 'The locked wheels do not match this interpreter. Check the reported detail; use the kit for the detected target, a supported Python, or --source online.',
    'DEPENDENCY_INSTALL_FAILED': 'pip could not install the locked wheels. Check free disk space and the reported detail; the interrupted runtime is recovered automatically on the next install.',
    'DEPENDENCY_CHECK_FAILED': 'The runtime dependency set is inconsistent. Rerun install once; it is recreated from the lock.',
    'RUNTIME_SMOKE_FAILED': 'The installed client failed its local MCP self-test. Preserve the report and runtime; rerun install with --replace-runtime once.',
}


def _redact(text):
    # Index URLs may carry credentials (https://user:token@host). Never echo them.
    import re
    return re.sub(r'://[^/\s@]+@', '://***@', text)


def child(args, stage, timeout=90, structured=False):
    """Run a local step. Only structured JSON from our own scripts is reflected, redacted."""
    env = dict(os.environ, PYTHONUTF8='1', PIP_CONFIG_FILE=os.devnull, PIP_DISABLE_PIP_VERSION_CHECK='1')
    env.pop('PYTHONPATH', None)
    try:
        result = subprocess.run([str(item) for item in args], capture_output=True, timeout=timeout, env=env,
                                stdin=subprocess.DEVNULL, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except subprocess.TimeoutExpired:
        raise InstallError('LOCAL_PROCESS_TIMEOUT', stage=stage, timeout_seconds=timeout,
                           next_action='The step exceeded its time limit. Check disk and CPU load; rerun once. Interrupted runtimes are recovered automatically.') from None
    except (OSError, subprocess.SubprocessError):
        raise InstallError('LOCAL_PROCESS_FAILED', stage=stage,
                           next_action='Check the selected interpreter and local file permissions; no automatic retry.') from None
    output = result.stdout.decode('utf-8', errors='replace')
    if structured:
        try:
            value = json.loads(output.strip().splitlines()[-1])
        except (ValueError, IndexError):
            value = None
        if result.returncode or not isinstance(value, dict) or value.get('ok') is not True:
            detail = value if isinstance(value, dict) else {}
            code = detail.get('code') if isinstance(detail.get('code'), str) else 'LOCAL_PROCESS_FAILED'
            raise InstallError(code, stage=stage, exit_code=result.returncode,
                               reason=_redact(str(detail.get('reason', ''))) or None,
                               detail=[_redact(str(line)) for line in detail.get('detail', [])][-6:] or None,
                               detected=detail.get('detected'),
                               next_action=detail.get('next_action') or RUNTIME_ACTIONS.get(code,
                                   'Check the selected interpreter/version and the kit prerequisites; preserve partial installation.'))
        return value
    require(result.returncode == 0, 'LOCAL_PROCESS_FAILED', stage=stage, exit_code=result.returncode,
            next_action='Check the selected interpreter/version and the kit prerequisites; preserve partial installation.')
    return output


def probe_runtime(args):
    python = python_path(args)
    # POSIX venvs expose bin/python as a link to the base interpreter by design;
    # the runtime directories themselves must still be real, unlinked paths.
    setup.safe(python.parent)
    if os.name == 'nt':
        setup.safe(python)
    require(python.is_file(), 'RUNTIME_NOT_INSTALLED', stage='runtime')
    source = ("import json,sys,coagen_client; from coagen_client import mcp; "
              "print(json.dumps({'version':coagen_client.__version__,'venv':sys.prefix!=sys.base_prefix,"
              "'mcp_import':'passed','python':sys.version.split()[0],'base_executable':getattr(sys,'_base_executable',None)}))")
    try:
        value = json.loads(child([python, '-I', '-X', 'utf8', '-c', source], 'runtime', timeout=30))
    except ValueError:
        raise InstallError('RUNTIME_VERSION_MISMATCH', stage='runtime') from None
    require(value.get('version') == CLIENT_VERSION and value.get('venv') is True,
            'RUNTIME_VERSION_MISMATCH', stage='runtime')
    return value


def runtime_state(args):
    """absent | installing (interrupted by us) | ready | unmarked (older kit or manual)."""
    setup.safe(args.runtime)
    if not os.path.lexists(args.runtime):
        return 'absent', None
    marker = args.runtime / RUNTIME_MARKER
    setup.safe(marker)
    if not marker.is_file():
        return 'unmarked', None
    try:
        value = json.loads(marker.read_text(encoding='utf-8'))
        return (value.get('state') if value.get('state') in ('installing', 'ready') else 'unmarked'), value
    except (OSError, ValueError, AttributeError):
        return 'unmarked', None


def retire_runtime(args, reason):
    """Move, never delete, a runtime that must not be reused."""
    name = '%s-%s-%s' % (args.runtime.name, reason, uuid.uuid4().hex[:12])
    holding = args.runtime.parent / '.coagen-retired' / name
    setup.safe(holding)
    holding.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(6):
        try:
            os.rename(args.runtime, holding)
            return str(holding)
        except PermissionError:
            # Windows refuses to rename a directory with an open file (a running
            # MCP server, or a scanner briefly holding python.exe). Bounded wait.
            if attempt == 5:
                raise InstallError('RUNTIME_IN_USE', stage='runtime', runtime=str(args.runtime),
                                   next_action='A process is still using this runtime. Close Agent hosts or sessions that run Coagen from it, then rerun the same command once.') from None
            time.sleep(0.5)


def builder_python(args):
    """The interpreter that creates runtimes: never one inside the runtime being replaced.

    INSTALL.cmd and install.sh may run the installer with an existing Coagen
    runtime's python. A venv is built from its base interpreter, so prefer that.
    """
    runtime = Path(os.path.abspath(args.runtime))
    for candidate in (getattr(sys, '_base_executable', None), sys.executable):
        if candidate and Path(candidate).is_file() and not Path(os.path.abspath(candidate)).is_relative_to(runtime):
            return candidate
    raise InstallError('INSTALLER_PYTHON_INSIDE_RUNTIME', stage='runtime', runtime=str(args.runtime),
                       next_action='The installer is running from the runtime it must replace and no base Python is available. Rerun with COAGEN_INSTALL_PYTHON set to another CPython 3.11-3.14.')


def runtime_command(args):
    command = [builder_python(args), '-I', '-X', 'utf8', args.kit / 'client/offline.py', 'new', args.runtime,
               '--source', args.source]
    if getattr(args, 'index_url', None):
        command += ['--index-url', args.index_url]
    return command


def ensure_runtime(args):
    state, _ = runtime_state(args)
    result = {'status': 'ready', 'version': CLIENT_VERSION, 'python': str(python_path(args)), 'source': args.source}
    if state == 'installing':
        # Only our own unfinished marker is retired automatically.
        builder_python(args)
        result['recovered_incomplete_runtime'] = retire_runtime(args, 'incomplete')
        state = 'absent'
    elif state in ('ready', 'unmarked'):
        try:
            probe_runtime(args)
        except InstallError as error:
            if getattr(args, 'replace_runtime', False):
                builder_python(args)  # Fail before moving anything if no builder would remain.
            else:
                raise InstallError('RUNTIME_BROKEN', stage='runtime', probe_code=error.report['code'],
                                   runtime=str(args.runtime),
                                   next_action='The existing runtime does not run Coagen %s (for example its base Python was removed or upgraded). Rerun the same install command once with --replace-runtime; the old directory is moved to .coagen-retired, not deleted.' % CLIENT_VERSION) from None
            result['replaced_runtime'] = retire_runtime(args, 'replaced')
            state = 'absent'
    if state == 'absent':
        created = child(runtime_command(args), 'runtime_install', timeout=900, structured=True)
        result.update(action='created', network_used=created.get('network_used'), target=created.get('target'))
    else:
        result['action'] = 'reused'
    result['probe'] = probe_runtime(args)
    smoke = child([python_path(args), '-I', '-X', 'utf8', args.kit / 'client/offline.py', 'smoke'],
                  'runtime_smoke', timeout=60, structured=True)
    result['local_smoke'] = 'passed' if smoke.get('mcp_prepare') == 'pass' else 'failed'
    return result


def check_adapter(args, apply=False):
    if not getattr(args, 'host_adapter', False):
        return {'status': 'not_required'}
    target = adapter_path(args)
    setup.safe(target)
    expected = (args.kit / 'coagen_host.py').read_bytes()
    if target.exists():
        require(target.read_bytes() == expected, 'ADAPTER_CONFLICT',
                next_action='The versioned adapter changed locally. Inspect it; do not overwrite in place.')
        return {'status': 'unchanged', 'path': str(target)}
    if apply:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(expected)
    return {'status': 'applied' if apply else 'planned', 'path': str(target)}


def skill_args(args, apply):
    return SimpleNamespace(bundle=args.kit / 'client', home=args.home, agents=[args.host],
                           mode=args.skill_mode, apply=apply)


def check_config(result, stage='config'):
    require(result.get('ok') is True, result.get('code', 'CONFIG_FAILED'), stage=stage,
            next_action=result.get('next_action', 'Review the reported host configuration condition and retained receipts.'),
            config_result=result)
    return result


def check_project_overrides(args):
    if args.host == 'generic':
        return
    relevant = {'codex': ('codex-project',), 'claude': ('claude-project', 'claude-local'),
                'workbuddy': ('workbuddy-project',),
                'zcode': ('zcode-project', 'zcode-project-legacy', 'agents-project'), 'dsh': ()}
    rows = setup.inspect(args.home, args.workspace)['configs']
    conflicts = [row['path'] for row in rows if row['agent'] in relevant[args.host] and row['coagen_present'] is True]
    require(not conflicts, 'PROJECT_OVERRIDE_PRESENT', paths=conflicts,
            next_action='This installer registers user scope. Review existing project/local Coagen entries before installation; they may shadow it.')


def activation(args):
    actions = {
        'claude': 'Claude Code loads user MCP servers at startup: confirm with `claude mcp get coagen` (public CLI), then start a new Claude Code session (or restart the app) and call native coagen_prepare. The Skill appears as /coagen. Already-running sessions keep their old tool list.',
        'codex': 'Codex loads MCP servers at startup: confirm with `codex mcp list` if available, start a new Codex session, then call native coagen_prepare. The Skill appears as $coagen.',
        'zcode': 'First call coagen_prepare if available. Otherwise use Settings > MCP refresh/reconnect and inspect Coagen status; start a new chat only if its tools remain stale.',
        'workbuddy': 'First call coagen_prepare if available. Otherwise inspect the Coagen custom connector, use the normal Trust/enable/reload control if offered, then start a new chat if needed.',
    }
    if args.host == 'generic':
        action = ('Register command, args and env from the exported stdio descriptor through this host\'s supported MCP configuration; '
                  'load the reported shared Skill directory (or select it through the host\'s documented skill provider). '
                  'Then call native coagen_prepare and verify version/workspace/binding_scope. Export alone is not registration.')
    else:
        action = actions.get(args.host, 'Inspect the host MCP connection and use its supported reload action if needed, then call coagen_prepare.')
    return {'configuration': 'exported_not_registered' if args.host == 'generic' else 'registered', 'connection': 'not_observed', 'tools': 'not_observed',
            'native_prepare': 'not_observed', 'skill_discovery': 'not_observed',
            'workspace_binding': 'fixed_user_configuration',
            'expected_workspace': str(args.workspace),
            'workspace_check': 'Compare native coagen_prepare.workspace with expected_workspace: the previously authorized stable attachment and export root. Text collaboration does not require the chat working directory to match. Preserve the existing binding when changing chats; re-register and reload only for an explicitly authorized change to the attachment root, after preserving active work.',
            'descriptor_path': str(config.config_path(args.home, config_host(args))),
            'shared_skill_path': str(args.home / '.agents/skills/coagen'),
            'next_action': action,
            'maximum_reload_attempts': 1,
            'on_failure': 'Stop and report the host connection/tool error; do not rerun install to repair a model, authentication or approval error.'}


def resume_parameters(args):
    def value(key):
        item = getattr(args, key, False if key == 'replace_runtime' else None)
        return str(item) if isinstance(item, Path) else item
    return {key: value(key) for key in RESUME_KEYS + OPTIONAL_RESUME_KEYS}


RESUME_KEYS = ('home', 'workspace', 'kit', 'runtime', 'host', 'host_exe', 'skill_mode',
               'host_adapter', 'agent_name', 'agent_version')
# r10 additions; an --index-url is never stored because it may carry credentials.
OPTIONAL_RESUME_KEYS = ('source', 'replace_runtime')


def failure_key(args):
    return args.host + ':' + str(config.config_path(args.home, config_host(args))).casefold()


def state_fingerprint(args):
    paths = [config.config_path(args.home, config_host(args)), adapter_path(args),
             args.home / '.agents/skills/coagen/SKILL.md', args.runtime / 'pyvenv.cfg',
             args.kit / 'kit-manifest.json']
    items = []
    for path in paths:
        try:
            setup.safe(path)
            value = setup.digest(path) if path.is_file() else 'absent'
        except (OSError, setup.SetupError):
            value = 'unreadable-or-unsafe'
        items.append((str(path), value))
    items.append(('index_url_sha256', hashlib.sha256((getattr(args, 'index_url', None) or '').encode()).hexdigest()))
    return hashlib.sha256(json.dumps([resume_parameters(args), items], sort_keys=True).encode('utf-8')).hexdigest()


def kit_targets(args):
    manifest = json.loads((args.kit / 'kit-manifest.json').read_text(encoding='utf-8-sig'))
    targets = manifest.get('targets', [])
    require(isinstance(targets, list) and all(isinstance(item, str) for item in targets), 'KIT_MANIFEST_INVALID')
    return targets


def select_source(args):
    targets = kit_targets(args)
    if getattr(args, 'source', None) in (None, 'auto'):
        args.source = 'offline' if targets else 'online'
    require(args.source in ('offline', 'online'), 'SOURCE_INVALID')
    require(args.source == 'online' or targets, 'KIT_HAS_NO_OFFLINE_WHEELS',
            next_action='This is the online kit. Use --source online with network access, or download the offline kit for this platform.')
    require(not getattr(args, 'index_url', None) or args.source == 'online', 'SOURCE_INVALID',
            next_action='--index-url only applies to --source online.')
    return targets


def platform_report(args, targets):
    facts = platforms.identity()
    failure = platforms.support(facts, targets, source=args.source)
    return facts, failure


def acceptance(components='planned', configuration='planned', skill_files='planned', hub='not_checked'):
    """Six separate layers; later layers are never inferred from earlier ones."""
    return {'1_components_and_dependencies': components,
            '2_mcp_configuration': configuration,
            '3_skill_files_installed': skill_files,
            '3b_skill_discovered_by_host': 'not_observed_by_installer',
            '4_native_mcp_loaded_and_prepare_called': 'not_observed_by_installer',
            '5_hub_network': hub,
            '6_encrypted_collaboration': 'not_performed_by_installer'}


def installation_plan(args):
    verify_kit(args.kit)
    resolve_host(args)
    require(not any(token in str(args.workspace) for token in ('实际工作目录', '<工作目录>', '<workspace>', '「', '」')),
            'WORKSPACE_PLACEHOLDER', next_action='Use the actual existing workspace directory, or omit --workspace to use the current working directory.')
    require(args.workspace.is_absolute() and args.workspace.is_dir(), 'WORKSPACE_MISSING')
    setup.safe(args.home)
    require(not setup.blocking_overrides(args.home, [args.host]), 'ROOT_OVERRIDE_REQUIRES_EXPLICIT_ADAPTER')
    check_project_overrides(args)
    setup.safe(args.runtime)
    targets = select_source(args)
    facts, failure = platform_report(args, targets)
    state, _ = runtime_state(args)
    if failure and (state in ('absent', 'installing') or getattr(args, 'replace_runtime', False)):
        # Refuse before any write; an existing working runtime needs no new wheels.
        action = failure['next_action']
        if failure['code'] == 'KIT_PLATFORM_MISMATCH':
            action = ('Download coagen-v%s-%s-%s.zip and its .sha256 from the same release, or rerun with --source online '
                      'when this machine may reach the package index.' % (CLIENT_VERSION, KIT_VERSION, failure['detected']['target']))
        raise InstallError(failure['code'], stage='platform', reason=failure['reason'],
                           detected=failure['detected'], next_action=action)
    adapter = check_adapter(args)
    config_plan = check_config(configure(args), 'preflight')
    skill_plan = setup.skills(skill_args(args, False))
    report = {'ok': True, 'kit_version': KIT_VERSION, 'client_version': CLIENT_VERSION,
              'host': args.host, 'workspace': str(args.workspace), 'native_mcp_verified': False,
              'host_selection': {'configuration_preset': args.host if args.host in setup.AGENTS else None,
                                 'detection_notice': getattr(args, 'host_detection', None),
                                 'brand_admission_required': False},
              'agent_info': {'name': args.agent_name, 'version': args.agent_version},
              'binding_scope': 'explicit_owner' if args.host_adapter else 'mcp_instance',
              'mcp_descriptor': make_entry(args), 'shared_skill_path': str(args.home / '.agents/skills/coagen'),
              'workspace_binding': 'fixed_user_configuration_not_current_chat',
              'status': 'planned', 'progress': {}, 'adapter': adapter, 'config': config_plan,
              'skill': skill_plan,
              'runtime': {'path': str(args.runtime), 'state': state, 'source': args.source,
                          'action': {'absent': 'create', 'installing': 'recover_incomplete_then_create'}.get(state, 'reuse_after_probe')},
              'platform': {key: facts[key] for key in ('os', 'arch', 'libc', 'libc_version', 'target')} |
                          {'python': facts['python']['version'], 'base_python': facts['python']['executable'],
                           'kit_targets': targets, 'offline_wheels_match': failure is None or failure['code'] != 'KIT_PLATFORM_MISMATCH'},
              'network_policy': 'no_network_package_index_disabled' if args.source == 'offline' else 'package_index_hash_locked',
              'acceptance': acceptance()}
    if args.host == 'generic':
        report['registration'] = registration_snippets(args)
        report['host_requirements'] = HOST_REQUIREMENTS
    report['resume'] = resume_parameters(args)
    return report


def verify_local_files(args):
    adapter = check_adapter(args)
    skill = setup.skills(skill_args(args, False))
    target = configure(args)
    matching = (adapter['status'] in ('unchanged', 'not_required') and
                all(row['action'] == 'unchanged' for row in skill['actions']) and
                target.get('ok') is True and target.get('status') == 'unchanged')
    require(matching, 'POST_INSTALL_VERIFY_FAILED', stage='verify',
            next_action='The observed files differ from the completed plan. Run diagnose and stop; preserve concurrent edits and the configuration receipt.')
    installed = {row['target']: skill_fingerprint(Path(row['target'])) for row in skill['actions']}
    return {'status': 'verified', 'config_sha256': target.get('original_sha256'), 'skill_fingerprints': installed}


def skill_fingerprint(path):
    return hashlib.sha256(json.dumps(setup.inventory(path), sort_keys=True).encode('utf-8')).hexdigest()


def install(args):
    report = installation_plan(args)
    if not args.apply:
        return report
    recorder = None
    current_stage = 'lock'
    try:
        with control.installation_lock(args.home, args.runtime):
            report = installation_plan(args)  # Re-read after acquiring both resource locks.
            control.check_retry(args.home, failure_key(args), state_fingerprint(args))
            recorder = control.RunReport(args.home, report)
            report['report_path'] = str(recorder.path)
            operations = [
                ('runtime', lambda: ensure_runtime(args)),
                ('adapter', lambda: check_adapter(args, apply=True)),
                ('skill', lambda: setup.skills(skill_args(args, True))),
                ('config', lambda: configure(args, apply=True)),
                ('verify', lambda: verify_local_files(args)),
            ]
            try:
                for current_stage, operation in operations:
                    recorder.begin(current_stage)
                    result = operation()
                    report[current_stage] = result
                    if current_stage == 'config':
                        check_config(result)
                    report['progress'][current_stage] = {'status': 'applied' if current_stage == 'skill' else result.get('status', 'passed')}
                    if current_stage == 'skill':
                        report['progress'][current_stage]['actions'] = result['actions']
                    recorder.value.update(report)
                    recorder.end('passed')
                report.update(status='awaiting_host_registration' if args.host == 'generic' else 'awaiting_host_prepare',
                              local_ready=True, activation=activation(args),
                              acceptance=acceptance('passed', 'exported_not_registered' if args.host == 'generic' else 'merged_on_disk',
                                                    'installed'))
                report['next_action'] = report['activation']['next_action']
                control.clear_failure(args.home, failure_key(args))
                return recorder.finish(report)
            except (InstallError, setup.SetupError, control.ControlError, OSError, ValueError) as error:
                detail = error.report if hasattr(error, 'report') else {'code': 'LOCAL_IO_ERROR'}
                if detail['code'] not in ('REPORT_WRITE_VERIFY_FAILED', 'CONTROL_UNSAFE_PATH'):
                    failure = control.record_failure(args.home, failure_key(args), state_fingerprint(args),
                                                     detail['code'], recorder.path)
                    report['failure_attempts'] = failure['attempts']
                    report['retry_allowed'] = failure['attempts'] < 2
                raise
    except (InstallError, setup.SetupError, control.ControlError, OSError, ValueError) as error:
        detail = error.report if hasattr(error, 'report') else {'code': 'LOCAL_IO_ERROR'}
        if 'actions' in detail:
            report['skill'] = detail
            report['progress']['skill'] = {'status': 'failed', 'actions': detail['actions']}
        report.update(ok=False, status='failed', code=detail['code'], stage=detail.get('stage', 'installation'),
                      next_action=detail.get('next_action', 'Preserve completed stages and backups; fix the reported condition before rerunning.'))
        if report['stage'] == 'installation':
            report['stage'] = current_stage
        report['diagnostic'] = detail
        if recorder:
            try:
                if recorder.value['stages'] and recorder.value['stages'][-1]['status'] == 'running':
                    recorder.end('failed', detail['code'])
                report = recorder.finish(report)
            except (OSError, control.ControlError):
                report['report_write_failed'] = True
        raise InstallError(report['code'], **{k: v for k, v in report.items() if k not in ('code', 'ok', 'status', 'native_mcp_verified')}) from None


def hub_check(args):
    """Layer 5 only: a bounded, credential-free reachability probe through the runtime.

    Without a token `coagen check` reports overall "partial" (exit 2) even when
    the Hub answered, so the JSON report decides, not the exit status.
    """
    env = dict(os.environ, PYTHONUTF8='1')
    env.pop('PYTHONPATH', None)
    try:
        result = subprocess.run([str(python_path(args)), '-I', '-X', 'utf8', '-m', 'coagen_client', 'check', '--hub', args.hub,
                                 '--timeout', '8', '--total-timeout', '20'], capture_output=True, timeout=40, env=env,
                                stdin=subprocess.DEVNULL, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        report = json.loads(result.stdout.decode('utf-8', 'replace').strip().splitlines()[-1])
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        return {'status': 'not_determined', 'code': 'HUB_CHECK_FAILED_TO_RUN', 'hub': args.hub}
    connect = next((item for item in report.get('checks', []) if item.get('name') == 'connect'), {})
    return {'status': 'reachable' if connect.get('status') == 'pass' else 'unreachable',
            'hub': args.hub, 'error_category': connect.get('error_category'), 'http_status': connect.get('http_status'),
            'elapsed_ms': report.get('elapsed_ms'), 'credentials_used': False,
            'note': 'Health endpoint only; room creation, encryption and delivery are separate checks.'}


def doctor(args):
    verify_kit(args.kit)
    select_source(args)
    resolve_host(args)
    require(not setup.blocking_overrides(args.home, [args.host]), 'ROOT_OVERRIDE_REQUIRES_EXPLICIT_ADAPTER')
    check_project_overrides(args)
    result = {'ok': False, 'host': args.host, 'status': 'incomplete', 'native_mcp_verified': False, 'checks': {}}
    state, marker = runtime_state(args)
    try:
        result['checks']['runtime'] = {**probe_runtime(args), 'state': state, 'path': str(args.runtime)}
    except InstallError as error:
        result['checks']['runtime'] = {'code': error.report['code'], 'state': state, 'path': str(args.runtime),
                                       'next_action': 'Rerun install; an interrupted runtime is recovered automatically, a broken one needs --replace-runtime once.'}
    adapter = check_adapter(args)
    result['checks']['adapter'] = adapter
    skill = setup.skills(skill_args(args, False))
    result['checks']['skill'] = {'matching': all(x['action'] == 'unchanged' for x in skill['actions']),
                                 'paths': [x['target'] for x in skill['actions']]}
    configured = configure(args)
    result['checks']['config'] = {'matching': configured.get('ok') is True and configured.get('status') == 'unchanged',
                                  'code': configured.get('code'), 'path': configured.get('path')}
    result['ok'] = ('code' not in result['checks']['runtime'] and adapter['status'] in ('unchanged', 'not_required') and
                    result['checks']['skill']['matching'] and result['checks']['config']['matching'])
    if result['ok']:
        result['status'] = 'awaiting_host_registration' if args.host == 'generic' else 'awaiting_host_prepare'
    result['local_ready'] = result['ok']
    result['activation'] = activation(args)
    if not result['checks']['config']['matching']:
        result['activation']['configuration'] = 'not_matching'
    hub = hub_check(args) if getattr(args, 'check_hub', False) and 'code' not in result['checks']['runtime'] else None
    if hub:
        result['checks']['hub'] = hub
    result['acceptance'] = acceptance(
        'passed' if 'code' not in result['checks']['runtime'] else 'failed',
        ('exported_not_registered' if args.host == 'generic' else 'merged_on_disk') if result['checks']['config']['matching'] else 'not_matching',
        'installed' if result['checks']['skill']['matching'] else 'not_matching',
        hub['status'] if hub else 'not_checked')
    result['mcp_descriptor'] = make_entry(args)
    if args.host == 'generic':
        result['registration'] = registration_snippets(args)
    result['agent_info'] = {'name': args.agent_name, 'version': args.agent_version}
    result['next_action'] = result['activation']['next_action'] if result['ok'] else 'Run diagnose with these arguments; correct the reported local condition before host activation.'
    return result


def diagnose(args):
    try:
        result = doctor(args)
    except (InstallError, setup.SetupError, control.ControlError) as error:
        result = dict(error.report)
    result['mode'] = 'read_only_diagnose'
    result['native_mcp_verified'] = False
    if args.host in (*setup.AGENTS, 'generic'):
        try:
            result['previous_failure'] = control.failure_state(args.home, failure_key(args))
        except control.ControlError as error:
            result['previous_failure'] = error.report
    result['diagnostic_policy'] = {'config_bodies': False, 'credential_reads': False, 'write_probes': False,
                                   'private_write_fallback': False, 'unchanged_failure_limit': 2}
    return result


def load_report(args):
    setup.safe(args.report)
    value = json.loads(args.report.read_text(encoding='utf-8'))
    saved = value.get('resume') if isinstance(value, dict) else None
    require(isinstance(saved, dict), 'REPORT_NOT_RESUMABLE',
            next_action='Use the released r13 installer with the original host, home and workspace. Older reports lack complete resume parameters; do not infer them from unrelated profiles.')
    return value, saved


def restore_arguments(args, argv):
    if not getattr(args, 'report', None):
        return args
    _, saved = load_report(args)
    require(set(RESUME_KEYS) <= set(saved) <= set(RESUME_KEYS + OPTIONAL_RESUME_KEYS) and
            saved['host'] in (*setup.AGENTS, 'generic') and saved['skill_mode'] in ('copy', 'junction')
            and type(saved['host_adapter']) is bool and saved.get('source') in (None, 'offline', 'online')
            and type(saved.get('replace_runtime', False)) is bool,
            'REPORT_INVALID')
    for key in RESUME_KEYS + OPTIONAL_RESUME_KEYS:
        flag = '--' + key.replace('_', '-')
        if key not in saved or flag in argv or any(arg.startswith(flag + '=') for arg in argv):
            continue
        raw = saved[key]
        if key == 'replace_runtime':
            continue  # A replacement is one explicit decision, never replayed by resume.
        if key in ('host', 'skill_mode', 'host_adapter', 'agent_name', 'agent_version', 'source'):
            setattr(args, key, raw)
        elif raw is None and key == 'host_exe':
            args.host_exe = None
        else:
            require(isinstance(raw, str) and Path(raw).is_absolute(), 'REPORT_INVALID')
            setattr(args, key, Path(raw))
    base = args.home / '.coagen-setup/reports'
    require(args.report.is_relative_to(base), 'REPORT_HOME_MISMATCH',
            next_action='Use the report belonging to the selected test/user home; no installation was resumed.')
    return args


def rollback_report(args, apply=False):
    """Undo one recorded installation: configuration, then Skill copies. Runtimes stay.

    Each component is checked against what this installation wrote; later edits
    are reported and never overwritten. This is not a cross-component transaction.
    """
    value, saved = load_report(args)
    require(args.report.is_relative_to(args.home / '.coagen-setup/reports'), 'REPORT_HOME_MISMATCH')
    require(value.get('status') in ('awaiting_host_prepare', 'awaiting_host_registration'), 'REPORT_NOT_COMPLETED',
            next_action='Only a completed installation report can be rolled back as a whole. For a failed run use rollback --receipt with the reported config receipt, and review skill backups listed in the report.')
    result = {'ok': True, 'mode': 'apply' if apply else 'preview', 'report': str(args.report), 'components': {},
              'runtime': {'action': 'retained', 'path': saved.get('runtime'),
                          'note': 'Versioned runtimes are never deleted by rollback; the restored configuration selects the previous one.'}}
    receipt = (value.get('config') or {}).get('receipt')
    if receipt:
        outcome = config.rollback(args.home, Path(receipt), apply=apply)
        result['components']['config'] = outcome
        result['ok'] = result['ok'] and outcome.get('ok') is True
    else:
        result['components']['config'] = {'ok': True, 'status': 'unchanged_by_install'}
    rows = []
    fingerprints = (value.get('verify') or {}).get('skill_fingerprints') or {}
    for action in (value.get('skill') or {}).get('actions', []):
        if action.get('status') != 'applied':
            continue
        target = Path(action['target'])
        row = {'target': str(target), 'restore_from': action.get('backup')}
        backup = Path(action['backup']) if action.get('backup') else None
        if backup and not os.path.lexists(backup) and os.path.lexists(target):
            rows.append({**row, 'status': 'already_restored', 'ok': True})
            continue
        if not backup and not os.path.lexists(target):
            rows.append({**row, 'status': 'already_removed', 'ok': True})
            continue
        try:
            setup.safe(target, include_leaf=False)
            current = skill_fingerprint(target) if target.is_dir() and not setup.linked(target) else None
        except (setup.SetupError, OSError):
            current = None
        if current is None or current != fingerprints.get(str(target)):
            row.update(status='skipped_changed_since_install', ok=False)
            result['ok'] = False
        elif apply:
            aside = args.home / '.coagen-setup/backups' / uuid.uuid4().hex / 'rolled-back' / target.parent.parent.name.lstrip('.') / 'coagen'
            setup.safe(aside)
            aside.parent.mkdir(parents=True, exist_ok=True)
            target.rename(aside)
            if action.get('backup'):
                Path(action['backup']).rename(target)
            row.update(status='restored' if action.get('backup') else 'removed_new_copy', moved_aside=str(aside), ok=True)
        else:
            row.update(status='planned_restore' if action.get('backup') else 'planned_remove_new_copy', ok=True)
        rows.append(row)
    result['components']['skill'] = rows
    done = (result['components']['config'].get('status') in ('unchanged', 'unchanged_by_install') and
            all(row['status'].startswith('already_') for row in rows))
    result['status'] = 'unchanged' if done and result['ok'] else (
        ('rolled_back' if apply else 'planned') if result['ok'] else 'partial_or_blocked')
    result['next_action'] = ('Restart or reload each affected host, then call native coagen_prepare to confirm the restored version.'
                             if result['ok'] else 'Some components changed after installation and were left untouched; review them manually.')
    return result


def main(argv=None):
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    argv = list(sys.argv[1:] if argv is None else argv)
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('install', 'doctor', 'diagnose', 'resume', 'rollback'):
        sub = commands.add_parser(name)
        sub.add_argument('--home', type=setup.absolute, default=Path.home())
        sub.add_argument('--apply', action='store_true') if name in ('install', 'rollback') else None
        if name == 'rollback':
            choice = sub.add_mutually_exclusive_group(required=True)
            choice.add_argument('--receipt', type=setup.absolute, help='Configuration receipt only')
            choice.add_argument('--report', type=setup.absolute, help='Completed installation report: config and Skill')
            continue
        sub.add_argument('--report', type=setup.absolute, required=name == 'resume')
        sub.add_argument('--host', default='auto', help='Optional known configuration preset, generic, or any Agent display name')
        sub.add_argument('--host-exe', type=setup.absolute)
        sub.add_argument('--host-adapter', action='store_true', help='Opt into a verified WorkBuddy/ZCode process adapter; default is standard MCP instance ownership')
        sub.add_argument('--agent-name', help='Optional self-reported Agent name; never an admission check')
        sub.add_argument('--agent-version', help='Optional self-reported Agent version, not a Coagen version requirement')
        sub.add_argument('--workspace', type=setup.absolute, default=Path.cwd())
        sub.add_argument('--kit', type=setup.absolute, default=HERE)
        sub.add_argument('--runtime', type=setup.absolute)
        sub.add_argument('--skill-mode', choices=('copy', 'junction'), default='copy')
        sub.add_argument('--source', choices=('auto', 'offline', 'online'), default=None,
                         help='offline (default for platform kits) never contacts an index; online installs the same hash-locked files from PyPI')
        sub.add_argument('--index-url', help='Online only: explicit package index URL; hashes are still enforced and the URL is never written to reports')
        if name in ('install', 'resume'):
            sub.add_argument('--replace-runtime', action='store_true',
                             help='Move a broken runtime of this version aside to .coagen-retired and recreate it')
        if name in ('doctor', 'diagnose', 'resume'):
            sub.add_argument('--check-hub', action='store_true', help='Also test outbound HTTPS to the Hub (no credentials)')
            sub.add_argument('--hub', default=DEFAULT_HUB)
    try:
        args = parser.parse_args(argv)
        if args.command == 'rollback':
            run = (lambda apply: rollback_report(args, apply)) if args.report else (
                lambda apply: config.rollback(args.home, args.receipt, apply=apply))
            if args.apply:
                with control.installation_lock(args.home):
                    result = run(True)
            else:
                result = run(False)
        else:
            restore_arguments(args, argv)
            if args.runtime is None:
                args.runtime = default_runtime(args.home)
            if args.source in (None, 'auto'):
                args.source = None
            if args.command == 'install':
                result = install(args)
            elif args.command == 'diagnose':
                result = diagnose(args)
            else:
                result = doctor(args)
    except (InstallError, setup.SetupError, control.ControlError) as error:
        result = error.report
    except (OSError, ValueError, subprocess.SubprocessError):
        result = {'ok': False, 'status': 'failed', 'code': 'LOCAL_INPUT_OR_IO_ERROR', 'native_mcp_verified': False}
    result.setdefault('elapsed_ms', round((time.monotonic() - started) * 1000))
    result.setdefault('native_mcp_verified', False)
    if not result.get('ok'):
        result.setdefault('next_action', 'Preserve the exact code and stage; run the public diagnose command. Do not probe writes, edit source or dump configuration backups.')
        result.setdefault('retry_allowed', False)
    print(setup.json_text(result), end='')
    return 0 if result.get('ok') else 1


if __name__ == '__main__':
    raise SystemExit(main())
