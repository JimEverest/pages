# Coagen kit r13 Windows entry. No installation code runs before the kit is verified.
# Dot sourcing exposes the same discovery helpers without starting installation.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:CoagenBootstrapRoot = $PSScriptRoot
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding

function Stop-CoagenBootstrap([string]$Code, [string]$NextAction) {
    $failure = New-Object System.Exception($Code)
    $failure.Data['coagen_code'] = $Code
    $failure.Data['next_action'] = $NextAction
    throw $failure
}

function Get-CoagenAbsolutePath([string]$Value, [string]$Code, [string]$Kind = '') {
    if ([string]::IsNullOrWhiteSpace($Value) -or $Value -match '[<>"\x00]|%[^%]+%|\$\{|\$\(' -or
        $Value -notmatch '^(?:[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)') {
        Stop-CoagenBootstrap $Code 'Use a real absolute path; replace all examples and placeholders.'
    }
    $absolute = [IO.Path]::GetFullPath($Value)
    if ($Kind -and -not (Test-Path -LiteralPath $absolute -PathType $Kind)) {
        Stop-CoagenBootstrap $Code 'The specified file or directory must already exist. Check the exact absolute path.'
    }
    return $absolute
}

function Assert-CoagenRegularPath([string]$Path) {
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                Stop-CoagenBootstrap 'KIT_REPARSE_POINT' 'Use a complete release kit in a regular directory, without links or junctions.'
            }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-CoagenRelativeName([string]$Name, [string]$Code) {
    if ([string]::IsNullOrWhiteSpace($Name) -or $Name -match '[\\:<>"|?*\x00]' -or $Name.StartsWith('/') -or $Name.EndsWith('/')) {
        Stop-CoagenBootstrap $Code 'Use an intact trusted release archive; do not repair archive entries manually.'
    }
    foreach ($segment in $Name.Split('/')) {
        if (-not $segment -or $segment -in @('.', '..') -or $segment -match '[. ]$' -or
            $segment -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') {
            Stop-CoagenBootstrap $Code 'Use an intact trusted release archive; do not repair archive entries manually.'
        }
    }
}

function Get-CoagenDigest([string]$Path) {
    # Avoid module auto-loading differences between Windows PowerShell and pwsh.
    $stream = [IO.File]::OpenRead($Path)
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hash.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $hash.Dispose(); $stream.Dispose() }
}

function Assert-CoagenKit([string]$Root) {
    Assert-CoagenRegularPath $Root
    $manifestPath = Join-Path $Root 'kit-manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        Stop-CoagenBootstrap 'SOURCE_TREE_NOT_INSTALLABLE' 'Run the entry from a complete extracted r13 release, or pass --zip ABSOLUTE_RELEASE.zip --sha256 TRUSTED_64_HEX_DIGEST. Do not search disks or rebuild a release.'
    }
    Assert-CoagenRegularPath $manifestPath
    try { $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { Stop-CoagenBootstrap 'KIT_MANIFEST_INVALID' 'Obtain a complete trusted r13 release and verify its published SHA-256.' }
    if ($manifest -isnot [PSCustomObject] -or -not $manifest.PSObject.Properties['files'] -or
        $manifest.files -isnot [PSCustomObject]) {
        Stop-CoagenBootstrap 'KIT_MANIFEST_INVALID' 'Obtain a complete trusted r13 release and verify its published SHA-256.'
    }
    if (-not $manifest.PSObject.Properties['kit_version'] -or $manifest.kit_version -ne 'multi-agent-kit-r13' -or
        -not $manifest.PSObject.Properties['client_version'] -or $manifest.client_version -ne '0.7.5') {
        Stop-CoagenBootstrap 'KIT_VERSION_MISMATCH' 'Use the complete r13 setup kit for Coagen client 0.7.3.'
    }
    $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $manifest.files.PSObject.Properties) {
        Assert-CoagenRelativeName $entry.Name 'KIT_MANIFEST_PATH_INVALID'
        if (-not $seen.Add($entry.Name) -or $entry.Value -isnot [string] -or $entry.Value -notmatch '^[a-fA-F0-9]{64}$') {
            Stop-CoagenBootstrap 'KIT_MANIFEST_INVALID' 'Use the unmodified manifest from a trusted release.'
        }
        $file = Join-Path $Root $entry.Name
        Assert-CoagenRegularPath $file
        if (-not (Test-Path -LiteralPath $file -PathType Leaf) -or
            (Get-CoagenDigest $file) -ne $entry.Value) {
            Stop-CoagenBootstrap 'KIT_CHECKSUM_MISMATCH' 'Stop. Obtain and verify a fresh copy of this release; do not overwrite or execute altered files.'
        }
    }
    foreach ($required in @('coagen_bootstrap.ps1', 'INSTALL.cmd', 'coagen_install.py', 'coagen_setup.py',
                            'coagen_config.py', 'coagen_control.py', 'coagen_platform.py', 'coagen_host.py',
                            'client/manifest.json', 'client/coagen_platform.py')) {
        if (-not $seen.Contains($required)) {
            Stop-CoagenBootstrap 'KIT_INCOMPLETE' 'Use the complete r13 release directory, including client and every entry component.'
        }
    }
}

function Expand-CoagenTrustedZip([string]$Zip, [string]$Digest) {
    if (-not $Zip -or $Digest -notmatch '^[a-fA-F0-9]{64}$') {
        Stop-CoagenBootstrap 'TRUSTED_ZIP_REQUIRED' 'Supply --zip ABSOLUTE_RELEASE.zip and --sha256 from a trusted release channel.'
    }
    $Zip = Get-CoagenAbsolutePath $Zip 'ZIP_PATH_INVALID' 'Leaf'
    Assert-CoagenRegularPath $Zip
    if ((Get-CoagenDigest $Zip) -ne $Digest) {
        Stop-CoagenBootstrap 'ZIP_CHECKSUM_MISMATCH' 'Stop. Verify the exact release ZIP and the SHA-256 supplied through the trusted channel.'
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::OpenRead($Zip)
    try {
        $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        [long]$total = 0
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.TrimEnd('/')
            Assert-CoagenRelativeName $name 'ZIP_ENTRY_INVALID'
            $total += $entry.Length
            if (-not $seen.Add($name) -or (($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000 -or
                ($entry.ExternalAttributes -band 0x400) -ne 0 -or $total -gt 536870912 -or $seen.Count -gt 10000) {
                Stop-CoagenBootstrap 'ZIP_ENTRY_INVALID' 'Use a complete trusted r13 ZIP without duplicate, linked or oversized entries.'
            }
        }
        $cache = Get-CoagenAbsolutePath $env:LOCALAPPDATA 'CACHE_PATH_INVALID'
        $base = Join-Path $cache 'Coagen/kits/r13'
        $target = Join-Path $base $Digest.ToLowerInvariant()
        Assert-CoagenRegularPath $target
        if (Test-Path -LiteralPath $target) { Assert-CoagenKit $target; return $target }
        $stage = Join-Path $base ('.staging-' + [Guid]::NewGuid().ToString('N'))
        [IO.Directory]::CreateDirectory($stage) | Out-Null
        foreach ($entry in $archive.Entries) {
            $output = Join-Path $stage $entry.FullName
            if ($entry.FullName.EndsWith('/')) { [IO.Directory]::CreateDirectory($output) | Out-Null }
            else {
                [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($output)) | Out-Null
                $inputStream = $entry.Open()
                try {
                    $outputStream = [IO.File]::Open($output, [IO.FileMode]::CreateNew)
                    try { $inputStream.CopyTo($outputStream) } finally { $outputStream.Dispose() }
                } finally { $inputStream.Dispose() }
            }
        }
        Assert-CoagenKit $stage
        try { [IO.Directory]::Move($stage, $target) }
        catch {
            if (-not (Test-Path -LiteralPath $target -PathType Container)) { throw }
            Assert-CoagenKit $target
        }
        return $target
    } finally { $archive.Dispose() }
}

function ConvertTo-CoagenNativeArguments([string[]]$Tokens) {
    # ProcessStartInfo on Windows PowerShell 5 has no ArgumentList. This is Windows
    # argv quoting, never a shell command; no cmd /c or expression evaluation.
    $quoted = foreach ($token in $Tokens) {
        '"' + ($token -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
    }
    return $quoted -join ' '
}

function Invoke-CoagenProbe([string]$Executable, [string[]]$Tokens) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $Executable
    $start.Arguments = ConvertTo-CoagenNativeArguments $Tokens
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = New-Object Diagnostics.Process
    $process.StartInfo = $start
    try {
        if (-not $process.Start()) { return $null }
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(5000)) { $process.Kill(); $process.WaitForExit(); return $null }
        if ($process.ExitCode -ne 0) { return $null }
        return $stdout.GetAwaiter().GetResult()
    } catch { return $null } finally { $process.Dispose() }
}

function Test-CoagenPython([string]$Candidate) {
    if (-not (Test-Path -LiteralPath $Candidate -PathType Leaf) -or $Candidate -match '\\WindowsApps\\') { return $null }
    $code = "import json,sys,platform,struct; print(json.dumps(dict(implementation=platform.python_implementation(),major=sys.version_info.major,minor=sys.version_info.minor,bits=struct.calcsize('P')*8,path=sys.executable)))"
    $raw = Invoke-CoagenProbe $Candidate @('-I', '-X', 'utf8', '-c', $code)
    if (-not $raw) { return $null }
    try { return $raw | ConvertFrom-Json } catch { return $null }
}

function Get-CoagenPythonCandidates {
    # Bounded inventories only: existing managed runtime, registered launcher,
    # PATH commands, PEP 514 registry entries, and the current host's known runtime.
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.7.5/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.7.4/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.7.3/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.7.2/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.7.1/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.7.0/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.6.0/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.5.0/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.4.2/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.4.1/Scripts/python.exe' }
    if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Coagen/runtimes/0.4.0/Scripts/python.exe' }
    $launcher = Get-Command py.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($launcher) {
        $listing = Invoke-CoagenProbe $launcher.Source @('-0p')
        if ($listing) {
            foreach ($line in ($listing -split '\r?\n')) {
                if ($line -match '((?:[A-Za-z]:[\\/]|\\\\).+?\.exe)\s*$') { $Matches[1] }
            }
        }
    }
    foreach ($name in @('python.exe', 'python3.exe')) {
        Get-Command $name -CommandType Application -All -ErrorAction SilentlyContinue | ForEach-Object { $_.Source }
    }
    foreach ($registry in @('HKCU:\Software\Python', 'HKLM:\Software\Python')) {
        if (Test-Path -LiteralPath $registry) {
            foreach ($company in (Get-ChildItem -LiteralPath $registry -ErrorAction SilentlyContinue)) {
                foreach ($version in (Get-ChildItem -LiteralPath $company.PSPath -ErrorAction SilentlyContinue)) {
                    $install = Join-Path $version.PSPath 'InstallPath'
                    if (Test-Path -LiteralPath $install) {
                        $key = Get-Item -LiteralPath $install
                        $exe = $key.GetValue('ExecutablePath')
                        if ($exe) { $exe } elseif ($key.GetValue('')) { Join-Path $key.GetValue('') 'python.exe' }
                    }
                }
            }
        }
    }
    if ($env:USERPROFILE) {
        $versions = Join-Path $env:USERPROFILE '.workbuddy/binaries/python/versions'
        if (Test-Path -LiteralPath $versions -PathType Container) {
            Get-ChildItem -LiteralPath $versions -Directory -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending | Select-Object -First 8 |
                ForEach-Object { Join-Path $_.FullName 'python.exe' }
        }
    }
}

function Get-CoagenPython([string]$ExplicitPath) {
    $candidates = if ($ExplicitPath) { @(Get-CoagenAbsolutePath $ExplicitPath 'PYTHON_UNAVAILABLE' 'Leaf') }
                  else { @(Get-CoagenPythonCandidates) }
    $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($candidate in ($candidates | Select-Object -First 32)) {
        if (-not $seen.Add($candidate)) { continue }
        $probe = Test-CoagenPython $candidate
        if ($probe -and $probe.implementation -eq 'CPython' -and $probe.major -eq 3 -and
            $probe.minor -ge 11 -and $probe.minor -le 14 -and $probe.bits -eq 64) { return $probe }
    }
    Stop-CoagenBootstrap 'PYTHON_UNAVAILABLE' 'Provide --python ABSOLUTE_python.exe for an existing Windows x64 CPython 3.11-3.14, or install one through the normal trusted Python distribution. No interpreter was installed or downloaded.'
}

function Invoke-CoagenBootstrap([string[]]$Tokens) {
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $options = @{}
    $forward = New-Object 'Collections.Generic.List[string]'
    for ($index = 0; $index -lt $Tokens.Count; $index++) {
        $token = $Tokens[$index]
        if ($token -in @('--zip', '--sha256', '--python', '--kit')) {
            if ($options.ContainsKey($token) -or $index + 1 -ge $Tokens.Count -or $Tokens[$index + 1].StartsWith('--')) {
                Stop-CoagenBootstrap 'BOOTSTRAP_ARGUMENT_INVALID' 'Supply each bootstrap option once, followed by its complete value.'
            }
            $options[$token] = $Tokens[++$index]
        } else { $forward.Add($token) }
    }
    if ($forward.Count -eq 0) { $forward.Add('install') }
    if ($forward[0] -notin @('install', 'doctor', 'diagnose', 'resume', 'rollback')) {
        Stop-CoagenBootstrap 'BOOTSTRAP_ARGUMENT_INVALID' 'Choose install, doctor, diagnose, resume or rollback; install previews unless --apply is specified.'
    }
    if (($options.ContainsKey('--zip') -ne $options.ContainsKey('--sha256')) -or
        ($options.ContainsKey('--zip') -and $options.ContainsKey('--kit'))) {
        Stop-CoagenBootstrap 'TRUSTED_ZIP_REQUIRED' 'Use either a complete extracted --kit directory or --zip ABSOLUTE_RELEASE.zip with --sha256 TRUSTED_64_HEX_DIGEST.'
    }
    $kit = if ($options.ContainsKey('--zip')) { Expand-CoagenTrustedZip $options['--zip'] $options['--sha256'] }
           elseif ($options.ContainsKey('--kit')) { Get-CoagenAbsolutePath $options['--kit'] 'KIT_PATH_INVALID' 'Container' }
           else { $script:CoagenBootstrapRoot }
    Assert-CoagenKit $kit
    $seenPaths = New-Object 'Collections.Generic.HashSet[string]'
    for ($index = 1; $index -lt $forward.Count; $index++) {
        if ($forward[$index] -in @('--workspace', '--home', '--runtime', '--host-exe', '--report', '--receipt')) {
            $option = $forward[$index]
            $code = if ($option -eq '--workspace') { 'WORKSPACE_INVALID' } else { 'ARGUMENT_PATH_INVALID' }
            if (-not $seenPaths.Add($option) -or $index + 1 -ge $forward.Count) {
                Stop-CoagenBootstrap $code 'Supply each path option exactly once with an actual absolute path.'
            }
            $kind = if ($option -eq '--workspace') { 'Container' }
                    elseif ($option -in @('--host-exe', '--report', '--receipt')) { 'Leaf' } else { '' }
            $forward[$index + 1] = Get-CoagenAbsolutePath $forward[$index + 1] $code $kind
            $index++
        }
    }
    if (-not $seenPaths.Contains('--workspace') -and -not $seenPaths.Contains('--report') -and $forward[0] -ne 'rollback') {
        $workspace = Get-CoagenAbsolutePath (Get-Location).Path 'WORKSPACE_INVALID' 'Container'
        $forward.Add('--workspace'); $forward.Add($workspace)
    }
    $python = Get-CoagenPython $options['--python']
    [Console]::Error.WriteLine((@{event='bootstrap_ready'; kit_version='multi-agent-kit-r13';
        python_version=('3.' + $python.minor); elapsed_ms=$watch.ElapsedMilliseconds} | ConvertTo-Json -Compress))
    $invokeArgs = @('-I', '-X', 'utf8', (Join-Path $kit 'coagen_install.py')) + $forward.ToArray()
    & $python.path @invokeArgs
    return $LASTEXITCODE
}

function Start-CoagenBootstrap([string[]]$Tokens) {
    try {
        # Keep child stdout untouched; function success output is forwarded by the
        # invocation, while its numeric exit status is stored separately.
        $script:CoagenExit = 0
        Invoke-CoagenBootstrap $Tokens | ForEach-Object {
            if ($_ -is [int]) { $script:CoagenExit = $_ } else { Write-Output $_ }
        }
        exit $script:CoagenExit
    } catch {
        $code = 'BOOTSTRAP_IO_ERROR'
        $next = 'Stop and report this code. Check the explicitly supplied paths and normal file permissions; do not run private writers or configuration probes.'
        if ($_.Exception.Data.Contains('coagen_code')) {
            $code = $_.Exception.Data['coagen_code']; $next = $_.Exception.Data['next_action']
        }
        @{ok=$false; status='failed'; stage='bootstrap'; code=$code; next_action=$next;
          native_mcp_verified=$false} | ConvertTo-Json -Compress
        exit 1
    }
}

if ($MyInvocation.InvocationName -ne '.') { Start-CoagenBootstrap $args }
