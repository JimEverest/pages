"""Coagen installer platform facts. Standard library only; no network, no writes.

One module answers every OS-dependent question for the installer and the
client bundle: which offline target this interpreter needs, whether that
combination is supported (and why not), where the per-user runtime lives,
which file is the venv interpreter, which ancestor process looks like a known
host, and whether a symbolic link in a path is a trusted system alias.
"""
import json
import os
from pathlib import Path
import platform
import re
import stat
import struct
import subprocess
import sys
import sysconfig

PYTHON_MIN = (3, 11)
PYTHON_MAX = (3, 14)

# Offline wheelhouse targets. ``pip`` lists the platform tags used when the
# release builder downloads hash-locked wheels for that target; the minimum
# system versions follow from the oldest tag of the native dependencies
# (cryptography, cffi, psutil). Keep this table and the support matrix in
# docs/coagen/platform-support.md together.
TARGETS = {
    'windows-x86_64': {'os': 'windows', 'arch': 'x86_64', 'pip': ['win_amd64'], 'minimum': 'Windows 10 x64'},
    'linux-x86_64-glibc': {'os': 'linux', 'arch': 'x86_64', 'libc': 'glibc', 'pip': ['manylinux2014_x86_64'],
                           'minimum': 'glibc 2.17', 'min_libc': (2, 17)},
    'linux-aarch64-glibc': {'os': 'linux', 'arch': 'aarch64', 'libc': 'glibc', 'pip': ['manylinux2014_aarch64'],
                            'minimum': 'glibc 2.17', 'min_libc': (2, 17)},
    'linux-x86_64-musl': {'os': 'linux', 'arch': 'x86_64', 'libc': 'musl', 'pip': ['musllinux_1_2_x86_64'],
                          'minimum': 'musl 1.2', 'min_libc': (1, 2)},
    'linux-aarch64-musl': {'os': 'linux', 'arch': 'aarch64', 'libc': 'musl', 'pip': ['musllinux_1_2_aarch64'],
                           'minimum': 'musl 1.2', 'min_libc': (1, 2)},
    'macos-arm64': {'os': 'macos', 'arch': 'arm64', 'pip': ['macosx_11_0_arm64'], 'minimum': 'macOS 11'},
}

# Known gaps, with the concrete reason and a usable alternative.
UNSUPPORTED = {
    ('macos', 'x86_64'): ('cryptography 50.0.1 publishes no macOS x86_64 wheel; Coagen installs binary wheels only.',
                          'Use a native arm64 CPython on Apple silicon. Intel Macs are not supported by this release.'),
    ('windows', 'arm64'): ('cryptography 50.0.1 publishes no Windows ARM64 wheel.',
                           'Install the x64 build of CPython 3.11-3.14 (it runs under Windows ARM64 emulation) and use the windows-x86_64 kit.'),
}


def _arch(machine):
    value = machine.lower()
    return {'amd64': 'x86_64', 'x64': 'x86_64', 'x86_64': 'x86_64', 'arm64': 'arm64',
            'aarch64': 'aarch64'}.get(value, value)


def _elf_interpreter(executable):
    """Return the PT_INTERP path of an ELF executable, or None."""
    try:
        with open(executable, 'rb') as stream:
            ident = stream.read(16)
            if ident[:4] != b'\x7fELF':
                return None
            wide, endian = ident[4] == 2, '<' if ident[5] == 1 else '>'
            header = stream.read(48 if wide else 36)
            if wide:
                phoff, = struct.unpack(endian + 'Q', header[16:24])
                phentsize, phnum = struct.unpack(endian + 'HH', header[38:42])
            else:
                phoff, = struct.unpack(endian + 'I', header[12:16])
                phentsize, phnum = struct.unpack(endian + 'HH', header[26:30])
            for index in range(min(phnum, 64)):
                stream.seek(phoff + index * phentsize)
                entry = stream.read(phentsize)
                if struct.unpack(endian + 'I', entry[:4])[0] != 3:  # PT_INTERP
                    continue
                if wide:
                    offset, size = struct.unpack(endian + 'Q', entry[8:16])[0], struct.unpack(endian + 'Q', entry[32:40])[0]
                else:
                    offset, size = struct.unpack(endian + 'I', entry[4:8])[0], struct.unpack(endian + 'I', entry[16:20])[0]
                stream.seek(offset)
                return stream.read(min(size, 4096)).rstrip(b'\0').decode('ascii', 'replace')
    except (OSError, struct.error, IndexError):
        return None
    return None


def _version(text):
    match = re.search(r'(\d+)\.(\d+)', text or '')
    return (int(match.group(1)), int(match.group(2))) if match else None


def libc():
    """Return (family, (major, minor)) for Linux; (None, None) elsewhere."""
    if not sys.platform.startswith('linux'):
        return None, None
    try:
        glibc = os.confstr('CS_GNU_LIBC_VERSION')
    except (AttributeError, ValueError, OSError):
        glibc = None
    if glibc and glibc.startswith('glibc'):
        return 'glibc', _version(glibc)
    interpreter = _elf_interpreter(sys.executable) or ''
    if 'musl' in interpreter or 'musl' in (sysconfig.get_config_var('HOST_GNU_TYPE') or ''):
        version = None
        if interpreter and Path(interpreter).is_file():
            try:
                # The musl loader prints its version on stderr when run directly.
                probe = subprocess.run([interpreter], capture_output=True, timeout=5)
                version = _version(probe.stderr.decode('utf-8', 'replace'))
            except (OSError, subprocess.SubprocessError):
                version = None
        return 'musl', version
    return 'unknown', None


def identity():
    """Describe this interpreter and OS without reading user data."""
    system = 'windows' if sys.platform == 'win32' else 'macos' if sys.platform == 'darwin' else (
        'linux' if sys.platform.startswith('linux') else sys.platform)
    if system == 'windows':
        arch = {'win-amd64': 'x86_64', 'win-arm64': 'arm64', 'win32': 'x86'}.get(sysconfig.get_platform(), sysconfig.get_platform())
    else:
        arch = _arch(platform.machine())
    family, version = libc()
    gil_disabled = bool(sysconfig.get_config_var('Py_GIL_DISABLED'))
    value = {
        'os': system, 'arch': arch, 'libc': family,
        'libc_version': '.'.join(map(str, version)) if version else None,
        'os_release': platform.release() if system != 'macos' else platform.mac_ver()[0],
        'python': {'implementation': platform.python_implementation(), 'version': platform.python_version(),
                   'abi': 'cp%d%d%s' % (*sys.version_info[:2], 't' if gil_disabled else ''),
                   'pointer_bits': struct.calcsize('P') * 8, 'free_threaded': gil_disabled,
                   'executable': sys.executable},
    }
    value['target'] = target_for(value)
    return value


def target_for(value):
    if value['os'] == 'linux':
        return 'linux-%s-%s' % (value['arch'], value['libc'])
    return '%s-%s' % (value['os'], value['arch'])


def support(value, kit_targets=None, source='offline'):
    """Return None if supported, otherwise a structured, actionable failure."""
    python = value['python']
    if python['implementation'] != 'CPython':
        return _failure('PYTHON_IMPLEMENTATION_UNSUPPORTED', value,
                        python['implementation'] + ' is not supported; native dependencies are locked for CPython.',
                        'Use CPython 3.11-3.14 from python.org, the OS package manager or Homebrew.')
    version = tuple(int(x) for x in python['version'].split('.')[:2])
    if not PYTHON_MIN <= version <= PYTHON_MAX:
        return _failure('PYTHON_VERSION_UNSUPPORTED', value,
                        'Python %s is outside the tested 3.11-3.14 range.' % python['version'],
                        'Select an existing CPython 3.11-3.14 with COAGEN_INSTALL_PYTHON=/path/to/python3.x, or install one; the installer does not install Python.')
    if python['free_threaded']:
        return _failure('PYTHON_FREE_THREADED_UNSUPPORTED', value,
                        'Free-threaded CPython builds are not part of the tested release matrix.',
                        'Use the standard (GIL) CPython build of the same version.')
    if python['pointer_bits'] != 64:
        return _failure('PYTHON_ARCHITECTURE_UNSUPPORTED', value,
                        '32-bit Python is not supported.', 'Use a 64-bit CPython build.')
    known = UNSUPPORTED.get((value['os'], value['arch']))
    if known:
        return _failure('PLATFORM_UNSUPPORTED', value, *known)
    if value['target'] not in TARGETS:
        return _failure('PLATFORM_UNSUPPORTED', value,
                        'No locked binary dependencies exist for %s.' % value['target'],
                        'Supported targets: ' + ', '.join(sorted(TARGETS)) + '. See docs/coagen/platform-support.md.')
    rule = TARGETS[value['target']]
    if 'min_libc' in rule and value['libc_version']:
        if _version(value['libc_version']) < rule['min_libc']:
            return _failure('LIBC_TOO_OLD', value, '%s requires %s; found %s %s.' % (
                value['target'], rule['minimum'], value['libc'], value['libc_version']),
                'Use a newer Linux distribution or container image.')
    if source == 'offline' and kit_targets is not None and value['target'] not in kit_targets:
        return _failure('KIT_PLATFORM_MISMATCH', value,
                        'This offline kit contains dependencies for %s, but this interpreter needs %s.' % (
                            ', '.join(kit_targets) or 'no platform', value['target']),
                        'Download coagen-<version>-kit-<revision>-%s.zip and its .sha256, or use --source online with network access.' % value['target'])
    return None


def _failure(code, value, reason, action):
    return {'ok': False, 'code': code, 'stage': 'platform', 'reason': reason, 'next_action': action,
            'detected': {key: value[key] for key in ('os', 'arch', 'libc', 'libc_version', 'target')} |
                        {'python': value['python']['version'], 'abi': value['python']['abi']},
            'retry_allowed': False}


def system_name():
    return 'windows' if sys.platform == 'win32' else 'macos' if sys.platform == 'darwin' else 'linux'


def runtime_base(home, real_home=True, environ=None):
    """Per-user versioned runtime root. ``real_home=False`` keeps tests inside home."""
    environ = os.environ if environ is None else environ
    system = system_name()
    if system == 'windows':
        local = environ.get('LOCALAPPDATA') if real_home else None
        return Path(local) / 'Coagen/runtimes' if local else Path(home) / 'AppData/Local/Coagen/runtimes'
    if system == 'macos':
        return Path(home) / 'Library/Application Support/Coagen/runtimes'
    data = environ.get('XDG_DATA_HOME') if real_home else None
    if data and Path(data).is_absolute():
        return Path(data) / 'coagen/runtimes'
    return Path(home) / '.local/share/coagen/runtimes'


def venv_python(runtime):
    return Path(runtime) / ('Scripts/python.exe' if system_name() == 'windows' else 'bin/python')


def trusted_system_link(path, info=None):
    """True only for a POSIX symlink that just the system administrator can change.

    The link must be owned by root and live in a root-owned directory that other
    users cannot modify (sticky directories such as /tmp qualify, because only
    the link owner may replace an entry). When Coagen itself runs as root, only
    top-level aliases are trusted. Examples: macOS /var -> private/var,
    /tmp -> private/tmp, and Linux layouts such as /home -> /var/home. A link
    created by the user, or anywhere the user could re-point it, is never
    trusted. Windows reparse points keep their existing fail-closed handling.
    """
    if os.name == 'nt':
        return False
    try:
        info = info or os.lstat(path)
        if not stat.S_ISLNK(info.st_mode) or info.st_uid != 0:
            return False
        # Ancestors are validated first by every caller, so follow them here.
        parent = os.stat(Path(path).parent)
    except OSError:
        return False
    mode = parent.st_mode
    if os.geteuid() == 0 and Path(path).parent != Path('/'):
        # For root every self-made link is root-owned; trust only top-level layout aliases.
        return False
    return (stat.S_ISDIR(mode) and parent.st_uid == 0 and
            (not mode & (stat.S_IWGRP | stat.S_IWOTH) or bool(mode & stat.S_ISVTX)))


def untrusted_link(path):
    """True for a link/reparse point that Coagen must not write through."""
    try:
        info = os.lstat(path)
    except (FileNotFoundError, NotADirectoryError):
        return False
    if stat.S_ISLNK(info.st_mode):
        return not trusted_system_link(path, info)
    return bool(getattr(info, 'st_file_attributes', 0) & 0x400)


# Ancestor process names that select a known configuration preset. A match
# only chooses a preset; an unknown or missing match falls back to generic.
POSIX_HOSTS = (
    ('claude', re.compile(r'(^|/)claude$'), re.compile(r'@anthropic-ai/claude-code')),
    ('codex', re.compile(r'(^|/)codex$'), re.compile(r'@openai/codex')),
    ('dsh', None, re.compile(r'@deepseek-ai/dsh/.*bin\.js')),
)


def _posix_parent(pid):
    """Return (ppid, executable, argv) for pid without psutil."""
    if sys.platform.startswith('linux'):
        proc = Path('/proc') / str(pid)
        text = (proc / 'stat').read_text(encoding='utf-8', errors='replace')
        ppid = int(text[text.rindex(')') + 2:].split()[1])
        try:
            exe = os.readlink(proc / 'exe')
        except OSError:
            exe = ''
        argv = (proc / 'cmdline').read_bytes().split(b'\0')
        return ppid, exe, [x.decode('utf-8', 'replace') for x in argv if x]
    result = subprocess.run(['ps', '-o', 'ppid=', '-o', 'comm=', '-p', str(pid)], capture_output=True, timeout=5)
    line = result.stdout.decode('utf-8', 'replace').strip()
    if result.returncode or not line:
        raise OSError('process not visible')
    ppid, _, comm = line.partition(' ')
    args = subprocess.run(['ps', '-o', 'args=', '-p', str(pid)], capture_output=True, timeout=5)
    return int(ppid), comm.strip(), args.stdout.decode('utf-8', 'replace').split()


def posix_host_candidates(start=None, limit=32):
    """Walk ancestors and return [{'host', 'executable'}]; never returns argv."""
    rows, seen, pid = [], set(), start or os.getppid()
    for _ in range(limit):
        if pid <= 1 or pid in seen:
            break
        seen.add(pid)
        try:
            ppid, exe, argv = _posix_parent(pid)
        except (OSError, ValueError, IndexError, subprocess.SubprocessError):
            break
        joined = ' '.join(argv)
        for host, name, script in POSIX_HOSTS:
            if (name and (name.search(exe) or (argv and name.search(argv[0])))) or (script and script.search(joined)):
                rows.append({'host': host, 'executable': exe or (argv[0] if argv else '')})
                break
        pid = ppid
    return rows


if __name__ == '__main__':
    print(json.dumps(identity(), indent=2))
