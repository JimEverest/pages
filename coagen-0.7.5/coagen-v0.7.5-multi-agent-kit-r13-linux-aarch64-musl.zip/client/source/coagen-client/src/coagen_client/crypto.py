"""SPAKE2 pairing and confirmed, directional AES-GCM sessions.

No secret is serialized. Callers persist and retry the ORIGINAL ciphertext;
they must not recreate a cipher after a process restart to resume a session.
Expiry, authorization and durable acknowledgement belong to the session layer.
"""
from __future__ import annotations

import hashlib
import json
import threading

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from spake2 import SPAKE2_A, SPAKE2_B
from spake2.spake2 import SPAKEError

PROTOCOL = "coagen/1-spake2-ed25519-aes256gcm"
MAX_PLAINTEXT_BYTES = 16 * 1024 * 1024 - 16
MAX_METADATA_BYTES = 16 * 1024
MAX_MESSAGES = 100_000


class CryptoError(ValueError):
    """An invalid or unauthenticated protocol object was refused."""


class ReplayError(CryptoError):
    """A sequence was reused; retry the original transport object instead."""


class StateError(CryptoError):
    """An operation is incompatible with the current ephemeral session."""


def _canonical(value: dict) -> bytes:
    if not isinstance(value, dict):
        raise CryptoError("Metadata must be a JSON object")
    pending = [(value, 0)]
    visited = set()
    while pending:
        item, depth = pending.pop()
        if depth > 32:
            raise CryptoError("Metadata nesting exceeds limit")
        if isinstance(item, (dict, list)):
            if id(item) in visited:
                raise CryptoError("Metadata must not contain cyclic or shared containers")
            visited.add(id(item))
            if isinstance(item, dict):
                if any(not isinstance(key, str) for key in item):
                    raise CryptoError("Metadata keys must be strings")
                children = item.values()
            else:
                children = item
            pending.extend((child, depth + 1) for child in children)
    try:
        result = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        raise CryptoError("Metadata is not valid JSON") from exc
    if len(result) > MAX_METADATA_BYTES:
        raise CryptoError("Metadata exceeds 16 KiB")
    return result


def _nonce(sequence: int) -> bytes:
    if type(sequence) is not int or not 1 <= sequence < 2**64:
        raise CryptoError("Sequence must be an integer in [1, 2^64)")
    return bytes(4) + sequence.to_bytes(8, "big")


class Pairing:
    """One-use asymmetric SPAKE2 exchange. Role A creates; role B joins.

    Production context must contain server_session_id, peer_a and peer_b so
    a relay cannot rebind an authenticated exchange to other identities.
    """

    def __init__(self, secret: str | bytes, room_id: str, role: str, *, context: dict | None = None):
        if role not in ("A", "B"):
            raise CryptoError("Role must be A or B")
        if not isinstance(room_id, str) or not room_id or len(room_id) > 256:
            raise CryptoError("Room identifier is invalid")
        if isinstance(secret, str):
            secret = secret.encode("utf-8")
        if not isinstance(secret, bytes) or not 1 <= len(secret) <= 1024:
            raise CryptoError("Pairing secret must be 1 to 1024 bytes")
        self._context = _canonical({"protocol": PROTOCOL, "room_id": room_id, "context": context if context is not None else {}})
        self._role = role
        identity_a = self._context + b"\x00A"
        identity_b = self._context + b"\x00B"
        cls = SPAKE2_A if role == "A" else SPAKE2_B
        self._spake = cls(secret, idA=identity_a, idB=identity_b)
        self._outbound = None
        self._finished = False

    def __reduce_ex__(self, _protocol):
        raise TypeError("Pairing secrets cannot be serialized")

    def start(self) -> bytes:
        if self._outbound is not None or self._finished:
            raise StateError("Pairing can start only once")
        self._outbound = self._spake.start()
        return self._outbound

    def finish(self, peer_message: bytes) -> SessionCipher:
        if self._outbound is None or self._finished:
            raise StateError("Pairing must start and may finish only once")
        self._finished = True
        try:
            if not isinstance(peer_message, bytes) or len(peer_message) != 33:
                raise CryptoError("Invalid pairing message")
            shared = self._spake.finish(peer_message)
            a, b = (self._outbound, peer_message) if self._role == "A" else (peer_message, self._outbound)
            transcript = hashlib.sha256(self._context + b"\x00" + a + b).digest()
            material = HKDF(algorithm=hashes.SHA256(), length=128, salt=transcript, info=b"coagen/1 directional data and confirmation keys").derive(shared)
            return SessionCipher(self._role, transcript.hex(), material)
        except (SPAKEError, ValueError, AssertionError) as exc:
            raise CryptoError("Pairing message was rejected") from exc
        finally:
            self._spake = None

    def close(self):
        self._spake = None
        self._finished = True


class SessionCipher:
    """Ephemeral keys with explicit peer confirmation and replay tracking.

    Send sequences strictly increase. Receive sequences may arrive out of order;
    successful ones are remembered until close. Durable duplicate transport
    delivery is handled by the caller's inbox before invoking decrypt again.
    """

    def __init__(self, role: str, session_id: str, material: bytes):
        self.session_id = session_id
        self._role = role
        self._peer_role = "B" if role == "A" else "A"
        ab, ba, ca, cb = (material[index:index + 32] for index in range(0, 128, 32))
        tx, rx, confirm_tx, confirm_rx = (ab, ba, ca, cb) if role == "A" else (ba, ab, cb, ca)
        self._tx = AESGCM(tx)
        self._rx = AESGCM(rx)
        self._confirm_rx = AESGCM(confirm_rx)
        self._proof = AESGCM(confirm_tx).encrypt(bytes(12), b"coagen/1 key confirmation", self._confirmation_aad(role))
        self._confirmed = False
        self._closed = False
        self._last_sent = 0
        self._sent_count = 0
        self._received = set()
        self._lock = threading.Lock()

    def __reduce_ex__(self, _protocol):
        raise TypeError("Session keys cannot be serialized")

    def _confirmation_aad(self, role):
        return (PROTOCOL + "\x00" + self.session_id + "\x00confirmation\x00" + role).encode("ascii")

    def _require_open(self, *, confirmed=False):
        if self._closed or (confirmed and not self._confirmed):
            raise StateError("Session is closed or peer confirmation is incomplete")

    def confirmation(self) -> bytes:
        with self._lock:
            self._require_open()
            return self._proof

    def verify_confirmation(self, peer_proof: bytes) -> None:
        with self._lock:
            self._require_open()
            try:
                if not isinstance(peer_proof, bytes) or len(peer_proof) != len(self._proof):
                    raise CryptoError("Invalid key confirmation")
                result = self._confirm_rx.decrypt(bytes(12), peer_proof, self._confirmation_aad(self._peer_role))
                if result != b"coagen/1 key confirmation":
                    raise CryptoError("Invalid key confirmation")
            except (InvalidTag, CryptoError) as exc:
                self._close_unlocked()
                raise CryptoError("Peer key confirmation failed") from exc
            self._confirmed = True

    def _aad(self, sequence, metadata, role):
        encoded = _canonical(metadata)
        header = _canonical({"protocol": PROTOCOL, "session_id": self.session_id, "direction": role, "sequence": sequence})
        return header + b"\x00" + encoded

    def encrypt(self, plaintext: bytes, *, sequence: int, metadata: dict) -> bytes:
        with self._lock:
            self._require_open(confirmed=True)
            nonce = _nonce(sequence)
            if sequence <= self._last_sent:
                raise ReplayError("Send sequence was already consumed")
            if self._sent_count >= MAX_MESSAGES:
                raise StateError("Session message limit reached; establish a new session")
            if not isinstance(plaintext, bytes) or len(plaintext) > MAX_PLAINTEXT_BYTES:
                raise CryptoError("Plaintext exceeds the message limit")
            aad = self._aad(sequence, metadata, self._role)
            self._last_sent = sequence
            self._sent_count += 1
            return self._tx.encrypt(nonce, plaintext, aad)

    def decrypt(self, ciphertext: bytes, *, sequence: int, metadata: dict) -> bytes:
        with self._lock:
            self._require_open(confirmed=True)
            nonce = _nonce(sequence)
            if sequence in self._received:
                raise ReplayError("Receive sequence was already accepted")
            if len(self._received) >= MAX_MESSAGES:
                raise StateError("Session message limit reached; establish a new session")
            if not isinstance(ciphertext, bytes) or not 16 <= len(ciphertext) <= MAX_PLAINTEXT_BYTES + 16:
                raise CryptoError("Ciphertext size is invalid")
            try:
                plaintext = self._rx.decrypt(nonce, ciphertext, self._aad(sequence, metadata, self._peer_role))
            except InvalidTag as exc:
                raise CryptoError("Message authentication failed") from exc
            self._received.add(sequence)
            return plaintext

    def _close_unlocked(self):
        self._closed = True
        self._confirmed = False
        self._tx = self._rx = self._confirm_rx = self._proof = None
        self._received.clear()

    def close(self):
        with self._lock:
            self._close_unlocked()
