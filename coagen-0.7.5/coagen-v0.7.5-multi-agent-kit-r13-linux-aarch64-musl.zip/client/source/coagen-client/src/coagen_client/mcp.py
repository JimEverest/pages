"""Small stdio MCP bridge for Coagen rooms.

The bridge talks to its local Python session helper. Any standard MCP host
starts this process over stdio, so routine Coagen operations do not appear as
shell commands. It deliberately implements only the MCP JSON-RPC surface needed
by this client and never prints diagnostics to stdout.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import sys
import threading
import time
import uuid

import psutil

from . import cli
from .observe import log
from .errors import CoagenError, classify_error
from .diagnostics import Diagnostics
from .store import _unlinked_path
from .agent_info import resolve_agent_info
from . import local_ops

TRANSIENT_WATCH_CODES = frozenset({'HUB_UNAVAILABLE', 'RATE_LIMITED', 'RETRY_NOT_DUE'})
LOG_LEVELS = ('debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency')
NOTIFICATION_CONTRACT = {'protocol': 'notifications/message', 'metadata_only': True,
                         'model_wakeup_guaranteed': False,
                         'host_action': 'Use a supported host notification callback or an authorized session scheduler to invoke coagen_watch; notification delivery alone does not start a model turn.'}


def _text(value):
    return {'content': [{'type': 'text', 'text': json.dumps(value, ensure_ascii=False)}]}


def _tool(name, description, properties=None, required=None):
    return {'name': name, 'description': description,
            'inputSchema': {'type': 'object', 'properties': properties or {},
                            'required': required or [], 'additionalProperties': False}}


TOOLS = [
    _tool('coagen_prepare', 'Inspect local installation and process ownership; no network or credentials.'),
    _tool('coagen_create', 'Create a group room by default (2–8 members, vanilla), or claim a reservation with its existing settings. Open group rooms permit fresh same-code rejoining. Basic is explicit legacy one-shot compatibility. Returns the eight-digit pairing code once.',
          {'state_dir': {'type': 'string'}, 'ttl': {'type': 'integer', 'minimum': 300, 'maximum': 21600},
           'label': {'type': 'string', 'maxLength': 128},
           'room_mode': {'type': 'string', 'enum': ['basic', 'group'], 'default': 'group'},
           'max_members': {'type': 'integer', 'minimum': 2, 'maximum': 8, 'default': 8},
           'mode': {'type': 'string', 'enum': ['vanilla', 'brainstorm', 'leader-led', 'round-robin'], 'default': 'vanilla'},
           'brainstorm_policy': {'type': 'string', 'enum': ['soft', 'strict'], 'description': 'New brainstorm defaults to soft: completion coordinates phases without muting corrections.'},
           'reservation_code': {'type': 'string', 'pattern': '^[A-Za-z0-9_-]{43}$',
                                'description': 'One-use administrator-issued reservation activation; ttl is ignored when claiming.'}}, []),
    _tool('coagen_join', 'Join with the user-authorized eight-digit code. After a confirmed membership end, an open group room allows same-code fresh membership and keys, without restoring identity, leadership or inbox. Never repeat an unknown-outcome join or replace an active binding. The code never enters a shell command.',
          {'code': {'type': 'string', 'pattern': '^[0-9]{8}$'}, 'state_dir': {'type': 'string'}}, ['code']),
    _tool('coagen_status', 'Read compact phase, lease, pending inbox and policy capabilities. Full incident history is opt-in.',
          {'detail': {'type': 'string', 'enum': ['compact', 'full']}}),
    _tool('coagen_watch', 'Wait up to 60 seconds for pending unconsumed messages. Cursor is per local session; it does not consume or mark business completion.',
          {'wait_seconds': {'type': 'number', 'minimum': 1, 'maximum': 60},
           'after_cursor': {'type': 'integer', 'minimum': 0}, 'max_messages': {'type': 'integer', 'minimum': 1, 'maximum': 100},
           'summary': {'type': 'boolean', 'description': 'Return short previews; use coagen_read_message for full content.'}}),
    _tool('coagen_receive', 'Receive and authenticate pending capsules now, optionally waiting up to 20 seconds.',
          {'wait_seconds': {'type': 'number', 'minimum': 0, 'maximum': 20},
           'after_cursor': {'type': 'integer', 'minimum': 0}, 'max_messages': {'type': 'integer', 'minimum': 1, 'maximum': 100},
           'summary': {'type': 'boolean'}}),
    _tool('coagen_send', 'Send exactly one body: inline text OR an existing UTF-8 README file path. Text does not require matching chat/workspace paths. Files remain restricted to attachment roots.',
          {'text': {'type': 'string', 'description': 'Inline body, mutually exclusive with readme_path/readme.'},
           'readme_path': {'type': 'string', 'description': 'Absolute existing UTF-8 file path under attachment roots; never inline text.'},
           'readme': {'type': 'string', 'description': 'Deprecated alias of readme_path: absolute FILE PATH, not body text.'},
           'files': {'type': 'array', 'items': {'type': 'string'}, 'description': 'Absolute existing file/directory paths under attachment roots.'},
           'kind': {'type': 'string'}, 'ext': {'type': 'object'}, 'request_id': {'type': 'string'},
           'recipient_id': {'type': 'string'}, 'broadcast': {'type': 'boolean'}}),
    _tool('coagen_collaboration', 'Explicitly configure, advance, pause, resume or finish group collaboration. ACK and consume never advance a turn. Read status for the current revision.',
          {'action': {'type': 'string', 'enum': ['configure', 'advance', 'pause', 'resume', 'finish', 'reopen']},
           'expected_revision': {'type': 'integer', 'minimum': 1}, 'request_id': {'type': 'string'},
           'mode': {'type': 'string', 'enum': ['vanilla', 'brainstorm', 'leader-led', 'round-robin']},
           'brainstorm_policy': {'type': 'string', 'enum': ['soft', 'strict']},
           'target_peer_id': {'type': 'string', 'description': 'Reopen contribution of this member; defaults to self, others require leader/admin.'},
           'leader_peer_id': {'type': 'string'}, 'max_turns': {'type': 'integer', 'minimum': 1, 'maximum': 256}},
          ['action', 'expected_revision', 'request_id']),
    _tool('coagen_retry_send', 'Retry only the saved original encrypted packet within its persisted recovery budget.',
          {'request_id': {'type': 'string'}}, ['request_id']),
    _tool('coagen_consume', 'Consume a processed message after preserving required results.',
          {'message_id': {'type': 'string', 'pattern': '^[0-9a-f]{32}$'}}, ['message_id']),
    _tool('coagen_message_status', 'Query Hub stored/receiver ACK/consumed receipt. ACK is local receiver storage, never model-read or business completion.',
          {'message_ids': {'type': 'array', 'minItems': 1, 'maxItems': 100,
                           'items': {'type': 'string', 'pattern': '^[0-9a-f]{32}$'}}}, ['message_ids']),
    _tool('coagen_read_message', 'Read one authenticated local inbox message without consuming it; large text can be paged.',
          {'message_id': {'type': 'string', 'pattern': '^[0-9a-f]{32}$'},
           'offset': {'type': 'integer', 'minimum': 0}, 'max_chars': {'type': 'integer', 'minimum': 1, 'maximum': 8388608}}, ['message_id']),
    _tool('coagen_export', 'Durably export a verified inbox message to dest_dir/message_id within attachment roots. Verifies hashes; never overwrites altered exports. Optional consume is journaled after saving.',
          {'message_id': {'type': 'string', 'pattern': '^[0-9a-f]{32}$'}, 'dest_dir': {'type': 'string'},
           'consume': {'type': 'boolean', 'description': 'Default false. Only true after task processing and authorization to consume.'}}, ['message_id', 'dest_dir']),
    _tool('coagen_sessions', 'List bounded local session audit summaries, without credentials or restoring any session.',
          {'limit': {'type': 'integer', 'minimum': 1, 'maximum': 100}}),
    _tool('coagen_audit', 'Read metadata-only local history. session_id comes from coagen_sessions; no active room or rejoin required.',
          {'session_id': {'type': 'string'}, 'limit': {'type': 'integer', 'minimum': 1, 'maximum': 1000},
           'since': {'type': 'number', 'minimum': 0}}),
    _tool('coagen_stop', 'Stop this session after preserving results. Basic closes its room; group leaves only this membership.'),
    _tool('coagen_resume', 'Continue a live group membership left by an earlier MCP process of this agent (host restart, idle shutdown, reconnect). Keeps identity, keys, leadership and inbox; no code is needed. A single matching session is resumed automatically; use this when several are listed in resumable_sessions.',
          {'session_id': {'type': 'string', 'pattern': '^[A-Za-z0-9_-]{1,80}$'}}, ['session_id']),
    _tool('coagen_network_check', 'Diagnose Hub reachability layer by layer (DNS, direct TCP, TLS certificate, HTTP /health through the client proxy settings) and name the first failing layer with concrete checks. No credentials or rooms are used.'),
]


class McpServer:
    def __init__(self, *, workspace=None, owner_pid=None, hub=None, state_dir=None,
                 agent_name=None, agent_version=None):
        self.workspace = Path(workspace or os.getcwd()).resolve()
        self.binding_scope = 'explicit_owner' if owner_pid is not None else 'mcp_instance'
        self.owner_pid = int(owner_pid) if owner_pid is not None else os.getpid()
        self.instance_id = uuid.uuid4().hex
        self._agent_name, self._agent_version = agent_name, agent_version
        self.agent_info = resolve_agent_info(agent_name, agent_version)
        self._closed = False
        self.hub = hub or os.environ.get('COAGEN_MCP_HUB', cli.DEFAULT_HUB)
        self.state_dir = Path(state_dir).resolve() if state_dir else None
        self._check_state_binding(self.state_dir)
        try:
            owner_started = psutil.Process(self.owner_pid).create_time()
        except psutil.Error:
            owner_started = 'unavailable'
        # A stable, non-secret identity keeps an uncertain establishment blocked
        # across bridge restarts without adopting another agent's diagnostics.
        identity_text = f'{self.workspace}\0{self.owner_pid}\0{owner_started}'
        if self.binding_scope == 'mcp_instance':
            identity_text += '\0' + self.instance_id
        identity = hashlib.sha256(identity_text.encode('utf-8')).hexdigest()
        self.diagnostic_root = cli.state_base() / 'bridges' / identity
        self.diagnostics = Diagnostics(self.diagnostic_root)
        self._generated_request_id = None
        self._operation_key = None
        self._notifications_initialized = False
        self._log_level = 'notice'
        self._notice_state = None
        self._notice_inbox = None
        self._notice_incidents = {}
        self._notice_phase = None
        self.auto_resume = os.environ.get('COAGEN_AUTO_RESUME', '1').strip().lower() not in ('0', 'false', 'no', 'off')
        self._resume_checked = False
        self._resume_notice = None
        self._resume_choices = []

    def _args(self, **values):
        defaults = {'hub': self.hub, 'state_dir': str(self.state_dir) if self.state_dir else None,
                    'owner_pid': self.owner_pid, 'ttl': 3600, 'admin_token_file': None,
                    'code': None, 'code_stdin': False, 'non_interactive': True,
                    'reservation_code': None, 'reservation_code_stdin': False,
                    'agent_info': dict(self.agent_info),
                    'mcp_instance_id': self.instance_id if self.binding_scope == 'mcp_instance' else None,
                    'workspace': str(self.workspace),
                    'resume_grace_seconds': cli.resume_grace_seconds() if self.binding_scope == 'mcp_instance' else 0}
        defaults.update(values)
        return argparse.Namespace(**defaults)

    def _check_state_binding(self, path):
        if path is None or self.binding_scope != 'mcp_instance':
            return
        control = _unlinked_path(Path(path) / 'control.json')
        try:
            value = json.loads(control.read_text(encoding='utf-8'))
        except FileNotFoundError:
            return
        if (not isinstance(value, dict) or (not value.get('stopped') and
                (value.get('owner_pid') != self.owner_pid or value.get('mcp_instance_id') != self.instance_id))):
            raise ValueError('Local session belongs to another MCP instance.')

    def close(self):
        """Bounded best-effort IPC stop; process ownership and Hub lease back it up."""
        if self._closed:
            return
        self._closed = True
        if self.state_dir is None:
            return
        def stop():
            try:
                self._check_state_binding(self.state_dir)
                if self.binding_scope == 'mcp_instance':
                    # The host closed stdio: it may be restarting this server.
                    # A Group helper detaches and waits for the next instance
                    # (COAGEN_RESUME_GRACE_SECONDS); a Basic helper stops.
                    value = cli.call_local(self.state_dir, {'op': 'detach', 'mcp_instance_id': self.instance_id})
                    log.info('mcp_closed', state_dir=str(self.state_dir), detached=bool(value.get('detached')))
                else:
                    cli.call_local(self.state_dir, {'op': 'stop'})
            except Exception:
                pass  # Instance exit revokes the helper through its Owner watchdog.
        thread = threading.Thread(target=stop, daemon=True)
        thread.start()
        thread.join(timeout=3)

    def _resume_candidates(self):
        return local_ops.resumable(cli.state_base(), workspace=str(self.workspace),
                                   agent_name=self.agent_info.get('name'))

    def _adopt(self, candidate, *, automatic):
        owner_started = psutil.Process(self.owner_pid).create_time()
        path = Path(candidate['state_dir'])
        value = cli.call_local(path, {'op': 'adopt', 'owner_pid': self.owner_pid, 'owner_started_at': owner_started,
                                      'mcp_instance_id': self.instance_id, 'workspace': str(self.workspace),
                                      'agent_info': dict(self.agent_info)})
        self.state_dir = path
        self.diagnostics.retire_session()
        resumed = value.get('resumed') or {}
        self._resume_notice = {'resumed': True, 'automatic': automatic, 'session_id': candidate['session_id'],
                               'room_id': value.get('room_id'), 'label': value.get('label', ''),
                               'peer_id': value.get('peer_id'), 'phase': value.get('phase'), **resumed,
                               'note': 'The membership started by an earlier MCP process of this agent continues: same '
                                       'identity, pairwise keys, leadership and local inbox; no rejoin happened. Check '
                                       'coagen_watch for messages that arrived meanwhile.'}
        log.info('session_resumed', session_id=candidate['session_id'], automatic=automatic, room_id=value.get('room_id'))
        return value

    def _maybe_resume(self):
        """Once per instance: adopt the single live membership this agent left behind."""
        if self._resume_checked or self.state_dir is not None or self.binding_scope != 'mcp_instance':
            return
        self._resume_checked = True
        try:
            candidates = self._resume_candidates()
        except Exception as error:
            log.warning('resume_scan_failed', cause=classify_error(error, operation='resume', stage='local_state').cause)
            return
        self._resume_choices = candidates
        if not candidates or not self.auto_resume:
            return
        if len(candidates) > 1:
            log.info('resume_ambiguous', candidates=len(candidates))
            return
        try:
            self._adopt(candidates[0], automatic=True)
            self._resume_choices = []
        except Exception as error:
            typed = classify_error(error, operation='resume', stage='adopt')
            log.warning('resume_failed', code=typed.code, session_id=candidates[0]['session_id'])

    def _resume_view(self):
        if self._resume_notice:
            return {'session_resumed': self._resume_notice}
        if self._resume_choices:
            return {'resumable_sessions': self._resume_choices,
                    'resume_hint': 'Several live memberships from earlier MCP processes match this workspace. Ask the '
                                   'user which one to continue, then call coagen_resume(session_id).'}
        return {}

    def _state(self, arguments, operation='status'):
        value = arguments.get('state_dir') or self.state_dir
        if not value:
            raise CoagenError('NO_ACTIVE_SESSION', operation=operation, stage='local_state', phase='no_session')
        path = Path(value).resolve()
        self._check_state_binding(path)
        return path

    def _snapshot(self):
        return self.diagnostics.snapshot()

    @property
    def minimum_log_level(self):
        return self._log_level

    def poll_notifications(self):
        """Read local helper metadata. This never polls the Hub or reads a README."""
        if not self._notifications_initialized or self.state_dir is None:
            return []
        if self._notice_state != self.state_dir:
            self._notice_state = self.state_dir
            self._notice_inbox, self._notice_phase = None, None
            self._notice_incidents = {}
        try:
            self._check_state_binding(self.state_dir)
            monitor = cli.call_local(self.state_dir, {'op': 'status', 'local_only': True})
        except Exception as error:
            typed = classify_error(error, operation='status', stage='local_helper')
            incident = self.diagnostics.record(typed, key='notification_monitor')
            monitor = {'incidents': [incident]}
        else:
            self.diagnostics.resolve(key='notification_monitor')
            monitor = self._with_diagnostics(monitor)
        notices = []

        def emit(event, level='notice', **metadata):
            if LOG_LEVELS.index(level) >= LOG_LEVELS.index(self.minimum_log_level):
                notices.append({'jsonrpc': '2.0', 'method': 'notifications/message',
                    'params': {'level': level, 'logger': 'coagen',
                               'data': {'event': event, 'model_wakeup_guaranteed': False, **metadata}}})

        count = monitor.get('local_inbox_count', 0)
        revision = monitor.get('inbox_revision')
        if type(count) is int and 0 <= count <= 4096 and isinstance(revision, str) and re.fullmatch('[0-9a-f]{64}', revision):
            current = (count, revision)
            if current != self._notice_inbox:
                if count or self._notice_inbox is not None:
                    emit('coagen.inbox_changed', local_inbox_count=count,
                         has_unprocessed=monitor.get('has_unprocessed') is True, inbox_revision=revision,
                         next_action='Use coagen_watch or coagen_receive, deduplicate by message_id, and follow existing task authorization.')
                self._notice_inbox = current
        for raw in monitor.get('incidents', []):
            if not isinstance(raw, dict) or not re.fullmatch('[0-9a-f]{32}', str(raw.get('incident_id', ''))):
                continue
            safe = CoagenError.from_dict(raw).to_dict()
            identity = safe['incident_id']
            status = 'resolved' if raw.get('status') == 'resolved' else 'active'
            previous = self._notice_incidents.get(identity)
            if previous != status:
                details = {key: safe[key] for key in ('incident_id', 'code', 'operation', 'stage', 'recovery', 'next_action')}
                if status == 'active':
                    level = safe['severity'] if safe['severity'] in LOG_LEVELS else 'error'
                    emit('coagen.incident', level, **details)
                elif previous == 'active':
                    emit('coagen.incident_resolved', **details)
                self._notice_incidents[identity] = status
        # Keep the bridge cache bounded just like the diagnostic journal.
        self._notice_incidents = dict(list(self._notice_incidents.items())[-64:])
        phase = monitor.get('phase')
        if phase in ('expired', 'revoked', 'owner_exited', 'stopped', 'pairing_failed', 'closed') and phase != self._notice_phase:
            emit('coagen.session_ended', phase=phase, next_action='Stop this collaboration schedule and report unfinished work; do not recreate a room automatically.')
        self._notice_phase = phase
        return notices

    def _status(self):
        self._check_state_binding(self.state_dir)
        value = cli.call_local(self.state_dir, {'op': 'status'}) if self.state_dir else {'phase': 'no_session'}
        self.diagnostics.resolve(channel='operation', key='status')
        return self._with_diagnostics(value)

    def _with_diagnostics(self, value):
        value = dict(value)
        # Errors crossing IPC are mirrored under the same incident ID. The
        # helper remains authoritative about resolving those session errors.
        self.diagnostics.resolve_incident_ids(row.get('incident_id') for row in value.get('incidents', [])
            if isinstance(row, dict) and row.get('status') == 'resolved')
        snapshot = self._snapshot()
        # The helper owns session diagnostics; bridge diagnostics supplement it.
        for key, item in snapshot.items():
            if key == 'incidents':
                value['incidents'] = list({row['incident_id']: row for row in
                                          [*item, *value.get('incidents', [])]}.values())
            elif key == 'diagnostic_write_failed':
                value[key] = bool(value.get(key) or item)
            elif value.get(key) is None:
                value[key] = item
            else:
                value['bridge_' + key] = item
        return value

    def _bound_helper_exited(self):
        """Only a nonexistent recorded PID proves a crashed helper is gone.

        Legacy control files have no helper create_time. A still-visible PID
        may be alive or reused, so never adopt, kill, or infer its identity.
        """
        try:
            control = _unlinked_path(self.state_dir / 'control.json')
            if control.stat().st_size > 65536:
                return False
            saved = json.loads(control.read_text(encoding='utf-8'))
            pid = saved.get('pid') if isinstance(saved, dict) else None
            if (not isinstance(saved, dict) or saved.get('owner_pid') != self.owner_pid or
                    (self.binding_scope == 'mcp_instance' and saved.get('mcp_instance_id') != self.instance_id)):
                return False
            return type(pid) is int and 0 < pid < 2**32 and not psutil.pid_exists(pid)
        except (OSError, ValueError, psutil.Error):
            return False

    def _establish(self, operation, arguments):
        gate = self.diagnostic_root / 'establishment.json'
        cli.check_establishment(gate)
        previous_helper_exited = False
        if self.state_dir is not None:
            self._check_state_binding(self.state_dir)
            try:
                previous = cli.call_local(self.state_dir, {'op': 'status', 'local_only': True})
            except CoagenError as error:
                if error.code != 'LOCAL_HELPER_UNAVAILABLE' or not self._bound_helper_exited():
                    raise
                # Keys died with that process; retain its files and unresolved
                # operation history, then establish a separate membership.
                previous_helper_exited = True
                previous = {'phase': 'owner_exited'}
            if previous.get('cleanup_state') == 'incomplete':
                raise CoagenError('CLEANUP_INCOMPLETE', operation=operation,
                                  stage='local_state', phase=previous.get('phase'))
            if previous.get('phase') not in {'stopped', 'expired', 'revoked', 'owner_exited', 'pairing_failed', 'closed'}:
                raise CoagenError('SESSION_ALREADY_ACTIVE', operation=operation,
                                  stage='local_state', phase=previous.get('phase'))
        target = Path(arguments.get('state_dir') or cli.new_state_dir()).resolve()
        if previous_helper_exited and target == self.state_dir:
            raise CoagenError('INVALID_ARGUMENT', operation=operation, stage='path_validation')
        if operation == 'join':
            cli.validate_join_state(arguments['code'], target)
        elif arguments.get('reservation_code') is not None:
            cli.validate_reservation_code(arguments['reservation_code'], target)
        pending = cli.begin_establishment(gate, operation)
        try:
            function = cli.create if operation == 'create' else cli.join
            value = function(self._args(state_dir=str(target),
                                       ttl=int(arguments.get('ttl', 3600)), code=arguments.get('code'),
                                       label=arguments.get('label'), room_mode=arguments.get('room_mode'),
                                       max_members=arguments.get('max_members'), mode=arguments.get('mode'),
                                       brainstorm_policy=arguments.get('brainstorm_policy'),
                                       reservation_code=arguments.get('reservation_code') if operation == 'create' else None))
        except Exception as exc:
            error = cli.establishment_error(exc, operation, pending)
            cli.finish_establishment(gate, error=error)
            raise error from None
        cli.finish_establishment(gate)
        self.state_dir = target
        self.diagnostics.retire_session()
        if previous_helper_exited:
            value = {**value, 'previous_session': {'helper_exited': True,
                     'state_preserved': True, 'operations_replayed': False}}
        return _text(value)

    def _path(self, value):
        path = _unlinked_path(Path(value).expanduser()).resolve()
        try:
            path.relative_to(self.workspace)
        except ValueError:
            raise ValueError('File is outside the authorized task workspace.') from None
        return path

    def _attachment(self, value, *, readme=False):
        code = 'README_PATH_INVALID' if readme else 'ATTACHMENT_PATH_INVALID'
        try:
            if not isinstance(value, str) or not value or not Path(value).is_absolute():
                raise ValueError('absolute path required')
            path = self._path(value)
            if not path.exists() or (readme and not path.is_file()):
                raise ValueError('path does not exist')
            return path
        except (ValueError, OSError):
            raise CoagenError(code, operation='send', stage='input', details={
                'field': 'readme_path' if readme else 'files',
                'expected': 'absolute_file_under_attachment_root'}) from None

    @staticmethod
    def _fetch(state, arguments, end, remaining):
        if arguments.get('after_cursor') is not None:
            # Serve already received pages before spending a long-poll budget.
            value = cli.call_local(state, {'op': 'receive', 'wait': 0})
            ready_page = local_ops.page_messages(state, value.get('messages', []),
                after_cursor=arguments['after_cursor'], max_messages=arguments.get('max_messages', 10),
                summary=arguments.get('summary') is True)
            if not ready_page['messages']:
                # Old unconsumed messages must not prevent fetching later arrivals.
                cli.call_local(state, {'op': 'receive', 'wait': min(20, max(0, end-time.monotonic())), 'prefetch': True,
                                       'defer_large': True})
                value = cli.call_local(state, {'op': 'receive', 'wait': 0})
            return value
        return cli.call_local(state, {'op': 'receive', 'wait': min(20, remaining), 'defer_large': True})

    def call(self, name, arguments):
        arguments = arguments or {}
        if name not in ('coagen_network_check', 'coagen_sessions', 'coagen_audit', 'coagen_resume'):
            self._maybe_resume()
        if name == 'coagen_resume':
            if self.state_dir is not None:
                raise CoagenError('SESSION_ALREADY_ACTIVE', operation='resume', stage='local_state')
            session_id = arguments.get('session_id')
            local_ops.session_path(cli.state_base(), session_id)
            candidate = next((row for row in local_ops.resumable(cli.state_base()) if row['session_id'] == session_id), None)
            if candidate is None:
                raise CoagenError('NO_ACTIVE_SESSION', operation='resume', stage='local_state', phase='no_session')
            value = self._adopt(candidate, automatic=False)
            self._resume_choices = []
            return _text({**value, 'session_resumed': self._resume_notice})
        if name == 'coagen_prepare':
            return _text({'version': cli.__version__, 'hub': cli.validate_hub(self.hub),
                          'workspace': str(self.workspace), 'owner_pid': self.owner_pid,
                          'attachment_roots': [str(self.workspace)], 'text_only_workspace_match_required': False,
                          'runtime_instance_id': self.instance_id,
                          'binding_scope': self.binding_scope,
                          'agent_info': dict(self.agent_info), 'agent_info_self_reported': True,
                          'runtime': cli.runtime_info(),
                          'notifications': NOTIFICATION_CONTRACT,
                          'phase': 'unknown' if self.state_dir else 'no_session',
                          'session_bound': self.state_dir is not None,
                          'state_dir': str(self.state_dir) if self.state_dir else None,
                          'logs': log.describe(), 'helper_start_timeout_seconds': cli.helper_start_timeout(),
                          'troubleshooting': 'Errors carry cause (layer, category, exception chain, checks) and context (stage timings, exit codes, stderr tail). coagen_network_check tests DNS/TCP/TLS/HTTP to the Hub. Detailed events are in logs.directory.',
                          'session_continuity': {'auto_resume': self.auto_resume and self.binding_scope == 'mcp_instance',
                                                 'resume_grace_seconds': cli.resume_grace_seconds()
                                                 if self.binding_scope == 'mcp_instance' else 0,
                                                 'settings': ['COAGEN_RESUME_GRACE_SECONDS', 'COAGEN_AUTO_RESUME']},
                          **self._resume_view(),
                          **self._snapshot()})
        if name == 'coagen_network_check':
            from .netcheck import check
            return _text(check(cli.validate_hub(self.hub)))
        if name == 'coagen_create':
            return self._establish('create', arguments)
        if name == 'coagen_join':
            code = arguments.get('code')
            if not isinstance(code, str) or re.fullmatch(r'[0-9]{8}', code) is None:
                raise ValueError('Pairing code must contain exactly eight ASCII digits.')
            return self._establish('join', arguments)
        if name == 'coagen_status':
            status = {**self._status(), 'runtime_instance_id': self.instance_id}
            return _text(status if arguments.get('detail') == 'full' else local_ops.compact_status(status))
        if name == 'coagen_sessions':
            return _text(local_ops.sessions(cli.state_base(), arguments.get('limit', 30)))
        if name == 'coagen_audit':
            if arguments.get('session_id'):
                target = local_ops.session_path(cli.state_base(), arguments['session_id'])
            elif self.state_dir:
                target = self.state_dir
            else:
                return _text({'phase': 'no_session', **local_ops.sessions(cli.state_base())})
            return _text(local_ops.history(target, limit=arguments.get('limit', 100), since=arguments.get('since', 0)))
        if name == 'coagen_consume':
            message_id = arguments['message_id']
            if not isinstance(message_id, str) or re.fullmatch('[0-9a-f]{32}', message_id) is None:
                raise CoagenError('INVALID_ARGUMENT', operation='consume', stage='input')
            self._operation_key = 'consume:' + message_id
        state = self._state(arguments, operation=name.removeprefix('coagen_'))
        if name == 'coagen_read_message':
            return _text(local_ops.read_message(state, arguments['message_id'], offset=arguments.get('offset', 0),
                                               max_chars=arguments.get('max_chars', 32768)))
        if name == 'coagen_export':
            return _text(local_ops.export_message(state, self.workspace, arguments['message_id'], arguments['dest_dir'],
                         consume=arguments.get('consume') is True, consume_call=cli.call_local))
        if name == 'coagen_message_status':
            ids = arguments.get('message_ids')
            if not isinstance(ids, list) or not 1 <= len(ids) <= 100:
                raise CoagenError('INVALID_ARGUMENT', operation='message_status', stage='input')
            for identity in ids:
                local_ops.identifier(identity)
            return _text(cli.call_local(state, {'op': 'message_status', 'message_ids': ids}))
        if name in ('coagen_watch', 'coagen_receive'):
            local_ops.bounded_int(arguments.get('max_messages', 10), 1, 100)
            if arguments.get('after_cursor') is not None:
                local_ops.bounded_int(arguments['after_cursor'], 0, 2**63-1)
            requested = float(arguments.get('wait_seconds', 60 if name == 'coagen_watch' else 0))
            end = time.monotonic() + min(60 if name == 'coagen_watch' else 20, max(0, requested))
            transient_wait, network_issue, downloading = 0, None, 0
            while True:
                remaining = max(0, end - time.monotonic())
                monitor = cli.call_local(state, {'op': 'status', 'local_only': True})
                phase = monitor.get('phase')
                if phase != 'ready' and monitor.get('connection_recovery_blocked'):
                    return _text({'messages': [], 'monitor': local_ops.compact_status(self._with_diagnostics(monitor)), 'stop': True})
                if phase not in {'ready', 'starting', 'waiting_for_peer', 'pairing'}:
                    self.diagnostics.resolve(channel='operation', key=name.removeprefix('coagen_'))
                    return _text({'messages': [], 'monitor': local_ops.compact_status(self._with_diagnostics(monitor)), 'stop': True})
                value = {'messages': []}
                fetching = (monitor.get('background_receive') or {}).get('state') == 'fetching'
                if phase == 'ready' and fetching:
                    # Background receive holds the Hub connection for a long
                    # download; read what is already stored instead of queueing.
                    value = cli.call_local(state, {'op': 'inbox'})
                elif phase == 'ready' and not (name == 'coagen_watch' and transient_wait > time.monotonic()):
                    try:
                        value = self._fetch(state, arguments, end, remaining)
                    except CoagenError as error:
                        # A watch waits for messages; a network fault on the way
                        # is not the agent's problem. The helper keeps retrying,
                        # so the watch keeps waiting and reports the degradation.
                        if name != 'coagen_watch' or error.code not in TRANSIENT_WATCH_CODES:
                            raise
                        network_issue = {'code': error.code, 'incident_id': error.incident_id,
                                         'category': (error.cause or {}).get('category'),
                                         'retry_after_seconds': error.retry.get('retry_after_seconds')}
                        transient_wait = time.monotonic() + max(1, min(10, error.retry.get('retry_after_seconds') or 2))
                downloading = value.get('downloading_in_background') or downloading
                value = local_ops.page_messages(state, value.get('messages', []),
                        after_cursor=arguments.get('after_cursor'), max_messages=arguments.get('max_messages', 10),
                        summary=arguments.get('summary') is True)
                if value.get('messages') or name == 'coagen_receive' or time.monotonic() >= end:
                    self.diagnostics.resolve(channel='operation', key=name.removeprefix('coagen_'))
                    value['monitor'] = local_ops.compact_status(self._with_diagnostics(monitor))
                    if downloading and not value.get('messages'):
                        value['downloading_in_background'] = {'count': downloading, 'next_action':
                            'A large message is being downloaded in the background over a slow link. Call coagen_watch '
                            'again; it appears in the local inbox when complete. No other action is needed.'}
                    if network_issue:
                        value['network_degraded'] = {**network_issue, 'automatic_recovery': True,
                            'next_action': 'No action needed: the membership is active and the helper retries in the '
                                           'background. Keep watching; do not rejoin or create a room.'}
                    return _text(value)
                time.sleep(min(0.2, max(0, end - time.monotonic())))
        if name == 'coagen_send':
            if not isinstance(arguments.get('text', ''), str):
                raise CoagenError('INVALID_ARGUMENT', operation='send', stage='input', details={'field': 'text'})
            readme_keys = [key for key in ('readme', 'readme_path') if key in arguments]
            if len(readme_keys) > 1 or (readme_keys and 'text' in arguments):
                raise CoagenError('INPUT_TEXT_OR_README', operation='send', stage='input',
                                  details={'expected': 'inline_text_or_readme_path'})
            request_id = arguments.get('request_id')
            if request_id is None:
                request_id = self._generated_request_id = uuid.uuid4().hex
            if not isinstance(request_id, str) or not 1 <= len(request_id) <= 128:
                raise CoagenError('INVALID_ARGUMENT', operation='send', stage='input')
            self._operation_key = 'send:' + request_id
            sources = arguments.get('files', [])
            if not isinstance(sources, list):
                raise CoagenError('ATTACHMENT_PATH_INVALID', operation='send', stage='input')
            files = [str(self._attachment(item)) for item in sources]
            operation = {'op': 'send', 'text': arguments.get('text', ''), 'files': files,
                         'kind': arguments.get('kind', 'message'), 'ext': arguments.get('ext', {}),
                         'request_id': request_id}
            for key in ('recipient_id', 'broadcast'):
                if key in arguments:
                    operation[key] = arguments[key]
            if readme_keys:
                operation['readme'] = cli.read_readme(self._attachment(arguments[readme_keys[0]], readme=True))
            result = cli.call_local(state, operation)
            if not sources and re.search(r'见附件|已附(?:件|文件)|see attached|file attached', arguments.get('text', ''), re.I):
                result['warnings'] = ['No files were attached to this send. Verify whether the text refers to an earlier attachment.']
            settled = result.get('state') == 'sent'
            if settled:
                self.diagnostics.resolve_settled('send')
            return _text(result)
        if name == 'coagen_retry_send':
            request_id = arguments['request_id']
            if not isinstance(request_id, str) or not 1 <= len(request_id) <= 128:
                raise CoagenError('INVALID_ARGUMENT', operation='retry_send', stage='input')
            self._operation_key = 'send:' + request_id
            return _text(cli.call_local(state, {'op': 'retry_saved_packet', 'request_id': arguments['request_id']}))
        if name == 'coagen_collaboration':
            fields = {key: arguments[key] for key in ('action', 'expected_revision', 'request_id',
                'mode', 'leader_peer_id', 'max_turns', 'brainstorm_policy', 'target_peer_id') if key in arguments}
            return _text(cli.call_local(state, {'op': 'collaboration', **fields}))
        if name == 'coagen_consume':
            return _text(cli.call_local(state, {'op': 'consume', 'message_id': arguments['message_id']}))
        if name == 'coagen_stop':
            return _text(cli.call_local(state, {'op': 'stop'}))
        raise ValueError('Unknown Coagen MCP tool.')

    def handle(self, request):
        method, request_id = request.get('method'), request.get('id')
        if method == 'initialize':
            params = request.get('params', {})
            try:
                if not isinstance(params, dict):
                    raise ValueError('Invalid initialize parameters.')
                info = resolve_agent_info(self._agent_name, self._agent_version, params.get('clientInfo'))
            except ValueError:
                return {'jsonrpc': '2.0', 'id': request_id,
                        'error': {'code': -32602, 'message': 'Invalid agent display metadata'}}
            self.agent_info = info
            return {'jsonrpc': '2.0', 'id': request_id, 'result': {
                'protocolVersion': request.get('params', {}).get('protocolVersion', '2024-11-05'),
                'capabilities': {'tools': {}, 'logging': {}}, 'serverInfo': {'name': 'coagen-basic', 'version': cli.__version__}}}
        if method == 'notifications/initialized':
            self._notifications_initialized = True
            return None
        if method == 'logging/setLevel':
            level = request.get('params', {}).get('level')
            if level not in LOG_LEVELS:
                return {'jsonrpc': '2.0', 'id': request_id, 'error': {'code': -32602, 'message': 'Invalid log level'}}
            self._log_level = level
            return {'jsonrpc': '2.0', 'id': request_id, 'result': {}}
        if method == 'ping':
            return {'jsonrpc': '2.0', 'id': request_id, 'result': {}}
        if method == 'tools/list':
            return {'jsonrpc': '2.0', 'id': request_id, 'result': {'tools': TOOLS}}
        if method == 'tools/call':
            params = request.get('params', {})
            self._generated_request_id = None
            self._operation_key = None
            started = time.monotonic()
            try:
                result = self.call(params['name'], params.get('arguments', {}))
                log.info('tool_call', tool=params.get('name'), ok=True, elapsed_ms=round((time.monotonic() - started) * 1000))
                if self._resume_notice and not self._resume_notice.get('reported'):
                    try:
                        value = json.loads(result['content'][0]['text'])
                        if isinstance(value, dict):
                            value.setdefault('session_resumed', dict(self._resume_notice))
                            result = _text(value)
                            self._resume_notice['reported'] = True
                    except (KeyError, IndexError, TypeError, ValueError):
                        pass
                operation = params['name'].removeprefix('coagen_')
                if operation in {'send', 'retry_send', 'consume', 'receive', 'stop'}:
                    value = json.loads(result['content'][0]['text'])
                    if operation not in {'send', 'retry_send'} or value.get('state') == 'sent':
                        self.diagnostics.resolve(channel='operation', key=self._operation_key or operation)
                return {'jsonrpc': '2.0', 'id': request_id, 'result': result}
            except Exception as error:
                operation = params.get('name', '').removeprefix('coagen_')
                if operation not in {'prepare', 'create', 'join', 'status', 'watch', 'receive', 'send', 'retry_send', 'consume', 'audit', 'stop', 'collaboration', 'sessions', 'read_message', 'message_status', 'export', 'network_check', 'resume'}:
                    operation = 'unknown'
                error = classify_error(error, operation=operation, stage='local_helper')
                # PENDING_SEND belongs to the helper's original saved request,
                # not this rejected new request. Its durable runtime incident
                # remains visible through status; keep the bridge's original
                # failure intact instead of creating an unrelated recovery key.
                report = (error.to_dict() if error.code == 'PENDING_SEND' else
                          self.diagnostics.record(error, channel='operation', key=self._operation_key or operation))
                report['diagnostic_write_failed'] = self._snapshot()['diagnostic_write_failed']
                report['log_file'] = log.describe()['current_file']
                if self._resume_notice and not self._resume_notice.get('reported'):
                    report['session_resumed'] = dict(self._resume_notice)
                    self._resume_notice['reported'] = True
                elif error.code == 'NO_ACTIVE_SESSION' and self._resume_choices:
                    report.update(self._resume_view())
                log.error('tool_call', tool=params.get('name'), ok=False, elapsed_ms=round((time.monotonic() - started) * 1000),
                          code=error.code, stage=error.stage, outcome=error.outcome, incident_id=report.get('incident_id'),
                          cause=error.cause, context=error.context)
                if self._generated_request_id and error.code != 'PENDING_SEND':
                    # Only a bridge-generated identifier is safe to reflect here;
                    # caller-supplied IDs and business inputs never enter logs.
                    report = {**report, 'request_id': self._generated_request_id}
                return {'jsonrpc': '2.0', 'id': request_id,
                        'result': {'isError': True, **_text(report)}}
        return {'jsonrpc': '2.0', 'id': request_id,
                'error': {'code': -32601, 'message': 'Unsupported MCP method'}}


def discover_owner_pid():
    """Legacy import compatibility: default ownership is this MCP instance."""
    return os.getpid()


def install_config(path, python, hub=cli.DEFAULT_HUB):
    path = Path(path).resolve()
    value = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    servers = value.setdefault('mcpServers', {})
    if not isinstance(servers, dict):
        raise ValueError('Existing mcpServers must be an object.')
    servers['coagen'] = {'type': 'stdio', 'command': str(Path(python).resolve()),
                         'args': ['-X', 'utf8', '-m', 'coagen_client', 'mcp'],
                         'env': {'COAGEN_MCP_HUB': cli.validate_hub(hub)}}
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def _serve_requests(server, incoming, emit):
    # The MCP wire is UTF-8, independent of Windows locale, PYTHONIOENCODING,
    # and the text wrappers installed by the host. Keep decoding inside the
    # per-line error boundary so a malformed line cannot terminate the bridge.
    for wire in incoming:
        response = None
        try:
            line = wire.decode('utf-8', errors='strict') if isinstance(wire, bytes) else wire
            if not line.strip():
                continue
            request = json.loads(line)
            # json.loads permits escaped lone surrogates even though they cannot
            # be represented on the UTF-8 wire. Reject them before dispatch.
            json.dumps(request, ensure_ascii=False).encode('utf-8', errors='strict')
            if not isinstance(request, dict):
                raise ValueError('Invalid request')
            response = server.handle(request)
            if response is not None:
                json.dumps(response, ensure_ascii=False, allow_nan=False).encode('utf-8', errors='strict')
        except UnicodeError:
            error = CoagenError('INVALID_UTF8', operation='stdio', stage='stdio_decode')
            report = server.diagnostics.record(error, channel='operation', key='stdio')
            response = {'jsonrpc': '2.0', 'id': None,
                        'error': {'code': -32700, 'message': 'Invalid UTF-8 input', 'data': report}}
        except Exception:
            response = {'jsonrpc': '2.0', 'id': None,
                        'error': {'code': -32600, 'message': 'Invalid request'}}
        if response is not None:
            emit(response)


def serve_stdio(server):
    incoming = getattr(sys.stdin, 'buffer', sys.stdin)
    binary = hasattr(sys.stdout, 'buffer')
    outgoing = getattr(sys.stdout, 'buffer', sys.stdout)
    lock, done = threading.Lock(), threading.Event()
    requests, requests_done = queue.Queue(maxsize=64), threading.Event()
    eof = object()

    def emit(message):
        if done.is_set():
            return
        wire = json.dumps(message, ensure_ascii=False, allow_nan=False) + '\n'
        with lock:
            outgoing.write(wire.encode('utf-8', errors='strict') if binary else wire)
            outgoing.flush()

    def notifications():
        def failed():
            error = CoagenError('NOTIFICATION_FAILED', operation='status', stage='notification_monitor')
            report = error.to_dict()
            try:
                report = server.diagnostics.record(error, key='notification_worker')
            except Exception:
                # Even if the local journal itself is unavailable, emit only a
                # fixed safe diagnostic, never the exception or a traceback.
                report['diagnostic_write_failed'] = True
            try:
                if LOG_LEVELS.index('error') < LOG_LEVELS.index(server.minimum_log_level):
                    return
                emit({'jsonrpc': '2.0', 'method': 'notifications/message',
                      'params': {'level': 'error', 'logger': 'coagen',
                                 'data': {'event': 'coagen.notification_failed',
                                          'model_wakeup_guaranteed': False, **report}}})
            except Exception:
                pass  # Output may already be closed; there is no second channel.

        while not done.wait(.5):
            try:
                poll = getattr(server, 'poll_notifications', None)
                messages = list(poll() if poll is not None else [])
            except Exception:
                failed()
                return  # No hidden restart or unbounded monitor recovery.
            for message in messages:
                if done.is_set():
                    return
                try:
                    emit(message)
                except OSError:
                    return  # The host closed its output.
                except Exception:
                    failed()
                    return
    thread = threading.Thread(target=notifications, daemon=True)
    thread.start()

    def queued_requests():
        while not done.is_set():
            try:
                wire = requests.get(timeout=.1)
            except queue.Empty:
                continue
            if wire is eof:
                return
            yield wire

    def process_requests():
        try:
            _serve_requests(server, queued_requests(), emit)
        finally:
            requests_done.set()

    def enqueue(value):
        if requests_done.is_set():
            return False
        try:
            requests.put(value, timeout=.1)
            return True
        except queue.Full:
            return False

    worker = threading.Thread(target=process_requests, daemon=True)
    worker.start()
    try:
        for wire in incoming:
            if not enqueue(wire):
                if not requests_done.is_set():
                    emit({'jsonrpc': '2.0', 'id': None, 'error': {
                        'code': -32000, 'message': 'MCP request queue capacity exceeded; connection closed'}})
                break
        enqueue(eof)
        # A disconnected host must not retain a sixty-second watch or a stalled
        # HTTP request. Drain ordinary buffered requests, then revoke locally;
        # the process Owner watchdog and short Hub lease cover a hard exit.
        worker.join(timeout=3)
    finally:
        done.set()
        thread.join(timeout=1)
        close = getattr(server, 'close', None)
        if close is not None:
            close()
