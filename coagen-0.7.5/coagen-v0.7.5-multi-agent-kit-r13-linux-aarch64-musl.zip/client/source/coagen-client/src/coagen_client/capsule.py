"""Bounded, authenticated-content capsule; call only after AEAD verification.

ZIP is a client-side container, never an execution format. This module accepts
only stored entries and validates the complete manifest before writing files.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile
import unicodedata
import zipfile

MAX_RAW_BYTES = 8 * 1024 * 1024
MAX_ENTRIES = 1000
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}


def _path(name: str) -> str:
    if not isinstance(name, str) or not name or len(name.encode("utf-8")) > 1024:
        raise ValueError("invalid capsule path")
    if "\\" in name or ":" in name or any(ord(character) < 32 for character in name):
        raise ValueError("unsafe capsule path")
    for part in name.split("/"):
        if (not part or part in {".", ".."} or part[-1] in " ." or
                part.split(".")[0].upper() in _RESERVED or
                any(character in '<>"|?*' for character in part) or
                len(part.encode("utf-8")) > 255):
            raise ValueError("unsafe capsule path")
    return name


def _key(name: str) -> str:
    return unicodedata.normalize("NFC", name).casefold()


def _unique_paths(files: list[str], directories: list[str]) -> None:
    all_names = files + directories
    keys = [_key(_path(name)) for name in all_names]
    if len(set(keys)) != len(keys):
        raise ValueError("duplicate or colliding capsule paths")
    file_keys = {_key(name) for name in files}
    for name in all_names:
        parts = _key(name).split("/")
        if any("/".join(parts[:i]) in file_keys for i in range(1, len(parts))):
            raise ValueError("file/directory capsule conflict")


def _encode_json(value: object) -> bytes:
    try:
        return json.dumps(value, ensure_ascii=False, allow_nan=False,
                          separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError, RecursionError, UnicodeError) as error:
        raise ValueError("invalid capsule JSON") from error


def _metadata(manifest: dict) -> None:
    if (not isinstance(manifest, dict) or set(manifest) !=
            {"version", "message_id", "kind", "ext", "files", "directories"}):
        raise ValueError("invalid capsule manifest fields")
    if type(manifest["version"]) is not int or manifest["version"] != 1:
        raise ValueError("unsupported capsule version")
    for field, limit in (("message_id", 128), ("kind", 64)):
        value = manifest[field]
        if (not isinstance(value, str) or not 1 <= len(value) <= limit or
                not re.fullmatch(r"[A-Za-z0-9_-]+", value)):
            raise ValueError(f"invalid capsule {field}")
    if not isinstance(manifest["ext"], dict):
        raise ValueError("capsule ext must be an object")
    if not isinstance(manifest["files"], list) or not isinstance(manifest["directories"], list):
        raise ValueError("invalid capsule file list")
    if len(manifest["files"]) + 2 > MAX_ENTRIES or len(manifest["directories"]) > MAX_ENTRIES:
        raise ValueError("too many capsule entries")
    names = []
    for record in manifest["files"]:
        if not isinstance(record, dict) or set(record) != {"name", "size", "sha256"}:
            raise ValueError("invalid capsule file record")
        name = _path(record["name"])
        if not name.startswith("files/"):
            raise ValueError("invalid capsule file prefix")
        if type(record["size"]) is not int or not 0 <= record["size"] <= MAX_RAW_BYTES:
            raise ValueError("invalid capsule file size")
        if not isinstance(record["sha256"], str) or not re.fullmatch("[0-9a-f]{64}", record["sha256"]):
            raise ValueError("invalid capsule file hash")
        names.append(name)
    for directory in manifest["directories"]:
        if not _path(directory).startswith("files/"):
            raise ValueError("invalid capsule directory prefix")
    _unique_paths(names, manifest["directories"])
    _encode_json(manifest)


def _is_link(path: Path) -> bool:
    # Windows junctions are directory reparse points and must not be traversed.
    return path.is_symlink() or getattr(path, "is_junction", lambda: False)()


def create_capsule(readme: str, sources: list[Path], *, message_id: str,
                   kind: str = "message", ext: dict | None = None) -> bytes:
    if not isinstance(readme, str):
        raise ValueError("capsule README must be text")
    try:
        readme_bytes = readme.encode("utf-8")
    except UnicodeError as error:
        raise ValueError("capsule README must be UTF-8") from error
    if len(readme_bytes) > MAX_RAW_BYTES:
        raise ValueError("capsule size limit exceeded")
    items: dict[str, bytes] = {}
    directories: list[str] = []
    size = len(readme_bytes)

    def collect(path: Path, name: str) -> None:
        nonlocal size
        _path(name)
        if _is_link(path):
            raise ValueError("source links are not allowed")
        if path.is_dir():
            directories.append(name)
            if len(directories) > MAX_ENTRIES:
                raise ValueError("too many capsule entries")
            for child in sorted(path.iterdir(), key=lambda value: value.name):
                collect(child, f"{name}/{child.name}")
        elif path.is_file():
            if name in items:
                raise ValueError("duplicate source filename")
            if len(items) + 3 > MAX_ENTRIES:
                raise ValueError("too many capsule entries")
            if path.stat().st_size + size > MAX_RAW_BYTES:
                raise ValueError("capsule size limit exceeded")
            with path.open("rb") as source:
                value = source.read(MAX_RAW_BYTES - size + 1)
            size += len(value)
            if size > MAX_RAW_BYTES:
                raise ValueError("capsule size limit exceeded")
            items[name] = value
        else:
            raise ValueError("source must be a regular file or directory")

    for source in sources:
        source = Path(source).absolute()
        collect(source, f"files/{source.name}")
    manifest = {"version": 1, "message_id": message_id, "kind": kind,
                "ext": {} if ext is None else ext,
                "files": [{"name": name, "size": len(value),
                           "sha256": hashlib.sha256(value).hexdigest()}
                          for name, value in items.items()],
                "directories": directories}
    _metadata(manifest)
    encoded = _encode_json(manifest)
    if size + len(encoded) > MAX_RAW_BYTES:
        raise ValueError("capsule size limit exceeded")
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED) as archive:
        archive.writestr("README.md", readme_bytes)
        archive.writestr("manifest.json", encoded)
        for name, value in items.items():
            archive.writestr(name, value)
    return output.getvalue()


def _json_pairs(pairs: list) -> dict:
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError("duplicate manifest JSON key")
        result[name] = value
    return result


def _validated(data: bytes) -> tuple[dict, dict[str, bytes], str]:
    # Limit stored ZIP overhead as well as declared and actual entry sizes.
    if len(data) > MAX_RAW_BYTES + MAX_ENTRIES * 2300:
        raise ValueError("capsule size limit exceeded")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            entries = archive.infolist()
            if len(entries) > MAX_ENTRIES:
                raise ValueError("too many capsule entries")
            names = [entry.filename for entry in entries]
            _unique_paths(names, [])
            total = 0
            for entry in entries:
                mode = (entry.external_attr >> 16) & 0xFFFF
                if (entry.is_dir() or stat.S_ISLNK(mode) or
                        (stat.S_IFMT(mode) not in (0, stat.S_IFREG)) or entry.flag_bits & 1):
                    raise ValueError("unsupported capsule entry type")
                if entry.compress_type != zipfile.ZIP_STORED or entry.compress_size != entry.file_size:
                    raise ValueError("capsule compression is not supported")
                total += entry.file_size
                if total > MAX_RAW_BYTES:
                    raise ValueError("capsule size limit exceeded")
            if "README.md" not in names or "manifest.json" not in names:
                raise ValueError("capsule requires README and manifest")
            values = {entry.filename: archive.read(entry) for entry in entries}
            manifest = json.loads(values["manifest.json"].decode("utf-8"),
                                  object_pairs_hook=_json_pairs,
                                  parse_constant=lambda value: (_ for _ in ()).throw(ValueError("invalid JSON number")))
            _metadata(manifest)
            expected = {"README.md", "manifest.json", *(record["name"] for record in manifest["files"])}
            if set(names) != expected:
                raise ValueError("capsule contains unlisted or missing entries")
            for record in manifest["files"]:
                value = values[record["name"]]
                if len(value) != record["size"]:
                    raise ValueError("capsule file size mismatch")
                if hashlib.sha256(value).hexdigest() != record["sha256"]:
                    raise ValueError("capsule file hash mismatch")
            readme = values["README.md"].decode("utf-8")
            return manifest, values, readme
    except (zipfile.BadZipFile, EOFError, OSError, UnicodeError, RuntimeError,
            TypeError, KeyError, RecursionError) as error:
        raise ValueError("invalid capsule archive") from error


def inspect_capsule(data: bytes) -> dict:
    manifest, _values, readme = _validated(data)
    return {"readme": readme, "manifest": manifest,
            "files": [{**record, "name": record["name"][6:]} for record in manifest["files"]]}


def extract_capsule(data: bytes, destination: Path) -> dict:
    manifest, values, readme = _validated(data)
    destination = Path(destination).absolute()
    if destination.exists() or destination.is_symlink():
        raise ValueError("capsule destination must be new")
    parent = destination.parent
    from .store import _unlinked_path
    try:
        # Same rule as state paths: only root-owned system aliases may appear above.
        _unlinked_path(parent)
    except ValueError:
        raise ValueError("capsule destination requires an existing non-link parent") from None
    if not parent.is_dir():
        raise ValueError("capsule destination requires an existing non-link parent")
    staging = Path(tempfile.mkdtemp(prefix=".coagen-capsule-", dir=parent))
    try:
        for directory in manifest["directories"]:
            (staging / directory).mkdir(parents=True, exist_ok=True, mode=0o700)
        for name, value in values.items():
            target = staging / name
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with target.open("xb") as output:
                output.write(value)
            target.chmod(0o600)
        # Creating the destination exclusively prevents replacing an existing
        # empty directory under POSIX rename semantics.
        destination.mkdir(mode=0o700)
        try:
            for child in staging.iterdir():
                os.replace(child, destination / child.name)
        except BaseException:
            shutil.rmtree(destination)
            raise
    finally:
        shutil.rmtree(staging)
    return {"readme": readme, "manifest": manifest,
            "files": [{**record, "name": record["name"][6:],
                       "path": str(destination / record["name"])}
                      for record in manifest["files"]]}
