"""Plain-language explanation of a Coagen error, written for the person, not the developer.

Every error report carries ``explain`` (structured) and ``message_for_user``
(ready to paste). They answer five questions in simple Chinese: what
happened, why, what it affects, what Coagen is already doing about it, and
what the user should do. Only codes, categories, numbers and safe context
fields are used; free-form exception text is never included.
"""
from __future__ import annotations

import time

OPERATIONS = {
    'receive': '收取消息', 'watch': '等待新消息', 'send': '发送消息', 'retry_send': '重发消息',
    'retry_saved_packet': '重发消息', 'consume': '确认消息已处理', 'heartbeat': '保持在线（心跳）',
    'pairing': '与其他成员建立加密通道', 'pair': '与其他成员建立加密通道', 'create': '创建房间',
    'join': '加入房间', 'status': '查询状态', 'stop': '离开房间', 'resume': '接回之前的会话',
    'message_status': '查询消息回执', 'collaboration': '协作控制', 'network_check': '网络检查',
    'export': '导出消息', 'read_message': '读取消息', 'prepare': '本机检查',
}

# Why: by cause.category
CAUSES = {
    'dns_failed': '电脑查不到 Hub 服务器的地址（DNS 查询失败）。常见于 VPN 刚断开或重连、公司 DNS 暂时不可用。',
    'connection_refused': '连到了 Hub 的地址，但连接被拒绝。可能是 Hub 正在重启，或本机/公司防火墙拦截。',
    'connect_timeout': '在限定时间内连不上 Hub。通常是网络很慢、VPN 不稳定，或公司网络要求走代理。',
    'network_unreachable': '操作系统报告网络不可达：网线/Wi-Fi/VPN 可能断开了。',
    'connection_reset': '连接被中途切断。公司代理、防火墙或 TLS 检查设备经常这样做，通常是暂时的。',
    'read_timeout': '请求已发出，但 Hub 迟迟没有回应。网络路径很慢或中间设备卡住了。',
    'write_timeout': '上传数据时超时，上行网络很慢。',
    'pool_timeout': '本机同时进行的网络请求太多，暂时排队。',
    'proxy_failed': '代理服务器出错或拒绝了请求。',
    'tls_certificate_verify_failed': ('无法验证 Hub 的安全证书。公司网络如果会检查加密流量，有时会换成公司自己的证书；'
                                      '本机信任的证书列表里缺少对应的根证书时就会这样。'),
    'tls_handshake_failed': '建立加密连接（TLS 握手）时被中断，通常是代理或防火墙干扰，多为暂时现象。',
    'remote_protocol_error': '收到的回应格式不对，像是被中间设备（代理/防火墙）改动或截断了。',
    'http_server_error': 'Hub 服务器内部出错或正在重启。',
    'http_rejected': 'Hub 拒绝了这个请求。',
    'permission_denied': '没有权限读写 Coagen 的本地文件，可能被安全软件拦截。',
    'file_not_found': '需要的本地文件不存在。',
    'disk_full': '磁盘空间不足。',
    'file_in_use': '本地文件被其他程序（常见是杀毒或备份软件）占用。',
    'path_rejected': '这个路径不在允许的工作目录内，或是快捷方式/链接，出于安全被拒绝。',
    'sqlite_busy': '本地数据库被占用，可能有另一个 Coagen 进程在用同一个目录。',
    'sqlite_error': '本地数据库出错，可能是磁盘或权限问题。',
    'process_spawn_failed': '无法启动 Coagen 的后台进程，可能被安全软件拦截。',
    'timeout': '这一步花的时间超过了允许的上限。',
}

# What happened / impact / what the user should do: by code
CODES = {
    'HUB_UNAVAILABLE': ('{op}时连接 Hub 失败。', '这一次{op}没有完成；房间和成员身份都还在。',
                        '一般不需要做任何事。如果几分钟后仍未恢复，可以让 Agent 运行一次 coagen_network_check，把结果发给维护者。'),
    'RETRY_NOT_DUE': ('{op}刚刚连续失败了几次，Coagen 正在短暂冷却后再试。', '暂时收不到或发不出，房间和成员身份都还在。',
                      '不用做任何事，也不要重新加入或新建房间。等提示的秒数过后会自动继续。'),
    'RETRY_BUDGET_EXHAUSTED': ('{op}多次重试都没有成功，已停止自动重试。', '这一项操作暂停了。',
                               '把这段说明发给维护者；不要自己修改 Coagen 的文件或数据库。'),
    'SEND_OUTCOME_UNKNOWN': ('消息已经发出，但没有收到 Hub 的确认，不确定对方是否能收到。', '这条消息可能已经送达，也可能没有。',
                             '让 Agent 用 coagen_retry_send 和原来的 request_id 重发；不要换新内容重发，以免对方收到两份。'),
    'TLS_FAILED': ('无法验证 Hub 的安全证书，Coagen 拒绝了这次连接以保护你的数据。', '在证书问题解决前无法连接（偶发的会自动重试）。',
                   '如果反复出现，请网络管理员确认本机信任的证书包里同时包含公共根证书和公司证书；不要关闭证书校验。'),
    'RATE_LIMITED': ('请求太频繁，Hub 要求稍等。', '暂时延迟。', '不用做任何事，会按 Hub 要求的时间自动继续。'),
    'AUTH_FAILED': ('Hub 不接受这次的身份凭据。', '这次操作被拒绝。', '确认使用的是正确的配对码或管理令牌；不要反复尝试猜测。'),
    'MEMBERSHIP_REVOKED': ('你在这个房间的成员身份已经结束（例如长时间没有在线，租约过期）。', '用这个身份收发消息都不可能了。',
                           '如果房间还开着，可以用原来的配对码重新加入一次；之前未收的消息需要请其他成员重发。'),
    'ROOM_CLOSED': ('房间已经被关闭。', '无法再在这个房间收发消息。', '如需继续协作，请创建新房间。'),
    'ROOM_EXPIRED': ('房间已经到期。', '无法再在这个房间收发消息。', '如需继续协作，请创建新房间。'),
    'SESSION_EXPIRED': ('本地会话已经结束。', '需要重新加入后才能继续。', '如果房间还开着，用原配对码重新加入一次。'),
    'SESSION_REVOKED': ('本地会话已被结束。', '需要重新加入后才能继续。', '如果房间还开着，用原配对码重新加入一次。'),
    'NO_ACTIVE_SESSION': ('当前没有加入任何房间。', '收发消息前需要先加入。', '给 Agent 配对码让它加入；如果刚重启过，可能需要重新加入一次。'),
    'SESSION_ALREADY_ACTIVE': ('已经在一个房间里了，不能再加入另一个。', '新的加入没有执行。',
                               '直接继续使用当前会话；如果确实要换房间，先让 Agent 执行 coagen_stop。'),
    'PAIRING_PENDING': ('和对方的加密通道还在建立中。', '暂时还不能收发。', '稍等片刻再试，一般几秒内完成。'),
    'PENDING_SEND': ('上一条消息的发送结果还没确认，为了不重复发送，暂时不发新消息。', '新消息暂时没有发出。',
                     '先让 Agent 用 coagen_retry_send 处理上一条，再发新的。'),
    'LOCAL_HELPER_UNAVAILABLE': ('Coagen 的本机后台进程没有响应。', '这次操作没有完成。',
                                 '让 Agent 调用一次 coagen_status；如果显示后台进程已退出，用原配对码重新加入一次。'),
    'LOCAL_HELPER_START_TIMEOUT': ('Coagen 的本机后台进程启动太慢，超过了等待时间。', '加入没有完成。',
                                   '电脑较慢或被安全软件扫描时会这样；可在 MCP 配置中调大 COAGEN_HELPER_START_TIMEOUT 后重试一次。'),
    'LOCAL_HELPER_EXITED': ('Coagen 的本机后台进程启动后马上退出了。', '加入没有完成。', '把这段说明发给维护者。'),
    'LOCAL_HELPER_SPAWN_FAILED': ('无法启动 Coagen 的本机后台进程。', '加入没有完成。', '可能被安全软件拦截；把这段说明发给维护者。'),
    'LOCAL_STORAGE_FAILED': ('读写本地文件失败。', '这次操作没有完成或没有保存。', '检查磁盘空间和权限；把这段说明发给维护者。'),
    'MESSAGE_AUTH_FAILED': ('收到的一条消息没有通过加密验证，已拒绝处理。', '这条消息不会被打开。', '请发送方重发这条消息；如果反复出现，告诉维护者。'),
    'INVALID_ARGUMENT': ('请求的参数不正确。', '这次操作没有执行。', '让 Agent 按错误中 details 的提示修正参数后再试。'),
    'INTERNAL_ERROR': ('Coagen 内部出现了未预料的错误。', '这次操作没有完成。', '把这段说明（含事件编号）发给维护者。'),
}

AUTOMATIC = {'HUB_UNAVAILABLE', 'RETRY_NOT_DUE', 'RATE_LIMITED', 'PAIRING_PENDING'}


def _seconds(value):
    return '%d秒' % max(1, round(value))


def explain(report):
    code, operation = report.get('code'), report.get('operation')
    op = OPERATIONS.get(operation, '这次操作')
    happened, impact, todo = CODES.get(code, ('{op}失败了（错误代码 %s）。' % code, '这次操作没有完成。',
                                              '把这段说明（含事件编号）发给维护者。'))
    cause = report.get('cause') or {}
    category = cause.get('category')
    why = CAUSES.get(category)
    if not why:
        why = report.get('possible_causes', [None])[0] if report.get('possible_causes') else None
    if not why:
        why = '没有更具体的原因信息。'
    request = cause.get('request') if isinstance(cause.get('request'), dict) else None
    if request and request.get('elapsed_ms') is not None:
        why += '（这次请求用了 %.1f 秒。）' % (request['elapsed_ms'] / 1000)
    if report.get('http_status'):
        why += '（服务器返回代码 %s。）' % report['http_status']

    retry = report.get('retry') or {}
    doing = '没有自动处理，需要按下面的建议操作。'
    if code in AUTOMATIC or (code == 'TLS_FAILED' and operation in ('heartbeat', 'receive', 'watch')):
        after = retry.get('retry_after_seconds')
        if after:
            doing = 'Coagen 会在约 %s 后自动重试，期间会继续保持在线、在后台收取消息。' % _seconds(after)
        else:
            doing = 'Coagen 会自动重试（间隔逐渐拉长，最长 1 分钟），期间继续保持在线、在后台收取消息。'
    elif code == 'SEND_OUTCOME_UNKNOWN':
        doing = '原消息已保存在本机，可以原样重发；Hub 会自动去重，对方不会收到两份。'

    original = (report.get('details') or {}).get('original_code')
    if code == 'RETRY_NOT_DUE' and original and not cause.get('category'):
        why = '前几次失败的原因是：' + CODES.get(original, ('错误代码 %s。' % original,))[0].format(op=op)
    fields = {'发生了什么': happened.format(op=op), '可能的原因': why, '影响': impact.format(op=op),
              'Coagen 正在做什么': doing, '你需要做什么': todo,
              '事件编号': report.get('incident_id')}
    when = report.get('timestamp')
    if isinstance(when, (int, float)):
        fields['时间'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(when))
    text = '\n'.join('%s：%s' % (key, value) for key, value in fields.items() if value)
    return fields, text
