"""Explicit group protocol: a separate ephemeral SPAKE2 channel for every pair.

The Hub routes ciphertext only. Display roles, leadership and collaboration
policy never select cryptographic directions or replace established keys.
"""
from __future__ import annotations

import base64
import copy
from dataclasses import dataclass
import hashlib
import threading
import time
import uuid

import httpx

from .carrier import pack_png
from .crypto import Pairing, CryptoError
from .errors import CoagenError, classify_error
from .runtime import SessionRuntime, AAD_FIELDS, PAIRING_TIMEOUT_SECONDS
from .transport import HubError, authoritative_revocation
from .observe import log

GROUP_PROTOCOL = 'coagen-group/1'
MODES = ('vanilla', 'brainstorm', 'leader-led', 'round-robin')


@dataclass
class PeerLink:
    pairing: object
    hello: str
    started_at: float
    cipher: object = None
    proof: str | None = None
    hello_sent: bool = False
    proof_sent: bool = False
    state: str = 'pairing'
    confirmed: bool = False
    attempts: int = 0
    retry_at: float = 0
    error: dict | None = None

    def close(self):
        for component in (self.pairing, self.cipher):
            if component is not None:
                component.close()


class GroupRuntime(SessionRuntime):
    aad_fields = (*AAD_FIELDS, 'collaboration_revision')
    remote_stop_operation = 'leave'

    def __init__(self, config):
        if config['member'].get('group_protocol') != GROUP_PROTOCOL:
            raise ValueError('Unsupported group protocol.')
        super().__init__(config)
        self.group_status_lock = threading.RLock()
        self.transport.api_prefix = '/api/team'
        self.links = {}
        self.peers = {}
        self.collaboration = copy.deepcopy(self.member.get('collaboration', {}))
        self.leader_peer_id = self.member.get('leader_peer_id')

    def _status_fields(self):
        with self.group_status_lock:
            fields = super()._status_fields()
            fields.update(room_mode='group', group_protocol=GROUP_PROTOCOL,
                          max_members=self.member.get('max_members', 8), leader_peer_id=self.leader_peer_id,
                          send_capabilities=copy.deepcopy(getattr(self, 'send_capabilities', {})),
                          collaboration=copy.deepcopy(self.collaboration), peers=copy.deepcopy(list(self.peers.values())),
                          channels=[{'peer_id': peer, 'phase': link.state, 'error': copy.deepcopy(link.error)}
                                    for peer, link in list(self.links.items())],
                          ready_peer_ids=[peer for peer, link in list(self.links.items()) if link.state == 'ready'])
            return fields

    def _update_group_status(self, status):
        if (not isinstance(status, dict) or status.get('room_id') != self.member['room_id']
                or status.get('session_id') != self.member['session_id']
                or status.get('group_protocol') != GROUP_PROTOCOL or status.get('room_mode') != 'group'):
            raise ValueError('Group status is not for the active session.')
        peers = status.get('peers')
        if (not isinstance(peers, list) or not 1 <= len(peers) <= 8
                or any(not isinstance(p, dict) or not isinstance(p.get('peer_id'), str)
                       or not 1 <= len(p['peer_id']) <= 128 for p in peers)
                or len({p['peer_id'] for p in peers}) != len(peers)
                or self.member['peer_id'] not in {p['peer_id'] for p in peers}):
            raise ValueError('Invalid active group roster.')
        collaboration = status.get('collaboration')
        if (not isinstance(collaboration, dict) or type(collaboration.get('revision')) is not int
                or collaboration['revision'] < 1 or collaboration.get('mode') not in MODES):
            raise ValueError('Invalid collaboration state.')
        # Heartbeat responses may arrive after a newer control response. Apply
        # one coherent snapshot without making status wait for network I/O.
        with self.group_status_lock:
            if collaboration['revision'] < self.collaboration.get('revision', 0):
                return
            self._update_room_deadline(status)
            self.peers = {p['peer_id']: copy.deepcopy(p) for p in peers}
            self.send_capabilities = copy.deepcopy(status.get('send_capabilities', {}))
            self.collaboration = copy.deepcopy(collaboration)
            self.leader_peer_id = status.get('leader_peer_id')

    def _link_error(self, identity, link, error):
        authentication = isinstance(error, (CryptoError, ValueError, KeyError)) and not isinstance(error, CoagenError)
        typed = (CoagenError('MESSAGE_AUTH_FAILED', operation='pairing', stage='pairing') if authentication
                 else classify_error(error, operation='pairing', stage='pairing'))
        link.attempts += 1
        # Network faults are retried with backoff until the pairing deadline
        # (PAIRING_TIMEOUT_SECONDS) ends this attempt; only authentication or
        # protocol failures close the pairwise channel immediately.
        retryable = typed.code in ('HUB_UNAVAILABLE', 'RATE_LIMITED')
        link.retry_at = time.monotonic() + max(min(10, 2 ** link.attempts), getattr(error, 'retry_after', None) or 1)
        if not retryable:
            link.state = 'failed'
            link.close()
        link.error = typed.to_dict()
        self.diagnostics.record(typed, channel='connection', key='pair:' + identity)

    def _pair(self, status):
        self._update_group_status(status)
        own = self.member['peer_id']
        active = set(self.peers) - {own}
        for identity, link in list(self.links.items()):
            if identity not in active and link.state != 'left':
                # Already stored packets from a departed sender remain valid.
                # Keep only an established receive cipher until this room ends;
                # the roster excludes this peer from every new send target set.
                if not link.confirmed:
                    link.close()
                else:
                    link.pairing.close()
                link.state = 'left'
        for identity in sorted(active):
            if identity not in self.links:
                low, high = sorted((own, identity))
                pairing = Pairing(self.secret, self.member['room_id'], 'A' if own == low else 'B',
                                  context={'server_session_id': self.member['session_id'],
                                           'peer_a': low, 'peer_b': high, 'group_protocol': GROUP_PROTOCOL})
                self.links[identity] = PeerLink(pairing, base64.b64encode(pairing.start()).decode('ascii'),
                                                time.monotonic())
        pending = [(identity, self.links[identity]) for identity in sorted(active)
                   if self.links[identity].state == 'pairing']
        if pending:
            signals = self.transport.exchange('signals')['signals']
            if not isinstance(signals, list):
                raise ValueError('Invalid directed group signals.')
            for identity, link in pending:
                if time.monotonic() < link.retry_at:
                    continue
                try:
                    if time.monotonic() - link.started_at >= PAIRING_TIMEOUT_SECONDS:
                        raise ValueError('Pairwise handshake deadline expired.')
                    if not link.hello_sent:
                        self.transport.exchange('signal', recipient_id=identity, slot='hello', payload=link.hello)
                        link.hello_sent = True
                    theirs = {item['slot']: item['payload'] for item in signals
                              if item.get('peer_id') == identity and item.get('recipient_id') == own}
                    if link.cipher is None and 'hello' in theirs:
                        link.cipher = link.pairing.finish(base64.b64decode(theirs['hello'], validate=True))
                        link.proof = base64.b64encode(link.cipher.confirmation()).decode('ascii')
                    if link.cipher is not None and not link.proof_sent:
                        self.transport.exchange('signal', recipient_id=identity, slot='confirm', payload=link.proof)
                        link.proof_sent = True
                    if link.proof_sent and 'confirm' in theirs:
                        link.cipher.verify_confirmation(base64.b64decode(theirs['confirm'], validate=True))
                        link.state, link.error = 'ready', None
                        link.confirmed = True
                        self.diagnostics.resolve(channel='connection', key='pair:' + identity)
                        self.store.audit('session', peer=identity, room=self.member['room_id'], result='paired')
                except Exception as error:
                    self._link_error(identity, link, error)
        ready = any(link.confirmed and link.state in ('ready', 'left') for link in self.links.values())
        self.phase = 'ready' if ready else 'pairing' if active else 'waiting_for_peer'
        self.connection_recovery_blocked = bool(active) and all(self.links[p].state == 'failed' for p in active)

    def worker(self):
        """Lease maintenance and pairing that survive transient network faults.

        Only an authoritative Hub rejection (its own 401/403/404/410 JSON) ends
        the membership. Any other failure, including TLS handshakes cut short
        by a proxy, HTML error pages from a middlebox and garbled responses, is
        retried with backoff (2 s doubling, capped at the heartbeat interval),
        so a brief outage uses the 180 s Hub lease instead of losing it.
        """
        heartbeat_at, status_at, failures = 0, 0, 0
        while self.active():
            try:
                now = time.monotonic()
                status = None
                if now >= heartbeat_at:
                    heartbeat_at = now + self.heartbeat_interval
                    with self._network_scope(time.time() + min(45, self.deadline.remaining())):
                        status = self._heartbeat()
                    self._update_group_status(status)
                    count = status.get('pending_count', 0)
                    if type(count) is not int or not 0 <= count <= 4096:
                        raise ValueError('Invalid pending count.')
                    self.pending_count, self.last_heartbeat_at = count, time.time()
                    self._write_heartbeat_snapshot(next_heartbeat_in=self.heartbeat_interval)
                if status is not None or now >= status_at:
                    with self._network_scope(time.time() + min(45, self.deadline.remaining())):
                        status = status or self.transport.exchange('status')
                        with self.operation_lock:
                            self._pair(status)
                    status_at = time.monotonic() + (0.5 if any(link.state == 'pairing' for link in self.links.values()) else 2)
                    failures = 0
                    self.last_error = None
                    self.diagnostics.resolve(channel='connection', key='worker')
                    self._connection_ok()
                if self.phase == 'ready' and self.pending_count and not self.background_receive_blocked:
                    self.prefetch_event.set()
                self.stop_event.wait(0.25)
            except Exception as error:
                typed = classify_error(error, operation='heartbeat', stage='heartbeat')
                self.diagnostics.record(typed, channel='connection', key='worker')
                self.last_error = typed.code
                if authoritative_revocation(error):
                    self.shutdown('revoked'); return
                failures += 1
                backoff = min(self.heartbeat_interval, 2 ** min(failures, 5))
                retry_after = getattr(error, 'retry_after', None)
                if isinstance(retry_after, (int, float)) and retry_after > 0:
                    backoff = max(backoff, min(retry_after, self.heartbeat_interval * 2))
                # Renew the lease sooner after a failure; do not wait a full interval.
                heartbeat_at = min(heartbeat_at, time.monotonic() + backoff)
                status_at = time.monotonic() + backoff
                self._connection_failed(typed, backoff)
                self.stop_event.wait(0.25)
        self.shutdown(self._end_reason())

    def _packet_cipher(self, metadata):
        link = self.links.get(metadata['sender_id'])
        if (link is None or not link.confirmed or link.state not in ('ready', 'left') or link.cipher is None
                or metadata['recipient_id'] != self.member['peer_id']
                or metadata['room_id'] != self.member['room_id']
                or metadata['crypto_session_id'] != link.cipher.session_id
                or metadata['expires_at'] <= time.time()
                or type(metadata['collaboration_revision']) is not int
                or metadata['collaboration_revision'] < 1):
            raise ValueError('Invalid or expired group message envelope.')
        # An accepted packet can outlive its policy epoch. The revision is
        # authenticated, not compared with today's policy when receiving it.
        return link.cipher

    def _targets(self, args):
        recipient, broadcast = args.get('recipient_id'), args.get('broadcast', False)
        if type(broadcast) is not bool or (recipient is not None and not isinstance(recipient, str)):
            raise ValueError('Invalid group recipient selection.')
        if recipient is not None and broadcast:
            raise ValueError('Choose recipient_id or broadcast, not both.')
        available = sorted(set(self.peers) - {self.member['peer_id']})
        targets = available if broadcast else ([recipient] if recipient else available if len(available) == 1 else [])
        if not targets or any(target not in available for target in targets):
            raise ValueError('Choose an active recipient or explicitly broadcast.')
        if any(self.links.get(target) is None or self.links[target].state != 'ready' for target in targets):
            raise CoagenError('PAIRING_PENDING', operation='send', stage='pairing')
        return targets

    def _check_plan_session(self, plan):
        if any(plan.get(key) != self.member[key] for key in ('room_id', 'session_id', 'peer_id')):
            raise CoagenError('REQUEST_CONFLICT', operation='send', stage='outbox_lookup')

    def _send_plan(self, request_id, plan):
        self._check_plan_session(plan)
        deliveries = []
        for target in plan['targets']:
            child = plan['children'][target]
            existing = self.store.outgoing(child['request_id'])
            if existing is None:
                raise CoagenError('LOCAL_STORAGE_FAILED', operation='send', stage='outbox_lookup')
            link = self.links.get(target)
            self._check_saved_session(existing, link.cipher if link else None, target)
            try:
                if existing['state'] == 'sent':
                    delivery = self._send_receipt(child['request_id'], existing, duplicate=True)
                elif existing['state'] == 'pending':
                    delivery = self._upload_saved(child['request_id'], existing)
                else:
                    raise CoagenError('SESSION_EXPIRED', operation='send', stage='outbox_lookup')
                deliveries.append({**delivery, 'recipient_id': target, 'parent_request_id': request_id,
                                   'delivery_request_id': child['request_id']})
                self.diagnostics.resolve(key=self._send_key(child['request_id']))
            except Exception as error:
                typed = self._operation_error(error, 'send')
                self.diagnostics.record(typed, key=self._send_key(child['request_id']))
                if len(plan['targets']) == 1 and not plan['selector']['broadcast']:
                    raise typed from None
                deliveries.append({'recipient_id': target, 'message_id': child['message_id'],
                                   'request_id': child['request_id'], 'parent_request_id': request_id,
                                   'delivery_request_id': child['request_id'], 'state': 'failed', 'error': typed.to_dict()})
        complete = all(item['state'] == 'sent' for item in deliveries)
        result = {'request_id': request_id, 'parent_request_id': request_id, 'state': 'sent' if complete else 'partial',
                  'all_sent': complete, 'deliveries': deliveries, 'recipient_ids': plan['targets']}
        if len(deliveries) == 1:
            result['message_id'] = deliveries[0]['message_id']
        return result

    def send(self, args):
        with self.operation_lock:
            self.require_active()
            if self.crypto_send_blocked:
                raise CoagenError('CRYPTO_FAILURE', operation='send', stage='encrypt')
            request_id = self._request_id(args.get('request_id') or uuid.uuid4().hex)
            plan = self.store.group_plan(request_id)
            if plan is not None:
                self._check_plan_session(plan)
            # The content fingerprint excludes message ID/timestamps, just as Basic does.
            _, fingerprint = self._capsule(args, uuid.uuid4().hex)
            selector = {'recipient_id': args.get('recipient_id'), 'broadcast': args.get('broadcast', False)}
            if plan is not None and (plan['fingerprint'] != fingerprint or plan['selector'] != selector):
                raise CoagenError('REQUEST_CONFLICT', operation='send', stage='request_validation')
            if plan is None:
                try:
                    self._pair(self.transport.exchange('status'))
                except (httpx.RequestError, HubError, CoagenError) as error:
                    # Refreshing the roster is a courtesy. If the Hub cannot be
                    # reached right now but the target channel is already
                    # established, send with the known roster (the Hub still
                    # authorizes the upload); only fail when it is needed.
                    typed = classify_error(error, operation='send', stage='pairing')
                    if authoritative_revocation(error) or typed.code not in ('HUB_UNAVAILABLE', 'RATE_LIMITED'):
                        raise
                    log.warning('send_roster_refresh_failed', code=typed.code, category=(typed.cause or {}).get('category'))
                targets = self._targets(args)
                if any(self.store.pending_group_target(target) for target in targets):
                    raise CoagenError('PENDING_SEND', operation='send', stage='outbox_lookup', outcome='unknown')
                plan = {'fingerprint': fingerprint, 'selector': selector, 'targets': targets,
                        'room_id': self.member['room_id'], 'session_id': self.member['session_id'],
                        'peer_id': self.member['peer_id'],
                        'collaboration_revision': self.collaboration['revision'],
                        'children': {target: {'message_id': uuid.uuid4().hex,
                            'request_id': 'group:' + hashlib.sha256((request_id + '\0' + target).encode()).hexdigest()}
                                     for target in targets}}
                self.store.save_group_plan(request_id, plan)
            # Persist every original ciphertext before uploading any packet.
            for target in plan['targets']:
                child = plan['children'][target]
                if self.store.outgoing(child['request_id']) is not None:
                    continue
                link = self.links.get(target)
                if link is None or link.state != 'ready':
                    raise CoagenError('PAIRING_PENDING', operation='send', stage='pairing')
                capsule, _ = self._capsule(args, child['message_id'])
                metadata = {'room_id': self.member['room_id'], 'message_id': child['message_id'],
                            'sender_id': self.member['peer_id'], 'recipient_id': target,
                            'expires_at': float(self.deadline.expires_at),
                            'sequence': self.store.next_sequence(link.cipher.session_id),
                            'crypto_session_id': link.cipher.session_id,
                            'collaboration_revision': plan['collaboration_revision']}
                self._stage('encrypt')
                png = pack_png(link.cipher.encrypt(capsule, sequence=metadata['sequence'], metadata=metadata))
                self.require_active()
                self._stage('save_outbox', outcome='local_only')
                self.store.save_outgoing(child['request_id'], metadata, png, fingerprint=fingerprint,
                                         receipt=self._capsule_receipt(capsule))
            return self._send_plan(request_id, plan)

    def retry_saved_packet(self, request_id):
        with self.operation_lock:
            self.require_active()
            if self.crypto_send_blocked:
                raise CoagenError('CRYPTO_FAILURE', operation='send', stage='encrypt')
            request_id = self._request_id(request_id)
            plan = self.store.group_plan(request_id)
            if plan is None:
                raise CoagenError('INVALID_ARGUMENT', operation='retry_saved_packet', stage='outbox_lookup')
            return self._send_plan(request_id, plan)

    def _view(self, row):
        return {**super()._view(row), 'collaboration_revision': row['metadata']['collaboration_revision']}

    def _dispatch(self, args):
        if args.get('op') == 'status' and not args.get('local_only') and self.active():
            if not self.operation_lock.acquire(timeout=2):
                # A long packet transfer holds the lock; never make status wait for it.
                value = self.status()
                value['hub_refresh'] = {'ok': False, 'code': None, 'category': 'busy',
                                        'note': 'Last known state; a packet transfer is in progress.'}
                return value
            try:
                try:
                    self._pair(self.transport.exchange('status'))
                finally:
                    self.operation_lock.release()
            except (httpx.RequestError, HubError, CoagenError) as error:
                typed = classify_error(error, operation='status', stage='hub_exchange')
                middlebox = isinstance(error, HubError) and getattr(error, 'hub_origin', True) is False
                if authoritative_revocation(error) or not (middlebox or typed.code in ('HUB_UNAVAILABLE', 'RATE_LIMITED')):
                    raise
                # Status must stay readable during an outage: report the last
                # known state and why it could not be refreshed.
                value = self.status()
                value['hub_refresh'] = {'ok': False, 'code': typed.code,
                                        'category': (typed.cause or {}).get('category'),
                                        'note': 'Last known state; the Hub could not be reached just now. '
                                                'The helper keeps retrying in the background.'}
                return value
            return self.status()
        if args.get('op') != 'collaboration':
            return super()._dispatch(args)
        with self.operation_lock:
            self.require_active(ready=False)
            fields = {key: args[key] for key in ('action', 'expected_revision', 'request_id', 'mode',
                                                'leader_peer_id', 'max_turns', 'brainstorm_policy', 'target_peer_id') if key in args}
            if (fields.get('action') not in ('configure', 'advance', 'pause', 'resume', 'finish', 'reopen')
                    or type(fields.get('expected_revision')) is not int or fields['expected_revision'] < 1):
                raise ValueError('Explicit collaboration action and revision are required.')
            self._request_id(fields.get('request_id'))
            self._stage('hub_exchange')
            if fields['action'] == 'reopen' or 'brainstorm_policy' in fields:
                latest = self.transport.exchange('status')
                self._update_group_status(latest)
                if latest.get('collaboration_policy_supported') is not True:
                    raise CoagenError('HUB_FEATURE_UNAVAILABLE', operation='collaboration', stage='hub_exchange')
            status = self.transport.exchange('collaboration', **fields)
            self._update_group_status(status)
            return self.status()

    def _close_crypto(self):
        self.secret = None
        for link in list(self.links.values()):
            try:
                link.close()
            except Exception:
                self.last_error = 'cleanup_incomplete'
        super()._close_crypto()
