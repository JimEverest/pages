"""Portable CLI. Secret setup stays outside agent prompts and routine output."""
import argparse
import getpass
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import traceback
import time
import uuid
import unicodedata

import httpx
import psutil

from .lifecycle import Owner
from .store import Store, secure_directory, atomic_private_json, _unlinked_path
from .transport import Transport, HubError, validate_hub
from . import __version__
from .errors import CoagenError, classify_error
from .diagnostics import Diagnostics
from .observe import categorize, describe, log, redact, startup_facts

DEFAULT_HUB = 'https://json-formatter.centralindia.cloudapp.azure.com/coagen'


def state_base():
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.local' / 'state'))) / 'Coagen'


def new_state_dir():
    return state_base() / 'sessions' / ('mcp-' + secrets.token_hex(12))


def cli_diagnostic_root(state=None):
    identity = hashlib.sha256(str(Path(state).absolute()).encode('utf-8')).hexdigest() if state else 'unbound'
    return state_base() / 'cli-diagnostics' / identity


def status_with_cli(root, value):
    snapshot = Diagnostics(cli_diagnostic_root(root)).snapshot()
    if not snapshot['incidents'] and not snapshot['diagnostic_write_failed']:
        return value
    value = dict(value)
    value['incidents'] = [*value.get('incidents', []), *snapshot['incidents']]
    for channel in ('last_operation_error', 'connection_error'):
        if value.get(channel) is None:
            value[channel] = snapshot[channel]
        elif snapshot[channel] is not None:
            value['cli_' + channel] = snapshot[channel]
    value['diagnostic_write_failed'] = bool(value.get('diagnostic_write_failed') or snapshot['diagnostic_write_failed'])
    return value


def runtime_info():
    versions = {}
    for package in ('httpx', 'psutil', 'cryptography', 'spake2'):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    return {'python_version': sys.version.split()[0], 'stdio_encoding': 'utf-8',
            'stdio_errors': 'strict', 'utf8_mode': bool(sys.flags.utf8_mode),
            'dependencies': versions}


def read_readme(path):
    try:
        return Path(path).read_text(encoding='utf-8', errors='strict')
    except (OSError, UnicodeError) as error:
        raise classify_error(error, operation='send', stage='readme') from None


def validate_join_state(code, path):
    if path and code in str(Path(path).expanduser().absolute()):
        raise CoagenError('INVALID_ARGUMENT', operation='join', stage='path_validation')


def validate_reservation_code(code, path=None):
    if not isinstance(code, str) or re.fullmatch(r'[A-Za-z0-9_-]{43}', code) is None:
        raise CoagenError('INVALID_ARGUMENT', operation='create', stage='input')
    if path and code in str(Path(path).expanduser().absolute()):
        raise CoagenError('INVALID_ARGUMENT', operation='create', stage='path_validation')


def check_establishment(path):
    """Never silently repeat an establishment whose result is still unknown."""
    path = Path(path)
    if not path.exists():
        return
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(value, dict):
            raise ValueError()
        if value.get('pending'):
            raise CoagenError.from_dict(value['error'])
    except CoagenError:
        raise
    except (OSError, ValueError, KeyError):
        raise CoagenError('LOCAL_STORAGE_FAILED', operation='unknown', stage='local_state') from None


def begin_establishment(path, operation):
    path = Path(path)
    check_establishment(path)
    pending = CoagenError('SESSION_OUTCOME_UNKNOWN', operation=operation,
                          stage='hub_establish', outcome='unknown')
    try:
        secure_directory(path.parent)
        atomic_private_json(path, {'pending': True, 'error': pending.to_dict()})
    except Exception:
        raise CoagenError('LOCAL_STORAGE_FAILED', operation=operation, stage='local_state') from None
    return pending


def establishment_error(error, operation, pending):
    if isinstance(error, CoagenError):
        return error
    if isinstance(error, HubError):
        return classify_error(error, operation=operation, stage='hub_establish')
    if isinstance(error, httpx.RequestError):
        return pending
    return classify_error(error, operation=operation, stage='preflight')


def finish_establishment(path, error=None):
    try:
        atomic_private_json(Path(path), {'pending': bool(error and error.to_dict()['outcome'] == 'unknown'),
                                        'error': error.to_dict() if error else None})
    except Exception:
        # The pre-dispatch marker remains. Never turn failed persistence into
        # permission to make another non-idempotent request.
        raise CoagenError('LOCAL_STORAGE_FAILED', operation='unknown', stage='local_state',
                          outcome='unknown' if error else 'hub_accepted') from None


def default_token_file():
    return Path.home() / '.config' / 'coagen' / 'azure-admin-token.txt'


def token_file_exists(path=None):
    """Report token presence without turning a protected path into a failure."""
    try:
        return (path or default_token_file()).is_file()
    except OSError:
        return False


def session_owner(pid):
    if pid is not None:
        return Owner.capture(pid)
    parent = psutil.Process(os.getppid())
    # Windows venv python.exe is a launcher which waits for the real interpreter.
    # Skip only this exact module invocation, never an arbitrary Python agent.
    safe_prefixes = (['-m', 'coagen_client'], ['-I', '-m', 'coagen_client'],
                     ['-X', 'utf8', '-m', 'coagen_client'],
                     ['-I', '-X', 'utf8', '-m', 'coagen_client'],
                     ['-X', 'utf8', '-I', '-m', 'coagen_client'])
    if (parent.name().lower() in ('python.exe', 'pythonw.exe')
            and Path(parent.exe()).resolve() == Path(sys.executable).resolve()
            and any(parent.cmdline()[1:1 + len(prefix)] == prefix for prefix in safe_prefixes)):
        parent = parent.parent()
    if parent is None or parent.name().lower() not in ('cmd.exe', 'powershell.exe', 'pwsh.exe', 'bash', 'zsh', 'sh', 'fish'):
        raise ValueError('Supply the stable Agent owner PID, or run directly in a terminal kept open for this session.')
    return Owner.capture(parent.pid)


def prepare(args):
    ancestors = []
    for process in psutil.Process().parents():
        try:
            ancestors.append({'pid': process.pid, 'name': process.name()})
        except psutil.Error:
            continue
    return {'version': __version__, 'python': sys.executable, 'hub': validate_hub(args.hub),
            'state_dir': str(new_state_dir()), 'runtime': runtime_info(), 'phase': 'no_session',
            'ancestors': ancestors,
            'note': 'Local preparation only. Choose the actual stable owner; this command does not create or join a room.'}


def retire_room(hub, member):
    """Best-effort leave/close after a failed setup; returns what actually happened."""
    operation = 'leave' if member.get('room_mode') == 'group' else 'close'
    try:
        with httpx.Client(timeout=3, follow_redirects=False) as client:
            prefix = '/api/team' if member.get('room_mode') == 'group' else '/api'
            response = client.post(validate_hub(hub) + prefix + '/exchange',
                                   headers={'Authorization': 'Bearer ' + member['token']},
                                   json={'room_id': member['room_id'], 'op': operation})
        result = {'operation': operation, 'result': 'confirmed' if response.is_success else 'rejected',
                  'http_status': response.status_code}
    except Exception as error:
        # Absolute TTL and the short member lease remain the bounded fallback.
        result = {'operation': operation, 'result': 'unconfirmed', 'category': categorize(error),
                  'fallback': 'member lease expires about 180 seconds after its last heartbeat'}
    log.info('setup_cleanup', room_id=member.get('room_id'), **result)
    return result


def launch_or_close(config, operation='unknown'):
    try:
        return launch_session(config)
    except CoagenError as error:
        error.operation = operation if error.operation == 'unknown' else error.operation
        error.context['cleanup'] = retire_room(config['hub'], config['member'])
        raise
    except Exception as error:
        cleanup = retire_room(config['hub'], config['member'])
        raise CoagenError('LOCAL_HELPER_UNAVAILABLE', operation=operation, stage='launch_helper',
                          outcome='hub_accepted', cause=describe(error), context={'cleanup': cleanup}) from None


def prepare_state(path):
    path = Path(path).absolute()
    check_establishment(path / 'establishment.json')
    if path.exists() and not (path / '.coagen-owner').is_file():
        if any(path.iterdir()):
            raise ValueError('Choose a new, empty dedicated Coagen state directory.')
    control = path / 'control.json'
    if control.exists():
        prior = json.loads(control.read_text(encoding='utf-8'))
        if not prior.get('stopped') and psutil.pid_exists(prior.get('pid', -1)):
            raise ValueError('This state directory already has a running session.')
    secure_directory(path)
    terminal = _unlinked_path(path / 'stopped.json')
    (path / '.coagen-owner').write_text('coagen-v1\n', encoding='ascii')
    Store(path).clear_ephemeral()
    control.unlink(missing_ok=True)
    terminal.unlink(missing_ok=True)
    return path


class StartupProgress:
    """Helper-side startup milestones, read by the parent when the helper is slow or exits."""

    def __init__(self, path, spawned_at):
        self.path = Path(path) if path else None
        self.spawned_at = spawned_at if isinstance(spawned_at, float) else time.time()
        self.stages, self.last_stage, self.failure = [], 'process_started', None

    def _write(self):
        if self.path is None:
            return
        try:
            atomic_private_json(self.path, {'pid': os.getpid(), 'last_stage': self.last_stage,
                                            'stages': self.stages, 'failed': self.failure})
        except (OSError, ValueError):
            pass

    def mark(self, stage):
        self.last_stage = stage
        self.stages.append({'stage': stage, 't': round(time.time() - self.spawned_at, 3)})
        self._write()

    def fail(self, error):
        self.failure = error.to_dict()
        self._write()


HELPER_START_DEFAULT_SECONDS = 60.0


def resume_grace_seconds():
    """How long a Group membership outlives its MCP process, waiting to be resumed.

    Hosts restart MCP servers (idle shutdown after ~30 minutes, reconnects,
    crashes). 0 disables; the room expiry always caps the grace.
    """
    try:
        value = float(os.environ.get('COAGEN_RESUME_GRACE_SECONDS', '7200'))
    except ValueError:
        return 7200.0
    return min(21600.0, max(0.0, value)) if value == value else 7200.0


def helper_start_timeout():
    """Seconds the parent waits for the helper's control endpoint (COAGEN_HELPER_START_TIMEOUT)."""
    raw = os.environ.get('COAGEN_HELPER_START_TIMEOUT')
    try:
        value = float(raw) if raw else HELPER_START_DEFAULT_SECONDS
    except ValueError:
        value = HELPER_START_DEFAULT_SECONDS
    return min(600.0, max(5.0, value)) if value == value else HELPER_START_DEFAULT_SECONDS


def _read_progress(path):
    try:
        value = json.loads(Path(path).read_text(encoding='utf-8'))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _stderr_tail(path, lines=25):
    try:
        with open(path, 'rb') as stream:
            stream.seek(0, os.SEEK_END)
            stream.seek(max(0, stream.tell() - 16384))
            text = stream.read().decode('utf-8', 'replace')
    except OSError:
        return []
    return [redact.text(line, 300) for line in text.splitlines()[-lines:]]


def launch_session(config):
    root = Path(config['state_dir'])
    member = config.get('member') or {}
    redact.register(config.get('secret'), member.get('token'))
    progress_path, stderr_path = root / 'helper-start.json', root / 'helper-stderr.log'
    timeout = helper_start_timeout()
    kwargs = {'stdin': subprocess.PIPE, 'stdout': subprocess.DEVNULL,
              'text': True, 'encoding': 'utf-8', 'close_fds': True}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
    else:
        kwargs['start_new_session'] = True
    isolation = ['-I'] if sys.flags.isolated else []
    spawned_at, started = time.time(), time.monotonic()
    context = {'state_dir': str(root), 'timeout_seconds': timeout, 'timeout_setting': 'COAGEN_HELPER_START_TIMEOUT',
               'stderr_log': str(stderr_path), 'progress_file': str(progress_path), 'room_id': member.get('room_id')}
    stderr = None
    argv = [sys.executable, *isolation, '-X', 'utf8', '-m', 'coagen_client', '_serve',
            '--progress', str(progress_path), '--spawned-at', repr(spawned_at)]
    try:
        # Helper stderr is kept in its own private state directory for diagnosis.
        stderr = os.fdopen(os.open(stderr_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600), 'wb')
        if os.name == 'nt':
            # A host that kills its MCP server's job object would also kill the
            # helper and end the membership. Leave the job when it permits that;
            # otherwise start inside it as before (resume then needs the helper
            # to outlive the MCP process some other way).
            try:
                process = subprocess.Popen(argv, stderr=stderr, **{
                    **kwargs, 'creationflags': kwargs['creationflags'] | 0x01000000})  # CREATE_BREAKAWAY_FROM_JOB
                context['job_breakaway'] = True
            except OSError as breakaway_error:
                if getattr(breakaway_error, 'winerror', None) != 5:
                    raise
                context['job_breakaway'] = False
                process = subprocess.Popen(argv, stderr=stderr, **kwargs)
        else:
            process = subprocess.Popen(argv, stderr=stderr, **kwargs)
    except OSError as error:
        log.error('helper_spawn_failed', **context, cause=describe(error))
        raise CoagenError('LOCAL_HELPER_SPAWN_FAILED', stage='launch_helper', outcome='hub_accepted',
                          cause=describe(error), context=context) from None
    finally:
        if stderr is not None:
            stderr.close()
    context['helper_pid'] = process.pid
    log.info('helper_spawned', **context)
    try:
        process.stdin.write(json.dumps(config) + '\n')
        process.stdin.close()
    except OSError:
        pass  # An early exit is reported below with its exit code.
    while True:
        if (root / 'control.json').is_file():
            # Keep ownership of this exact Popen until exit. On POSIX an
            # unreaped helper remains a zombie with a visible PID, preventing
            # the conservative fresh-membership recovery from proving exit.
            # Never wait for unrelated children or block the MCP request here.
            threading.Thread(target=process.wait, daemon=True).start()
            elapsed = round(time.monotonic() - started, 2)
            stages = _read_progress(progress_path).get('stages', [])
            log.info('helper_ready', helper_pid=process.pid, start_seconds=elapsed, stages=stages, room_id=member.get('room_id'))
            return {'phase': 'starting', 'state_dir': str(root), 'helper_pid': process.pid,
                    'room_id': member.get('room_id'), 'helper_start_seconds': elapsed}
        if process.poll() is not None or time.monotonic() - started >= timeout:
            break
        time.sleep(0.1)
    exited = process.poll() is not None
    if not exited:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=10)
    progress = _read_progress(progress_path)
    context.update(waited_seconds=round(time.monotonic() - started, 2), exit_code=process.returncode,
                   stopped_by_parent=not exited, last_stage=progress.get('last_stage', 'not_started'),
                   stage_seconds={item.get('stage'): item.get('t') for item in progress.get('stages', [])
                                  if isinstance(item, dict)},
                   stderr_tail=_stderr_tail(stderr_path))
    failure = progress.get('failed') if isinstance(progress.get('failed'), dict) else None
    if failure:
        context['helper_error'] = {key: failure.get(key) for key in ('code', 'stage', 'summary', 'facts')}
    code = 'LOCAL_HELPER_EXITED' if exited else 'LOCAL_HELPER_START_TIMEOUT'
    log.error('helper_start_failed', code=code, **context)
    raise CoagenError(code, stage='launch_helper', outcome='hub_accepted',
                      cause=(failure or {}).get('cause'), context=context)


def room_options(args):
    ttl = getattr(args, 'ttl', 3600)
    if type(ttl) is not int or not 1 <= ttl <= 21600:
        raise ValueError('Initial TTL must be between 1 and 21600 seconds.')
    options = {'ttl_seconds': ttl}
    label = getattr(args, 'label', None)
    if label is not None:
        if (not isinstance(label, str) or len(label) > 128
                or any(unicodedata.category(char) in ('Cc', 'Cs') for char in label)):
            raise ValueError('Room label must be valid Unicode without control characters, up to 128 characters.')
        options['label'] = label
    mode, capacity, collaboration = (getattr(args, key, None) for key in ('room_mode', 'max_members', 'mode'))
    # A room outlives any one member's connection. Basic's one-shot lifecycle
    # remains available only when explicitly requested for legacy compatibility.
    mode = 'group' if mode is None else mode
    if mode == 'group':
        capacity = 8 if capacity is None else capacity
        collaboration = 'vanilla' if collaboration is None else collaboration
    if mode is not None:
        if mode not in ('basic', 'group'):
            raise ValueError('Unknown room mode.')
        options['room_mode'] = mode
    if capacity is not None:
        if mode != 'group' or type(capacity) is not int or not 2 <= capacity <= 8:
            raise ValueError('Group capacity must be between two and eight.')
        options['max_members'] = capacity
    if collaboration is not None:
        if mode != 'group' or collaboration not in ('vanilla', 'brainstorm', 'leader-led', 'round-robin'):
            raise ValueError('Collaboration mode requires an explicit group room.')
        options['mode'] = collaboration
    policy = getattr(args, 'brainstorm_policy', None)
    if policy is not None:
        if mode != 'group' or collaboration != 'brainstorm' or policy not in ('soft', 'strict'):
            raise ValueError('Brainstorm policy requires an explicit group room and soft or strict.')
        options['brainstorm_policy'] = policy
    return options


def public_room_fields(member):
    return {key: member[key] for key in ('label', 'label_revision', 'room_mode', 'group_protocol',
        'max_members', 'leader_peer_id', 'collaboration', 'expires_at') if key in member}


def create(args):
    from .agent_info import info_from_args
    agent_info = info_from_args(args)
    options = room_options(args)
    reservation = getattr(args, 'reservation_code', None)
    if getattr(args, 'reservation_code_stdin', False):
        reservation = sys.stdin.readline(96).rstrip('\r\n')
    if reservation is not None:
        validate_reservation_code(reservation, args.state_dir)
    owner = session_owner(args.owner_pid)
    root = prepare_state(args.state_dir)
    if reservation is None:
        credential = Path(args.admin_token_file) if args.admin_token_file else default_token_file()
        if getattr(args, 'non_interactive', False) and not credential.is_file():
            raise CoagenError('AUTH_FAILED', operation='create', stage='preflight')
        token = (credential.read_text(encoding='utf-8').strip()
                 if args.admin_token_file or credential.is_file() else getpass.getpass('Service access token: '))
        transport = Transport(args.hub, token)
    else:
        # Activation is an independent, one-use credential. Never read or attach
        # the administrator credential on this route, or persist the activation.
        transport = Transport(args.hub)
    if reservation is None and ('room_mode' in options or 'label' in options or args.ttl > 3600):
        try:
            capabilities = getattr(transport, 'capabilities', lambda: {})()
            if options.get('room_mode') == 'basic' and capabilities.get('group_protocol') != 'coagen-group/1':
                options.pop('room_mode')
            if (options.get('room_mode') == 'group' and capabilities.get('group_protocol') != 'coagen-group/1'
                    or 'label' in options and capabilities.get('room_names') is not True
                    or 'brainstorm_policy' in options and capabilities.get('collaboration_policy_supported') is not True
                    or args.ttl > capabilities.get('max_initial_ttl_seconds', 3600)):
                raise CoagenError('HUB_FEATURE_UNAVAILABLE', operation='create', stage='preflight')
        except Exception as error:
            transport.close()
            raise classify_error(error, operation='create', stage='preflight') from None
    gate = root / 'establishment.json'
    pending = begin_establishment(gate, 'create')
    try:
        route, body = (('/api/rooms', options) if reservation is None else
                       ('/api/rooms/claim', {'activation_code': reservation}))
        member = transport.request(route, json_body=body).json()
    except Exception as exc:
        # A malformed/lost success response cannot establish non-acceptance.
        error = establishment_error(exc, 'create', pending) if isinstance(exc, (HubError, httpx.RequestError, CoagenError)) else pending
        finish_establishment(gate, error)
        raise error from None
    finally:
        transport.close()
    locator = member.get('locator')
    if not isinstance(locator, str) or re.fullmatch(r'[0-9]{3}', locator) is None:
        retire_room(args.hub, member)
        finish_establishment(gate, CoagenError('INVALID_ARGUMENT', operation='create', stage='hub_create', outcome='hub_accepted'))
        raise ValueError('Hub does not support eight-digit Basic pairing. Upgrade the hub and client together.')
    code = locator + f'{secrets.randbelow(100000):05d}'
    config = {'hub': validate_hub(args.hub), 'member': member, 'secret': code,
              'state_dir': str(root), 'owner_pid': owner.pid, 'owner_started_at': owner.started_at,
              'agent_info': agent_info, 'mcp_instance_id': getattr(args, 'mcp_instance_id', None),
              'workspace': getattr(args, 'workspace', None),
              'resume_grace_seconds': getattr(args, 'resume_grace_seconds', 0) or 0}
    try:
        result = launch_or_close(config, 'create')
    except CoagenError as error:
        finish_establishment(gate, error)
        raise
    finish_establishment(gate)
    result.update(public_room_fields(member))
    result['pairing_code'] = code
    result['note'] = ('Give this eight-digit code only to intended group members. While the room remains open, a disconnected member can explicitly join again with this code using a fresh identity and keys; prior identity, leadership and inbox are not restored. It is not saved or uploaded.'
                      if member.get('room_mode') == 'group' else
                      'Give this one-time eight-digit code to the intended peer; it is not saved or uploaded.')
    return result


def join(args):
    from .agent_info import info_from_args
    agent_info = info_from_args(args)
    code = args.code
    if code is None:
        code = sys.stdin.readline(64).rstrip('\r\n') if args.code_stdin else getpass.getpass('Eight-digit pairing code: ')
    if not isinstance(code, str) or re.fullmatch(r'[0-9]{8}', code) is None:
        raise ValueError('Pairing code must contain exactly eight ASCII digits, including leading zeros.')
    validate_join_state(code, args.state_dir)
    owner = session_owner(args.owner_pid)
    root = prepare_state(args.state_dir)
    transport = Transport(args.hub)
    try:
        # The capability read sends neither the room code nor its secret suffix.
        capabilities = getattr(transport, 'capabilities', lambda: {})()
        body = {'locator': code[:3]}
        if capabilities.get('group_protocol') == 'coagen-group/1':
            body['protocols'] = ['coagen-group/1']
    except Exception as error:
        transport.close()
        raise classify_error(error, operation='join', stage='preflight') from None
    gate = root / 'establishment.json'
    pending = begin_establishment(gate, 'join')
    try:
        member = transport.request('/api/join', json_body=body).json()
    except Exception as exc:
        error = establishment_error(exc, 'join', pending) if isinstance(exc, (HubError, httpx.RequestError, CoagenError)) else pending
        finish_establishment(gate, error)
        raise error from None
    finally:
        transport.close()
    try:
        result = launch_or_close({'hub': validate_hub(args.hub), 'member': member,
                                 'secret': code, 'state_dir': str(root),
                                 'owner_pid': owner.pid, 'owner_started_at': owner.started_at,
                                 'agent_info': agent_info, 'mcp_instance_id': getattr(args, 'mcp_instance_id', None),
                                 'workspace': getattr(args, 'workspace', None),
                                 'resume_grace_seconds': getattr(args, 'resume_grace_seconds', 0) or 0},
                                'join')
    except CoagenError as error:
        finish_establishment(gate, error)
        raise
    finish_establishment(gate)
    result.update(public_room_fields(member))
    result['note'] = ('This is a fresh group membership and fresh pairwise keys. Rejoining an open room with the same authorized code does not restore a previous identity, leadership or inbox; request an encrypted context summary from a remaining member.'
                      if member.get('room_mode') == 'group' else
                      'This legacy Basic room ends when either membership ends; its pairing code cannot reopen a closed room.')
    return result


def terminal_status(root, operation, *, outcome='not_started'):
    path = Path(root) / 'stopped.json'
    try:
        # POSIX exclusive publication briefly has a staging hard link before
        # unlinking it. Wait only for that metadata transition, never follow it.
        _unlinked_path(path.parent)
        for attempt in range(3):
            info = path.lstat()
            if info.st_nlink == 2 and attempt < 2:
                time.sleep(0.005)
                continue
            _unlinked_path(path)
            break
        value = json.loads(path.read_text(encoding='utf-8'))
        status = value['status']
        if value.get('stopped') is not True or not isinstance(status, dict) or status.get('phase') not in {
                'stopped', 'expired', 'revoked', 'owner_exited', 'pairing_failed', 'closed'}:
            raise ValueError('Invalid terminal state.')
    except FileNotFoundError:
        return None
    except (OSError, ValueError, KeyError, TypeError):
        raise CoagenError('LOCAL_STORAGE_FAILED', operation=operation, stage='local_state') from None
    if operation not in ('status', 'stop'):
        raise CoagenError('SESSION_EXPIRED' if status['phase'] == 'expired' else 'SESSION_REVOKED',
                          operation=operation, stage='local_helper', phase=status['phase'], outcome=outcome)
    journal = Diagnostics(root).snapshot()
    status = dict(status)
    status['diagnostic_write_failed'] = bool(status.get('diagnostic_write_failed') or journal['diagnostic_write_failed'])
    known = {item.get('incident_id') for item in status.get('incidents', [])}
    new = [item for item in journal['incidents'] if item.get('incident_id') not in known]
    if new:
        status['incidents'] = [*status.get('incidents', []), *new][-64:]
        status['last_operation_error'] = journal['last_operation_error'] or status.get('last_operation_error')
    return status_with_cli(root, status) if operation == 'status' else status


def helper_context(root, control=None):
    """Where the local helper stands, for errors that say it is unavailable."""
    root = Path(root)
    pid = (control or {}).get('pid')
    alive = None
    if type(pid) is int:
        try:
            process = psutil.Process(pid)
            alive = process.is_running() and process.status() != psutil.STATUS_ZOMBIE
        except psutil.Error:
            alive = False
    progress = _read_progress(root / 'helper-start.json')
    return {'state_dir': str(root), 'control_present': (root / 'control.json').is_file(), 'helper_pid': pid,
            'helper_alive': alive, 'startup_last_stage': progress.get('last_stage'),
            'stderr_tail': _stderr_tail(root / 'helper-stderr.log', 10), 'stderr_log': str(root / 'helper-stderr.log')}


def call_local(root, args):
    if root is None:
        if args['op'] == 'status':
            return {'phase': 'no_session', **Diagnostics(cli_diagnostic_root()).snapshot()}
        raise CoagenError('NO_ACTIVE_SESSION', operation=args['op'], stage='local_state', phase='no_session')
    root = Path(root)
    if args['op'] == 'audit':
        return Store(root).history(limit=args.get('limit', 100), since=args.get('since', 0),
                                   direction=args.get('direction'), peer=args.get('peer'))
    terminal = terminal_status(root, args['op'])
    if terminal is not None:
        return terminal
    try:
        control = json.loads((root / 'control.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        terminal = terminal_status(root, args['op'])
        if terminal is not None:
            return terminal
        raise CoagenError('LOCAL_HELPER_UNAVAILABLE', operation=args['op'], stage='local_helper',
                          context=helper_context(root)) from None
    if control.get('stopped'):
        if args['op'] in ('status', 'stop'):
            return status_with_cli(root, control['status']) if args['op'] == 'status' else control['status']
        phase = control.get('status', {}).get('phase', 'stopped')
        raise CoagenError('SESSION_EXPIRED' if phase == 'expired' else 'SESSION_REVOKED',
                          operation=args['op'], stage='local_helper', phase=phase)
    # These credentials authorize loopback IPC only, not hub access or content decryption.
    if not control['url'].startswith('http://127.0.0.1:'):
        raise ValueError('Invalid local control address.')
    # Uploads run inside the call and may take minutes on a slow uplink
    # (transfers are capped at TRANSFER_CAP_SECONDS); everything else is short.
    long_running = args['op'] in ('send', 'retry_saved_packet')
    with httpx.Client(timeout=960 if long_running else 60, trust_env=False) as client:
        try:
            response = client.post(control['url'], headers={'Authorization': 'Bearer ' + control['token']}, json=args)
        except httpx.RequestError as request_error:
            # Shutdown can finish after we read the live control file but before connecting.
            terminal = terminal_status(root, args['op'],
                outcome='unknown' if args['op'] in {'send', 'consume', 'retry_saved_packet'} else 'not_started')
            if terminal is not None:
                return terminal
            try:
                latest = json.loads((root / 'control.json').read_text(encoding='utf-8'))
            except (OSError, ValueError):
                latest = {}
            if latest.get('stopped') and args['op'] in ('status', 'stop'):
                return status_with_cli(root, latest['status']) if args['op'] == 'status' else latest['status']
            context = helper_context(root, control)
            log.error('helper_unreachable', op=args['op'], **context, cause=describe(request_error))
            raise CoagenError('LOCAL_HELPER_UNAVAILABLE', operation=args['op'], stage='local_helper',
                              outcome='unknown' if args['op'] in {'send', 'consume', 'retry_saved_packet'} else 'not_started',
                              cause=describe(request_error), context=context) from None
        response.raise_for_status()
        result = response.json()
    if args['op'] in ('status', 'stop'):
        terminal = terminal_status(root, args['op'])
        if terminal is not None:
            return terminal
    if not result['ok']:
        report = result.get('error')
        if isinstance(report, dict):
            raise CoagenError.from_dict(report)
        # Old helpers may return exception strings; never reflect them.
        raise CoagenError('INTERNAL_ERROR', operation=args['op'], stage='local_helper')
    return status_with_cli(root, result['data']) if args['op'] == 'status' else result['data']


def parser():
    parser = argparse.ArgumentParser(prog='coagen', description='Encrypted collaboration capsules for pairs and small groups')
    commands = parser.add_subparsers(dest='command', required=True)
    prepare_parser = commands.add_parser('prepare', help='Inspect local setup; no networking or secrets')
    prepare_parser.add_argument('--hub', default=DEFAULT_HUB)
    check_parser = commands.add_parser('check', help='Small, finite connectivity and optional read/write probe')
    check_parser.add_argument('--hub', default=DEFAULT_HUB)
    check_parser.add_argument('--admin-token-file')
    check_parser.add_argument('--timeout', type=float, default=8)
    check_parser.add_argument('--total-timeout', type=float, default=30)
    check_parser.add_argument('--output')
    create_parser = commands.add_parser('create')
    create_parser.add_argument('--hub', default=DEFAULT_HUB)
    create_parser.add_argument('--admin-token-file')
    create_parser.add_argument('--reservation-code-stdin', action='store_true',
                               help='Read a one-use room activation code from stdin; no administrator token is used')
    create_parser.add_argument('--ttl', type=int, default=3600)
    create_parser.add_argument('--label')
    create_parser.add_argument('--room-mode', choices=('basic', 'group'), default='group',
                               help='group (default) permits fresh same-code rejoining while open; basic is legacy one-shot compatibility')
    create_parser.add_argument('--max-members', type=int)
    create_parser.add_argument('--mode', choices=('vanilla', 'brainstorm', 'leader-led', 'round-robin'))
    create_parser.add_argument('--brainstorm-policy', choices=('soft', 'strict'))
    join_parser = commands.add_parser('join')
    join_parser.add_argument('--hub', default=DEFAULT_HUB)
    code_group = join_parser.add_mutually_exclusive_group()
    code_group.add_argument('--code', help='Eight-digit one-time pairing code; omit for private interactive input')
    code_group.add_argument('--code-stdin', action='store_true', help='Read the code from one line of stdin')
    for sub in (create_parser, join_parser):
        sub.add_argument('--owner-pid', type=int, help='Stable Agent PID; manual terminals may omit')
        sub.add_argument('--state-dir', required=True)
    for name in ('status', 'send', 'retry-send', 'receive', 'consume', 'audit', 'stop', 'collaboration'):
        sub = commands.add_parser(name)
        sub.add_argument('--state-dir', required=name != 'status')
        if name == 'send':
            group = sub.add_mutually_exclusive_group()
            group.add_argument('--text', default='')
            group.add_argument('--readme')
            sub.add_argument('--file', action='append', default=[])
            sub.add_argument('--kind', default='message')
            sub.add_argument('--ext', default='{}')
            sub.add_argument('--request-id')
            target = sub.add_mutually_exclusive_group()
            target.add_argument('--recipient-id')
            target.add_argument('--broadcast', action='store_true')
        elif name == 'retry-send':
            sub.add_argument('--request-id', required=True)
        elif name == 'receive':
            sub.add_argument('--wait', type=float, default=0)
        elif name == 'consume':
            sub.add_argument('--message-id', required=True)
        elif name == 'audit':
            sub.add_argument('--limit', type=int, default=100)
            sub.add_argument('--since', type=float, default=0)
            sub.add_argument('--direction')
            sub.add_argument('--peer')
            sub.add_argument('--output')
        elif name == 'collaboration':
            sub.add_argument('--action', required=True, choices=('configure', 'advance', 'pause', 'resume', 'finish', 'reopen'))
            sub.add_argument('--expected-revision', required=True, type=int)
            sub.add_argument('--request-id', required=True)
            sub.add_argument('--mode', choices=('vanilla', 'brainstorm', 'leader-led', 'round-robin'))
            sub.add_argument('--leader-peer-id')
            sub.add_argument('--max-turns', type=int)
            sub.add_argument('--brainstorm-policy', choices=('soft', 'strict'))
            sub.add_argument('--target-peer-id')
    serve_parser = commands.add_parser('_serve', help=argparse.SUPPRESS)
    serve_parser.add_argument('--progress')
    serve_parser.add_argument('--spawned-at', type=float)
    mcp_parser = commands.add_parser('mcp', help='Run the local stdio MCP bridge for an Agent')
    mcp_parser.add_argument('--workspace', default=os.getcwd())
    # None lets COAGEN_MCP_HUB (written by install-mcp and host descriptors) apply
    # before the production default; an explicit --hub still wins.
    mcp_parser.add_argument('--hub', default=None)
    mcp_parser.add_argument('--state-dir')
    mcp_parser.add_argument('--owner-pid', type=int)
    for sub in (create_parser, join_parser, mcp_parser):
        sub.add_argument('--agent-name', help='Optional self-reported Agent name for room display')
        sub.add_argument('--agent-version', help='Optional self-reported Agent version; never inferred')
    install_parser = commands.add_parser('install-mcp', help='Merge the local Coagen MCP server into .mcp.json')
    install_parser.add_argument('--path', default='.mcp.json')
    install_parser.add_argument('--hub', default=DEFAULT_HUB)
    return parser


def main(argv=None):
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='strict')
    args = parser().parse_args(argv)
    logical_key = None
    startup = None
    log.configure(state_base(), {'_serve': 'helper', 'mcp': 'mcp'}.get(args.command, 'cli'))
    if args.command == 'mcp':
        log.info('mcp_starting', workspace=args.workspace, **startup_facts())
    try:
        if args.command == '_serve':
            startup = StartupProgress(args.progress, args.spawned_at)
            startup.mark('cli_imported')
            config = json.loads(sys.stdin.readline())
            redact.register(config.get('secret'), (config.get('member') or {}).get('token'))
            startup.mark('config_read')
            from . import runtime as runtime_module
            from .runtime import SessionRuntime
            runtime = SessionRuntime
            if config['member'].get('room_mode') == 'group':
                from .group_runtime import GroupRuntime
                runtime = GroupRuntime
            runtime_module.STARTUP = startup
            startup.mark('runtime_imported')
            log.info('helper_starting', room_id=config['member'].get('room_id'), state_dir=config.get('state_dir'),
                     **startup_facts())
            instance = runtime(config)
            log.info('helper_initialized', stages=startup.stages)
            instance.serve()
            return 0
        if args.command == 'mcp':
            from .mcp import McpServer, serve_stdio
            serve_stdio(McpServer(workspace=args.workspace, hub=args.hub, state_dir=args.state_dir,
                                  owner_pid=args.owner_pid, agent_name=args.agent_name,
                                  agent_version=args.agent_version))
            return 0
        if args.command == 'install-mcp':
            from .mcp import install_config
            install_config(args.path, sys.executable, args.hub)
            print(json.dumps({'installed': str(Path(args.path).absolute()), 'server': 'coagen'}, ensure_ascii=False))
            return 0
        if args.command == 'check':
            from .healthcheck import check_hub
            token = Path(args.admin_token_file).read_text(encoding='utf-8').strip() if args.admin_token_file else None
            result = check_hub(args.hub, admin_token=token, timeout=args.timeout, total_timeout=args.total_timeout)
            if args.output:
                atomic_private_json(Path(args.output), result)
            print(json.dumps(result, ensure_ascii=False, allow_nan=False))
            return {'pass': 0, 'partial': 2, 'fail': 1}[result['overall']]
        if args.command == 'prepare':
            result = prepare(args)
        elif args.command == 'create':
            result = create(args)
        elif args.command == 'join':
            result = join(args)
        else:
            operation = {'op': args.command}
            if args.command == 'send':
                ext = json.loads(args.ext)
                if not isinstance(ext, dict):
                    raise ValueError('ext must be a JSON object.')
                operation.update(text=args.text, files=[str(Path(p).absolute()) for p in args.file],
                                 kind=args.kind, ext=ext, request_id=args.request_id or uuid.uuid4().hex,
                                 recipient_id=args.recipient_id, broadcast=args.broadcast)
                logical_key = 'send:' + operation['request_id']
                if args.readme:
                    operation['readme'] = read_readme(args.readme)
            elif args.command == 'retry-send':
                operation.update(op='retry_saved_packet', request_id=args.request_id)
                logical_key = 'send:' + args.request_id
            elif args.command == 'receive':
                operation['wait'] = args.wait
            elif args.command == 'consume':
                operation['message_id'] = args.message_id
                logical_key = 'consume:' + args.message_id
            elif args.command == 'audit':
                operation.update(limit=args.limit, since=args.since, direction=args.direction, peer=args.peer)
            elif args.command == 'collaboration':
                operation.update({key: getattr(args, key) for key in ('action', 'expected_revision', 'request_id',
                    'mode', 'leader_peer_id', 'max_turns', 'brainstorm_policy', 'target_peer_id') if getattr(args, key) is not None})
            result = call_local(args.state_dir, operation)
            if args.command == 'audit' and args.output:
                atomic_private_json(Path(args.output), result)
        if args.command in {'create', 'join', 'send', 'retry-send', 'consume', 'receive', 'stop'}:
            if args.command not in {'send', 'retry-send'} or result.get('state') == 'sent':
                Diagnostics(cli_diagnostic_root(getattr(args, 'state_dir', None))).resolve(
                    channel='operation', key=logical_key or args.command.replace('-', '_'))
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 0
    except Exception as error:
        operation = args.command.replace('-', '_')
        original = error
        error = classify_error(error, operation=operation, stage='local_helper' if args.command == '_serve' else 'preflight')
        if args.command == '_serve':
            # The parent reads these to explain an early exit; stderr goes to helper-stderr.log.
            if startup is not None:
                startup.fail(error)
            log.error('helper_failed', code=error.code, cause=error.cause, last_stage=startup.last_stage if startup else None)
            print(redact.text(''.join(traceback.format_exception(original)), 8000), file=sys.stderr)
        root = cli_diagnostic_root(getattr(args, 'state_dir', None))
        diagnostics = Diagnostics(root)
        report = diagnostics.record(error, channel='operation', key=logical_key or operation)
        report['diagnostic_write_failed'] = diagnostics.snapshot()['diagnostic_write_failed']
        print(json.dumps(report, ensure_ascii=False, allow_nan=False), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
