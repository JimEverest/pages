"""Coagen client: client-only encryption and explicit, bounded collaboration."""

__version__ = "0.7.5"
