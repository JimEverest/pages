"""Optional self-reported display identity; never used for authorization."""
import os
import unicodedata

from . import __version__

LIMITS = {'name': 128, 'version': 64, 'client_version': 64}


def validate_agent_info(value):
    if value is None:
        value = {}
    if not isinstance(value, dict) or set(value) - LIMITS.keys():
        raise ValueError('Invalid agent display metadata.')
    result = {}
    for field, limit in LIMITS.items():
        item = value.get(field)
        if item is not None:
            if (not isinstance(item, str) or len(item) > limit
                    or any(unicodedata.category(char) in ('Cc', 'Cs') for char in item)):
                raise ValueError('Invalid agent display metadata.')
            item = item or None
        result[field] = item
    return result


def resolve_agent_info(name=None, version=None, client_info=None):
    info = {} if client_info is None else client_info
    if not isinstance(info, dict):
        raise ValueError('Invalid agent display metadata.')
    # Validate supplied clientInfo even when an explicit override wins. Extra
    # MCP clientInfo fields (title, icons, websiteUrl) are unrelated and ignored.
    reported = validate_agent_info({'name': info.get('name'), 'version': info.get('version')})
    return validate_agent_info({
        'name': name if name is not None else os.environ.get('COAGEN_AGENT_NAME', reported['name']),
        'version': version if version is not None else os.environ.get('COAGEN_AGENT_VERSION', reported['version']),
        'client_version': __version__,
    })


def info_from_args(args):
    supplied = getattr(args, 'agent_info', None)
    if supplied is not None:
        value = validate_agent_info(supplied)
        value['client_version'] = __version__
        return value
    return resolve_agent_info(getattr(args, 'agent_name', None), getattr(args, 'agent_version', None))
