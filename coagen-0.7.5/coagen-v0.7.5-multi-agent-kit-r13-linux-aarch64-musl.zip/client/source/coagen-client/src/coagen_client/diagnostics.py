"""Bounded private incident metadata, independent of delivery payloads and secrets."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import threading
import time

from .errors import CoagenError
from .store import _unlinked_path, atomic_private_json, secure_directory

MAX_INCIDENTS = 64
MAX_BYTES = 128 * 1024


class Diagnostics:
    def __init__(self, root):
        self.root, self.path = Path(root), Path(root) / 'diagnostics.json'
        self._lock = threading.RLock()
        self._records = []
        self._write_failed = False
        self._available = False
        try:
            secure_directory(self.root)
            self._available = True
            self._load()
        except (OSError, ValueError):
            self._write_failed = True

    @staticmethod
    def _key(key):
        return hashlib.sha256(str(key).encode('utf-8', errors='replace')).hexdigest() if key is not None else ''

    def _load(self):
        _unlinked_path(self.path)
        if not self.path.exists():
            return
        if self.path.stat().st_size > MAX_BYTES:
            raise ValueError('Diagnostic journal exceeds its size limit.')
        raw = json.loads(self.path.read_text(encoding='utf-8'))
        if not isinstance(raw, dict) or not isinstance(raw.get('incidents', []), list):
            raise ValueError('Invalid diagnostic journal.')
        for value in raw.get('incidents', [])[-MAX_INCIDENTS:]:
            if not isinstance(value, dict):
                continue
            clean = CoagenError.from_dict(value).to_dict()
            clean['channel'] = value.get('channel') if value.get('channel') in ('connection', 'operation') else 'operation'
            clean['status'] = 'resolved' if value.get('status') == 'resolved' else 'active'
            clean['_key'] = value.get('_key', '') if isinstance(value.get('_key', ''), str) and len(value.get('_key', '')) in (0, 64) and all(c in '0123456789abcdef' for c in value.get('_key', '')) else ''
            for key in ('first_seen', 'last_seen', 'resolved_at'):
                number = value.get(key)
                if type(number) in (int, float) and 0 <= number < 1e15:
                    clean[key] = number
            count = value.get('occurrences', 1)
            clean['occurrences'] = min(1000000, max(1, count)) if type(count) is int else 1
            self._records.append(clean)

    def _save(self):
        try:
            if not self._available:
                raise OSError('Diagnostic directory unavailable.')
            self._records = self._records[-MAX_INCIDENTS:]
            value = {'schema_version': 1, 'incidents': self._records}
            while len(json.dumps(value, ensure_ascii=False).encode('utf-8')) >= MAX_BYTES and len(self._records) > 1:
                self._records.pop(0)
            atomic_private_json(self.path, value)
            self._write_failed = False
        except (OSError, ValueError):
            self._write_failed = True

    @staticmethod
    def _public(value):
        return {key: copy.deepcopy(item) for key, item in value.items() if key != '_key'}

    def record(self, error, channel='operation', key=None):
        with self._lock:
            channel = channel if channel in ('connection', 'operation') else 'operation'
            report = CoagenError.from_dict(error.to_dict()).to_dict()
            digest = self._key(key)
            previous = next((item for item in reversed(self._records) if item['status'] == 'active'
                and item['channel'] == channel and item['_key'] == digest
                and item['code'] == report['code'] and item['operation'] == report['operation']
                and item['stage'] == report['stage']), None)
            now = time.time()
            if previous:
                report.update(incident_id=previous['incident_id'], first_seen=previous['first_seen'],
                              occurrences=min(1000000, previous['occurrences'] + 1))
                self._records.remove(previous)
            else:
                report.update(first_seen=now, occurrences=1)
            error.incident_id = report['incident_id']
            report.update(last_seen=now, status='active', channel=channel, _key=digest)
            from .observe import log
            log.error('incident', incident_id=report['incident_id'], code=report['code'], operation=report['operation'],
                      stage=report['stage'], outcome=report['outcome'], occurrences=report['occurrences'],
                      http_status=report['http_status'], cause=report.get('cause'), context=report.get('context'),
                      journal=str(self.path))
            self._records.append(report)
            self._save()
            return self._public(report)

    def resolve(self, channel='operation', key=None):
        with self._lock:
            digest = self._key(key)
            changed = False
            for item in self._records:
                if item['channel'] == channel and item['_key'] == digest and item['status'] == 'active':
                    item.update(status='resolved', resolved_at=time.time())
                    changed = True
            if changed:
                self._save()

    def retire_session(self):
        """A new or resumed session starts clean: earlier bridge incidents belonged to another session.

        They stay in the journal as resolved records for audit, but no longer
        show as active errors of the new session.
        """
        with self._lock:
            changed = False
            for item in self._records:
                if item['status'] == 'active':
                    item.update(status='resolved', resolved_at=time.time())
                    changed = True
            if changed:
                self._save()

    def resolve_incident_ids(self, incident_ids):
        """Reconcile mirrored errors only when the owning helper proves them resolved."""
        identities = set(identity for identity in incident_ids if isinstance(identity, str))
        with self._lock:
            changed = False
            for item in self._records:
                if item['incident_id'] in identities and item['status'] == 'active':
                    item.update(status='resolved', resolved_at=time.time())
                    changed = True
            if changed:
                self._save()

    def resolve_settled(self, operation, *, keys=None):
        """A later success retires obsolete input/policy errors, never uncertain delivery."""
        settled_codes = {'INVALID_ARGUMENT', 'INVALID_UTF8', 'INPUT_TEXT_OR_README',
                         'README_PATH_INVALID', 'ATTACHMENT_PATH_INVALID', 'PAIRING_PENDING'}
        digests = {self._key(key) for key in keys} if keys is not None else None
        if digests is not None:
            settled_codes.update(('HUB_REJECTED', 'RETRY_NOT_ALLOWED'))
        with self._lock:
            changed = False
            for item in self._records:
                if (item['channel'] == 'operation' and item['status'] == 'active'
                        and item['operation'] == operation and item['code'] in settled_codes
                        and (digests is None or item['_key'] in digests)
                        and item['outcome'] in ('not_started', 'local_only')):
                    item.update(status='resolved', resolved_at=time.time())
                    changed = True
            if changed:
                self._save()

    def snapshot(self, *, blocking=True):
        if not self._lock.acquire(blocking=blocking):
            return None
        try:
            public = [self._public(item) for item in self._records]
            last = lambda channel: next((item for item in reversed(public)
                if item['channel'] == channel and item['status'] == 'active'), None)
            return {'last_operation_error': last('operation'), 'connection_error': last('connection'),
                    'incidents': public, 'diagnostic_write_failed': self._write_failed}
        finally:
            self._lock.release()
