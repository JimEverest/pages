"""A strict PNG carrier for already authenticated ciphertext, not encryption.

The image is a fixed 1x1 transparent PNG. A private ancillary chunk carries a
versioned, bounded payload. It is intentionally identifiable and must survive
transport byte-for-byte; PNG re-encoding may discard private chunks.
"""
import struct
import zlib

MAX_CIPHERTEXT_BYTES = 16 * 1024 * 1024
SIGNATURE = b"\x89PNG\r\n\x1a\n"
_IHDR = struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)
# Fixed zlib stream prevents differing compression-library releases from
# producing incompatible carrier bytes; one filter byte + transparent RGBA.
_IDAT = bytes.fromhex("789c636000020000050001")
_VERSION = b"CGP1"
_KINDS = (b"IHDR", b"IDAT", b"cgEn", b"IEND")


class CarrierError(ValueError):
    """The payload was not a supported, intact Coagen PNG carrier."""


def _chunk(kind: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def pack_png(ciphertext: bytes) -> bytes:
    if not isinstance(ciphertext, bytes) or not 16 <= len(ciphertext) <= MAX_CIPHERTEXT_BYTES:
        raise CarrierError("Ciphertext must contain 16 bytes to 16 MiB")
    payload = _VERSION + struct.pack(">I", len(ciphertext)) + ciphertext
    return SIGNATURE + _chunk(b"IHDR", _IHDR) + _chunk(b"IDAT", _IDAT) + _chunk(b"cgEn", payload) + _chunk(b"IEND", b"")


def unpack_png(container: bytes) -> bytes:
    if not isinstance(container, bytes) or not 16 <= len(container) <= MAX_CIPHERTEXT_BYTES + 512:
        raise CarrierError("Carrier size is invalid")
    if not container.startswith(SIGNATURE):
        raise CarrierError("Invalid PNG signature")
    offset, chunks = 8, []
    for expected in _KINDS:
        if offset + 12 > len(container):
            raise CarrierError("Truncated PNG chunk")
        length = struct.unpack(">I", container[offset:offset + 4])[0]
        kind = container[offset + 4:offset + 8]
        if kind != expected or length > MAX_CIPHERTEXT_BYTES + 8 or offset + length + 12 > len(container):
            raise CarrierError("Invalid PNG chunk layout")
        data = container[offset + 8:offset + 8 + length]
        crc = struct.unpack(">I", container[offset + 8 + length:offset + 12 + length])[0]
        if crc != zlib.crc32(kind + data) & 0xffffffff:
            raise CarrierError("PNG checksum mismatch")
        chunks.append(data)
        offset += length + 12
    if offset != len(container) or chunks[0] != _IHDR or chunks[1] != _IDAT or chunks[3] != b"":
        raise CarrierError("Unsupported PNG structure or trailing data")
    payload = chunks[2]
    if len(payload) < 24 or payload[:4] != _VERSION:
        raise CarrierError("Invalid carrier version or payload")
    length = struct.unpack(">I", payload[4:8])[0]
    if length != len(payload) - 8 or not 16 <= length <= MAX_CIPHERTEXT_BYTES:
        raise CarrierError("Carrier payload length mismatch")
    return payload[8:]
