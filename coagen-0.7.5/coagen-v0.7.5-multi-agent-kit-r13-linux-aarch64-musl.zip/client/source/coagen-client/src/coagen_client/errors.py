"""Safe, shared failures. Exception text and server response bodies never cross this boundary."""
from __future__ import annotations

import math
import re
import ssl
import sqlite3
import time
import uuid

import httpx

# severity, allowed recovery, summary, next action
CATALOG = {
    'HUB_FEATURE_UNAVAILABLE': ('error', 'user_intervention', 'The Hub does not advertise the requested feature.', 'Update the Hub or explicitly choose a supported operation; do not recreate an active room to probe support.'),
    'INPUT_TEXT_OR_README': ('error', 'correct_input', 'Choose exactly one inline text or README file source.', 'Use text for inline content, or readme_path for an existing absolute file path.'),
    'README_PATH_INVALID': ('error', 'correct_input', 'The README file path is invalid or unavailable.', 'Use text for inline content; readme_path requires an existing absolute file under the attachment root.'),
    'ATTACHMENT_PATH_INVALID': ('error', 'correct_input', 'An attachment path is invalid or unavailable.', 'Provide an existing absolute path under the authorized attachment root.'),
    'HISTORY_NOT_FOUND': ('error', 'inspect_local', 'The requested local history record is unavailable.', 'List local sessions and use an existing session identifier; no room needs to be created.'),
    'EXPORT_CONFLICT': ('error', 'correct_input', 'The export destination conflicts with existing data.', 'Choose a new authorized destination; existing data has not been overwritten.'),
    'RETRY_NOT_ALLOWED': ('error', 'stop_operation', 'This saved request is not eligible for retransmission.', 'Inspect the original rejection reason. After correcting a confirmed rejected operation or an authorized policy change, start a new request; never replace an unknown-outcome send.'),
    'NO_ACTIVE_SESSION': ('error', 'join_if_authorized', 'No local session is bound.', 'Create or join once under the existing user authorization.'),
    'SESSION_ALREADY_ACTIVE': ('error', 'inspect_local', 'This MCP instance already has an active or unconfirmed local session.', 'Continue the existing session, or explicitly stop it after preserving results before creating or joining another membership.'),
    'INVALID_UTF8': ('error', 'correct_input', 'Local text is not valid UTF-8.', 'Correct the input or update the client; do not silently change the message.'),
    'INVALID_ARGUMENT': ('error', 'correct_input', 'A local parameter or path is invalid.', 'Check the documented input and authorized workspace before continuing.'),
    'PAIRING_PENDING': ('info', 'wait_status', 'Peer pairing is not ready.', 'Wait within the existing deadline and check status; do not join again.'),
    'SESSION_EXPIRED': ('error', 'stop_operation', 'The session or its owner is no longer active.', 'Preserve required results and report unfinished work; a new room needs authorization.'),
    'SESSION_REVOKED': ('error', 'stop_operation', 'The Hub rejected continued use of this session.', 'Report the observed status; do not guess the closing peer or recreate the room.'),
    'MEMBERSHIP_REVOKED': ('error', 'join_if_authorized', 'This membership has ended; the room may still be open.', 'Only when details.rejoin_allowed is true, join the same authorized code once as a fresh member after the old helper has ended. Keys, identity, leadership and inbox are not restored; request context from a remaining member.'),
    'ROOM_CLOSED': ('error', 'stop_operation', 'The room is closed and its pairing code cannot reopen it.', 'Report the structured reason and preserve results. A new room requires user authorization; legacy Basic rooms end with either member.'),
    'ROOM_EXPIRED': ('error', 'stop_operation', 'The room has reached its expiry.', 'Preserve results and report the expiry. The original pairing code cannot revive it; a new room requires user authorization.'),
    'LOCAL_HELPER_START_TIMEOUT': ('error', 'join_if_authorized', 'The local session helper did not become ready within the startup limit.', 'The helper was stopped and this membership was left on the Hub (see context.cleanup). Read context.last_stage and context.stage_seconds: slow imports or security scanning on this machine are typical. If the room is still wanted, set COAGEN_HELPER_START_TIMEOUT (seconds, up to 600) in the MCP server env, reload the host once and join again once with the same code.'),
    'LOCAL_HELPER_EXITED': ('error', 'inspect_local', 'The local session helper exited before it became ready.', 'Read context.exit_code, context.last_stage, context.helper_error and context.stderr_tail; correct that cause before joining again once. The membership was left on the Hub (see context.cleanup).'),
    'LOCAL_HELPER_SPAWN_FAILED': ('error', 'inspect_local', 'The local session helper process could not be started.', 'Read cause: the runtime Python may be missing or blocked by application control. Repair the runtime before joining again once.'),
    'LOCAL_HELPER_UNAVAILABLE': ('error', 'inspect_local', 'The local session helper is unavailable.', 'Inspect local status once. An explicitly authorized fresh join is possible only after the recorded helper is confirmed exited. If identity or liveness is unknown, preserve results and use the host normal MCP reload; do not replace the owner or infer a Hub failure.'),
    'HUB_UNAVAILABLE': ('error', 'bounded_retry', 'The connection or Hub request failed.', 'Use only the operation-specific bounded recovery; retain the incident if it fails.'),
    'HUB_REJECTED': ('error', 'stop_operation', 'The Hub rejected this request.', 'Inspect the safe status and documented parameters; do not repeat an unchanged rejected request.'),
    'SEND_OUTCOME_UNKNOWN': ('error', 'retry_saved_packet', 'The Hub may have accepted the upload; delivery is unconfirmed.', 'Check the saved request and retry only its frozen packet within its remaining budget.'),
    'SESSION_OUTCOME_UNKNOWN': ('error', 'inspect_local', 'Session establishment may have reached the Hub; its result is unknown.', 'Preserve the attempt and inspect local evidence; do not create or join again blindly.'),
    'ESTABLISHMENT_BLOCKED': ('error', 'inspect_local', 'An earlier session establishment has an unresolved outcome.', 'Resolve the original incident before another create or join attempt.'),
    'CRYPTO_FAILURE': ('critical', 'stop_operation', 'Client-side encryption failed.', 'Stop this operation and inspect the client; never send plaintext as a fallback.'),
    'MESSAGE_AUTH_FAILED': ('critical', 'stop_operation', 'The received packet failed validation or authentication.', 'Do not process its content or consume it as successful; preserve safe diagnostics.'),
    'LOCAL_STORAGE_FAILED': ('error', 'inspect_local', 'Required local data could not be read or saved.', 'Inspect local storage and preserve results before cleanup or another business action.'),
    'RETRY_BUDGET_EXHAUSTED': ('error', 'user_intervention', 'The recovery attempt or time limit has been reached.', 'Stop automatic recovery and report the original operation and its unresolved outcome.'),
    'RETRY_NOT_DUE': ('warning', 'wait_retry', 'The recovery attempt is not due yet.', 'Wait retry.retry_after_seconds, then repeat the same call with the same request identifier. Do not rejoin or create a room: the membership is still active and the helper keeps retrying in the background.'),
    'REQUEST_CONFLICT': ('error', 'stop_operation', 'This request identifier belongs to different content.', 'Use the original saved request; do not change content while recovering it.'),
    'PENDING_SEND': ('error', 'retry_saved_packet', 'An unresolved saved upload blocks new business messages.', 'Resolve the original saved upload before starting another send.'),
    'INTERNAL_ERROR': ('error', 'user_intervention', 'An unclassified local failure interrupted the operation.', 'Preserve the incident identifier for the developer; do not experiment with recovery.'),
    'DIAGNOSTIC_WRITE_FAILED': ('error', 'inspect_local', 'The diagnostic record could not be persisted.', 'Preserve the visible primary error and inspect local storage permissions.'),
    'NOTIFICATION_FAILED': ('error', 'user_intervention', 'The local MCP notification worker stopped after a failure.', 'Read coagen_status or coagen_prepare for the incident and report notification delivery as unavailable; do not restart an active room automatically.'),
    'AUTH_FAILED': ('error', 'user_intervention', 'Required authentication or authorization is unavailable or rejected.', 'Check the configured credential through its normal local management flow; do not expose it.'),
    'RATE_LIMITED': ('warning', 'bounded_retry', 'The Hub requested a lower request rate.', 'Respect the reported wait and operation budget; stop when the budget is insufficient.'),
    'TLS_FAILED': ('error', 'user_intervention', 'TLS verification failed.', 'Check the approved network and certificate setup; do not disable certificate verification.'),
    'ROOM_UNAVAILABLE': ('error', 'user_intervention', 'The requested room is unavailable or already occupied.', 'Report the Hub status and check the intended room; do not guess codes or recreate it.'),
    'CLEANUP_INCOMPLETE': ('error', 'inspect_local', 'Cleanup has not been fully confirmed.', 'Report which cleanup remains unconfirmed and preserve results; do not delete arbitrary directories.'),
}
OPERATIONS = frozenset(('unknown', 'prepare', 'create', 'join', 'status', 'watch', 'receive', 'send', 'consume',
                        'audit', 'stop', 'heartbeat', 'pair', 'pairing', 'retry_saved_packet', 'retry_send', 'stdio', 'initialize', 'establish', 'collaboration', 'sessions', 'read_message', 'message_status', 'export', 'network_check', 'resume', 'detach'))
STAGES = frozenset(('unknown', 'preflight', 'local_state', 'stdio_decode', 'stdio_encode', 'stdio', 'local_helper',
                   'create', 'join', 'hub_create', 'hub_join', 'hub_request', 'hub_exchange', 'hub_upload', 'hub_poll',
                   'hub_read', 'hub_ack', 'hub_consume', 'hub_close', 'heartbeat', 'pairing', 'encode_capsule',
                   'encrypt', 'save_outbox', 'mark_sent', 'receive_validate', 'validate', 'decrypt', 'extract',
                   'save_inbox', 'consume', 'cleanup', 'diagnostics', 'readme', 'read_input', 'input', 'state',
                   'launch_helper', 'owner', 'path_validation', 'read_attachment', 'fingerprint', 'retry',
                   'receive', 'send', 'status', 'store', 'storage', 'local_prepare', 'local_launch', 'hub_establish',
                   'hub_establishment', 'local_setup', 'session_state', 'request_validation', 'outbox_lookup',
                   'inbox_lookup', 'recovery', 'dispatch', 'receive_ack', 'read_inbox', 'receive_poll',
                   'verify_envelope', 'packet_download', 'verify_packet', 'extract_capsule', 'verify_capsule',
                   'consume_ack', 'consume_remote', 'cleanup_inbox', 'notification_monitor', 'retry_precondition',
                   'adopt', 'detach'))
PHASES = frozenset(('unknown', 'no_session', 'starting', 'waiting_for_peer', 'pairing', 'ready', 'stopping',
                   'stopped', 'expired', 'revoked', 'owner_exited', 'pairing_failed', 'cleanup_incomplete', 'closed'))
OUTCOMES = frozenset(('not_started', 'local_only', 'unknown', 'hub_accepted'))
RETRY_FIELDS = frozenset(('attempts_used', 'max_attempts', 'deadline', 'retry_after_seconds', 'remaining_attempts', 'window_seconds',
                          'new_incident_at', 'incident'))


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1e15


def safe_retry(value):
    return {key: number for key, number in (value or {}).items()
            if key in RETRY_FIELDS and _finite(number)} if isinstance(value, dict) else {}


HUB_REASONS = frozenset(('COLLAB_REVISION_MISMATCH', 'CONTRIBUTION_ALREADY_COMPLETED',
    'PHASE_SEND_NOT_ALLOWED', 'RECIPIENT_NOT_READY', 'MEMBERSHIP_INACTIVE',
    'REQUEST_ID_PAYLOAD_CONFLICT', 'COLLABORATION_PAUSED', 'COLLABORATION_COMPLETED',
    'TURN_SEND_NOT_ALLOWED', 'RECIPIENT_INACTIVE', 'SENDER_INACTIVE', 'INVALID_RECIPIENT',
    'COLLABORATION_NOT_RUNNING', 'LEADER_REQUIRED', 'PHASE_REOPEN_NOT_ALLOWED',
    'CONTRIBUTION_NOT_COMPLETED', 'TURN_LIMIT_REACHED', 'CONTRIBUTION_REOPEN_NOT_ALLOWED',
    'LEADER_RECIPIENT_REQUIRED', 'MESSAGE_STATUS_UNAVAILABLE',
    'MESSAGE_ID_PAYLOAD_CONFLICT', 'MESSAGE_SEQUENCE_CONFLICT',
    'ROOM_EXPIRED', 'ROOM_CLOSED', 'BASIC_SESSION_ENDED', 'MEMBER_INACTIVE', 'ROOM_CAPACITY_REACHED'))
SAFE_ACTIONS = frozenset(('refresh_status', 'review_current_state', 'contact_leader',
    'configure', 'reopen', 'advance', 'wait', 'stop', 'resume', 'new_request_after_correction',
    'inspect_request', 'correct_input', 'wait_for_turn', 'wait_for_peer', 'request_reopen',
    'inspect_membership', 'review_current_policy', 'inspect_original_request', 'send_to_leader',
    'wait_for_phase', 'reopen_contribution', 'inspect_message_ids',
    'join_again_explicitly', 'wait_for_member_slot', 'inspect_room', 'create_new_room'))
LOCAL_REASONS = frozenset(('invalid_kind', 'invalid_ext', 'invalid_json', 'invalid_readme',
    'invalid_utf8', 'invalid_path', 'duplicate_path', 'source_not_regular', 'source_link',
    'too_many_entries', 'size_limit_exceeded', 'recording_failed', 'invalid_message_ids',
    'incident_cooldown', 'session_owned_by_live_instance', 'owner_not_running'))


def safe_details(value):
    """Accept typed diagnostic metadata only; never relay arbitrary server text."""
    if not isinstance(value, dict):
        return {}
    result = {}
    reason = value.get('reason_code', value.get('code'))
    if isinstance(reason, str) and reason in HUB_REASONS:
        result['reason_code'] = reason
    if value.get('room_mode') in ('basic', 'group'):
        result['room_mode'] = value['room_mode']
    if type(value.get('rejoin_allowed')) is bool and result.get('reason_code') in {
            'ROOM_EXPIRED', 'ROOM_CLOSED', 'BASIC_SESSION_ENDED', 'MEMBER_INACTIVE', 'ROOM_CAPACITY_REACHED'}:
        result['rejoin_allowed'] = value['rejoin_allowed']
    if reason == 'ROOM_CAPACITY_REACHED' and _finite(value.get('retry_after_seconds')) and value['retry_after_seconds'] <= 21600:
        result['retry_after_seconds'] = value['retry_after_seconds']
    for key in ('current_revision', 'expected_revision'):
        if type(value.get(key)) is int and 0 <= value[key] <= 2**53:
            result[key] = value[key]
    actions = value.get('allowed_actions')
    if isinstance(actions, list):
        result['allowed_actions'] = list(dict.fromkeys(a for a in actions if isinstance(a, str) and a in SAFE_ACTIONS))[:16]
    for key, choices in {
        'field': ('text', 'readme', 'readme_path', 'files', 'kind', 'ext', 'message_ids', 'request_id', 'destination', 'session_id'),
        'reason': LOCAL_REASONS,
        'expected': ('absolute_file_under_attachment_root', 'inline_text_or_readme_path', 'json_object', 'ascii_identifier', 'message_id_list'),
    }.items():
        if isinstance(value.get(key), str) and value[key] in choices:
            result[key] = value[key]
    if isinstance(value.get('original_code'), str) and value['original_code'] in CATALOG:
        result['original_code'] = value['original_code']
    incident = value.get('original_incident_id')
    if isinstance(incident, str) and re.fullmatch('[0-9a-f]{32}', incident):
        result['original_incident_id'] = incident
    for key in ('request_id_reusable', 'new_request_after_correction'):
        if type(value.get(key)) is bool:
            result[key] = value[key]
    collaboration = value.get('collaboration')
    if isinstance(collaboration, dict):
        clean = {}
        if type(collaboration.get('revision')) is int and 1 <= collaboration['revision'] <= 2**53:
            clean['revision'] = collaboration['revision']
        for key, choices in {'mode': ('vanilla', 'leader-led', 'round-robin', 'brainstorm'),
                             'phase': ('propose', 'review', 'synthesis', 'active', 'complete'),
                             'status': ('running', 'paused', 'completed'),
                             'brainstorm_policy': ('soft', 'strict')}.items():
            if isinstance(collaboration.get(key), str) and collaboration[key] in choices:
                clean[key] = collaboration[key]
        result['collaboration'] = clean
    return result


def _context(value):
    if not isinstance(value, dict):
        return {}
    from .observe import redact
    return {str(key): redact.value(item) for key, item in list(value.items())[:32]}


class CoagenError(ValueError):
    def __init__(self, code, *, operation='unknown', stage='unknown', outcome='not_started',
                 http_status=None, incident_id=None, retry=None, phase=None, side=None, details=None,
                 cause=None, context=None):
        self.code = code if isinstance(code, str) and code in CATALOG else 'INTERNAL_ERROR'
        self.operation = operation if isinstance(operation, str) and operation in OPERATIONS else 'unknown'
        self.stage = stage if isinstance(stage, str) and stage in STAGES else 'unknown'
        self.outcome = outcome if isinstance(outcome, str) and outcome in OUTCOMES else 'unknown'
        self.http_status = http_status if type(http_status) is int and 100 <= http_status <= 599 else None
        self.incident_id = incident_id if isinstance(incident_id, str) and re.fullmatch('[0-9a-f]{32}', incident_id) else uuid.uuid4().hex
        self.retry = safe_retry(retry)
        self.details = safe_details(details)
        self.phase = phase if isinstance(phase, str) and phase in PHASES else 'unknown'
        self.side = side.lower() if isinstance(side, str) and side.lower() in tuple('abcdefgh') else 'unknown'
        self.timestamp = time.time()
        from .observe import sanitize_cause
        # cause: why (layer, category, exception chain); context: where (stage timings, paths, exit codes).
        self.cause = sanitize_cause(cause)
        self.context = _context(context)
        super().__init__(CATALOG[self.code][2])

    def to_dict(self):
        severity, recovery, summary, next_action = CATALOG[self.code]
        report = {'schema_version': 1, 'incident_id': self.incident_id, 'timestamp': self.timestamp,
                'source': 'local', 'side': self.side, 'severity': severity, 'code': self.code,
                'operation': self.operation, 'stage': self.stage, 'phase': self.phase,
                'summary': summary, 'impact': 'The affected operation is incomplete or requires confirmation.',
                'outcome': self.outcome, 'delivery_outcome': self.outcome,
                'local_recording_outcome': ('failed' if self.code == 'LOCAL_STORAGE_FAILED' else 'not_reported'),
                'details': safe_details(self.details), 'facts': self._facts(summary),
                'possible_causes': ([self.cause['explanation']] if self.cause and self.cause.get('explanation') else []),
                'checks': list(self.cause.get('checks', [])) if self.cause else [],
                'cause': self.cause, 'context': self.context,
                'http_status': self.http_status, 'recovery': recovery, 'retry': safe_retry(self.retry),
                'next_action': next_action}
        # Plain-language version for the person; agents relay message_for_user verbatim.
        from .explain import explain
        report['explain'], report['message_for_user'] = explain(report)
        return report

    def _facts(self, summary):
        facts = [summary]
        if self.cause:
            chain = self.cause.get('chain') or []
            if chain:
                last = chain[-1]
                numbers = ', '.join('%s=%s' % (key, last[key]) for key in ('errno', 'errno_name', 'winerror', 'ssl_reason') if key in last)
                facts.append('%s failure (%s): %s%s' % (self.cause.get('layer'), self.cause.get('category'), last.get('type'),
                                                         (' [' + numbers + ']') if numbers else ''))
                if last.get('message'):
                    facts.append('Underlying error: ' + last['message'])
            request = self.cause.get('request')
            if isinstance(request, dict) and request.get('url'):
                facts.append('Request: %s %s after %s ms' % (request.get('method'), request.get('url'), request.get('elapsed_ms')))
        if self.http_status:
            facts.append('HTTP status %d' % self.http_status)
        for key in ('last_stage', 'exit_code', 'waited_seconds'):
            if key in self.context:
                facts.append('%s: %s' % (key, self.context[key]))
        return facts

    @classmethod
    def from_dict(cls, value):
        value = value if isinstance(value, dict) else {}
        item = cls(value.get('code'), **{key: value[key] for key in
            ('operation', 'stage', 'outcome', 'http_status', 'incident_id', 'retry', 'phase', 'side', 'details',
             'cause', 'context') if key in value})
        if _finite(value.get('timestamp')):
            item.timestamp = value['timestamp']
        return item


def classify_error(error, *, operation, stage, outcome='not_started'):
    if isinstance(error, CoagenError):
        return error
    status = getattr(error, 'status', None)
    if isinstance(error, httpx.HTTPStatusError):
        status = error.response.status_code
    reason = safe_details(getattr(error, 'details', {})).get('reason_code')
    cause, tls, tls_verify = error, False, False
    for _ in range(8):
        if cause is None:
            break
        tls = tls or isinstance(cause, ssl.SSLError)
        tls_verify = tls_verify or isinstance(cause, ssl.SSLCertVerificationError)
        cause = cause.__cause__ or cause.__context__
    if isinstance(error, UnicodeError):
        code = 'INVALID_UTF8'
    elif tls_verify:
        code = 'TLS_FAILED'
    elif tls:
        # A handshake cut short (EOF, reset, alert) by an inspecting proxy, VPN
        # or unstable link is a transient transport failure, not a certificate
        # decision. cause.category keeps the TLS detail for diagnosis.
        code = 'HUB_UNAVAILABLE'
    elif status == 403 and safe_details(getattr(error, 'details', {})).get('reason_code'):
        code = 'HUB_REJECTED'
    elif status in (401, 403):
        code = 'AUTH_FAILED'
    elif status == 410 and reason in ('ROOM_CLOSED', 'BASIC_SESSION_ENDED', 'ROOM_EXPIRED', 'MEMBER_INACTIVE'):
        code = {'ROOM_CLOSED': 'ROOM_CLOSED', 'BASIC_SESSION_ENDED': 'ROOM_CLOSED',
                'ROOM_EXPIRED': 'ROOM_EXPIRED', 'MEMBER_INACTIVE': 'MEMBERSHIP_REVOKED'}[reason]
    elif status == 410 and (operation in ('create', 'join', 'heartbeat', 'status', 'pair', 'pairing')
                           or stage in ('receive_poll', 'hub_poll', 'pairing')):
        code = 'SESSION_REVOKED'
    elif status in (404, 409) and operation == 'join':
        code = 'ROOM_UNAVAILABLE'
    elif status == 429:
        code = 'RATE_LIMITED'
    elif type(status) is int and status not in (408, 500, 502, 503, 504):
        code = 'HUB_REJECTED'
    elif stage == 'local_helper' and isinstance(error, (httpx.RequestError, OSError)):
        code = 'LOCAL_HELPER_UNAVAILABLE'
    elif isinstance(error, httpx.RequestError) or type(status) is int:
        code = ('SEND_OUTCOME_UNKNOWN' if operation in ('send', 'retry_saved_packet', 'retry_send') and outcome == 'unknown'
                else 'SESSION_OUTCOME_UNKNOWN' if operation in ('create', 'join') and outcome == 'unknown'
                else 'HUB_UNAVAILABLE')
    elif stage in ('receive_validate', 'validate', 'decrypt', 'extract', 'verify_envelope', 'verify_packet', 'extract_capsule', 'verify_capsule'):
        code = 'LOCAL_STORAGE_FAILED' if isinstance(error, (OSError, sqlite3.Error)) else 'MESSAGE_AUTH_FAILED'
    elif stage == 'encrypt':
        code = 'CRYPTO_FAILURE'
    elif isinstance(error, (OSError, sqlite3.Error)):
        code = 'LOCAL_STORAGE_FAILED'
    elif isinstance(error, (ValueError, TypeError, KeyError)):
        code = 'INVALID_ARGUMENT'
    else:
        code = 'INTERNAL_ERROR'
    from .observe import CATEGORIES, describe
    cause = describe(error, http_status=status if type(status) is int else None,
                     reason_code=reason)
    if type(status) is int:
        category = 'http_server_error' if status >= 500 else 'http_rejected'
        layer, explanation, checks = CATEGORIES[category]
        cause.update(category=category, layer=layer, explanation=explanation, checks=list(checks))
    return CoagenError(code, operation=operation, stage=stage, outcome=outcome, http_status=status,
                       details=getattr(error, 'details', None), cause=cause)
