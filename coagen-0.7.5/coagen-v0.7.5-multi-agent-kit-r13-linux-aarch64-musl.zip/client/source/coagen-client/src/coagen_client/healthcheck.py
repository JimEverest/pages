"""Small, explicit connectivity and encrypted read/write diagnostics.

This probe uses normal verified HTTPS and the environment's proxy settings. It
does not alter networking, create local state, start helpers, or access user
files. Report strings are fixed categories, never remote bodies or exceptions.
Temporary rooms have a 60-second lifetime if a connection drops before cleanup.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import math
import re
import secrets
import socket
import ssl
import threading
import time

import httpx

from .carrier import pack_png, unpack_png
from .crypto import Pairing
from .transport import validate_hub

_JSON_LIMIT = 64 * 1024
_PACKET_LIMIT = 1024
_ROOM_TTL = 60
_NAMES = ('connect', 'authenticate', 'write', 'read', 'cleanup')
_DNS_SLOTS = threading.BoundedSemaphore(2)


def _diagnostic_loop():
    loop = asyncio.new_event_loop()

    async def getaddrinfo(host, port, *, family=0, type=0, proto=0, flags=0):
        # Use the normal OS resolver, including proxy hostnames. An OS resolver
        # cannot be cancelled safely; asyncio's default executor waits for it
        # during shutdown and can defeat the probe's deadline. A bounded daemon
        # worker may finish its lookup later but cannot hold the CLI open. It
        # handles only host/port, never a token, payload, or client state.
        if not _DNS_SLOTS.acquire(blocking=False):
            raise OSError('Diagnostic resolver capacity unavailable')
        future = loop.create_future()

        def finish(result, error):
            if not future.done():
                if error is not None:
                    future.set_exception(error)
                else:
                    future.set_result(result)

        def resolve():
            result = error = None
            try:
                result = socket.getaddrinfo(host, port, family, type, proto, flags)
            except Exception as caught:
                error = caught
            finally:
                _DNS_SLOTS.release()
            try:
                loop.call_soon_threadsafe(finish, result, error)
            except RuntimeError:
                pass  # The timed-out diagnostic already closed its event loop.

        try:
            threading.Thread(target=resolve, name='coagen-health-dns', daemon=True).start()
        except BaseException:
            _DNS_SLOTS.release()
            raise
        return await future

    loop.getaddrinfo = getaddrinfo
    return loop


class _Failure(Exception):
    def __init__(self, category):
        self.category = category
        super().__init__(category)


def _category(error):
    if isinstance(error, _Failure):
        return error.category
    if isinstance(error, (TimeoutError, httpx.TimeoutException)):
        return 'timeout'
    cause = error
    for _ in range(8):
        if isinstance(cause, ssl.SSLError):
            return 'tls_error'
        cause = getattr(cause, '__cause__', None)
        if cause is None:
            break
    if isinstance(error, httpx.RequestError):
        return 'network_error'
    return 'internal_error'


def _report():
    return {
        'service': 'coagen', 'overall': 'partial', 'elapsed_ms': 0,
        'checks': [dict(name=name, status='skipped', latency_ms=0,
                        http_status=None, error_category='not_tested', bytes=0)
                   for name in _NAMES],
        'temporary_resources': {
            'room_created': False, 'packet_created': False,
            'cleanup_confirmed': False, 'ttl_seconds': _ROOM_TTL,
        },
    }


def _object(data):
    try:
        value = json.loads(data)
    except (ValueError, UnicodeError, RecursionError):
        raise _Failure('unexpected_response') from None
    if not isinstance(value, dict):
        raise _Failure('unexpected_response')
    return value


def _identifier(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{32}', value) is not None


def _token(value):
    return isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9_-]{20,256}', value) is not None


def _member(value, role):
    if (not all(_identifier(value.get(name)) for name in ('room_id', 'session_id', 'peer_id'))
            or not _token(value.get('token')) or value.get('role') != role
            or type(value.get('expires_at')) not in (int, float)
            or not math.isfinite(value['expires_at']) or value['expires_at'] <= 0):
        raise _Failure('unexpected_response')
    if role == 'a' and (not isinstance(value.get('locator'), str)
                        or re.fullmatch(r'[0-9]{3}', value['locator']) is None):
        raise _Failure('unexpected_response')
    return value


class _Probe:
    def __init__(self, hub, token, timeout, total_timeout, report, started):
        self.hub, self.token, self.timeout = hub, token, timeout
        self.report = report
        self.checks = {item['name']: item for item in report['checks']}
        self.resources = report['temporary_resources']
        self.deadline = started + total_timeout
        self.reserve = min(timeout, 5.0, total_timeout / 4) if token else 0
        self.work_deadline = self.deadline - self.reserve
        self.a = self.b = None
        self.room_credentials = None
        self.room_uncertain = False
        self.pairings = []
        self.ciphers = []
        self.metadata = None
        self.png = self.plaintext = None
        self.verified = False

    async def request(self, stage, method, path, *, token=None, body=None,
                      data=None, files=None, max_bytes=_JSON_LIMIT, deadline=None):
        stage['http_status'] = None
        remaining = (self.work_deadline if deadline is None else deadline) - time.monotonic()
        if remaining <= 0:
            raise _Failure('budget_exhausted')
        duration = min(self.timeout, remaining)
        headers = {'Accept-Encoding': 'identity'}
        if token is not None:
            headers['Authorization'] = 'Bearer ' + token
        async with asyncio.timeout(duration):
            async with self.client.stream(method, self.hub + path, headers=headers,
                                          json=body, data=data, files=files,
                                          timeout=httpx.Timeout(duration)) as response:
                stage['http_status'] = response.status_code
                if not response.is_success:
                    raise _Failure({401: 'authentication_required', 403: 'forbidden'}.get(
                        response.status_code, 'http_error'))
                if response.headers.get('Content-Encoding', 'identity').lower() != 'identity':
                    raise _Failure('unexpected_encoding')
                length = response.headers.get('Content-Length')
                if length is not None:
                    try:
                        if int(length) < 0:
                            raise ValueError
                        if int(length) > max_bytes:
                            raise _Failure('response_too_large')
                    except ValueError:
                        raise _Failure('unexpected_response') from None
                chunks, count = [], 0
                # Raw iteration avoids decompression and bounds buffering before
                # parsing. The outer timeout also stops indefinitely slow drips.
                async for chunk in response.aiter_raw():
                    count += len(chunk)
                    if count > max_bytes:
                        raise _Failure('response_too_large')
                    chunks.append(chunk)
                if stage['name'] != 'write':
                    stage['bytes'] += count
                return b''.join(chunks)

    async def stage(self, name, action):
        stage = self.checks[name]
        started = time.monotonic()
        try:
            await action(stage)
        except Exception as error:
            stage.update(status='fail', error_category=_category(error))
            return False
        else:
            stage.update(status='pass', error_category=None)
            return True
        finally:
            stage['latency_ms'] = round((time.monotonic() - started) * 1000)

    async def connect(self, stage):
        health = _object(await self.request(stage, 'GET', '/health'))
        if health.get('status') != 'ok' or health.get('service') != 'coagen':
            raise _Failure('unexpected_response')

    async def authenticate(self, stage):
        self.room_uncertain = True
        data = await self.request(stage, 'POST', '/api/rooms', token=self.token,
                                  body={'ttl_seconds': _ROOM_TTL})
        self.resources['room_created'] = True
        value = _object(data)
        # Retain the minimum cleanup credentials before validating other fields.
        if _identifier(value.get('room_id')) and _token(value.get('token')):
            self.room_credentials = (value['room_id'], value['token'])
        self.a = _member(value, 'a')
        self.b = _member(_object(await self.request(
            stage, 'POST', '/api/join', body={'locator': self.a['locator']})), 'b')
        if (self.a['room_id'] != self.b['room_id']
                or self.a['session_id'] != self.b['session_id']
                or self.a['peer_id'] == self.b['peer_id']):
            raise _Failure('unexpected_response')

    async def write(self, stage):
        context = {'server_session_id': self.a['session_id'],
                   'peer_a': self.a['peer_id'], 'peer_b': self.b['peer_id']}
        secret = self.a['locator'] + f'{secrets.randbelow(100000):05d}'
        self.pairings = [Pairing(secret, self.a['room_id'], role, context=context)
                         for role in ('A', 'B')]
        hello_a, hello_b = (pair.start() for pair in self.pairings)
        self.ciphers = [self.pairings[0].finish(hello_b), self.pairings[1].finish(hello_a)]
        cipher_a, cipher_b = self.ciphers
        confirmation_a, confirmation_b = cipher_a.confirmation(), cipher_b.confirmation()
        cipher_a.verify_confirmation(confirmation_b)
        cipher_b.verify_confirmation(confirmation_a)
        self.metadata = {
            'room_id': self.a['room_id'], 'message_id': secrets.token_hex(16),
            'sender_id': self.a['peer_id'], 'recipient_id': self.b['peer_id'],
            'expires_at': float(min(self.a['expires_at'], self.b['expires_at'])),
            'sequence': 1, 'crypto_session_id': cipher_a.session_id,
        }
        self.plaintext = secrets.token_bytes(32)
        self.png = pack_png(cipher_a.encrypt(self.plaintext, sequence=1, metadata=self.metadata))
        if len(self.png) > _PACKET_LIMIT:
            raise _Failure('internal_error')
        stage['bytes'] = len(self.png)
        ext = {key: value for key, value in self.metadata.items() if key != 'sender_id'}
        data = await self.request(stage, 'POST', '/api/packets', token=self.a['token'],
                                  data={'ext': json.dumps(ext)},
                                  files={'file[]': ('probe.png', self.png, 'image/png')})
        self.resources['packet_created'] = True
        descriptor = _object(data)
        if (any(descriptor.get(key) != value for key, value in self.metadata.items())
                or descriptor.get('size') != len(self.png)
                or descriptor.get('sha256') != hashlib.sha256(self.png).hexdigest()
                or descriptor.get('consumed') is not False):
            raise _Failure('unexpected_response')

    async def read(self, stage):
        data = await self.request(stage, 'POST', '/api/packets/read', token=self.b['token'],
                                  body={'room_id': self.b['room_id'],
                                        'message_id': self.metadata['message_id']},
                                  max_bytes=_PACKET_LIMIT)
        try:
            if not secrets.compare_digest(data, self.png):
                raise ValueError
            plaintext = self.ciphers[1].decrypt(unpack_png(data), sequence=1, metadata=self.metadata)
            if not secrets.compare_digest(plaintext, self.plaintext):
                raise ValueError
        except ValueError:
            raise _Failure('integrity_error') from None
        self.verified = True

    async def cleanup(self, stage):
        failure = None
        failure_status = None
        if self.verified:
            # Leave time for room revocation even if an ACK or consume stalls.
            mutation_deadline = self.deadline - min(1.0, self.reserve / 2)
            try:
                for operation, key in (('ack', 'acked'), ('consume', 'consumed')):
                    ids = [self.metadata['message_id']]
                    response = _object(await self.request(
                        stage, 'POST', '/api/exchange', token=self.b['token'],
                        body={'room_id': self.b['room_id'], 'op': operation, 'message_ids': ids},
                        deadline=mutation_deadline))
                    if response.get(key) != ids:
                        raise _Failure('unexpected_response')
            except Exception as error:
                failure = error
                failure_status = stage['http_status']
        try:
            room_id, token = self.room_credentials
            response = _object(await self.request(
                stage, 'POST', '/api/exchange', token=token,
                body={'room_id': room_id, 'op': 'close'}, deadline=self.deadline))
            if response.get('closed') is not True:
                raise _Failure('unexpected_response')
        except Exception as error:
            if failure is None:
                failure, failure_status = error, stage['http_status']
        if failure is not None:
            stage['http_status'] = failure_status
            raise failure
        self.resources['cleanup_confirmed'] = True

    async def run(self):
        try:
            async with httpx.AsyncClient(verify=True, trust_env=True, follow_redirects=False) as client:
                self.client = client
                try:
                    if not await self.stage('connect', self.connect) or not self.token:
                        return
                    if not await self.stage('authenticate', self.authenticate):
                        return
                    if not await self.stage('write', self.write):
                        return
                    await self.stage('read', self.read)
                finally:
                    if self.room_credentials is not None:
                        await self.stage('cleanup', self.cleanup)
                    elif self.room_uncertain and self.checks['authenticate']['http_status'] not in (
                            400, 401, 403, 404, 405, 422, 429):
                        self.checks['cleanup'].update(status='fail', error_category='cleanup_unconfirmed')
        finally:
            for value in self.ciphers + self.pairings:
                value.close()
            self.token = self.a = self.b = self.room_credentials = None
            self.plaintext = self.png = None


def check_hub(hub, admin_token=None, timeout=8, total_timeout=30):
    """Return a sanitized report; a token enables one temporary 32-byte probe.

    ``bytes`` counts the encrypted PNG for write/read and response bytes for
    other stages. ``room_created``/``packet_created`` mean acknowledged creation;
    lost responses may leave a temporary room until its 60-second expiry. All
    network operations share the total budget, with time reserved for cleanup.
    This synchronous API is intended for CLI callers, outside an asyncio loop.
    """
    started = time.monotonic()
    report = _report()
    try:
        if (type(timeout) not in (float, int) or type(total_timeout) not in (float, int)
                or not math.isfinite(timeout) or not math.isfinite(total_timeout)
                or not 0 < timeout <= 60 or not 0 < total_timeout <= 120
                or (admin_token is not None and (not isinstance(admin_token, str)
                    or not 1 <= len(admin_token) <= 4096
                    or any(ord(char) < 33 or ord(char) > 126 for char in admin_token)))):
            raise ValueError
        hub = validate_hub(hub)
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            raise ValueError
    except (ValueError, TypeError, AttributeError):
        report['checks'][0].update(status='fail', error_category='invalid_configuration')
    else:
        probe = _Probe(hub, admin_token, float(timeout), float(total_timeout), report, started)
        try:
            with asyncio.Runner(loop_factory=_diagnostic_loop) as runner:
                runner.run(probe.run())
        except Exception as error:
            # Client initialization/closure can also fail; never expose details.
            stage = next((item for item in report['checks'] if item['status'] != 'pass'),
                         report['checks'][-1])
            stage.update(status='fail', error_category=_category(error))
    report['overall'] = ('fail' if any(item['status'] == 'fail' for item in report['checks'])
                         else 'pass' if all(item['status'] == 'pass' for item in report['checks'])
                         else 'partial')
    report['elapsed_ms'] = round((time.monotonic() - started) * 1000)
    return report
