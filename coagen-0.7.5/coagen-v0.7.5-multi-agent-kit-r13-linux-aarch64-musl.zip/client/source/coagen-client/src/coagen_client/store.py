"""Local durable delivery bookkeeping. E2EE keys never enter this database."""
import getpass
from contextlib import contextmanager
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import subprocess
import time
import uuid

from .errors import CoagenError


class FileSharingViolation(OSError):
    """A replacement blocked by a confirmed Windows sharing conflict."""
    winerror = 32


def _windows_file_handle(path, access):
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    create = kernel.CreateFileW
    create.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
                       wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    create.restype = wintypes.HANDLE
    close = kernel.CloseHandle
    close.argtypes, close.restype = [wintypes.HANDLE], wintypes.BOOL
    # Share read, write and delete; OPEN_EXISTING never creates or changes a file.
    handle = create(str(path), access, 7, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    return handle, close


def _replace_sharing_conflict(path, error):
    if os.name != 'nt':
        return False
    if getattr(error, 'winerror', None) in (32, 33):
        return True
    if getattr(error, 'winerror', None) != 5:
        return False
    # MoveFileEx can report ACCESS_DENIED for a reader denying delete sharing.
    # Confirm that specific cause without deleting or changing permissions.
    try:
        handle, close = _windows_file_handle(path, 0x10000)  # DELETE access only
    except OSError as probe:
        return getattr(probe, 'winerror', None) in (32, 33)
    close(handle)
    return False


def _trusted_system_link(path, info):
    """A POSIX symlink only the administrator can change, e.g. macOS /var or /tmp.

    The link must be root-owned inside a root-owned directory that other users
    cannot modify (sticky directories qualify). Links a user created, or could
    re-point, are never trusted. Windows reparse points stay fail-closed.
    """
    if os.name == 'nt' or not stat.S_ISLNK(info.st_mode) or info.st_uid != 0:
        return False
    if os.geteuid() == 0 and path.parent != Path('/'):
        # For root every self-made link is root-owned; trust only top-level layout aliases.
        return False
    try:
        # Ancestors were already validated in order, so following them is safe.
        parent = path.parent.stat()
    except OSError:
        return False
    return (stat.S_ISDIR(parent.st_mode) and parent.st_uid == 0 and
            (not parent.st_mode & (stat.S_IWGRP | stat.S_IWOTH) or bool(parent.st_mode & stat.S_ISVTX)))


def _unlinked_path(path):
    """Reject links before touching state, including Windows reparse points.

    Fails closed for user-controlled links and hard links. Root-owned system
    aliases above the user's data (macOS /var -> /private/var, /tmp, Linux
    /home -> /var/home) are accepted because only the administrator can change
    them. This is not a guarantee against a hostile local process racing
    filesystem changes after validation.
    """
    path = Path(path).absolute()
    for candidate in reversed((path, *path.parents)):
        try:
            info = candidate.lstat()
        except (FileNotFoundError, NotADirectoryError):
            continue
        if ((stat.S_ISLNK(info.st_mode) and not _trusted_system_link(candidate, info))
                or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)
                or (stat.S_ISREG(info.st_mode) and info.st_nlink > 1)):
            raise ValueError('State paths cannot contain links or reparse points.')
    return path


def secure_directory(path):
    path = _unlinked_path(path)
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    _unlinked_path(path)
    if os.name == 'nt':
        result = subprocess.run(['icacls', str(path), '/inheritance:r', '/grant:r',
                                 f'{getpass.getuser()}:(OI)(CI)F'],
                                capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
        if result.returncode:
            raise ValueError('Could not restrict session directory access.')
    else:
        path.chmod(0o700)
    return path


def atomic_private_json(path, value):
    _write_private_json(path, value)


def publish_private_json(path, value, *, parent_identity):
    """Publish a complete immutable record once, without replacing an old one."""
    _write_private_json(path, value, exclusive=True, parent_identity=parent_identity)


def _write_private_json(path, value, *, exclusive=False, parent_identity=None):
    path = _unlinked_path(path)
    parent = path.parent.stat()
    expected_parent = parent_identity or (parent.st_dev, parent.st_ino)
    if (parent.st_dev, parent.st_ino) != expected_parent:
        raise ValueError('State directory changed before publication.')
    if exclusive and path.exists():
        raise FileExistsError('A terminal record already exists.')
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False)
        stream.flush(); os.fsync(stream.fileno())
    _unlinked_path(path)
    parent = path.parent.stat()
    if (parent.st_dev, parent.st_ino) != expected_parent:
        raise ValueError('State directory changed during publication.')
    if exclusive:
        if os.name == 'nt':
            os.rename(temporary, path)  # Windows rename refuses existing targets.
        else:
            os.link(temporary, path, follow_symlinks=False)  # Atomic, no overwrite.
            temporary.unlink()
        return
    try:
        os.replace(temporary, path)
    except OSError as error:
        if _replace_sharing_conflict(path, error):
            raise FileSharingViolation('Atomic replacement is blocked by a file reader.') from None
        raise


def remove_owned_tree(root, target):
    root, target = _unlinked_path(root), _unlinked_path(target)
    resolved_root, resolved = root.resolve(), target.resolve()
    if resolved == resolved_root or resolved.parent != resolved_root:
        raise ValueError('Cleanup target must be a direct child of the owned directory.')
    if not resolved.exists():
        return
    for entry in resolved.rglob('*'):
        _unlinked_path(entry)
    shutil.rmtree(resolved)


def incident_cooldown(previous_incidents):
    """Seconds before a spent retry incident may reopen: 5, 10, 20, 40, then 60."""
    return min(60, 5 * 2 ** min(int(previous_incidents or 0), 4))


class Store:
    def __init__(self, root):
        self.root = _unlinked_path(root)
        self.path = self.root / 'delivery.sqlite3'
        self._validate_paths()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        for name in ('inbox', 'outbox'):
            (self.root / name).mkdir(exist_ok=True, mode=0o700)
        with self.db() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS counters(session TEXT PRIMARY KEY, value INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS outgoing(request_id TEXT PRIMARY KEY, metadata TEXT NOT NULL,
                path TEXT NOT NULL, state TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS incoming(message_id TEXT PRIMARY KEY, metadata TEXT NOT NULL,
                folder TEXT NOT NULL, state TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS group_plans(request_id TEXT PRIMARY KEY, plan TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit(sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL, direction TEXT, peer TEXT, room TEXT, kind TEXT,
                bytes INTEGER, result TEXT, message_id TEXT);
            CREATE TABLE IF NOT EXISTS recovery(key TEXT PRIMARY KEY, started REAL NOT NULL,
                attempts INTEGER NOT NULL, code TEXT, stage TEXT, outcome TEXT,
                retryable INTEGER NOT NULL DEFAULT 1);
            ''')
            columns = {row[1] for row in db.execute('PRAGMA table_info(outgoing)')}
            for name, declaration in {
                'fingerprint': 'TEXT', 'attempts': 'INTEGER NOT NULL DEFAULT 0',
                'first_attempt': 'REAL', 'outcome': "TEXT NOT NULL DEFAULT 'local_only'",
                'retryable': 'INTEGER NOT NULL DEFAULT 1', 'next_attempt_at': 'REAL NOT NULL DEFAULT 0',
                'receipt': 'TEXT', 'failure': 'TEXT',
            }.items():
                if name not in columns:
                    db.execute(f'ALTER TABLE outgoing ADD COLUMN {name} {declaration}')
            recovery_columns = {row[1] for row in db.execute('PRAGMA table_info(recovery)')}
            for name, declaration in {'next_attempt_at': 'REAL NOT NULL DEFAULT 0',
                                      'incidents': 'INTEGER NOT NULL DEFAULT 0'}.items():
                if name not in recovery_columns:
                    db.execute(f'ALTER TABLE recovery ADD COLUMN {name} {declaration}')
            for name, declaration in {'incidents': 'INTEGER NOT NULL DEFAULT 0'}.items():
                if name not in columns:
                    db.execute(f'ALTER TABLE outgoing ADD COLUMN {name} {declaration}')

    def _validate_paths(self):
        # SQLite can write sidecars as soon as a connection opens. Check all
        # known state paths first, not just the main database filename.
        for path in (self.root, self.root / 'inbox', self.root / 'outbox', self.path,
                     Path(str(self.path) + '-wal'), Path(str(self.path) + '-shm'),
                     Path(str(self.path) + '-journal')):
            _unlinked_path(path)

    @contextmanager
    def db(self):
        self._validate_paths()
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def next_sequence(self, session):
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO counters VALUES (?, 0) ON CONFLICT DO NOTHING', (session,))
            db.execute('UPDATE counters SET value=value+1 WHERE session=?', (session,))
            return db.execute('SELECT value FROM counters WHERE session=?', (session,)).fetchone()[0]

    def group_plan(self, request_id):
        with self.db() as db:
            row = db.execute('SELECT plan FROM group_plans WHERE request_id=?', (request_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_group_plan(self, request_id, plan):
        with self.db() as db:
            db.execute('INSERT INTO group_plans VALUES(?,?)', (request_id, json.dumps(plan)))

    def save_outgoing(self, request_id, metadata, data, *, fingerprint=None, receipt=None):
        self._validate_paths()
        path = self.root / 'outbox' / (uuid.uuid4().hex + '.png')
        with path.open('xb') as stream:
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
        try:
            with self.db() as db:
                db.execute('INSERT INTO outgoing(request_id,metadata,path,state,fingerprint,receipt) VALUES (?, ?, ?, ?, ?, ?)',
                           (request_id, json.dumps(metadata), str(path), 'pending', fingerprint, json.dumps(receipt) if receipt is not None else None))
        except Exception:
            path.unlink(missing_ok=True)
            raise

    def outgoing(self, request_id):
        with self.db() as db:
            row = db.execute('SELECT * FROM outgoing WHERE request_id=?', (request_id,)).fetchone()
        if row is None:
            return None
        result = dict(row); result['metadata'] = json.loads(result['metadata'])
        result['receipt'] = json.loads(result['receipt']) if result.get('receipt') else None
        result['failure'] = json.loads(result['failure']) if result.get('failure') else None
        result['path'] = _unlinked_path(result['path'])
        if result['path'].resolve().parent != (self.root / 'outbox').resolve():
            raise ValueError('Outgoing data must remain in the owned outbox.')
        result['bytes'] = result['path'].read_bytes() if result['state'] == 'pending' else None
        return result

    def mark_sent(self, request_id):
        row = self.outgoing(request_id)
        if row:
            with self.db() as db:
                db.execute("UPDATE outgoing SET state='sent' WHERE request_id=?", (request_id,))
            row['path'].unlink(missing_ok=True)

    def has_pending_send(self, *, excluding=None):
        with self.db() as db:
            return db.execute("SELECT 1 FROM outgoing WHERE state='pending' AND (outcome!='local_only' OR retryable=1) AND request_id != ? LIMIT 1",
                              (excluding or '',)).fetchone() is not None

    def pending_request_id(self):
        with self.db() as db:
            row = db.execute("SELECT request_id FROM outgoing WHERE state='pending' AND (outcome!='local_only' OR retryable=1) LIMIT 1").fetchone()
            return row[0] if row else None

    def pending_group_target(self, peer_id):
        """An uncertain delivery forbids fresh business sends on that channel."""
        with self.db() as db:
            rows = db.execute("SELECT request_id,metadata FROM outgoing WHERE state='pending' AND outcome='unknown'").fetchall()
        return next((row['request_id'] for row in rows if json.loads(row['metadata']).get('recipient_id') == peer_id), None)

    def rejected_send_request_ids(self, recipient_id):
        """Known rejections on the same channel; never include unknown uploads."""
        with self.db() as db:
            rows = db.execute("SELECT request_id,metadata FROM outgoing WHERE outcome='local_only' AND retryable=0").fetchall()
            plans = db.execute('SELECT request_id,plan FROM group_plans').fetchall()
        requests = {row['request_id'] for row in rows if json.loads(row['metadata']).get('recipient_id') == recipient_id}
        # A directed group failure is recorded under both child and tool request IDs.
        for row in plans:
            plan = json.loads(row['plan'])
            if len(plan.get('targets', [])) == 1 and any(child.get('request_id') in requests for child in plan.get('children', {}).values()):
                requests.add(row['request_id'])
        return requests

    def claim_send_attempt(self, request_id, *, max_attempts=2, window_seconds=30):
        """Reserve an upload before doing network I/O; repeated tools share the budget."""
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM outgoing WHERE request_id=?', (request_id,)).fetchone()
            if row is None or row['state'] != 'pending':
                raise CoagenError('INVALID_ARGUMENT', operation='retry_saved_packet', stage='outbox_lookup')
            now = time.time()
            first = row['first_attempt'] if row['first_attempt'] is not None else now
            retry = {'attempts_used': row['attempts'], 'max_attempts': max_attempts,
                     'deadline': first + window_seconds, 'retry_after_seconds': 0}
            if not row['retryable']:
                failure = CoagenError.from_dict(json.loads(row['failure']) if row['failure'] else {}).to_dict()
                raise CoagenError('RETRY_NOT_ALLOWED', operation='send', stage='retry_precondition',
                    outcome=row['outcome'], http_status=failure.get('http_status'),
                    retry={**retry, 'remaining_attempts': 0}, details={**failure.get('details', {}),
                    'original_code': failure['code'], 'original_incident_id': failure['incident_id'],
                    'request_id_reusable': False, 'new_request_after_correction': failure.get('details', {}).get('new_request_after_correction', False)})
            if (row['attempts'] >= max_attempts
                    or now >= first + window_seconds or row['next_attempt_at'] >= first + window_seconds):
                # The saved packet keeps its message ID, so the Hub accepts a
                # repeated upload idempotently. A spent window opens a new
                # incident after a growing cooldown instead of blocking forever.
                # Derived from the row, so it needs no write before raising.
                cooldown = (min(first + window_seconds, row['next_attempt_at'])
                            + incident_cooldown(row['incidents']))
                if now < cooldown:
                    raise CoagenError('RETRY_NOT_DUE', operation='send', stage='hub_upload', outcome=row['outcome'],
                                      retry={**retry, 'retry_after_seconds': cooldown - now, 'deadline': cooldown + window_seconds,
                                             'new_incident_at': cooldown, 'incident': row['incidents'] + 1},
                                      details={'reason': 'incident_cooldown'})
                db.execute("UPDATE outgoing SET attempts=1,first_attempt=?,outcome='unknown',next_attempt_at=?,"
                           "incidents=incidents+1 WHERE request_id=?", (now, now + 1, request_id))
                return {'attempts_used': 1, 'max_attempts': max_attempts, 'deadline': now + window_seconds,
                        'retry_after_seconds': 1, 'incident': row['incidents'] + 2}
            if now < row['next_attempt_at']:
                retry['retry_after_seconds'] = row['next_attempt_at'] - now
                raise CoagenError('RETRY_NOT_DUE', operation='send', stage='hub_upload', outcome=row['outcome'], retry=retry)
            db.execute("UPDATE outgoing SET attempts=attempts+1,first_attempt=?,outcome='unknown',next_attempt_at=? WHERE request_id=?",
                       (first, now + 1, request_id))
            retry['attempts_used'] += 1
            retry['retry_after_seconds'] = 1
            return retry

    def set_upload_outcome(self, request_id, outcome, *, retryable=True):
        with self.db() as db:
            db.execute('UPDATE outgoing SET outcome=?,retryable=? WHERE request_id=?',
                       (outcome, int(retryable), request_id))

    def set_upload_failure(self, request_id, error):
        with self.db() as db:
            # The retry window is measured from the first failure of an incident,
            # not from when a possibly long first request started.
            db.execute('UPDATE outgoing SET failure=?,first_attempt=CASE WHEN attempts<=1 THEN ? ELSE first_attempt END '
                       'WHERE request_id=?', (json.dumps(error.to_dict()), time.time(), request_id))

    def defer_upload(self, request_id, seconds=1):
        with self.db() as db:
            db.execute('UPDATE outgoing SET next_attempt_at=MAX(next_attempt_at,?) WHERE request_id=?',
                       (time.time() + max(1, seconds), request_id))

    def claim_recovery_attempt(self, key, *, operation, max_attempts=3, window_seconds=30):
        """Bound automatic and tool retries per incident without ever locking an operation.

        An incident allows ``max_attempts`` within ``window_seconds`` of its
        first failure. When it is spent, the next incident opens after a
        cooldown that grows with consecutive incidents (5 s up to 60 s); any
        success deletes the row. Network jitter therefore delays an idempotent
        receive or consume but can no longer disable it for the whole session.
        """
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM recovery WHERE key=?', (key,)).fetchone()
            now = time.time()
            if row is None:
                db.execute('INSERT INTO recovery(key,started,attempts,next_attempt_at) VALUES(?,?,1,?)', (key, now, now + 1))
                return {'attempts_used': 1, 'max_attempts': max_attempts, 'deadline': now + window_seconds}
            retry = {'attempts_used': row['attempts'], 'max_attempts': max_attempts,
                     'deadline': row['started'] + window_seconds, 'incident': row['incidents'] + 1}
            if (not row['retryable'] or row['attempts'] >= max_attempts
                    or now >= row['started'] + window_seconds or row['next_attempt_at'] >= row['started'] + window_seconds):
                # Derived from the row, so it needs no write before raising.
                cooldown = (min(row['started'] + window_seconds, max(row['next_attempt_at'], row['started']))
                            + incident_cooldown(row['incidents']))
                if now < cooldown:
                    raise CoagenError('RETRY_NOT_DUE', operation=operation, stage=row['stage'] or 'recovery',
                                      outcome=row['outcome'] or 'not_started',
                                      retry={**retry, 'retry_after_seconds': cooldown - now, 'new_incident_at': cooldown,
                                             'deadline': cooldown + window_seconds},
                                      details={'reason': 'incident_cooldown', 'original_code': row['code']})
                db.execute('UPDATE recovery SET started=?,attempts=1,code=NULL,stage=NULL,outcome=NULL,retryable=1,'
                           'next_attempt_at=?,incidents=incidents+1 WHERE key=?', (now, now + 1, key))
                return {'attempts_used': 1, 'max_attempts': max_attempts, 'deadline': now + window_seconds,
                        'incident': row['incidents'] + 2}
            if now < row['next_attempt_at']:
                retry['retry_after_seconds'] = row['next_attempt_at'] - now
                raise CoagenError('RETRY_NOT_DUE', operation=operation, stage=row['stage'] or 'recovery',
                                  outcome=row['outcome'] or 'not_started', retry=retry)
            db.execute('UPDATE recovery SET attempts=attempts+1,next_attempt_at=? WHERE key=?',
                       (now + min(2, row['attempts'] + 1), key))
            retry['attempts_used'] += 1
            return retry

    def fail_recovery(self, key, error, *, retryable):
        value = error.to_dict()
        with self.db() as db:
            now = time.time()
            delay = max(1, value.get('retry', {}).get('retry_after_seconds', 1))
            # The window starts at the first failure of the incident.
            db.execute('UPDATE recovery SET code=?,stage=?,outcome=?,retryable=?,next_attempt_at=MAX(next_attempt_at,?),'
                       'started=CASE WHEN code IS NULL AND attempts<=1 THEN ? ELSE started END WHERE key=?',
                       (value['code'], value['stage'], value['outcome'], int(retryable), now + delay, now, key))

    def resolve_recovery(self, key):
        with self.db() as db:
            db.execute('DELETE FROM recovery WHERE key=?', (key,))

    def incoming(self, message_id):
        with self.db() as db:
            row = db.execute('SELECT * FROM incoming WHERE message_id=?', (message_id,)).fetchone()
        if row is None:
            return None
        result = dict(row); result['metadata'] = json.loads(result['metadata'])
        result['receipt'] = json.loads(result['receipt']) if result.get('receipt') else None
        result['failure'] = json.loads(result['failure']) if result.get('failure') else None
        return result

    def record_incoming(self, message_id, metadata, folder):
        with self.db() as db:
            db.execute('INSERT INTO incoming VALUES (?, ?, ?, ?) ON CONFLICT DO NOTHING',
                       (message_id, json.dumps(metadata), str(folder), 'received'))

    def set_incoming_state(self, message_id, state):
        if state not in ('received', 'consuming', 'consumed', 'expired'):
            raise ValueError('Invalid delivery state.')
        with self.db() as db:
            db.execute('UPDATE incoming SET state=? WHERE message_id=?', (state, message_id))

    def pending(self):
        with self.db() as db:
            rows = db.execute("SELECT message_id FROM incoming WHERE state IN ('received','consuming')").fetchall()
        return [self.incoming(row[0]) for row in rows]

    def audit(self, direction, *, peer='', room='', kind='', size=0, result='', message_id=''):
        with self.db() as db:
            db.execute('INSERT INTO audit(timestamp,direction,peer,room,kind,bytes,result,message_id) '
                       'VALUES(?,?,?,?,?,?,?,?)',
                       (time.time(), direction, peer, room, kind, int(size), result, message_id))

    def history(self, *, limit=100, since=0, direction=None, peer=None):
        clauses, values = ['timestamp>=?'], [float(since)]
        if direction:
            clauses.append('direction=?'); values.append(direction)
        if peer:
            clauses.append('peer=?'); values.append(peer)
        query = 'SELECT * FROM audit WHERE ' + ' AND '.join(clauses) + ' ORDER BY sequence DESC LIMIT ?'
        with self.db() as db:
            rows = db.execute(query, [*values, min(1000, max(1, int(limit)))]).fetchall()
            totals = db.execute("SELECT direction,count(*) FROM audit WHERE result='ok' GROUP BY direction").fetchall()
        return {'records': [dict(row) for row in rows], 'totals': dict(totals)}

    def clear_ephemeral(self):
        self._validate_paths()
        for path in (self.root / 'inbox').iterdir():
            _unlinked_path(path)
            if path.is_dir():
                remove_owned_tree(self.root / 'inbox', path)
        for path in (self.root / 'outbox').glob('*.png'):
            _unlinked_path(path)
            if path.resolve().parent == (self.root / 'outbox').resolve():
                path.unlink(missing_ok=True)
        with self.db() as db:
            db.execute("UPDATE incoming SET state='consumed'")
            db.execute("UPDATE outgoing SET state='expired' WHERE state='pending'")
