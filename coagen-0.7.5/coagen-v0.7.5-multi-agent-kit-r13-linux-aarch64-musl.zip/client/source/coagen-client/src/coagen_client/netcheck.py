"""Layer-by-layer reachability of the Hub: DNS, TCP, TLS, then HTTP /health.

No credentials, rooms or payloads are involved. Direct TCP/TLS stages bypass
proxies on purpose; the HTTP stage uses the same settings as the real client
(including HTTPS_PROXY and SSL_CERT_FILE), so a working proxy explains a
failed direct stage instead of hiding it.
"""
from __future__ import annotations

import os
import socket
import ssl
import time
from urllib.parse import urlsplit

import certifi
import httpx

from .observe import describe, log, proxy_environment


def _stage(name, function):
    started = time.monotonic()
    try:
        detail = function() or {}
        return {'stage': name, 'status': 'pass', 'elapsed_ms': round((time.monotonic() - started) * 1000), **detail}
    except Exception as error:  # noqa: BLE001 - every failure is described, none is hidden
        return {'stage': name, 'status': 'fail', 'elapsed_ms': round((time.monotonic() - started) * 1000),
                'cause': describe(error)}


def _tls_context():
    context = ssl.create_default_context()
    bundle = os.environ.get('SSL_CERT_FILE')
    context.load_verify_locations(bundle if bundle and os.path.isfile(bundle) else certifi.where())
    return context


PUBLIC_CA_HINTS = ("let's encrypt", 'isrg', 'digicert', 'sectigo', 'comodo', 'globalsign', 'google trust',
                   'amazon', 'microsoft', 'zerossl', 'entrust', 'godaddy', 'identrust', 'certum', 'buypass',
                   'starfield', 'baltimore', 'usertrust', 'actalis', 'ssl.com', 'quovadis', 'thawte', 'geotrust')


def _handshake_ms(host, address, port, timeout):
    started = time.monotonic()
    with socket.create_connection((address, port), timeout=timeout) as raw:
        connected = time.monotonic()
        with _tls_context().wrap_socket(raw, server_hostname=host):
            done = time.monotonic()
    return round((connected - started) * 1000), round((done - connected) * 1000)


def check(hub, timeout=8.0):
    parts = urlsplit(hub)
    host, secure = parts.hostname, parts.scheme == 'https'
    port = parts.port or (443 if secure else 80)
    state = {}
    stages = []

    def dns():
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        state['addresses'] = list(dict.fromkeys(info[4][0] for info in infos))[:4]
        return {'addresses': state['addresses']}

    def tcp():
        sock = socket.create_connection((state['addresses'][0], port), timeout=timeout)
        state['socket'] = sock
        return {'address': state['addresses'][0], 'port': port, 'path': 'direct (no proxy)'}

    def tls():
        loaded = time.monotonic()
        context = _tls_context()
        ca_load_ms = round((time.monotonic() - loaded) * 1000)
        handshake = time.monotonic()
        wrapped = context.wrap_socket(state.pop('socket'), server_hostname=host)
        handshake_ms = round((time.monotonic() - handshake) * 1000)
        try:
            certificate = wrapped.getpeercert() or {}
            subject = dict(item[0] for item in certificate.get('subject', ()))
            issuer = dict(item[0] for item in certificate.get('issuer', ()))
            issuer_name = issuer.get('organizationName') or issuer.get('commonName')
            result = {'version': wrapped.version(), 'certificate_subject': subject.get('commonName'),
                      'certificate_issuer': issuer_name, 'certificate_not_after': certificate.get('notAfter'),
                      'ca_bundle': 'SSL_CERT_FILE' if os.environ.get('SSL_CERT_FILE') else 'certifi',
                      'ca_load_ms': ca_load_ms, 'handshake_ms': handshake_ms}
        finally:
            wrapped.close()
        # Repeat the handshake: an unstable path shows as large spread, a
        # middlebox that answers locally as a near-zero TCP connect time.
        samples = []
        for _ in range(2):
            try:
                connect_ms, tls_ms = _handshake_ms(host, state['addresses'][0], port, timeout)
                samples.append({'tcp_ms': connect_ms, 'tls_ms': tls_ms})
            except Exception as error:  # noqa: BLE001 - reported, never hidden
                samples.append({'error': describe(error)['category']})
        result['repeat_handshakes'] = samples
        if issuer_name and not any(hint in issuer_name.lower() for hint in PUBLIC_CA_HINTS):
            result['tls_inspection_possible'] = True
            result['note'] = ('The certificate was issued by %r, which is not a common public CA. A TLS-inspecting '
                              'proxy, firewall or VPN probably re-signs this connection; it can add seconds per '
                              'handshake and drop long requests. Ask the network team to exempt the Hub host from '
                              'inspection. Coagen keeps verifying certificates either way.' % issuer_name)
        return result

    def http():
        with httpx.Client(timeout=httpx.Timeout(timeout), follow_redirects=False) as client:
            started = time.monotonic()
            response = client.get(hub.rstrip('/') + '/health')
            cold_ms = round((time.monotonic() - started) * 1000)
            warm_ms = None
            if response.is_success:
                # Same pooled connection: the difference is the per-connection
                # TCP + TLS (+ proxy) setup cost that keep-alive avoids.
                started = time.monotonic()
                client.get(hub.rstrip('/') + '/health')
                warm_ms = round((time.monotonic() - started) * 1000)
        body = {}
        try:
            body = response.json()
        except ValueError:
            pass
        if not response.is_success:
            error = httpx.HTTPStatusError('health', request=response.request, response=response)
            raise error
        return {'http_status': response.status_code, 'service': body.get('service'), 'hub_version': body.get('version'),
                'path': 'client settings (proxy environment honoured)', 'cold_request_ms': cold_ms,
                'reused_connection_ms': warm_ms}

    for name, function in (('dns', dns), ('tcp', tcp), ('tls', tls), ('http_health', http)):
        if name == 'tls' and not secure:
            continue
        if name != 'http_health' and any(stage['status'] != 'pass' for stage in stages):
            stages.append({'stage': name, 'status': 'skipped', 'reason': 'an earlier direct stage did not pass'})
            continue
        stages.append(_stage(name, function))
    if state.get('socket'):
        state['socket'].close()
    failed = [stage for stage in stages if stage['status'] == 'fail']
    http_ok = any(stage['stage'] == 'http_health' and stage['status'] == 'pass' for stage in stages)
    result = {'hub': hub, 'host': host, 'port': port, 'reachable': http_ok, 'stages': stages,
              'proxy_environment': proxy_environment()}
    if failed:
        first = failed[0]
        result['first_failure'] = {'stage': first['stage'], 'category': first['cause']['category'],
                                   'explanation': first['cause']['explanation'], 'checks': first['cause']['checks']}
        if http_ok:
            result['note'] = ('The Hub is reachable through the configured client path (for example a proxy); '
                              'the failed direct stage is expected when direct internet access is blocked.')
    slow = [stage['stage'] for stage in stages if stage.get('status') == 'pass' and stage.get('elapsed_ms', 0) > 3000]
    if slow:
        result['slow_stages'] = slow
        result.setdefault('note', 'Reachable but slow (%s over 3 s). Coagen reuses connections and retries '
                                  'automatically; persistent slowness points at a proxy, VPN or inspection device.'
                          % ', '.join(slow))
    log.info('network_check', reachable=http_ok, stages=[{k: v for k, v in s.items() if k != 'cause'} for s in stages],
             first_failure=result.get('first_failure'))
    return result
