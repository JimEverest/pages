"""HTTPS transport. Server tokens and opaque E2EE data are distinct."""
import ipaddress
import json
from contextlib import contextmanager
import math
import threading
import time
from urllib.parse import urlsplit

import httpx
from .errors import CoagenError, safe_details


def validate_hub(value):
    parsed = urlsplit(value)
    if not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Use a hub URL without credentials, query parameters or fragments.')
    loopback = parsed.hostname == 'localhost'
    try:
        loopback = loopback or ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:
        pass
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and loopback):
        raise ValueError('HTTPS is required except for loopback development.')
    return value.rstrip('/')


class HubError(RuntimeError):
    def __init__(self, status, message='Coagen request failed.', *, retry_after=None, details=None, hub_origin=True):
        self.status = status
        self.retry_after = retry_after
        self.details = safe_details(details)
        # False when the error response was not the Hub's JSON error body, for
        # example an HTML page from a proxy, firewall or captive portal. Such a
        # response cannot prove that the Hub revoked this membership.
        self.hub_origin = hub_origin
        super().__init__(f'{message} (HTTP {status})')


def authoritative_revocation(error):
    """Only the Hub itself can end a membership; a middlebox error is transient."""
    return (isinstance(error, HubError) and error.status in (401, 403, 404, 410)
            and getattr(error, 'hub_origin', True) is not False)


def _env_seconds(name, default, low, high):
    import os
    try:
        value = float(os.environ.get(name, default))
    except ValueError:
        return default
    return min(high, max(low, value))


# Exchange operations that are safe to send twice: reads, lease renewal and
# acknowledgement. Uploads, consume, signals and membership changes are not.
IDEMPOTENT_OPS = frozenset({'heartbeat', 'status', 'signals', 'poll', 'ack', 'message_status'})
# Failures where the request never reached the Hub or a pooled connection was
# already dead: one immediate retry on a fresh connection is safe and cheap.
STALE_CONNECTION_ERRORS = (httpx.RemoteProtocolError, httpx.ReadError, httpx.WriteError, httpx.ConnectError)
POLL_READ_MARGIN_SECONDS = 15
# Connecting includes the TLS handshake. Behind a TLS-inspecting proxy that
# alone took 3-10 s on the intranet path, so 10 s failed joins and heartbeats.
CONNECT_TIMEOUT_SECONDS = _env_seconds('COAGEN_HTTP_CONNECT_TIMEOUT', 30, 5, 120)
# A connection that was never established cannot have delivered the request,
# so any request (even a non-idempotent one) may be retried after these.
NOT_SENT_ERRORS = (httpx.ConnectError, httpx.ConnectTimeout)
CONNECT_ATTEMPTS = 3
# Total cap for one packet transfer (16 MiB at ~20 KB/s); idle timeouts apply first.
TRANSFER_CAP_SECONDS = 900


class Transport:
    def __init__(self, hub, token='', room_id='', *, group=False):
        self.hub = validate_hub(hub)
        self.token, self.room_id = token, room_id
        self.api_prefix = '/api/team' if group else '/api'
        # Heartbeats run every 30 s. httpx closes idle connections after 5 s by
        # default, so every heartbeat paid a new TCP + TLS handshake, which an
        # inspecting proxy can stretch to several seconds. Keep the connection
        # a little longer than one heartbeat interval; stale ones are retried.
        self.keepalive_seconds = _env_seconds('COAGEN_HTTP_KEEPALIVE_SECONDS', 45, 0, 300)
        self.client = httpx.Client(timeout=httpx.Timeout(25, connect=CONNECT_TIMEOUT_SECONDS), follow_redirects=False,
                                   limits=httpx.Limits(max_connections=8, max_keepalive_connections=4,
                                                       keepalive_expiry=self.keepalive_seconds))
        from .observe import log, proxy_environment
        log.info('transport_created', hub=self.hub, proxy_environment=proxy_environment(),
                 keepalive_seconds=self.keepalive_seconds)
        self.check_active = None
        self._deadline_context = threading.local()

    @contextmanager
    def operation_deadline(self, deadline):
        previous = getattr(self._deadline_context, 'deadline', None)
        self._deadline_context.deadline = deadline
        try:
            yield
        finally:
            self._deadline_context.deadline = previous

    def _remaining(self):
        deadline = getattr(self._deadline_context, 'deadline', None)
        if deadline is None:
            return None
        remaining = deadline - time.time()
        if remaining <= 0:
            # The operation's time budget ran out during network I/O: this is a
            # timeout of this attempt, recoverable like any other Hub timeout.
            from .observe import describe
            raise CoagenError('HUB_UNAVAILABLE', stage='hub_request', retry={'deadline': deadline},
                              cause=describe(TimeoutError('operation time budget reached during the Hub request')))
        return remaining

    def request(self, path, *, data=None, files=None, json_body=None, max_bytes=1024 * 1024, method='POST',
                idempotent=False, read_timeout=None):
        started = time.monotonic()
        op = (json_body or {}).get('op') if isinstance(json_body, dict) else None

        def send():
            return self._request(path, data=data, files=files, json_body=json_body, max_bytes=max_bytes,
                                 method=method, read_timeout=read_timeout)

        def retry_allowed(attempt, error):
            remaining = self._remaining()
            if remaining is not None and remaining < 3:
                return False
            # Never connected: nothing was sent, any request may be repeated
            # (up to CONNECT_ATTEMPTS). A dead pooled connection: only an
            # idempotent request may be repeated, once.
            if isinstance(error, NOT_SENT_ERRORS):
                return attempt < CONNECT_ATTEMPTS
            return idempotent and attempt == 1 and isinstance(error, STALE_CONNECTION_ERRORS)

        try:
            attempt = 1
            while True:
                try:
                    response = send()
                    break
                except (NOT_SENT_ERRORS + STALE_CONNECTION_ERRORS) as error:
                    if not retry_allowed(attempt, error):
                        raise
                    from .observe import categorize, log
                    log.info('hub_request_retried', method=method, url=self.hub + path, op=op, attempt=attempt,
                             error_type=type(error).__name__, category=categorize(error),
                             elapsed_ms=round((time.monotonic() - started) * 1000))
                    time.sleep(attempt if isinstance(error, NOT_SENT_ERRORS) else 0.2)
                    attempt += 1
        except Exception as error:
            # Record where and how long, never headers, bodies or credentials.
            request = {'method': method, 'url': self.hub + path, 'elapsed_ms': round((time.monotonic() - started) * 1000),
                       'op': op}
            try:
                error.coagen_request = request
            except AttributeError:
                pass
            from .observe import categorize, log
            log.warning('hub_request_failed', **request, error_type=type(error).__name__,
                        http_status=getattr(error, 'status', None), category=categorize(error))
            raise
        elapsed = time.monotonic() - started
        if elapsed > 5:
            from .observe import log
            log.warning('hub_request_slow', method=method, url=self.hub + path, elapsed_ms=round(elapsed * 1000))
        return response

    def _request(self, path, *, data=None, files=None, json_body=None, max_bytes=1024 * 1024, method='POST',
                 read_timeout=None):
        remaining = self._remaining()
        read = 25 if read_timeout is None else read_timeout
        timeout = (httpx.Timeout(min(read, remaining), connect=min(CONNECT_TIMEOUT_SECONDS, remaining)) if remaining is not None
                   else httpx.Timeout(read, connect=CONNECT_TIMEOUT_SECONDS))
        headers = {'Accept-Encoding': 'identity'}
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
        with self.client.stream(method, self.hub + path,
                                headers=headers,
                                data=data, files=files, json=json_body, timeout=timeout) as response:
            self._remaining()
            if not response.is_success:
                # Avoid reflecting server bodies, URLs or credentials into agent logs.
                retry_after = None
                if response.status_code == 429:
                    try:
                        candidate = float(response.headers.get('Retry-After', ''))
                        if math.isfinite(candidate) and 0 <= candidate <= 86400:
                            retry_after = candidate
                    except (TypeError, ValueError):
                        pass
                # A bounded JSON error body supplies enum/numeric diagnostics only.
                details, hub_origin = {}, False
                if response.headers.get('Content-Encoding', 'identity') == 'identity':
                    try:
                        body = bytearray()
                        for chunk in response.iter_bytes(chunk_size=4096):
                            self._remaining()
                            if len(body) + len(chunk) > 16384:
                                break
                            body.extend(chunk)
                        else:
                            payload = json.loads(body)
                            # The Hub (FastAPI) always answers errors with {"detail": ...}.
                            hub_origin = isinstance(payload, dict) and 'detail' in payload
                            details = safe_details(payload.get('detail')) if isinstance(payload, dict) else {}
                    except (ValueError, TypeError, UnicodeError, RecursionError, httpx.RequestError):
                        pass
                raise HubError(response.status_code, retry_after=retry_after, details=details, hub_origin=hub_origin)
            # Iteration is deliberately bounded before decoding JSON or parsing PNG.
            # Reject compression: a relay should return the original bytes, and compressed
            # responses can allocate large decompression buffers before our byte limit.
            if response.headers.get('Content-Encoding', 'identity') != 'identity':
                raise ValueError('Unexpected compressed relay response.')
            chunks, size = [], 0
            for chunk in response.iter_bytes(chunk_size=65536):
                self._remaining()
                if self.check_active:
                    self.check_active()
                size += len(chunk)
                if size > max_bytes:
                    raise ValueError('Relay response exceeds size limit.')
                chunks.append(chunk)
            if self.check_active:
                self.check_active()
            self._remaining()
            return httpx.Response(response.status_code, content=b''.join(chunks), request=response.request)

    def exchange(self, op, **fields):
        read_timeout = None
        if op == 'poll':
            # A long poll is held by the Hub for wait_seconds; leave room for a
            # slow proxy or TLS path before calling the response lost.
            read_timeout = float(fields.get('wait_seconds') or 0) + POLL_READ_MARGIN_SECONDS
        return self.request(self.api_prefix + '/exchange', json_body={'room_id': self.room_id, 'op': op, **fields},
                            idempotent=op in IDEMPOTENT_OPS, read_timeout=read_timeout).json()

    @contextmanager
    def _transfer_scope(self):
        """A packet transfer that has started is not cut off by the retry window.

        The operation budget decides whether a transfer may *start*. A started
        upload or download is bounded by the idle read/write timeouts (no bytes
        for 25 s fails it) and a generous total cap, not by the seconds left in
        the window: on a slow or inspected link a 7.5 MB packet took 23 s, and
        a window-bounded transfer of a larger packet could never finish.
        """
        self._remaining()  # never start after the budget ended
        with self.operation_deadline(time.time() + TRANSFER_CAP_SECONDS):
            yield

    def send_packet(self, metadata, data):
        ext = {key: value for key, value in metadata.items() if key != 'sender_id'}
        with self._transfer_scope():
            return self.request(self.api_prefix + '/packets', data={'ext': json.dumps(ext)},
                                files={'file[]': ('packet.png', data, 'image/png')}).json()

    def read_packet(self, message_id):
        with self._transfer_scope():
            return self.request(self.api_prefix + '/packets/read',
                                json_body={'room_id': self.room_id, 'message_id': message_id},
                                max_bytes=16 * 1024 * 1024 + 4096, idempotent=True).content

    def close(self):
        self.client.close()

    def capabilities(self):
        """Read the advertised protocol set; old Hubs remain a valid Basic target."""
        try:
            value = self.request('/health', method='GET', max_bytes=65536, idempotent=True).json()
        except HubError as error:
            if error.status not in (404, 405):
                raise
            return {}
        capabilities = value.get('capabilities', {}) if isinstance(value, dict) else {}
        return capabilities if isinstance(capabilities, dict) else {}
