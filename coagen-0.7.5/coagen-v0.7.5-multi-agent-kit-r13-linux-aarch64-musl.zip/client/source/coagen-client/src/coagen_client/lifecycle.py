"""Bind a session to a particular process instance and a monotonic deadline."""
from dataclasses import dataclass
import math
import os
import time

import psutil


def _windows_owner_alive(pid, started_at):
    """Check identity and termination on one handle; PID visibility can lag exit."""
    import ctypes
    from ctypes import wintypes

    if type(pid) is not int or not 0 < pid < 2 ** 32:
        return False
    handle = None
    close = None
    alive = False
    try:
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        open_process = kernel.OpenProcess
        open_process.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        open_process.restype = wintypes.HANDLE
        get_times = kernel.GetProcessTimes
        get_times.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
        get_times.restype = wintypes.BOOL
        wait = kernel.WaitForSingleObject
        wait.argtypes, wait.restype = [wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD
        close = kernel.CloseHandle
        close.argtypes, close.restype = [wintypes.HANDLE], wintypes.BOOL
        # SYNCHRONIZE and PROCESS_QUERY_LIMITED_INFORMATION; no mutation rights.
        handle = open_process(0x00100000 | 0x1000, False, pid)
        if not handle:
            return False
        created, exited, kernel_time, user_time = (wintypes.FILETIME() for _ in range(4))
        if not get_times(handle, ctypes.byref(created), ctypes.byref(exited),
                         ctypes.byref(kernel_time), ctypes.byref(user_time)):
            return False
        ticks = (created.dwHighDateTime << 32) | created.dwLowDateTime
        observed_started_at = ticks / 10000000 - 11644473600
        if not abs(observed_started_at - started_at) < 0.001:
            return False
        # WAIT_TIMEOUT is the only proof the same process is still nonsignaled.
        # A signaled object can retain a visible PID and a psutil running status.
        alive = wait(handle, 0) == 0x102
    except (OSError, ValueError, TypeError, OverflowError):
        alive = False
    finally:
        if handle and close is not None:
            try:
                if not close(handle):
                    alive = False
            except OSError:
                alive = False
    return alive


@dataclass(frozen=True)
class Owner:
    pid: int
    started_at: float

    @classmethod
    def capture(cls, pid):
        process = psutil.Process(int(pid))
        if not process.is_running():
            raise ValueError('The owning agent process is not running.')
        return cls(process.pid, process.create_time())

    def alive(self):
        if os.name == 'nt':
            return _windows_owner_alive(self.pid, self.started_at)
        try:
            process = psutil.Process(self.pid)
            return (process.is_running() and process.status() != psutil.STATUS_ZOMBIE
                    and abs(process.create_time() - self.started_at) < 0.001)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False


class Deadline:
    def __init__(self, expires_at, *, now=None, monotonic=time.monotonic):
        self.monotonic = monotonic
        self.expires_at = float(expires_at)
        self.end = monotonic() + max(0, self.expires_at - (time.time() if now is None else now))

    def active(self):
        return self.monotonic() < self.end

    def remaining(self):
        return max(0, self.end - self.monotonic())

    def update(self, expires_at):
        """Apply an authenticated room deadline change without reviving an expired lease.

        Use the delta to preserve the original monotonic clock anchor, including
        when the wall clock has moved since this session started.
        """
        if not self.active() or type(expires_at) not in (int, float) or not math.isfinite(expires_at) or expires_at <= 0:
            raise ValueError('Invalid deadline update for an inactive session.')
        self.end += expires_at - self.expires_at
        self.expires_at = float(expires_at)
