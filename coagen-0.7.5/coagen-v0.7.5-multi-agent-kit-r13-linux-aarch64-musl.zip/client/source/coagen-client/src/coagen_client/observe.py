"""Explainable failures: redacted exception causes and a private local event log.

Every Coagen process (MCP server, session helper, CLI) appends JSON lines to
``<state base>/logs/``. Errors carry a ``cause`` block that names the failing
layer (DNS, TCP, TLS, proxy, HTTP, file system, SQLite, process) with the
exception chain, errno/WinError values and concrete checks, so a host can tell
*why* an operation failed without reading code. Secrets registered with
``redact.register`` (tokens, pairing and activation codes, control tokens) and
token-like strings are masked before anything is stored or returned.
"""
from __future__ import annotations

import errno as errno_module
import json
import os
from pathlib import Path
import re
import socket
import ssl
import sqlite3
import sys
import threading
import time

import httpx

MAX_LOG_BYTES = 2 * 1024 * 1024
MAX_LOG_FILES = 24
_SECRETS = set()
_SECRET_LOCK = threading.Lock()
_RUN = re.compile(r'[A-Za-z0-9_-]{24,}')
_BEARER = re.compile(r'(?i)(bearer\s+)\S+')
_URL_QUERY = re.compile(r'(https?://[^\s?#\'"]+)\?[^\s\'"]*')


def _mask_token(match):
    # URL-safe tokens mix upper and lower case; hex identifiers and file names stay readable.
    run = match.group(0)
    if re.search('[A-Z]', run) and re.search('[a-z]', run) and re.search(r'[0-9_-]', run):
        return '[redacted-token]'
    return run


class Redactor:
    def register(self, *values):
        with _SECRET_LOCK:
            for value in values:
                if isinstance(value, str) and len(value) >= 6:
                    _SECRETS.add(value)

    def text(self, value, limit=400):
        text = str(value)
        with _SECRET_LOCK:
            secrets = sorted(_SECRETS, key=len, reverse=True)
        for secret in secrets:
            if secret in text:
                text = text.replace(secret, '[redacted]')
        text = _BEARER.sub(r'\1[redacted]', text)
        text = _URL_QUERY.sub(r'\1?[redacted]', text)
        text = _RUN.sub(_mask_token, text)
        return text if len(text) <= limit else text[:limit] + '…'

    def value(self, value, depth=0):
        if depth > 6:
            return '[nested]'
        if isinstance(value, str):
            return self.text(value, 2000)
        if isinstance(value, (bool, int, float)) or value is None:
            return value
        if isinstance(value, dict):
            return {str(k): self.value(v, depth + 1) for k, v in list(value.items())[:64]}
        if isinstance(value, (list, tuple)):
            return [self.value(v, depth + 1) for v in list(value)[:64]]
        return self.text(repr(value), 400)


redact = Redactor()

# Category → (layer, plain explanation, concrete checks)
CATEGORIES = {
    'dns_failed': ('network', 'The Hub host name could not be resolved.',
                   ['Resolve the Hub host with nslookup or Resolve-DnsName from this machine.',
                    'Check corporate DNS, VPN state and whether a proxy is required to reach the internet.']),
    'connection_refused': ('network', 'The Hub address was reached but the connection was refused.',
                           ['Check that the Hub URL and port are correct and the service is running.',
                            'A local firewall or proxy may be rejecting the connection.']),
    'connect_timeout': ('network', 'No TCP connection could be established within the timeout.',
                        ['Check outbound HTTPS (port 443) to the Hub host; corporate networks may require a proxy.',
                         'Set HTTPS_PROXY for the MCP server process if your network requires one.']),
    'network_unreachable': ('network', 'The operating system reports the network or host as unreachable.',
                            ['Check the network connection, VPN and routing.']),
    'connection_reset': ('network', 'The connection was closed or reset by the remote side or an intermediary.',
                         ['A proxy, firewall or TLS inspection device may be terminating the connection.',
                          'Retry once later; if it persists, compare with coagen_network_check.']),
    'read_timeout': ('network', 'The Hub accepted the connection but did not answer in time.',
                     ['The Hub or network path is slow; the operation outcome may be unknown.']),
    'write_timeout': ('network', 'Sending the request body timed out.', ['Check upload bandwidth and proxies.']),
    'pool_timeout': ('local', 'All local HTTP connections were busy.', ['Retry once; report if it persists.']),
    'proxy_failed': ('network', 'The configured HTTP proxy failed or rejected the request.',
                     ['Check HTTPS_PROXY/HTTP_PROXY/ALL_PROXY/NO_PROXY values for the MCP server process.']),
    'tls_certificate_verify_failed': ('tls', 'The Hub certificate could not be verified.',
                                      ['A TLS-inspecting proxy may present a corporate certificate: point SSL_CERT_FILE at the corporate CA bundle.',
                                       'Check the system clock. Never disable certificate verification.']),
    'tls_handshake_failed': ('tls', 'The TLS handshake failed.',
                             ['A proxy or firewall may be interfering with TLS; compare with coagen_network_check.']),
    'remote_protocol_error': ('network', 'The response was not valid HTTP.',
                              ['An intermediary may be altering traffic; check proxies.']),
    'http_server_error': ('hub', 'The Hub returned a server error.', ['Retry later; the Hub may be restarting or overloaded.']),
    'http_rejected': ('hub', 'The Hub rejected the request.', ['See http_status and reason_code.']),
    'permission_denied': ('filesystem', 'The operating system denied access to a local file or directory.',
                          ['Check permissions and whether security software blocks the Coagen data directory.']),
    'file_not_found': ('filesystem', 'A required local file or directory does not exist.', ['Check the reported path.']),
    'disk_full': ('filesystem', 'The disk is full or a quota was exceeded.', ['Free disk space for the Coagen data directory.']),
    'file_in_use': ('filesystem', 'A local file is locked by another process.',
                    ['Another program (often antivirus or backup) holds the file open; retry after it releases it.']),
    'path_rejected': ('filesystem', 'A path was refused by Coagen safety checks (link, reparse point or outside the workspace).',
                      ['Use a real directory inside the authorized workspace.']),
    'sqlite_busy': ('storage', 'The local SQLite database is locked.', ['Another Coagen process may use the same state directory.']),
    'sqlite_error': ('storage', 'The local SQLite database reported an error.', ['Check disk health and permissions of the state directory.']),
    'process_spawn_failed': ('process', 'A local process could not be started.',
                             ['Check that the runtime python.exe exists and is not blocked by application control.']),
    'timeout': ('local', 'A local step exceeded its time limit.', ['See context for the stage and elapsed time.']),
    'unknown': ('unknown', 'The failure did not match a known category.', ['Use the exception chain and the local log.']),
}

_WINSOCK = {10060: 'connect_timeout', 10061: 'connection_refused', 10051: 'network_unreachable',
            10065: 'network_unreachable', 10054: 'connection_reset', 10053: 'connection_reset',
            11001: 'dns_failed', 11002: 'dns_failed', 11004: 'dns_failed'}
_ERRNO = {errno_module.ECONNREFUSED: 'connection_refused', errno_module.ETIMEDOUT: 'connect_timeout',
          errno_module.ENETUNREACH: 'network_unreachable', errno_module.EHOSTUNREACH: 'network_unreachable',
          errno_module.ECONNRESET: 'connection_reset', errno_module.EPIPE: 'connection_reset',
          errno_module.EACCES: 'permission_denied', errno_module.EPERM: 'permission_denied',
          errno_module.ENOENT: 'file_not_found', errno_module.ENOSPC: 'disk_full'}
_WINERROR = {5: 'permission_denied', 32: 'file_in_use', 33: 'file_in_use', 2: 'file_not_found', 3: 'file_not_found',
             112: 'disk_full', 39: 'disk_full'}


def _chain(error, limit=6):
    items, seen = [], set()
    while error is not None and len(items) < limit and id(error) not in seen:
        seen.add(id(error))
        items.append(error)
        error = error.__cause__ or error.__context__
    return items


def _entry(error):
    value = {'type': type(error).__module__.replace('builtins', '') + ('.' if type(error).__module__ != 'builtins' else '') + type(error).__qualname__}
    value['type'] = value['type'].lstrip('.')
    number = getattr(error, 'errno', None)
    if type(number) is int:
        value['errno'] = number
        if number in errno_module.errorcode:
            value['errno_name'] = errno_module.errorcode[number]
    winerror = getattr(error, 'winerror', None)
    if type(winerror) is int:
        value['winerror'] = winerror
    if isinstance(error, ssl.SSLError):
        if getattr(error, 'reason', None):
            value['ssl_reason'] = str(error.reason)[:80]
        if getattr(error, 'verify_message', None):
            value['verify_message'] = str(error.verify_message)[:160]
    if isinstance(error, sqlite3.Error) and getattr(error, 'sqlite_errorname', None):
        value['sqlite_error'] = error.sqlite_errorname
    # Free-form exception text is never reflected: it may contain anything.
    # Only operating-system and library generated fields are reported.
    if isinstance(error, OSError) and not isinstance(error, ssl.SSLError):
        if isinstance(getattr(error, 'strerror', None), str):
            value['message'] = redact.text(error.strerror, 200)
        for key in ('filename', 'filename2'):
            if isinstance(getattr(error, key, None), (str, os.PathLike)):
                value[key] = redact.text(os.fspath(getattr(error, key)), 300)
    return value


def categorize(error):
    chain = _chain(error)
    for item in chain:
        if isinstance(item, ssl.SSLCertVerificationError) or 'CERTIFICATE_VERIFY_FAILED' in str(getattr(item, 'reason', '')):
            return 'tls_certificate_verify_failed'
    for item in chain:
        if isinstance(item, httpx.ProxyError):
            return 'proxy_failed'
        if isinstance(item, socket.gaierror):
            return 'dns_failed'
        if isinstance(item, ssl.SSLError):
            return 'tls_handshake_failed'
        if isinstance(item, httpx.ConnectTimeout):
            return 'connect_timeout'
        if isinstance(item, httpx.ReadTimeout):
            return 'read_timeout'
        if isinstance(item, httpx.WriteTimeout):
            return 'write_timeout'
        if isinstance(item, httpx.PoolTimeout):
            return 'pool_timeout'
        if isinstance(item, httpx.RemoteProtocolError):
            return 'remote_protocol_error'
        winerror = getattr(item, 'winerror', None)
        if type(winerror) is int and (winerror in _WINSOCK or winerror in _WINERROR):
            return _WINSOCK.get(winerror) or _WINERROR[winerror]
        number = getattr(item, 'errno', None)
        if type(number) is int and number in _WINSOCK:
            return _WINSOCK[number]
        if type(number) is int and number in _ERRNO:
            return _ERRNO[number]
        if isinstance(item, sqlite3.OperationalError) and 'locked' in str(item).lower():
            return 'sqlite_busy'
        if isinstance(item, sqlite3.Error):
            return 'sqlite_error'
        if isinstance(item, PermissionError):
            return 'permission_denied'
        if isinstance(item, FileNotFoundError):
            return 'file_not_found'
        if isinstance(item, ValueError) and re.search(r'links or reparse|outside the authorized', str(item)):
            return 'path_rejected'
    text = ' '.join(str(item) for item in chain).lower()
    if 'name or service not known' in text or 'getaddrinfo failed' in text or 'nodename nor servname' in text:
        return 'dns_failed'
    if any(isinstance(item, httpx.ConnectError) for item in chain):
        return 'connection_refused' if 'refused' in text else 'connect_timeout' if 'timed out' in text else 'network_unreachable' if 'unreachable' in text else 'unknown'
    if any(isinstance(item, (TimeoutError, httpx.TimeoutException)) for item in chain):
        return 'timeout'
    return 'unknown'


def proxy_environment():
    """Names only: which proxy/certificate variables are set for this process."""
    names = ('HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY', 'NO_PROXY', 'SSL_CERT_FILE', 'SSL_CERT_DIR', 'REQUESTS_CA_BUNDLE')
    present = [name for name in names if os.environ.get(name) or os.environ.get(name.lower())]
    return {'set': present, 'values_reported': False}


def describe(error, **context):
    """A JSON-safe, redacted explanation of an exception."""
    category = categorize(error)
    layer, explanation, checks = CATEGORIES[category]
    cause = {'category': category, 'layer': layer, 'explanation': explanation, 'checks': list(checks),
             'chain': [_entry(item) for item in _chain(error)]}
    request = getattr(error, 'coagen_request', None)
    if isinstance(request, dict):
        cause['request'] = redact.value(request)
    if layer in ('network', 'tls'):
        cause['proxy_environment'] = proxy_environment()
    for key, value in context.items():
        if value is not None:
            cause[key] = redact.value(value)
    return cause


def sanitize_cause(value):
    """Re-validate a cause that crossed a process boundary."""
    if not isinstance(value, dict):
        return None
    clean = redact.value(value)
    if clean.get('category') not in CATEGORIES:
        clean['category'] = 'unknown'
    return clean


# ---------------------------------------------------------------- event log

class EventLog:
    def __init__(self):
        self._lock = threading.Lock()
        self.role = 'process'
        self.directory = None
        self.path = None
        self.failed = False

    def configure(self, base, role):
        with self._lock:
            self.role = role
            try:
                from .store import _unlinked_path, secure_directory
                directory = secure_directory(_unlinked_path(Path(base) / 'logs'))
                self.directory = directory
                stamp = time.strftime('%Y%m%d', time.gmtime())
                self.path = directory / ('%s-%s-%d.jsonl' % (stamp, role, os.getpid()))
                files = sorted(directory.glob('*.jsonl'), key=lambda p: p.stat().st_mtime)
                for old in files[:-MAX_LOG_FILES]:
                    old.unlink(missing_ok=True)
                self.failed = False
            except (OSError, ValueError):
                self.failed = True
        return self.path

    def write(self, event, level='info', **fields):
        if self.path is None:
            return
        record = {'ts': round(time.time(), 3), 'level': level, 'role': self.role, 'pid': os.getpid(), 'event': event,
                  **redact.value(fields)}
        line = json.dumps(record, ensure_ascii=False, default=str) + '\n'
        with self._lock:
            try:
                if self.path.exists() and self.path.stat().st_size > MAX_LOG_BYTES:
                    self.path = self.path.with_name(self.path.stem + '-%d.jsonl' % int(time.time()))
                flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0)
                fd = os.open(self.path, flags, 0o600)
                with os.fdopen(fd, 'a', encoding='utf-8') as stream:
                    stream.write(line)
            except OSError:
                self.failed = True

    def info(self, event, **fields):
        self.write(event, 'info', **fields)

    def warning(self, event, **fields):
        self.write(event, 'warning', **fields)

    def error(self, event, **fields):
        self.write(event, 'error', **fields)

    def describe(self):
        return {'directory': str(self.directory) if self.directory else None, 'current_file': str(self.path) if self.path else None,
                'write_failed': self.failed, 'format': 'JSON lines, redacted, private to this user'}


log = EventLog()


def startup_facts():
    return {'python': sys.version.split()[0], 'executable': sys.executable, 'platform': sys.platform,
            'httpx': getattr(httpx, '__version__', None), 'openssl': ssl.OPENSSL_VERSION,
            'proxy_environment': proxy_environment()}
