"""Delivery certainty and coherent policy snapshots from independent review."""
import copy

import httpx
import pytest

from coagen_client.transport import HubError
from test_recovery_runtime import runtime, fail, allow_retry
from test_group_runtime import team


@pytest.mark.parametrize('http_status', [401, 403, 409, 429])
def test_basic_later_http_rejection_cannot_erase_prior_unknown_upload(runtime, http_status):
    uploaded = runtime.transport.send_packet
    def accepted_then_lost(metadata, png):
        uploaded(metadata, png)
        raise httpx.ReadTimeout('synthetic lost response')
    runtime.transport.send_packet = accepted_then_lost
    fail(runtime, {'op': 'send', 'request_id': 'first', 'text': 'business action'}, 'SEND_OUTCOME_UNKNOWN')
    allow_retry(runtime)
    runtime.transport.send_packet = lambda *_: (_ for _ in ()).throw(HubError(http_status))
    expected = 'AUTH_FAILED' if http_status in (401, 403) else 'RATE_LIMITED' if http_status == 429 else 'HUB_REJECTED'
    error = fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'first'}, expected)
    assert error.outcome == 'unknown'
    assert error.details['new_request_after_correction'] is False
    assert runtime.store.outgoing('first')['outcome'] == 'unknown'
    runtime.transport.send_packet = uploaded
    fail(runtime, {'op': 'send', 'request_id': 'second', 'text': 'business action'}, 'PENDING_SEND')
    assert len(runtime.transport.uploads) == 1


@pytest.mark.parametrize('http_status', [401, 403, 409, 429])
def test_group_later_http_rejection_cannot_erase_prior_unknown_upload(team, http_status):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    uploaded = a.transport.send_packet
    def accepted_then_lost(metadata, png):
        uploaded(metadata, png)
        raise httpx.ReadTimeout('synthetic lost response')
    a.transport.send_packet = accepted_then_lost
    fail(a, {'op': 'send', 'request_id': 'first', 'recipient_id': 'b', 'text': 'business action'}, 'SEND_OUTCOME_UNKNOWN')
    allow_retry(a)
    a.transport.send_packet = lambda *_: (_ for _ in ()).throw(HubError(http_status))
    expected = 'AUTH_FAILED' if http_status in (401, 403) else 'RATE_LIMITED' if http_status == 429 else 'HUB_REJECTED'
    error = fail(a, {'op': 'retry_saved_packet', 'request_id': 'first'}, expected)
    assert error.outcome == 'unknown'
    assert error.details['new_request_after_correction'] is False
    a.transport.send_packet = uploaded
    fail(a, {'op': 'send', 'request_id': 'second', 'recipient_id': 'b', 'text': 'business action'}, 'PENDING_SEND')
    assert len(relay.packets) == 1


def test_group_stale_policy_cannot_replace_current_capabilities_or_roster(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    current = relay.status()
    current['collaboration']['revision'] = 10
    current['send_capabilities'] = {'collaboration_revision': 10, 'can_send': False}
    stale = copy.deepcopy(current)
    stale['collaboration']['revision'] = 9
    stale['send_capabilities'] = {'collaboration_revision': 9, 'can_send': True}
    stale['peers'] = [peer for peer in stale['peers'] if peer['peer_id'] == 'a']
    a._update_group_status(current)
    a._update_group_status(stale)
    result = a.status()
    assert result['collaboration']['revision'] == 10
    assert result['send_capabilities'] == current['send_capabilities']
    assert {peer['peer_id'] for peer in result['peers']} == {'a', 'b'}


@pytest.mark.parametrize('control', [{'action': 'reopen'}, {'action': 'configure', 'mode': 'brainstorm', 'brainstorm_policy': 'strict'}])
def test_group_explicit_new_policy_requires_advertised_hub_support(team, control):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    before = relay.revision
    fail(a, {'op': 'collaboration', 'expected_revision': before, 'request_id': 'new-feature', **control},
         'HUB_FEATURE_UNAVAILABLE')
    assert relay.revision == before


@pytest.mark.parametrize('control', [{'action': 'reopen'}, {'action': 'configure', 'mode': 'brainstorm', 'brainstorm_policy': 'strict'}])
def test_group_explicit_new_policy_forwards_original_cas_when_supported(team, control):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    status = relay.status
    relay.status = lambda: {**status(), 'collaboration_policy_supported': True}
    calls = []
    exchange = a.transport.exchange
    def recording(operation, **fields):
        calls.append((operation, fields))
        return exchange(operation, **fields)
    a.transport.exchange = recording
    before = relay.revision
    result = a.dispatch({'op': 'collaboration', 'expected_revision': before, 'request_id': 'supported-feature', **control})
    assert result['collaboration']['revision'] == before + 1
    assert calls[-1] == ('collaboration', {'expected_revision': before, 'request_id': 'supported-feature', **control})
