"""Real stdio processes and real helpers under a plain Python MCP harness."""
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest
import psutil

from coagen_client import cli


@pytest.fixture
def relay():
    members, heartbeats, closed = {}, [], set()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass
        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            if self.path == '/api/rooms/claim':
                room = uuid.uuid4().hex
                member = dict(room_id=room, session_id=uuid.uuid4().hex, peer_id=uuid.uuid4().hex,
                    token=uuid.uuid4().hex, role='a', locator='007', expires_at=time.time() + 300,
                    agent_info_supported=True)
                members[room] = member
                result = member
            else:
                member = members[body['room_id']]
                assert self.headers['Authorization'] == 'Bearer ' + member['token']
                if body['op'] == 'close':
                    closed.add(member['room_id'])
                    result = {'closed': True}
                else:
                    if body['op'] == 'heartbeat':
                        heartbeats.append((member['room_id'], body.get('agent_info')))
                    result = dict(room_id=member['room_id'], session_id=member['session_id'],
                        expires_at=member['expires_at'], pending_count=0, agent_info_supported=True,
                        peers=[{'role': 'a', 'peer_id': member['peer_id']}])
            data = json.dumps(result).encode()
            self.send_response(200)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f'http://127.0.0.1:{server.server_port}', heartbeats, closed
    server.shutdown()
    thread.join(2)
    server.server_close()


class Peer:
    def __init__(self, workspace, hub, name):
        env = os.environ.copy()
        env['LOCALAPPDATA'] = str(workspace / 'private-local')
        env['PYTHONPATH'] = str(Path(cli.__file__).resolve().parents[1])
        env.pop('COAGEN_AGENT_NAME', None)
        env.pop('COAGEN_AGENT_VERSION', None)
        self.process = subprocess.Popen([sys.executable, '-X', 'utf8', '-m', 'coagen_client',
            'mcp', '--workspace', str(workspace), '--hub', hub], env=env, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8')
        self.responses, self.sequence = queue.Queue(), 0
        def read():
            for line in self.process.stdout:
                self.responses.put(json.loads(line))
        threading.Thread(target=read, daemon=True).start()
        assert 'result' in self.rpc('initialize', {'clientInfo': {'name': name, 'version': 'future β'}})
        result = self.call('coagen_prepare')
        assert result['binding_scope'] == 'mcp_instance'
        self.owner_pid = result['owner_pid']
        # Windows venv python.exe may be a launcher for the real interpreter.
        actual = psutil.Process(self.owner_pid)
        assert self.owner_pid == self.process.pid or self.process.pid in [p.pid for p in actual.parents()]
        assert 'coagen_client' in actual.cmdline() and 'mcp' in actual.cmdline()
        self.created = self.call('coagen_create', {'reservation_code': 'a' * 43})
        self.state = Path(self.created['state_dir'])

    def send(self, method, params):
        self.sequence += 1
        self.process.stdin.write(json.dumps({'id': self.sequence, 'jsonrpc': '2.0',
            'method': method, 'params': params}, ensure_ascii=False) + '\n')
        self.process.stdin.flush()
        return self.sequence

    def rpc(self, method, params):
        identity = self.send(method, params)
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            response = self.responses.get(timeout=max(.01, deadline - time.monotonic()))
            if response.get('id') == identity:
                assert 'error' not in response, response
                return response
        raise AssertionError('No bounded stdio response')

    def call(self, name, arguments=None):
        response = self.rpc('tools/call', {'name': name, 'arguments': arguments or {}})
        assert not response['result'].get('isError'), response
        return json.loads(response['result']['content'][0]['text'])

    def stop(self):
        if self.process.poll() is None:
            self.process.stdin.close()
            try:
                self.process.wait(10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(5)


def terminal(peer, timeout=8):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        path = peer.state / 'stopped.json'
        if path.is_file():
            value = json.loads(path.read_text(encoding='utf-8'))
            if value.get('stopped'):
                return value['status']
        time.sleep(.03)
    raise AssertionError('Helper did not publish bounded terminal cleanup')


def test_real_unknown_hosts_have_independent_sessions_eof_and_crash_cleanup(tmp_path, relay):
    hub, heartbeats, closed = relay
    first = Peer(tmp_path, hub, 'Unknown Agent 🦊')
    second = None
    try:
        second = Peer(tmp_path, hub, '另一种 Agent')
        assert first.owner_pid != second.owner_pid
        assert first.state != second.state
        deadline = time.monotonic() + 5
        while len(heartbeats) < 2 and time.monotonic() < deadline:
            time.sleep(.03)
        info = dict(heartbeats)
        assert info[first.created['room_id']]['name'] == 'Unknown Agent 🦊'
        assert info[second.created['room_id']]['name'] == '另一种 Agent'
        first.process.stdin.close()
        first.process.wait(8)
        assert terminal(first)['phase'] in ('stopped', 'owner_exited')
        assert first.created['room_id'] in closed
        assert second.call('coagen_status')['phase'] == 'waiting_for_peer'
        psutil.Process(second.owner_pid).kill()
        second.process.wait(5)
        assert terminal(second)['phase'] == 'owner_exited'
        assert second.created['room_id'] in closed
    finally:
        first.stop()
        if second is not None:
            second.stop()


def test_transport_eof_during_sixty_second_watch_exits_within_eight_seconds(tmp_path, relay):
    peer = Peer(tmp_path, relay[0], 'Unbranded Harness')
    try:
        peer.send('tools/call', {'name': 'coagen_watch', 'arguments': {'wait_seconds': 60}})
        # Ensure the request can enter its wait before EOF closes the pipe.
        time.sleep(.25)
        started = time.monotonic()
        peer.process.stdin.close()
        peer.process.wait(8)
        assert time.monotonic() - started < 8
        assert terminal(peer)['phase'] in ('stopped', 'owner_exited')
    finally:
        peer.stop()
