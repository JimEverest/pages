import io
import json
import os
from pathlib import Path
from unittest.mock import Mock

import pytest

from coagen_client import mcp


@pytest.fixture(autouse=True)
def private_test_diagnostics(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))


def rpc(method, params=None, request_id=1):
    return {'jsonrpc': '2.0', 'id': request_id, 'method': method,
            'params': params or {}}


def test_mcp_protocol_lists_safe_tools_and_does_not_log_to_stdout(monkeypatch):
    server = mcp.McpServer(workspace=Path.cwd(), owner_pid=os.getpid())
    response = server.handle(rpc('initialize'))
    assert response['result']['capabilities']['tools'] == {}
    listed = server.handle(rpc('tools/list', request_id=2))
    names = {item['name'] for item in listed['result']['tools']}
    assert {'coagen_prepare', 'coagen_create', 'coagen_join', 'coagen_status',
            'coagen_watch', 'coagen_receive', 'coagen_send', 'coagen_consume',
            'coagen_audit', 'coagen_stop'} <= names


def test_mcp_create_and_join_keep_pairing_code_out_of_shell(monkeypatch, tmp_path):
    created = {'pairing_code': '00700042', 'room_id': 'room', 'phase': 'starting'}
    joined = {'phase': 'starting', 'room_id': 'room'}
    create = Mock(return_value=created)
    join = Mock(return_value=joined)
    monkeypatch.setattr(mcp.cli, 'create', create)
    monkeypatch.setattr(mcp.cli, 'join', join)
    server = mcp.McpServer(workspace=tmp_path, owner_pid=123)
    result = server.call('coagen_create', {'state_dir': str(tmp_path / 'a')})
    assert json.loads(result['content'][0]['text']) == created
    assert create.call_args.args[0].owner_pid == 123
    server = mcp.McpServer(workspace=tmp_path, owner_pid=123)
    result = server.call('coagen_join', {'code': '00700042', 'state_dir': str(tmp_path / 'b')})
    assert json.loads(result['content'][0]['text']) == joined
    assert join.call_args.args[0].owner_pid == 123
    assert '00700042' not in json.dumps(result)


def test_mcp_create_forwards_reservation_code_only_as_structured_input(monkeypatch, tmp_path):
    activation = 'a' * 43
    create = Mock(return_value={'pairing_code': '00700042', 'phase': 'starting'})
    monkeypatch.setattr(mcp.cli, 'create', create)
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    result = server.call('coagen_create', {'reservation_code': activation})
    assert create.call_args.args[0].reservation_code == activation
    assert activation not in json.dumps(result)
    assert activation not in create.call_args.args[0].state_dir
    tool = next(item for item in mcp.TOOLS if item['name'] == 'coagen_create')
    assert 'reservation_code' in tool['inputSchema']['properties']


def test_mcp_rejects_code_in_paths_and_invalid_code_before_network(monkeypatch, tmp_path):
    server = mcp.McpServer(workspace=tmp_path, owner_pid=123)
    with pytest.raises(ValueError, match='eight ASCII digits'):
        server.call('coagen_join', {'code': '1234', 'state_dir': str(tmp_path / 'b')})
    monkeypatch.setattr(mcp.cli, 'join', Mock(side_effect=AssertionError('network')))
    server.state_dir = tmp_path / 'state'
    with pytest.raises(ValueError, match='attachment path'):
        server.call('coagen_send', {'files': [str(Path(tmp_path).parent / 'outside.txt')]})
    with pytest.raises(ValueError, match='README file path'):
        server.call('coagen_send', {'readme': str(Path(tmp_path).parent / 'README.md')})


def test_watch_repeats_bounded_receive_until_message(monkeypatch, tmp_path):
    calls = []
    responses = [{'phase': 'ready', 'pending_count': 0}, {'messages': []},
                 {'phase': 'ready', 'pending_count': 1}, {'messages': [{'message_id': 'm'}]}]
    monkeypatch.setattr(mcp.cli, 'call_local', lambda state, operation: calls.append(operation) or responses.pop(0))
    server = mcp.McpServer(workspace=tmp_path, owner_pid=123, state_dir=tmp_path / 'state')
    result = server.call('coagen_watch', {'wait_seconds': 3})
    assert json.loads(result['content'][0]['text'])['messages'] == [{'message_id': 'm'}]
    assert calls[0]['op'] == 'status'
    receive_calls = [call for call in calls if call.get('op') == 'receive']
    assert all(0 <= call['wait'] <= 20 for call in receive_calls)
    assert json.loads(result['content'][0]['text'])['monitor']['phase'] == 'ready'


def test_install_mcp_merges_without_credentials(tmp_path):
    config = tmp_path / '.mcp.json'
    config.write_text(json.dumps({'mcpServers': {'other': {'command': 'other'}}}))
    mcp.install_config(config, Path(r'C:\Tools\python.exe'), 'https://example.test/coagen')
    value = json.loads(config.read_text())
    assert set(value['mcpServers']) == {'other', 'coagen'}
    coagen = value['mcpServers']['coagen']
    assert coagen['args'] == ['-X', 'utf8', '-m', 'coagen_client', 'mcp']
    assert 'token' not in json.dumps(value).lower()
