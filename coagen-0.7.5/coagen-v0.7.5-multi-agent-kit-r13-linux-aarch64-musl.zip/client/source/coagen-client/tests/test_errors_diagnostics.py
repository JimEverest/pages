import importlib
import importlib.util
import json

import httpx
import pytest


def modules():
    assert importlib.util.find_spec('coagen_client.errors') is not None, 'shared error contract is missing'
    assert importlib.util.find_spec('coagen_client.diagnostics') is not None, 'persistent diagnostics are missing'
    return importlib.import_module('coagen_client.errors'), importlib.import_module('coagen_client.diagnostics')


def test_safe_error_classification_does_not_reflect_secret():
    errors, _ = modules()
    secret = 'PRIVATE-TOKEN-DO-NOT-LOG'
    error = errors.classify_error(httpx.ReadTimeout(secret), operation='send', stage='hub_upload', outcome='unknown')
    report = error.to_dict()
    assert report['code'] == 'SEND_OUTCOME_UNKNOWN'
    assert report['outcome'] == 'unknown'
    assert report['recovery'] == 'retry_saved_packet'
    assert secret not in json.dumps(report)
    assert secret not in str(error)
    assert report['incident_id']


def test_untrusted_error_fields_are_filtered_and_roundtrip_is_safe():
    errors, _ = modules()
    secret = 'SECRET-IN-ERROR'
    value = errors.CoagenError('HUB_UNAVAILABLE', operation='receive', stage='hub_poll', http_status=503,
                              retry={'attempts_used': 1, 'max_attempts': 3, 'deadline': 1000, 'secret': secret}).to_dict()
    value.update(summary=secret, next_action=secret, raw_exception=secret)
    restored = errors.CoagenError.from_dict(value).to_dict()
    assert restored['code'] == 'HUB_UNAVAILABLE'
    assert restored['http_status'] == 503
    assert restored['retry']['attempts_used'] == 1
    assert secret not in json.dumps(restored)
    unknown = errors.CoagenError.from_dict({'code': secret, 'stage': secret, 'operation': secret}).to_dict()
    assert unknown['code'] == 'INTERNAL_ERROR'
    assert secret not in json.dumps(unknown)


def test_business_incident_survives_connection_recovery_and_restart(tmp_path):
    errors, diagnostics = modules()
    journal = diagnostics.Diagnostics(tmp_path)
    first = journal.record(errors.CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload', outcome='unknown'), key='private-request')
    repeated = journal.record(errors.CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload', outcome='unknown'), key='private-request')
    assert first['incident_id'] == repeated['incident_id']
    assert repeated['occurrences'] == 2
    journal.record(errors.CoagenError('HUB_UNAVAILABLE', operation='heartbeat', stage='hub_exchange'), channel='connection')
    journal.resolve(channel='connection')
    snapshot = diagnostics.Diagnostics(tmp_path).snapshot()
    assert snapshot['connection_error'] is None
    assert snapshot['last_operation_error']['code'] == 'SEND_OUTCOME_UNKNOWN'
    assert 'private-request' not in (tmp_path / 'diagnostics.json').read_text(encoding='utf-8')
    journal.resolve(key='private-request')
    snapshot = journal.snapshot()
    assert snapshot['last_operation_error'] is None
    assert any(item['status'] == 'resolved' for item in snapshot['incidents'])


def test_journal_is_bounded_and_write_failure_preserves_primary_error(tmp_path, monkeypatch):
    errors, diagnostics = modules()
    journal = diagnostics.Diagnostics(tmp_path)
    for i in range(80):
        journal.record(errors.CoagenError('INVALID_ARGUMENT', operation='send', stage='preflight'), key=str(i))
    assert len(journal.snapshot()['incidents']) <= 64
    assert (tmp_path / 'diagnostics.json').stat().st_size < 131072
    def fail(*args, **kwargs):
        raise OSError('SECRET-DISK-PATH')
    monkeypatch.setattr(diagnostics, 'atomic_private_json', fail)
    report = journal.record(errors.CoagenError('LOCAL_STORAGE_FAILED', operation='send', stage='save_outbox'))
    assert report['code'] == 'LOCAL_STORAGE_FAILED'
    assert journal.snapshot()['diagnostic_write_failed'] is True
    assert 'SECRET-DISK-PATH' not in json.dumps(journal.snapshot())


def test_invalid_utf8_and_crypto_errors_have_stable_actions():
    errors, _ = modules()
    error = errors.classify_error(UnicodeDecodeError('utf-8', b'\xff', 0, 1, 'bad'), operation='send', stage='stdio_decode')
    assert error.to_dict()['code'] == 'INVALID_UTF8'
    assert error.to_dict()['recovery'] == 'correct_input'
    report = errors.CoagenError('CRYPTO_FAILURE', operation='send', stage='encrypt').to_dict()
    assert report['severity'] == 'critical'
    assert report['recovery'] == 'stop_operation'


def test_malformed_helper_error_and_journal_fail_closed(tmp_path):
    errors, diagnostics = modules()
    report = errors.CoagenError.from_dict({'code': [], 'stage': {}, 'phase': [], 'operation': {}, 'outcome': []}).to_dict()
    assert report['code'] == 'INTERNAL_ERROR'
    assert report['stage'] == 'unknown'
    (tmp_path / 'diagnostics.json').write_text('[]', encoding='utf-8')
    journal = diagnostics.Diagnostics(tmp_path)
    assert journal.snapshot()['diagnostic_write_failed']


@pytest.mark.parametrize(('status', 'operation', 'stage', 'code'), [
    (409, 'join', 'hub_establishment', 'ROOM_UNAVAILABLE'),
    (404, 'join', 'hub_establishment', 'ROOM_UNAVAILABLE'),
    (409, 'send', 'hub_upload', 'HUB_REJECTED'),
    (404, 'receive', 'packet_download', 'HUB_REJECTED'),
    (410, 'receive', 'packet_download', 'HUB_REJECTED'),
    (410, 'send', 'hub_upload', 'HUB_REJECTED'),
    (410, 'heartbeat', 'heartbeat', 'SESSION_REVOKED'),
    (410, 'receive', 'receive_poll', 'SESSION_REVOKED'),
])
def test_http_rejection_does_not_invent_room_failure(status, operation, stage, code):
    errors, _ = modules()
    from coagen_client.transport import HubError
    report = errors.classify_error(HubError(status), operation=operation, stage=stage).to_dict()
    assert report['code'] == code
    assert report['http_status'] == status
