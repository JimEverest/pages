"""Regression tests for pre-session recovery and the actual UTF-8 MCP wire."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from coagen_client import cli, mcp


def payload(result):
    return json.loads(result['content'][0]['text'])


def call(server, name, arguments=None):
    return server.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
                          'params': {'name': name, 'arguments': arguments or {}}})['result']


@pytest.fixture(autouse=True)
def private_test_diagnostics(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))


@pytest.fixture
def server(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    return mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())


def test_fresh_code_only_join_allocates_private_random_state(server, monkeypatch):
    join = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'join', join)
    result = call(server, 'coagen_join', {'code': '00700042'})
    assert not result.get('isError')
    state = Path(join.call_args.args[0].state_dir)
    assert state == server.state_dir
    assert state.parent.name == 'sessions'
    assert '00700042' not in str(state)


def test_failed_join_does_not_rebind_live_session(server, monkeypatch, tmp_path):
    old = tmp_path / 'old'
    server.state_dir = old
    monkeypatch.setattr(cli, 'join', Mock(side_effect=httpx.ReadTimeout('SECRET-CODE-00700042')))
    result = call(server, 'coagen_join', {'code': '00700042', 'state_dir': str(tmp_path / 'new')})
    assert result['isError']
    assert server.state_dir == old
    assert '00700042' not in json.dumps(result)


def test_no_session_status_and_prepare_are_usable_and_do_not_probe_credentials(server, monkeypatch):
    monkeypatch.setattr(cli, 'default_token_file', Mock(side_effect=AssertionError('credential probe')))
    state = payload(call(server, 'coagen_status'))
    assert state['phase'] == 'no_session'
    assert 'last_operation_error' in state
    prepared = payload(call(server, 'coagen_prepare'))
    assert prepared['version'] == cli.__version__
    assert prepared['runtime']['stdio_encoding'] == 'utf-8'
    assert prepared['runtime']['python_version']
    assert prepared['phase'] == 'no_session'


def test_mcp_create_without_default_token_never_prompts_on_stdio(server, monkeypatch, tmp_path):
    monkeypatch.setattr(cli, 'default_token_file', lambda: tmp_path / 'absent-token')
    prompt = Mock(side_effect=AssertionError('do not read MCP protocol as credential'))
    monkeypatch.setattr(cli.getpass, 'getpass', prompt)
    result = payload(call(server, 'coagen_create'))
    assert result['code'] == 'AUTH_FAILED'
    assert result['stage'] == 'preflight'
    assert prompt.call_count == 0


def test_cli_diagnostic_write_failure_does_not_hide_primary_error(tmp_path, monkeypatch, capsys):
    from coagen_client.errors import CoagenError
    diagnostic = Mock()
    diagnostic.record.side_effect = lambda error, **kw: error.to_dict()
    diagnostic.snapshot.return_value = {'diagnostic_write_failed': True}
    monkeypatch.setattr(cli, 'Diagnostics', lambda root: diagnostic)
    assert cli.main(['join', '--code', 'bad-code', '--state-dir', str(tmp_path / 's')]) == 1
    output = capsys.readouterr()
    error = json.loads(output.err)
    assert error['code'] == 'INVALID_ARGUMENT'
    assert error['diagnostic_write_failed'] is True
    assert output.out == ''


def test_mcp_send_reads_utf8_readme_and_assigns_id_before_helper(server, tmp_path, monkeypatch):
    server.state_dir = tmp_path / 'state'
    readme = tmp_path / '说明.md'
    readme.write_text('# 任务\n中文与 emoji 🌍', encoding='utf-8')
    helper = Mock(return_value={'state': 'sent'})
    monkeypatch.setattr(cli, 'call_local', helper)
    result = call(server, 'coagen_send', {'readme': str(readme)})
    assert not result.get('isError')
    operation = helper.call_args.args[1]
    assert operation['readme'] == '# 任务\n中文与 emoji 🌍'
    assert len(operation['request_id']) == 32


def test_readme_hardlink_is_rejected_before_read_or_helper(server, tmp_path, monkeypatch):
    server.state_dir = tmp_path / 'state'
    source = tmp_path / 'source.md'
    source.write_text('PRIVATE', encoding='utf-8')
    linked = tmp_path / 'linked.md'
    os.link(source, linked)
    helper = Mock(side_effect=AssertionError('no helper'))
    monkeypatch.setattr(cli, 'call_local', helper)
    result = call(server, 'coagen_send', {'readme': str(linked)})
    assert result['isError']
    assert payload(result)['code'] == 'README_PATH_INVALID'
    assert helper.call_count == 0
    assert 'PRIVATE' not in json.dumps(result)


def test_no_active_session_error_names_the_attempted_operation(server):
    result = payload(call(server, 'coagen_send', {'text': 'private'}))
    assert result['code'] == 'NO_ACTIVE_SESSION'
    assert result['operation'] == 'send'


def test_waiting_watch_uses_status_without_trying_receive(server, tmp_path, monkeypatch):
    server.state_dir = tmp_path / 'state'
    helper = Mock(return_value={'phase': 'waiting_for_peer'})
    monkeypatch.setattr(cli, 'call_local', helper)
    result = payload(call(server, 'coagen_watch', {'wait_seconds': 0}))
    assert result['messages'] == []
    assert result['monitor']['phase'] == 'waiting_for_peer'
    assert all(entry.args[1]['op'] == 'status' for entry in helper.call_args_list)


def test_terminal_watch_returns_explicit_stop(server, tmp_path, monkeypatch):
    server.state_dir = tmp_path / 'state'
    helper = Mock(return_value={'phase': 'expired'})
    monkeypatch.setattr(cli, 'call_local', helper)
    result = payload(call(server, 'coagen_watch', {'wait_seconds': 20}))
    assert result['stop'] is True
    assert result['monitor']['phase'] == 'expired'
    assert helper.call_count == 1


@pytest.mark.parametrize('name', ['coagen_watch', 'coagen_receive'])
def test_blocked_pairing_returns_stop_with_original_error_without_waiting(server, tmp_path, monkeypatch, name):
    from coagen_client.errors import CoagenError
    server.state_dir = tmp_path / 'state'
    incident = CoagenError('RETRY_BUDGET_EXHAUSTED', operation='pair', stage='pairing').to_dict()
    helper = Mock(return_value={'phase': 'pairing', 'connection_recovery_blocked': True,
                                'connection_error': incident})
    monkeypatch.setattr(cli, 'call_local', helper)
    sleep = Mock(side_effect=AssertionError('blocked pairing must return immediately'))
    monkeypatch.setattr(mcp.time, 'sleep', sleep)
    result = call(server, name, {'wait_seconds': 20})
    assert not result.get('isError')
    value = payload(result)
    assert value['stop'] is True
    assert value['monitor']['connection_error']['incident_id'] == incident['incident_id']
    assert value['monitor']['connection_recovery_blocked'] is True
    assert helper.call_args_list[0].args[1]['op'] == 'status'
    assert helper.call_count == 1
    assert sleep.call_count == 0


def test_first_error_is_structured_retained_and_redacted(server, monkeypatch):
    monkeypatch.setattr(cli, 'join', Mock(side_effect=httpx.ReadTimeout('SECRET-00700042-token')))
    result = call(server, 'coagen_join', {'code': '00700042'})
    assert result['isError']
    error = payload(result)
    assert error['code'] == 'SESSION_OUTCOME_UNKNOWN'
    assert error['operation'] == 'join'
    assert error['outcome'] == 'unknown'
    assert error['incident_id']
    status = payload(call(server, 'coagen_status'))
    assert status['last_operation_error']['incident_id'] == error['incident_id']
    assert 'SECRET' not in json.dumps(status)


def test_unknown_join_outcome_cannot_retry_with_fresh_code_only_dir(server, monkeypatch):
    join = Mock(side_effect=httpx.ReadTimeout('SECRET'))
    monkeypatch.setattr(cli, 'join', join)
    first = payload(call(server, 'coagen_join', {'code': '00700042'}))
    second = payload(call(server, 'coagen_join', {'code': '00812345'}))
    assert first['code'] == second['code'] == 'SESSION_OUTCOME_UNKNOWN'
    assert first['incident_id'] == second['incident_id']
    assert join.call_count == 1


def test_unknown_establishment_gate_survives_bridge_restart(server, monkeypatch):
    join = Mock(side_effect=httpx.ReadTimeout('SECRET'))
    monkeypatch.setattr(cli, 'join', join)
    first = payload(call(server, 'coagen_join', {'code': '00700042'}))
    restarted = mcp.McpServer(workspace=server.workspace, owner_pid=server.owner_pid)
    second = payload(call(restarted, 'coagen_create'))
    assert second['code'] == 'SESSION_OUTCOME_UNKNOWN'
    assert second['incident_id'] == first['incident_id']
    assert restarted.state_dir is None
    assert join.call_count == 1


def test_invalid_readme_utf8_reports_specific_local_stage(server, monkeypatch, tmp_path):
    server.state_dir = tmp_path / 'state'
    readme = tmp_path / 'README.md'
    readme.write_bytes(b'\xffSECRET')
    helper = Mock(side_effect=AssertionError('must not reach helper'))
    monkeypatch.setattr(cli, 'call_local', helper)
    result = payload(call(server, 'coagen_send', {'readme': str(readme)}))
    assert result['code'] == 'INVALID_UTF8'
    assert result['stage'] == 'readme'
    assert result['outcome'] == 'not_started'
    assert 'SECRET' not in json.dumps(result)
    assert helper.call_count == 0


def test_status_preserves_bridge_error_when_helper_has_no_error(server, monkeypatch, tmp_path):
    server.state_dir = tmp_path / 'state'
    monkeypatch.setattr(cli, 'call_local', Mock(side_effect=httpx.ConnectError('SECRET')))
    first = payload(call(server, 'coagen_send', {'text': 'private-body'}))
    monkeypatch.setattr(cli, 'call_local', Mock(return_value={'phase': 'ready', 'last_operation_error': None}))
    status = payload(call(server, 'coagen_status'))
    assert status['last_operation_error']['incident_id'] == first['incident_id']
    assert any(row['incident_id'] == first['incident_id'] for row in status['incidents'])


def test_successful_retry_resolves_only_matching_send_incident(server, monkeypatch, tmp_path):
    from coagen_client.errors import CoagenError
    server.state_dir = tmp_path / 'state'
    helper = Mock(side_effect=CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload', outcome='unknown'))
    monkeypatch.setattr(cli, 'call_local', helper)
    first = payload(call(server, 'coagen_send', {'text': 'body', 'request_id': 'original'}))
    helper.side_effect = None
    helper.return_value = {'state': 'sent', 'request_id': 'different'}
    call(server, 'coagen_send', {'text': 'unrelated', 'request_id': 'different'})
    assert server.diagnostics.snapshot()['last_operation_error']['incident_id'] == first['incident_id']
    helper.return_value = {'state': 'sent', 'request_id': 'original'}
    call(server, 'coagen_retry_send', {'request_id': 'original'})
    state = server.diagnostics.snapshot()
    assert state['last_operation_error'] is None
    assert state['incidents'][0]['status'] == 'resolved'


@pytest.mark.parametrize('name', ['coagen_status', 'coagen_watch'])
def test_successful_monitor_resolves_own_failure_only(server, monkeypatch, tmp_path, name):
    from coagen_client.errors import CoagenError
    server.state_dir = tmp_path / 'state'
    helper = Mock(side_effect=httpx.ConnectError('SECRET'))
    monkeypatch.setattr(cli, 'call_local', helper)
    failure = payload(call(server, name, {'wait_seconds': 0}))
    separate = server.diagnostics.record(CoagenError('SEND_OUTCOME_UNKNOWN', operation='send',
                                         stage='hub_upload', outcome='unknown'), key='send:original')
    helper.side_effect = None
    helper.return_value = {'phase': 'waiting_for_peer'}
    result = payload(call(server, name, {'wait_seconds': 0}))
    snapshot = server.diagnostics.snapshot()
    assert next(row for row in snapshot['incidents'] if row['incident_id'] == failure['incident_id'])['status'] == 'resolved'
    assert snapshot['last_operation_error']['incident_id'] == separate['incident_id']
    returned = result['monitor'] if name == 'coagen_watch' else result
    assert all(row['incident_id'] != failure['incident_id'] for row in returned['incidents'])
    assert returned['incident_summary']['resolved'] >= 1
    full = payload(call(server, 'coagen_status', {'detail':'full'}))
    assert next(row for row in full['incidents'] if row['incident_id'] == failure['incident_id'])['status'] == 'resolved'


def test_mcp_consume_success_resolves_only_same_message(server, monkeypatch, tmp_path):
    from coagen_client.errors import CoagenError
    server.state_dir = tmp_path / 'state'
    helper = Mock(side_effect=CoagenError('HUB_UNAVAILABLE', operation='consume', stage='hub_consume', outcome='unknown'))
    monkeypatch.setattr(cli, 'call_local', helper)
    first = payload(call(server, 'coagen_consume', {'message_id': 'a' * 32}))
    helper.side_effect = None
    helper.return_value = {'state': 'consumed'}
    call(server, 'coagen_consume', {'message_id': 'b' * 32})
    assert server.diagnostics.snapshot()['last_operation_error']['incident_id'] == first['incident_id']
    call(server, 'coagen_consume', {'message_id': 'a' * 32})
    assert server.diagnostics.snapshot()['last_operation_error'] is None


def test_cli_consume_success_resolves_only_same_message(tmp_path, monkeypatch, capsys):
    from coagen_client.errors import CoagenError
    state = tmp_path / 'state'
    helper = Mock(side_effect=CoagenError('HUB_UNAVAILABLE', operation='consume', stage='hub_consume', outcome='unknown'))
    monkeypatch.setattr(cli, 'call_local', helper)
    common = ['consume', '--state-dir', str(state), '--message-id']
    assert cli.main([*common, 'a' * 32]) == 1
    first = json.loads(capsys.readouterr().err)
    helper.side_effect = None
    helper.return_value = {'state': 'consumed'}
    assert cli.main([*common, 'b' * 32]) == 0
    snapshot = cli.Diagnostics(cli.cli_diagnostic_root(state)).snapshot()
    assert snapshot['last_operation_error']['incident_id'] == first['incident_id']
    assert cli.main([*common, 'a' * 32]) == 0
    assert cli.Diagnostics(cli.cli_diagnostic_root(state)).snapshot()['last_operation_error'] is None


def test_pending_send_never_returns_new_unusable_recovery_id(server, monkeypatch, tmp_path):
    from coagen_client.errors import CoagenError
    server.state_dir = tmp_path / 'state'
    helper = Mock(side_effect=CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload', outcome='unknown'))
    monkeypatch.setattr(cli, 'call_local', helper)
    original = payload(call(server, 'coagen_send', {'text': 'original'}))
    assert original['request_id']
    helper.side_effect = CoagenError('PENDING_SEND', operation='send', stage='outbox_lookup', outcome='unknown')
    blocked = payload(call(server, 'coagen_send', {'text': 'new'}))
    assert blocked['code'] == 'PENDING_SEND'
    assert 'request_id' not in blocked
    assert any(row['incident_id'] == original['incident_id'] and row['status'] == 'active'
               for row in server.diagnostics.snapshot()['incidents'])


def test_join_rejects_explicit_state_path_containing_code_before_network(server, monkeypatch, tmp_path):
    join = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'join', join)
    code = '00700042'
    target = tmp_path / ('room-' + code)
    result = payload(call(server, 'coagen_join', {'code': code, 'state_dir': str(target)}))
    assert result['code'] == 'INVALID_ARGUMENT'
    assert result['stage'] == 'path_validation'
    assert code not in json.dumps(result)
    assert join.call_count == 0
    assert not target.exists()


def test_cli_join_rejects_state_path_containing_code_before_network(tmp_path, monkeypatch, capsys):
    transport = Mock(side_effect=AssertionError('no network'))
    monkeypatch.setattr(cli, 'Transport', transport)
    code = '00700042'
    assert cli.main(['join', '--code', code, '--state-dir', str(tmp_path / code),
                     '--owner-pid', str(os.getpid())]) == 1
    error = json.loads(capsys.readouterr().err)
    assert error['code'] == 'INVALID_ARGUMENT'
    assert error['stage'] == 'path_validation'
    assert code not in json.dumps(error)
    assert transport.call_count == 0


def test_cli_repeated_unknown_establishment_blocks_second_post(tmp_path, monkeypatch):
    transport = Mock()
    transport.request.side_effect = httpx.ReadTimeout('SECRET-CODE')
    monkeypatch.setattr(cli, 'Transport', Mock(return_value=transport))
    args = argparse.Namespace(code='00700042', owner_pid=os.getpid(), state_dir=str(tmp_path / 'state'),
                              hub='https://example.invalid', code_stdin=False)
    for _ in range(2):
        with pytest.raises(ValueError) as error:
            cli.join(args)
        assert getattr(error.value, 'code', None) == 'SESSION_OUTCOME_UNKNOWN'
    assert transport.request.call_count == 1


def test_claim_unknown_outcome_blocks_replay_without_persisting_activation(tmp_path, monkeypatch):
    transport = Mock()
    activation = 'Z' * 43
    transport.request.side_effect = httpx.ReadTimeout(activation)
    constructor = Mock(return_value=transport)
    monkeypatch.setattr(cli, 'Transport', constructor)
    args = argparse.Namespace(reservation_code=activation, owner_pid=os.getpid(),
                              state_dir=str(tmp_path / 'state'), hub='https://example.invalid')
    for _ in range(2):
        with pytest.raises(cli.CoagenError) as error:
            cli.create(args)
        assert error.value.code == 'SESSION_OUTCOME_UNKNOWN'
        assert activation not in json.dumps(error.value.to_dict())
    constructor.assert_called_once_with('https://example.invalid')
    transport.request.assert_called_once_with('/api/rooms/claim', json_body={'activation_code': activation})
    assert all(activation.encode() not in p.read_bytes() for p in tmp_path.rglob('*') if p.is_file())


def test_cli_invalid_code_diagnostics_do_not_poison_future_state_directory(tmp_path, monkeypatch, capsys):
    target = tmp_path / 'session'
    assert cli.main(['join', '--code', 'bad', '--state-dir', str(target), '--owner-pid', str(os.getpid())]) == 1
    capsys.readouterr()
    transport = Mock()
    transport.request.return_value = SimpleNamespace(json=lambda: {'room_id': 'room', 'token': 'member'})
    monkeypatch.setattr(cli, 'Transport', Mock(return_value=transport))
    monkeypatch.setattr(cli, 'launch_session', Mock(return_value={'phase': 'starting'}))
    assert cli.main(['join', '--code', '00700042', '--state-dir', str(target), '--owner-pid', str(os.getpid())]) == 0


def test_retry_send_dispatches_frozen_packet_only(server, tmp_path, monkeypatch):
    server.state_dir = tmp_path / 'state'
    helper = Mock(return_value={'state': 'sent'})
    monkeypatch.setattr(cli, 'call_local', helper)
    result = call(server, 'coagen_retry_send', {'request_id': 'original'})
    assert not result.get('isError')
    assert helper.call_args.args[1] == {'op': 'retry_saved_packet', 'request_id': 'original'}


def test_call_local_preserves_typed_helper_error(tmp_path, monkeypatch):
    from coagen_client.errors import CoagenError
    report = CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload', outcome='unknown').to_dict()
    (tmp_path / 'control.json').write_text(json.dumps({'url': 'http://127.0.0.1:12345/rpc', 'token': 'SECRET'}))
    response = httpx.Response(200, json={'ok': False, 'error': report},
                              request=httpx.Request('POST', 'http://127.0.0.1:12345/rpc'))
    monkeypatch.setattr(httpx.Client, 'post', lambda *a, **kw: response)
    with pytest.raises(CoagenError) as caught:
        cli.call_local(tmp_path, {'op': 'send'})
    assert caught.value.to_dict()['incident_id'] == report['incident_id']
    assert caught.value.code == 'SEND_OUTCOME_UNKNOWN'


def test_actual_stdio_is_utf8_under_ascii_process_defaults(tmp_path):
    script = """
import os
from coagen_client import mcp
mcp.cli.call_local = lambda state, op: {'phase': 'ready', 'text': op.get('text')}
server = mcp.McpServer(workspace=os.environ['TEST_WORKSPACE'], owner_pid=os.getpid(), state_dir=os.environ['TEST_WORKSPACE'])
mcp.serve_stdio(server)
"""
    env = {**os.environ, 'PYTHONUTF8': '0', 'PYTHONIOENCODING': 'ascii:strict',
           'TEST_WORKSPACE': str(tmp_path), 'LOCALAPPDATA': str(tmp_path / 'local')}
    request = {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call',
               'params': {'name': 'coagen_send', 'arguments': {'text': '中文任务 🌍'}}}
    wire = json.dumps(request, ensure_ascii=False).encode('utf-8') + b'\n'
    run = subprocess.run([sys.executable, '-c', script], input=wire, capture_output=True, env=env, timeout=15)
    assert run.returncode == 0, run.stderr.decode('utf-8', 'replace')
    assert run.stderr == b''
    result = json.loads(run.stdout.decode('utf-8'))
    assert payload(result['result'])['text'] == '中文任务 🌍'
    assert '中文任务'.encode('utf-8') in run.stdout


def test_invalid_utf8_is_contained_and_next_request_still_works(tmp_path):
    script = "from coagen_client import mcp; import os; mcp.serve_stdio(mcp.McpServer(owner_pid=os.getpid()))"
    env = {**os.environ, 'PYTHONUTF8': '0', 'PYTHONIOENCODING': 'cp1252:strict',
           'LOCALAPPDATA': str(tmp_path / 'local')}
    wire = b'{"method":"ping","bad":"\xff"}\n' + b'{"jsonrpc":"2.0","id":4,"method":"ping"}\n'
    run = subprocess.run([sys.executable, '-c', script], input=wire, capture_output=True, env=env, timeout=15)
    assert run.returncode == 0
    assert run.stderr == b''
    responses = [json.loads(line) for line in run.stdout.decode('utf-8').splitlines()]
    assert responses[0]['error']['data']['code'] == 'INVALID_UTF8'
    assert responses[1] == {'jsonrpc': '2.0', 'id': 4, 'result': {}}


def test_escaped_unpaired_unicode_surrogate_is_contained(tmp_path):
    script = "from coagen_client import mcp; import os; mcp.serve_stdio(mcp.McpServer(owner_pid=os.getpid()))"
    env = {**os.environ, 'LOCALAPPDATA': str(tmp_path / 'local')}
    wire = b'{"jsonrpc":"2.0","id":"\\ud800","method":"ping"}\n'
    wire += b'{"jsonrpc":"2.0","id":4,"method":"ping"}\n'
    run = subprocess.run([sys.executable, '-c', script], input=wire, capture_output=True, env=env, timeout=15)
    assert run.returncode == 0
    assert run.stderr == b''
    responses = [json.loads(line) for line in run.stdout.decode('utf-8').splitlines()]
    assert responses[0]['error']['data']['code'] == 'INVALID_UTF8'
    assert responses[1]['id'] == 4
