"""Shutdown remains effective even when local cleanup/storage is unavailable."""
import json
import os
from pathlib import Path
import threading
import time
from unittest.mock import Mock

import pytest

from coagen_client.lifecycle import Owner
from coagen_client.runtime import SessionRuntime
from coagen_client.store import atomic_private_json


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    owner = Owner.capture(os.getpid())
    runtime = SessionRuntime({
        "state_dir": str(tmp_path), "owner_pid": owner.pid,
        "owner_started_at": owner.started_at, "hub": "http://127.0.0.1:1",
        "secret": "PRIVATE-PAIRING-SECRET", "member": {
            "room_id": "room", "peer_id": "peer-b", "token": "PRIVATE-SERVER-TOKEN",
            "session_id": "server-session", "role": "b", "expires_at": time.time() + 3600,
        },
    })
    runtime.transport.close()
    runtime.transport = Mock()
    runtime.pairing = Mock()
    runtime.cipher = Mock()
    runtime.httpd = Mock()
    remote = Mock()
    remote.__enter__ = Mock(return_value=remote)
    remote.__exit__ = Mock(return_value=None)
    monkeypatch.setattr("coagen_client.runtime.httpx.Client", Mock(return_value=remote))
    yield runtime


def assert_stopped(runtime):
    runtime.httpd.shutdown.assert_called_once()
    runtime.pairing.close.assert_called_once()
    runtime.cipher.close.assert_called_once()
    assert runtime.stop_event.is_set()
    assert runtime.secret is None
    assert runtime.member["token"] == ""
    # 0.4.1 publishes stopped.json first; control.json is a best-effort bridge
    # for older readers and can be delayed or fail independently.
    assert runtime.status()['control_write_state'] == 'verified', runtime.status()
    control = (runtime.root / "stopped.json").read_text(encoding="utf-8")
    assert json.loads(control)["stopped"] is True
    assert "PRIVATE-PAIRING-SECRET" not in control
    assert "PRIVATE-SERVER-TOKEN" not in control


def test_locked_inbox_does_not_prevent_key_release_or_helper_shutdown(runtime, monkeypatch):
    monkeypatch.setattr(runtime.store, "clear_ephemeral", Mock(side_effect=PermissionError("locked file")))
    runtime.shutdown("owner_exited")
    assert_stopped(runtime)
    assert runtime.last_error == "cleanup_incomplete"


def test_failed_audit_does_not_prevent_shutdown(runtime, monkeypatch):
    monkeypatch.setattr(runtime.store, "audit", Mock(side_effect=OSError("disk unavailable")))
    runtime.shutdown("expired")
    assert_stopped(runtime)


def test_transport_close_failure_still_drops_other_keys(runtime):
    runtime.transport.close.side_effect = RuntimeError("transport failure")
    runtime.shutdown("stopped")
    assert_stopped(runtime)


def test_transient_cleanup_failure_is_retried_once(runtime, monkeypatch):
    original = runtime.store.clear_ephemeral
    calls = []

    def retry():
        calls.append(True)
        if len(calls) == 1:
            raise PermissionError("temporary file handle")
        original()

    monkeypatch.setattr(runtime.store, "clear_ephemeral", retry)
    runtime.shutdown("stopped")
    assert len(calls) == 2
    assert_stopped(runtime)
    assert runtime.last_error is None


def test_shutdown_does_not_wait_indefinitely_for_active_operation(runtime):
    entered, release = threading.Event(), threading.Event()

    def operation():
        with runtime.operation_lock:
            entered.set()
            release.wait(10)

    holder = threading.Thread(target=operation, daemon=True)
    holder.start()
    assert entered.wait(2)
    closing = threading.Thread(target=runtime.shutdown, args=("owner_exited",), daemon=True)
    try:
        closing.start()
        closing.join(4)
        assert not closing.is_alive(), "Shutdown waited for the blocked operation"
        assert_stopped(runtime)
        assert runtime.last_error == "cleanup_incomplete"
    finally:
        release.set()
        holder.join(2)
        closing.join(2)


def test_failed_control_write_still_stops_http_helper(runtime, monkeypatch):
    monkeypatch.setattr("coagen_client.runtime.atomic_private_json", Mock(side_effect=OSError("disk full")))
    runtime.shutdown("expired")
    runtime.httpd.shutdown.assert_called_once()
    runtime.cipher.close.assert_called_once()
    assert runtime.member["token"] == ""


def test_optional_legacy_control_failure_does_not_invalidate_terminal_record(runtime, monkeypatch):
    monkeypatch.setattr('coagen_client.runtime.atomic_private_json',
                        Mock(side_effect=PermissionError('test-only compatibility failure')))
    runtime.shutdown('owner_exited')
    assert not (runtime.root / 'control.json').exists()
    assert_stopped(runtime)
    assert runtime.status()['compatibility_control_write_state'] == 'failed'
    assert runtime.status()['cleanup_state'] == 'complete'
    assert runtime.last_error is None
    from coagen_client.cli import call_local
    assert call_local(runtime.root, {'op': 'status'})['phase'] == 'owner_exited'


def test_hung_cleanup_cannot_keep_owner_bound_helper_alive(runtime, monkeypatch):
    release, finished = threading.Event(), threading.Event()

    def blocked_cleanup():
        release.wait(8)
        finished.set()

    monkeypatch.setattr(runtime.store, "clear_ephemeral", blocked_cleanup)
    started = time.monotonic()
    try:
        runtime.shutdown("owner_exited")
        assert time.monotonic() - started < 4
        assert_stopped(runtime)
        assert runtime.last_error == "cleanup_incomplete"
    finally:
        release.set()
        assert finished.wait(2)


@pytest.mark.skipif(os.name != 'nt', reason='Windows file sharing regression')
def test_terminal_control_retries_a_real_read_handle_and_verifies_result(runtime, monkeypatch):
    control = runtime.root / 'control.json'
    atomic_private_json(control, {'url': 'http://127.0.0.1:1/rpc', 'token': 'PRIVATE-LOCAL-TOKEN'})
    reader = control.open('rb')
    attempted, released = threading.Event(), threading.Event()
    failures = []

    def write(path, value):
        try:
            return atomic_private_json(path, value)
        except OSError as error:
            failures.append(error.winerror)
            attempted.set()
            assert released.wait(2)
            raise

    def release_reader():
        if attempted.wait(2):
            reader.close()
            released.set()

    releaser = threading.Thread(target=release_reader)
    monkeypatch.setattr('coagen_client.runtime.atomic_private_json', write)
    releaser.start()
    try:
        runtime.shutdown('expired')
    finally:
        reader.close()
        releaser.join(3)
    assert failures == [32]
    assert_stopped(runtime)
    assert runtime.status()['control_write_state'] == 'verified'
    assert runtime.status()['compatibility_control_write_state'] == 'verified'
    assert json.loads(control.read_text(encoding='utf-8'))['status']['control_write_state'] == 'recorded'
    assert runtime.last_error is None


@pytest.mark.skipif(os.name != 'nt', reason='Windows file sharing regression')
def test_permanent_control_reader_is_bounded_and_not_reported_as_written(runtime, monkeypatch):
    control = runtime.root / 'control.json'
    original = {'url': 'http://127.0.0.1:1/rpc', 'token': 'PRIVATE-LOCAL-TOKEN'}
    atomic_private_json(control, original)
    attempts = []
    def write(path, value):
        attempts.append(True)
        return atomic_private_json(path, value)
    monkeypatch.setattr('coagen_client.runtime.atomic_private_json', write)
    started = time.monotonic()
    with control.open('rb'):
        runtime.shutdown('expired')
    assert time.monotonic() - started < 4
    assert len(attempts) == 3
    assert json.loads(control.read_text(encoding='utf-8')) == original
    assert runtime.status()['control_write_state'] == 'verified'
    assert runtime.status()['compatibility_control_write_state'] == 'failed'
    assert runtime.status()['cleanup_state'] == 'complete'
    assert runtime.last_error is None
    assert runtime.status()['last_operation_error']['code'] == 'LOCAL_STORAGE_FAILED'
    from coagen_client.cli import call_local
    assert call_local(runtime.root, {'op': 'status'})['phase'] == 'expired'
    assert runtime.member['token'] == '' and runtime.secret is None
    runtime.httpd.shutdown.assert_called_once()


@pytest.mark.parametrize('mode', ['noop', 'corrupt', 'permission'])
def test_terminal_control_does_not_trust_a_write_without_readback(runtime, monkeypatch, mode):
    control = runtime.root / 'control.json'
    atomic_private_json(control, {'stopped': False})
    calls = []
    def write(path, value, **kwargs):
        calls.append(True)
        if mode == 'permission':
            raise PermissionError('PRIVATE-OS-ERROR')
        if mode == 'corrupt':
            Path(path).write_text('{"stopped":false}', encoding='utf-8')
    monkeypatch.setattr('coagen_client.runtime.publish_private_json', write)
    runtime.shutdown('expired')
    assert len(calls) == 1
    status = runtime.status()
    assert status['control_write_state'] == 'failed'
    assert status['last_operation_error']['code'] == 'LOCAL_STORAGE_FAILED'
    assert 'PRIVATE-OS-ERROR' not in str(status)
    assert json.loads(control.read_text(encoding='utf-8'))['stopped'] is False
    runtime.httpd.shutdown.assert_called_once()


def test_terminal_snapshot_does_not_query_the_delivery_database(runtime, monkeypatch):
    monkeypatch.setattr(runtime.store, 'pending', Mock(side_effect=OSError('PRIVATE-DB-ERROR')))
    runtime.shutdown('expired')
    assert_stopped(runtime)
    assert runtime.status()['local_inbox_count'] == 0
    assert runtime.status()['cleanup_state'] == 'complete'


def test_terminal_snapshot_does_not_wait_for_a_diagnostic_writer(runtime):
    entered, release = threading.Event(), threading.Event()
    def writer():
        with runtime.diagnostics._lock:
            entered.set()
            release.wait(8)
    holder = threading.Thread(target=writer)
    holder.start()
    assert entered.wait(2)
    try:
        started = time.monotonic()
        runtime.shutdown('expired')
        assert time.monotonic() - started < 4
        assert_stopped(runtime)
        assert runtime.status()['diagnostic_snapshot_incomplete'] is True
        assert runtime.status()['diagnostic_write_failed'] is True
    finally:
        release.set()
        holder.join(2)


def test_hung_terminal_writer_reports_unconfirmed_and_still_exits(runtime, monkeypatch):
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    def blocked_write(path, value, **kwargs):
        entered.set()
        release.wait(8)
        try:
            return atomic_private_json(path, value)
        finally:
            finished.set()
    monkeypatch.setattr('coagen_client.runtime.publish_private_json', blocked_write)
    try:
        started = time.monotonic()
        runtime.shutdown('owner_exited')
        assert entered.is_set()
        assert time.monotonic() - started < 4
        assert runtime.status()['control_write_state'] == 'unconfirmed'
        assert not (runtime.root / 'control.json').exists()
        assert runtime.member['token'] == '' and runtime.secret is None
        runtime.httpd.shutdown.assert_called_once()
    finally:
        release.set()
        assert finished.wait(2)


def test_failed_control_write_does_not_wait_for_blocked_diagnostic_persistence(runtime, monkeypatch):
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    def blocked_record(*args, **kwargs):
        entered.set()
        release.wait(8)
        finished.set()
    monkeypatch.setattr(runtime.diagnostics, 'record', blocked_record)
    monkeypatch.setattr('coagen_client.runtime.publish_private_json', Mock(side_effect=OSError('PRIVATE-OS-ERROR')))
    try:
        started = time.monotonic()
        runtime.shutdown('expired')
        assert entered.is_set()
        assert time.monotonic() - started < 4
        status = runtime.status()
        assert status['control_write_state'] == 'failed'
        assert status['last_operation_error']['code'] == 'LOCAL_STORAGE_FAILED'
        assert 'PRIVATE-OS-ERROR' not in str(status)
        runtime.httpd.shutdown.assert_called_once()
    finally:
        release.set()
        assert finished.wait(2)
