"""State cleanup must never traverse Windows junctions or linked database files."""
import os
from pathlib import Path
import sqlite3
import stat
from types import SimpleNamespace

import pytest

from coagen_client.store import Store, atomic_private_json, remove_owned_tree, secure_directory


def junction(target, link):
    if os.name != 'nt':
        pytest.skip('Windows junction regression')
    import _winapi
    _winapi.CreateJunction(str(target), str(link))
    # Path.is_junction() is only available from Python 3.12. Validate the
    # actual mount-point reparse tag on every supported Windows Python.
    assert link.lstat().st_reparse_tag == stat.IO_REPARSE_TAG_MOUNT_POINT
    assert not link.is_symlink()


def test_constructor_rejects_outbox_junction_before_database_write(tmp_path):
    root = tmp_path / 'state'; root.mkdir()
    outside = tmp_path / 'outside'; outside.mkdir()
    sentinel = outside / 'keep.png'; sentinel.write_bytes(b'preserve this')
    junction(outside, root / 'outbox')
    with pytest.raises(ValueError, match='link|reparse'):
        Store(root)
    assert sentinel.read_bytes() == b'preserve this'
    assert not (root / 'delivery.sqlite3').exists()


def test_cleanup_revalidates_outbox_junction_and_preserves_external_png(tmp_path):
    root = tmp_path / 'state'; store = Store(root)
    outside = tmp_path / 'outside'; outside.mkdir()
    sentinel = outside / 'keep.png'; sentinel.write_bytes(b'preserve this')
    (root / 'outbox').rmdir()
    junction(outside, root / 'outbox')
    with pytest.raises(ValueError, match='link|reparse'):
        store.clear_ephemeral()
    assert sentinel.read_bytes() == b'preserve this'


def test_secure_directory_rejects_junction_ancestor_before_creating_child(tmp_path):
    outside = tmp_path / 'outside'; outside.mkdir()
    link = tmp_path / 'linked-parent'
    junction(outside, link)
    with pytest.raises(ValueError, match='link|reparse'):
        secure_directory(link / 'new-state')
    assert not (outside / 'new-state').exists()


def test_secure_directory_rejects_junction_before_changing_target_acl(tmp_path, monkeypatch):
    outside = tmp_path / 'outside'; outside.mkdir()
    link = tmp_path / 'linked-state'
    junction(outside, link)
    calls = []
    def pretend_acl(*args, **kwargs):
        calls.append(args)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr('coagen_client.store.subprocess.run', pretend_acl)
    with pytest.raises(ValueError, match='link|reparse'):
        secure_directory(link)
    assert calls == []


def test_remove_owned_tree_rejects_nested_junction_without_deleting_owned_files(tmp_path):
    owned = tmp_path / 'inbox'; owned.mkdir()
    message = owned / 'message'; message.mkdir()
    own = message / 'README.md'; own.write_text('owned')
    outside = tmp_path / 'outside'; outside.mkdir()
    external = outside / 'keep.txt'; external.write_text('external')
    junction(outside, message / 'linked-folder')
    with pytest.raises(ValueError, match='link|reparse'):
        remove_owned_tree(owned, message)
    assert own.read_text() == 'owned'
    assert external.read_text() == 'external'


def test_linked_database_cannot_modify_external_database(tmp_path):
    root = tmp_path / 'state'; root.mkdir()
    outside = tmp_path / 'external.sqlite3'
    with sqlite3.connect(outside) as connection:
        connection.execute('CREATE TABLE preserve(value INTEGER)')
    connection.close()
    os.link(outside, root / 'delivery.sqlite3')
    with pytest.raises(ValueError, match='link'):
        Store(root)
    with sqlite3.connect(outside) as connection:
        names = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    connection.close()
    assert names == {'preserve'}


def test_database_connection_revalidates_replaced_link(tmp_path):
    root = tmp_path / 'state'; store = Store(root)
    saved = root / 'original.sqlite3'
    store.path.rename(saved)
    outside = tmp_path / 'external.sqlite3'; outside.write_bytes(saved.read_bytes())
    os.link(outside, store.path)
    before = outside.read_bytes()
    with pytest.raises(ValueError, match='link'):
        store.audit('must-not-write')
    assert outside.read_bytes() == before


def test_linked_sidecar_file_is_refused_before_sqlite_opens(tmp_path):
    root = tmp_path / 'state'; root.mkdir()
    outside = tmp_path / 'external-wal'; outside.write_bytes(b'outside sentinel')
    os.link(outside, root / 'delivery.sqlite3-wal')
    with pytest.raises(ValueError, match='link'):
        Store(root)
    assert outside.read_bytes() == b'outside sentinel'


def test_atomic_json_rejects_linked_ancestor_before_writing(tmp_path):
    outside = tmp_path / 'outside'; outside.mkdir()
    link = tmp_path / 'linked'
    junction(outside, link)
    with pytest.raises(ValueError, match='link|reparse'):
        atomic_private_json(link / 'control.json', {'secret': 'test'})
    assert list(outside.iterdir()) == []


@pytest.mark.skipif(os.name != 'nt', reason='Windows replacement error classification')
def test_access_denied_without_sharing_evidence_is_not_classified_as_transient(tmp_path, monkeypatch):
    from coagen_client import store
    path = tmp_path / 'control.json'
    denied = PermissionError('PRIVATE-OS-ERROR')
    denied.winerror = 5
    def reject(*args):
        raise denied
    monkeypatch.setattr(store.os, 'replace', reject)
    monkeypatch.setattr(store, '_windows_file_handle', reject)
    with pytest.raises(PermissionError) as caught:
        atomic_private_json(path, {'stopped': True})
    assert caught.value is denied
    assert not isinstance(caught.value, store.FileSharingViolation)


def test_terminal_publication_cannot_replace_an_existing_record(tmp_path):
    from coagen_client.store import publish_private_json
    path = tmp_path / 'stopped.json'
    parent = tmp_path.stat()
    identity = (parent.st_dev, parent.st_ino)
    publish_private_json(path, {'stopped': True}, parent_identity=identity)
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        publish_private_json(path, {'stopped': False}, parent_identity=identity)
    assert path.read_bytes() == before


def test_terminal_publication_rejects_a_replaced_state_directory(tmp_path):
    from coagen_client.store import publish_private_json
    root = tmp_path / 'state'; root.mkdir()
    parent = root.stat()
    identity = (parent.st_dev, parent.st_ino)
    root.rename(tmp_path / 'old-state')
    root.mkdir()
    with pytest.raises(ValueError, match='directory changed'):
        publish_private_json(root / 'stopped.json', {'stopped': True}, parent_identity=identity)
    assert list(root.iterdir()) == []


def test_terminal_publication_rejects_a_junction_parent(tmp_path):
    from coagen_client.store import publish_private_json
    outside = tmp_path / 'outside'; outside.mkdir()
    link = tmp_path / 'state'
    junction(outside, link)
    parent = outside.stat()
    with pytest.raises(ValueError, match='link|reparse'):
        publish_private_json(link / 'stopped.json', {'stopped': True},
                             parent_identity=(parent.st_dev, parent.st_ino))
    assert list(outside.iterdir()) == []


def _root_owned_system_link():
    """An existing root-owned alias such as macOS /var or merged-/usr Linux /bin."""
    for name in ('/var', '/tmp', '/etc', '/home', '/bin', '/lib', '/sbin'):
        path = Path(name)
        try:
            info, parent = path.lstat(), path.parent.stat()
        except OSError:
            continue
        if stat.S_ISLNK(info.st_mode) and info.st_uid == 0 and parent.st_uid == 0 and \
                not parent.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            return path
    return None


@pytest.mark.skipif(os.name == 'nt', reason='POSIX system alias policy')
def test_root_owned_system_alias_above_state_is_accepted():
    from coagen_client.store import _unlinked_path
    alias = _root_owned_system_link()
    if alias is None:
        pytest.skip('This system has no root-owned top-level symlink to exercise')
    # The path below need not exist; only the trusted alias is traversed.
    candidate = alias / 'coagen-nonexistent-child' / 'state'
    assert _unlinked_path(candidate) == candidate


@pytest.mark.skipif(os.name == 'nt', reason='POSIX system alias policy')
def test_state_in_platform_temp_dir_works_without_resolving(tmp_path_factory):
    # macOS temp directories live below the root-owned /var -> /private/var alias.
    import tempfile
    base = Path(tempfile.mkdtemp(prefix='coagen-alias-'))
    try:
        store = Store(base / 'state')
        store.clear_ephemeral()
        atomic_private_json(base / 'state' / 'probe.json', {'ok': True})
        assert (base / 'state' / 'probe.json').is_file()
    finally:
        import shutil
        shutil.rmtree(base)


@pytest.mark.skipif(os.name == 'nt', reason='POSIX symlink regression')
def test_user_created_symlink_ancestor_is_still_rejected(tmp_path):
    outside = tmp_path / 'outside'; outside.mkdir()
    link = tmp_path / 'user-link'
    link.symlink_to(outside, target_is_directory=True)
    assert link.lstat().st_uid == os.getuid()
    with pytest.raises(ValueError, match='link|reparse'):
        secure_directory(link / 'state')
    with pytest.raises(ValueError, match='link|reparse'):
        Store(link / 'state')
    assert list(outside.iterdir()) == []
