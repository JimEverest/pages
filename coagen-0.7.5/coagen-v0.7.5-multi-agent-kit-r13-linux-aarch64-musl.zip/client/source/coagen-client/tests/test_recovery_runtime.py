"""Offline regression tests for constrained, durable Coagen recovery."""
import os
import time
from pathlib import Path
from unittest.mock import Mock

import httpx
import pytest

from coagen_client.lifecycle import Owner
from coagen_client.runtime import SessionRuntime
from coagen_client.store import Store


class Cipher:
    session_id = 'offline-crypto-session'

    def __init__(self):
        self.calls = 0

    def encrypt(self, value, **kwargs):
        self.calls += 1
        return b'OFFLINE-CIPHER-' + value

    def close(self):
        pass


class Hub:
    def __init__(self):
        self.uploads = []
        self.fail_upload = False
        self.polls = 0
        self.fail_poll = False

    def send_packet(self, metadata, png):
        self.uploads.append((dict(metadata), bytes(png)))
        if self.fail_upload:
            raise httpx.ReadTimeout('PRIVATE-TOKEN-AND-URL')
        return {'ok': True}

    def exchange(self, op, **kwargs):
        if op == 'poll':
            self.polls += 1
            if self.fail_poll:
                raise httpx.ReadTimeout('PRIVATE-TOKEN-AND-URL')
            return {'messages': []}
        return {}

    def close(self):
        pass


@pytest.fixture
def runtime(tmp_path):
    owner = Owner.capture(os.getpid())
    instance = SessionRuntime({
        'state_dir': str(tmp_path), 'owner_pid': owner.pid,
        'owner_started_at': owner.started_at, 'hub': 'http://127.0.0.1:1',
        'secret': 'OFFLINE-ONLY', 'member': {
            'room_id': 'offline-room', 'peer_id': 'offline-a', 'role': 'a',
            'token': 'OFFLINE-ONLY', 'session_id': 'offline-session',
            'expires_at': time.time() + 300,
        },
    })
    instance.transport.close()
    instance.transport = Hub()
    instance.cipher = Cipher()
    instance.phase, instance.other = 'ready', 'offline-b'
    yield instance
    instance.transport.close()
    instance.cipher.close()


def fail(runtime, args, code):
    with pytest.raises(Exception) as caught:
        runtime.dispatch(args)
    assert getattr(caught.value, 'code', None) == code
    assert 'PRIVATE-TOKEN-AND-URL' not in str(caught.value)
    return caught.value


def allow_retry(runtime):
    """Advance only the backoff gate; do not alter attempt or incident deadlines."""
    with runtime.store.db() as db:
        db.execute('UPDATE outgoing SET next_attempt_at=0')
        db.execute('UPDATE recovery SET next_attempt_at=0')


def test_pending_send_blocks_new_ids_and_retry_budget_survives_store_reopen(runtime, monkeypatch):
    runtime.transport.fail_upload = True
    original = {'op': 'send', 'request_id': 'task-1', 'text': 'one task'}
    error = fail(runtime, original, 'SEND_OUTCOME_UNKNOWN')
    assert error.to_dict()['outcome'] == 'unknown'
    fail(runtime, {'op': 'send', 'request_id': 'task-2', 'text': 'one task'}, 'PENDING_SEND')
    assert len(runtime.transport.uploads) == 1
    runtime.store = Store(runtime.root)
    allow_retry(runtime)
    fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'SEND_OUTCOME_UNKNOWN')
    runtime.store = Store(runtime.root)
    # A spent incident waits for its cooldown instead of locking the request forever.
    cooling = fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'RETRY_NOT_DUE')
    assert cooling.to_dict()['details']['reason'] == 'incident_cooldown'
    fail(runtime, original, 'RETRY_NOT_DUE')
    assert len(runtime.transport.uploads) == 2
    later = cooling.to_dict()['retry']['new_incident_at'] + 0.1
    monkeypatch.setattr('coagen_client.store.time.time', lambda: later)
    runtime.transport.fail_upload = False
    assert runtime.dispatch({'op': 'retry_saved_packet', 'request_id': 'task-1'})['state'] == 'sent'
    assert len(runtime.transport.uploads) == 3
    assert runtime.transport.uploads[0] == runtime.transport.uploads[1] == runtime.transport.uploads[2]
    assert runtime.cipher.calls == 1


def test_saved_retry_uses_original_packet_even_when_attachment_has_changed(runtime, tmp_path):
    attachment = tmp_path / 'business.txt'
    attachment.write_text('first', encoding='utf-8')
    runtime.transport.fail_upload = True
    args = {'op': 'send', 'request_id': 'files-1', 'files': [str(attachment)]}
    fail(runtime, args, 'SEND_OUTCOME_UNKNOWN')
    attachment.write_text('changed', encoding='utf-8')
    fail(runtime, args, 'REQUEST_CONFLICT')
    runtime.transport.fail_upload = False
    allow_retry(runtime)
    result = runtime.dispatch({'op': 'retry_saved_packet', 'request_id': 'files-1'})
    assert result['state'] == 'sent'
    assert runtime.transport.uploads[0] == runtime.transport.uploads[1]
    assert runtime.cipher.calls == 1


def test_same_request_id_cannot_silently_accept_changed_text_after_success(runtime):
    args = {'op': 'send', 'request_id': 'task-1', 'text': 'first'}
    runtime.dispatch(args)
    duplicate = runtime.dispatch(args)
    assert duplicate['duplicate'] is True
    fail(runtime, {**args, 'text': 'different'}, 'REQUEST_CONFLICT')
    assert len(runtime.transport.uploads) == 1


def test_pending_retry_deadline_cannot_be_reset_by_repeated_tool_calls(runtime, monkeypatch):
    runtime.transport.fail_upload = True
    clock = [time.time()]
    monkeypatch.setattr('coagen_client.store.time.time', lambda: clock[0])
    fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'SEND_OUTCOME_UNKNOWN')
    clock[0] += 2
    fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'SEND_OUTCOME_UNKNOWN')
    opens = set()
    for _ in range(5):
        clock[0] += 0.5
        error = fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'RETRY_NOT_DUE')
        opens.add(error.to_dict()['retry']['new_incident_at'])
    # Repeated calls neither spend attempts nor push the next incident back.
    assert len(opens) == 1 and len(runtime.transport.uploads) == 2
    clock[0] = opens.pop() + 0.01
    fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'SEND_OUTCOME_UNKNOWN')
    assert len(runtime.transport.uploads) == 3


def test_confirmed_upload_then_local_commit_failure_reports_hub_accepted(runtime, monkeypatch):
    def fail_commit(_request_id):
        raise OSError('PRIVATE-TOKEN-AND-URL')
    monkeypatch.setattr(runtime.store, 'mark_sent', fail_commit)
    error = fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'LOCAL_STORAGE_FAILED')
    assert error.to_dict()['outcome'] == 'hub_accepted'
    assert len(runtime.transport.uploads) == 1
    assert runtime.status()['last_operation_error']['code'] == 'LOCAL_STORAGE_FAILED'


def test_crypto_failure_is_visible_and_never_uploads(runtime, monkeypatch):
    from coagen_client.crypto import CryptoError
    def fail_crypto(*args, **kwargs):
        raise CryptoError('PRIVATE-TOKEN-AND-URL')
    monkeypatch.setattr(runtime.cipher, 'encrypt', fail_crypto)
    error = fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'CRYPTO_FAILURE')
    assert error.to_dict()['stage'] == 'encrypt'
    assert runtime.transport.uploads == []
    assert runtime.status()['last_operation_error']['code'] == 'CRYPTO_FAILURE'


def test_receive_network_failure_has_persistent_bounded_retries(runtime, monkeypatch):
    runtime.transport.fail_poll = True
    for _ in range(3):
        allow_retry(runtime)
        fail(runtime, {'op': 'receive', 'wait': 0}, 'HUB_UNAVAILABLE')
        runtime.store = Store(runtime.root)
    cooling = fail(runtime, {'op': 'receive', 'wait': 0}, 'RETRY_NOT_DUE')
    assert runtime.transport.polls == 3
    retry = cooling.to_dict()['retry']
    assert 0 < retry['retry_after_seconds'] <= 10 and retry['incident'] == 1
    # The intranet failure: after the cooldown the same call works again.
    runtime.transport.fail_poll = False
    later = retry['new_incident_at'] + 0.1
    monkeypatch.setattr('coagen_client.store.time.time', lambda: later)
    assert runtime.dispatch({'op': 'receive', 'wait': 0}) == {'messages': []}
    assert runtime.transport.polls == 4
    with runtime.store.db() as db:
        assert db.execute('SELECT COUNT(*) FROM recovery').fetchone()[0] == 0


def test_retry_window_starts_at_first_failure_not_at_a_long_first_request(runtime, monkeypatch):
    clock = [1000.0]
    monkeypatch.setattr('coagen_client.store.time.time', lambda: clock[0])
    runtime.store.claim_recovery_attempt('receive:x', operation='receive')
    clock[0] += 25  # a 25 s read timeout used most of the old claim-based window
    from coagen_client.errors import CoagenError
    runtime.store.fail_recovery('receive:x', CoagenError('HUB_UNAVAILABLE', operation='receive', stage='receive_poll'),
                                retryable=True)
    clock[0] += 5.9  # the intranet agent retried 5.9 s after the failure
    retry = runtime.store.claim_recovery_attempt('receive:x', operation='receive')
    assert retry['attempts_used'] == 2 and retry['deadline'] == pytest.approx(1000 + 25 + 30)


def test_consecutive_incident_cooldowns_grow_and_stay_bounded():
    from coagen_client.store import incident_cooldown
    assert [incident_cooldown(n) for n in range(7)] == [5, 10, 20, 40, 60, 60, 60]


def test_connection_recovery_does_not_erase_operation_failure(runtime):
    runtime.transport.fail_upload = True
    fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'SEND_OUTCOME_UNKNOWN')
    runtime.diagnostics.resolve(channel='connection')
    assert runtime.status()['last_operation_error']['code'] == 'SEND_OUTCOME_UNKNOWN'


def test_pairing_pending_returns_a_specific_error_without_poll(runtime):
    runtime.phase = 'pairing'
    error = fail(runtime, {'op': 'receive', 'wait': 0}, 'PAIRING_PENDING')
    assert error.to_dict()['phase'] == 'pairing'
    assert runtime.transport.polls == 0


def test_worker_connection_failures_wait_for_cooldown_and_remain_visible(runtime, monkeypatch):
    runtime.phase = 'pairing'
    calls = []
    def unavailable(op, **kwargs):
        calls.append(op)
        raise httpx.ReadTimeout('PRIVATE-TOKEN-AND-URL')
    runtime.transport.exchange = unavailable
    def advance_backoff(_seconds):
        allow_retry(runtime)
        return False
    monkeypatch.setattr(runtime.stop_event, 'wait', advance_backoff)
    # Keep the test finite even against the old unbounded worker loop.
    monkeypatch.setattr(runtime, 'active', Mock(side_effect=[True] * 8 + [False]))
    monkeypatch.setattr(runtime, 'shutdown', Mock())
    monkeypatch.setattr('coagen_client.runtime.time.monotonic', Mock(side_effect=range(0, 10000, 31)))
    runtime.worker()
    # One incident allows three attempts; then the worker waits for the
    # cooldown instead of giving up on the connection.
    assert len(calls) == 3
    status = runtime.status()
    assert status['connection_recovery_blocked'] is False
    assert status['connection_error']['code'] == 'RETRY_NOT_DUE'
    assert status['connection']['state'] == 'degraded' and status['connection']['automatic_recovery'] is True
    assert 'PRIVATE-TOKEN-AND-URL' not in str(status)


def test_ready_heartbeat_recovers_only_at_normal_cadence_and_keeps_business_error(runtime, monkeypatch):
    from coagen_client.errors import CoagenError
    runtime.diagnostics.record(CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload'), key='business')
    clock = [100.0]
    calls = []
    def heartbeat(op, **kwargs):
        calls.append(clock[0])
        if len(calls) == 1:
            raise httpx.ReadTimeout('PRIVATE-TOKEN-AND-URL')
        return {'pending_count': 0}
    def advance(seconds):
        clock[0] += seconds
        return False
    runtime.transport.exchange = heartbeat
    monkeypatch.setattr(runtime, 'active', lambda: len(calls) < 2)
    monkeypatch.setattr(runtime.stop_event, 'wait', advance)
    monkeypatch.setattr(runtime, 'shutdown', Mock())
    monkeypatch.setattr('coagen_client.runtime.time.monotonic', lambda: clock[0])
    monkeypatch.setattr('coagen_client.store.time.time', lambda: clock[0])
    runtime.worker()
    assert len(calls) == 2 and calls[1] - calls[0] >= runtime.heartbeat_interval
    assert runtime.status()['connection_error'] is None
    assert runtime.status()['last_operation_error']['code'] == 'SEND_OUTCOME_UNKNOWN'
    assert runtime.connection_recovery_blocked is False


def test_cleanup_failure_has_safe_persistent_status(runtime, monkeypatch):
    runtime.httpd = Mock()
    monkeypatch.setattr(runtime.store, 'clear_ephemeral', Mock(side_effect=OSError('PRIVATE-TOKEN-AND-URL')))
    remote = Mock()
    remote.__enter__ = Mock(return_value=remote)
    remote.__exit__ = Mock(return_value=None)
    monkeypatch.setattr('coagen_client.runtime.httpx.Client', Mock(return_value=remote))
    runtime.shutdown('stopped')
    failure = runtime.status()['last_operation_error']
    assert failure['code'] == 'CLEANUP_INCOMPLETE'
    assert failure['stage'] == 'cleanup'
    assert 'PRIVATE-TOKEN-AND-URL' not in str(failure)


def test_terminal_receive_auth_failure_is_not_retried(runtime):
    from coagen_client.transport import HubError
    calls = []
    def rejected(op, **kwargs):
        calls.append(op)
        raise HubError(403)
    runtime.transport.exchange = rejected
    fail(runtime, {'op': 'receive', 'wait': 0}, 'AUTH_FAILED')
    # A rejection spends the incident at once; the next call waits for the cooldown.
    fail(runtime, {'op': 'receive', 'wait': 0}, 'RETRY_NOT_DUE')
    assert len(calls) == 1


def test_immediate_send_retry_is_rejected_without_spending_an_attempt(runtime):
    runtime.transport.fail_upload = True
    fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'SEND_OUTCOME_UNKNOWN')
    error = fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'RETRY_NOT_DUE')
    assert error.to_dict()['retry']['retry_after_seconds'] > 0
    assert error.to_dict()['retry']['attempts_used'] == 1
    assert len(runtime.transport.uploads) == 1


def test_poll_wait_is_capped_by_existing_recovery_deadline(runtime):
    runtime.transport.fail_poll = True
    fail(runtime, {'op': 'receive', 'wait': 0}, 'HUB_UNAVAILABLE')
    with runtime.store.db() as db:
        db.execute('UPDATE recovery SET started=?,next_attempt_at=0', (time.time() - 28,))
    waits = []
    def capture(op, **kwargs):
        waits.append(kwargs['wait_seconds'])
        return {'messages': []}
    runtime.transport.exchange = capture
    runtime.dispatch({'op': 'receive', 'wait': 20})
    assert waits and 0 <= waits[0] <= 2


def test_successful_other_request_duplicate_does_not_hide_failed_send(runtime):
    original = {'op': 'send', 'request_id': 'task-1', 'text': 'one'}
    runtime.dispatch(original)
    runtime.transport.fail_upload = True
    fail(runtime, {'op': 'send', 'request_id': 'task-2', 'text': 'two'}, 'SEND_OUTCOME_UNKNOWN')
    runtime.dispatch(original)
    assert runtime.status()['last_operation_error']['code'] == 'SEND_OUTCOME_UNKNOWN'


def test_definitive_upload_rejection_does_not_allow_another_network_attempt(runtime):
    from coagen_client.transport import HubError
    def rejected(metadata, png):
        runtime.transport.uploads.append((metadata, png))
        raise HubError(422)
    runtime.transport.send_packet = rejected
    fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'HUB_REJECTED')
    allow_retry(runtime)
    fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'RETRY_NOT_ALLOWED')
    assert len(runtime.transport.uploads) == 1


def test_transport_enforces_remaining_timeout_and_never_starts_after_deadline():
    from coagen_client.transport import Transport
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    seen = []
    def handler(request):
        seen.append(request.extensions['timeout'])
        return httpx.Response(200, json={'ok': True})
    transport.client = httpx.Client(transport=httpx.MockTransport(handler))
    try:
        with transport.operation_deadline(time.time() + 2):
            assert transport.request('/offline').json()['ok']
        assert all(0 < seconds <= 2 for seconds in seen[0].values())
        with transport.operation_deadline(time.time() - 1):
            with pytest.raises(ValueError) as error:
                transport.request('/offline')
            # The attempt's time budget ran out: a recoverable Hub timeout.
            assert error.value.code == 'HUB_UNAVAILABLE'
            assert error.value.cause['category'] == 'timeout'
        assert len(seen) == 1
    finally:
        transport.close()


@pytest.mark.parametrize(('header', 'expected'), [('5', 5), ('Infinity', None), ('SECRET-TOKEN', None)])
def test_transport_captures_only_safe_numeric_retry_after(header, expected):
    from coagen_client.transport import Transport, HubError
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    transport.client = httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(429, headers={'Retry-After': header}, text='PRIVATE-TOKEN-AND-URL')))
    try:
        with pytest.raises(HubError) as caught:
            transport.request('/offline')
        assert caught.value.retry_after == expected
        assert header not in str(caught.value) or header == '5'
        assert 'PRIVATE-TOKEN-AND-URL' not in str(caught.value)
    finally:
        transport.close()


def test_failed_recovery_bookkeeping_preserves_ambiguous_delivery_and_blocks_retry(runtime, monkeypatch):
    runtime.transport.fail_upload = True
    def broken(*args):
        raise OSError('PRIVATE-TOKEN-AND-URL')
    monkeypatch.setattr(runtime.store, 'defer_upload', broken)
    error = fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'SEND_OUTCOME_UNKNOWN')
    assert error.outcome == 'unknown'
    fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'task-1'}, 'RETRY_NOT_ALLOWED')
    assert len(runtime.transport.uploads) == 1
    assert any(item['code'] == 'LOCAL_STORAGE_FAILED' for item in runtime.status()['incidents'])


def test_crypto_failure_cannot_be_bypassed_with_a_new_request_id(runtime, monkeypatch):
    from coagen_client.crypto import CryptoError
    cipher = Mock(side_effect=CryptoError('PRIVATE-TOKEN-AND-URL'))
    monkeypatch.setattr(runtime.cipher, 'encrypt', cipher)
    fail(runtime, {'op': 'send', 'request_id': 'task-1', 'text': 'one'}, 'CRYPTO_FAILURE')
    fail(runtime, {'op': 'send', 'request_id': 'task-2', 'text': 'one'}, 'CRYPTO_FAILURE')
    assert cipher.call_count == 1
    assert runtime.transport.uploads == []


def test_successfully_consuming_another_message_does_not_hide_prior_failure(runtime, monkeypatch):
    def consume(message_id):
        runtime._stage('consume_remote', outcome='unknown')
        if message_id == 'a' * 32:
            raise httpx.ReadTimeout('PRIVATE-TOKEN-AND-URL')
        return {'state': 'consumed', 'message_id': message_id}
    monkeypatch.setattr(runtime, 'consume', consume)
    fail(runtime, {'op': 'consume', 'message_id': 'a' * 32}, 'HUB_UNAVAILABLE')
    runtime.dispatch({'op': 'consume', 'message_id': 'b' * 32})
    assert runtime.status()['last_operation_error']['code'] == 'HUB_UNAVAILABLE'
