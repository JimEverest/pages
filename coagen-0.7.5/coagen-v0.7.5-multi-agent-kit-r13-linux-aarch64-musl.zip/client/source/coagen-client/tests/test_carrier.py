import struct
import zlib

import pytest

from coagen_client.carrier import CarrierError, MAX_CIPHERTEXT_BYTES, pack_png, unpack_png


def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


@pytest.mark.parametrize("data", [bytes(16), bytes(range(256)), b"ciphertext" * 100000], ids=["tag", "binary", "large"])
def test_roundtrip_valid_png(data):
    packed = pack_png(data)
    assert packed.startswith(b"\x89PNG\r\n\x1a\n")
    assert packed.endswith(chunk(b"IEND", b""))
    assert unpack_png(packed) == data
    offset = packed.index(b"IDAT")
    length = struct.unpack(">I", packed[offset - 4:offset])[0]
    assert zlib.decompress(packed[offset + 4:offset + 4 + length]) == bytes(5)


def test_crc_corruption_and_every_truncation_rejected():
    packed = pack_png(b"ciphertext" * 2)
    for index in range(len(packed)):
        with pytest.raises(CarrierError):
            unpack_png(packed[:index])
    for index in [0, 12, 29, len(packed) - 18, len(packed) - 1]:
        damaged = bytearray(packed)
        damaged[index] ^= 1
        with pytest.raises(CarrierError):
            unpack_png(bytes(damaged))


def test_extra_duplicate_or_trailing_chunks_rejected():
    packed = pack_png(bytes(16))
    end = packed[-12:]
    for mutated in [packed + b"trailer", packed[:-12] + chunk(b"cgEn", b"anything") + end, packed[:-12] + chunk(b"tEXt", b"extra") + end, packed[:-12] + end + end]:
        with pytest.raises(CarrierError):
            unpack_png(mutated)


def test_invalid_size_limits_rejected_before_parsing():
    with pytest.raises(CarrierError):
        pack_png(b"x" * (MAX_CIPHERTEXT_BYTES + 1))
    with pytest.raises(CarrierError):
        unpack_png(b"x" * (MAX_CIPHERTEXT_BYTES + 1024))
    packed = pack_png(bytes(16))
    with pytest.raises(CarrierError):
        unpack_png(packed[:8] + b"\x7f\xff\xff\xff" + packed[12:])


def test_authenticated_ciphertext_minimum_size():
    with pytest.raises(CarrierError):
        pack_png(b"short")


def test_recomputed_crc_does_not_override_version_or_length_checks():
    packed = pack_png(bytes(16))
    offset = packed.index(b"cgEn") - 4
    length = struct.unpack(">I", packed[offset:offset + 4])[0]
    payload = packed[offset + 8:offset + 8 + length]
    for invalid in [b"BAD!" + payload[4:], payload[:4] + struct.pack(">I", 100) + payload[8:]]:
        with pytest.raises(CarrierError):
            unpack_png(packed[:offset] + chunk(b"cgEn", invalid) + packed[offset + length + 12:])
