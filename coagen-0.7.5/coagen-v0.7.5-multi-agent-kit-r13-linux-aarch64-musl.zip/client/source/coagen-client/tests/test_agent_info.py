"""Display metadata is negotiated independently from pairing and encryption."""
import os
import time
from contextlib import nullcontext
from unittest.mock import Mock

import pytest

from coagen_client import cli
from coagen_client.lifecycle import Owner
from coagen_client.runtime import SessionRuntime
from coagen_client.transport import HubError


INFO = {'name': '未来 Agent', 'version': 'v-next', 'client_version': cli.__version__}


def runtime(tmp_path, supported=None):
    owner = Owner.capture(os.getpid())
    member = dict(room_id='room', peer_id='a', role='a', token='test', session_id='session',
                  expires_at=time.time() + 300)
    if supported is not None:
        member['agent_info_supported'] = supported
    value = SessionRuntime(dict(state_dir=str(tmp_path), owner_pid=owner.pid,
        owner_started_at=owner.started_at, hub='http://127.0.0.1:1', secret='00700042',
        member=member, agent_info=INFO))
    value.transport.close()
    value.transport = Mock()
    value.transport.operation_deadline.side_effect = lambda _deadline: nullcontext()
    return value


@pytest.mark.parametrize('supported', [None, False, True, 'true'])
def test_heartbeat_sends_metadata_only_after_explicit_capability(tmp_path, supported):
    value = runtime(tmp_path, supported)
    value.phase = 'ready'
    value.transport.exchange.return_value = {'pending_count': 0}
    value.active = Mock(side_effect=[True, False])
    value.stop_event.wait = Mock()
    value.shutdown = Mock()
    value.worker()
    expected = {'agent_info': INFO} if supported is True else {}
    value.transport.exchange.assert_called_once_with('heartbeat', **expected)
    assert value.status()['agent_info'] == INFO


def test_later_authenticated_status_can_advertise_metadata_capability(tmp_path):
    value = runtime(tmp_path)
    value._update_room_deadline({'room_id': 'room', 'session_id': 'session',
                                'agent_info_supported': True})
    assert value.agent_info_supported is True


def test_capability_from_wrong_room_is_not_accepted(tmp_path):
    value = runtime(tmp_path)
    with pytest.raises(ValueError):
        value._update_room_deadline({'room_id': 'other', 'session_id': 'session',
                                    'agent_info_supported': True})
    assert value.agent_info_supported is False


@pytest.mark.parametrize('capability', ['missing', False])
def test_running_session_negotiates_once_after_hub_rollback_422(tmp_path, capability):
    value = runtime(tmp_path, True)
    probe = {'room_id': 'room', 'session_id': 'session'}
    if capability != 'missing':
        probe['agent_info_supported'] = capability
    value.transport.exchange.side_effect = [HubError(422), probe, {'pending_count': 0}]
    assert value._heartbeat() == {'pending_count': 0}
    assert [(call.args, call.kwargs) for call in value.transport.exchange.call_args_list] == [
        (('heartbeat',), {'agent_info': INFO}), (('status',), {}), (('heartbeat',), {})]
    assert value.agent_info_supported is False


@pytest.mark.parametrize('status', [401, 403, 404, 409, 429, 500])
def test_other_heartbeat_failures_never_trigger_metadata_downgrade(tmp_path, status):
    value = runtime(tmp_path, True)
    value.transport.exchange.side_effect = HubError(status)
    with pytest.raises(HubError) as caught:
        value._heartbeat()
    assert caught.value.status == status
    value.transport.exchange.assert_called_once_with('heartbeat', agent_info=INFO)
    assert value.agent_info_supported is True


@pytest.mark.parametrize('probe', [
    {'room_id': 'room', 'session_id': 'session', 'agent_info_supported': True},
    {'room_id': 'room', 'session_id': 'session', 'agent_info_supported': 'false'},
    {'room_id': 'room', 'session_id': 'session', 'agent_info_supported': None},
    {'room_id': 'different', 'session_id': 'session'},
    {'room_id': 'room', 'session_id': 'different'},
    {},
])
def test_status_must_bind_same_session_and_explicitly_allow_legacy_mode(tmp_path, probe):
    value = runtime(tmp_path, True)
    value.transport.exchange.side_effect = [HubError(422), probe]
    with pytest.raises((HubError, ValueError)):
        value._heartbeat()
    assert value.transport.exchange.call_count == 2
    assert value.agent_info_supported is True


def test_failed_recheck_is_reported_without_retry_or_downgrade(tmp_path):
    value = runtime(tmp_path, True)
    value.transport.exchange.side_effect = [HubError(422), HubError(503)]
    with pytest.raises(HubError) as caught:
        value._heartbeat()
    assert caught.value.status == 503
    assert value.transport.exchange.call_count == 2
    assert value.agent_info_supported is True


def test_legacy_retry_failure_is_not_recursively_negotiated(tmp_path):
    value = runtime(tmp_path, True)
    value.transport.exchange.side_effect = [HubError(422),
        {'room_id': 'room', 'session_id': 'session'}, HubError(422)]
    with pytest.raises(HubError) as caught:
        value._heartbeat()
    assert caught.value.status == 422
    assert value.transport.exchange.call_count == 3
    assert value.agent_info_supported is False


def test_already_legacy_heartbeat_422_never_attempts_probe(tmp_path):
    value = runtime(tmp_path, False)
    value.transport.exchange.side_effect = HubError(422)
    with pytest.raises(HubError):
        value._heartbeat()
    value.transport.exchange.assert_called_once_with('heartbeat')
