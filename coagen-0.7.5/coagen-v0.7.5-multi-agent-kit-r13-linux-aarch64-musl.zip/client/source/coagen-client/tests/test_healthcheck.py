import asyncio
from email import policy
from email.parser import BytesParser
import hashlib
import json
from pathlib import Path
import ssl
import socket
import subprocess
import threading
import time

import httpx
import pytest

from coagen_client import healthcheck


def test_current_creation_descriptor_uses_public_locator():
    value = dict(room_id='a'*32, session_id='b'*32, peer_id='c'*32, role='a',
                 token='X'*32, locator='007', expires_at=2000000000)
    assert healthcheck._member(value, 'a')['locator'] == '007'


def check(report, name):
    return next(item for item in report['checks'] if item['name'] == name)


def mock_client(monkeypatch, handler):
    original = httpx.AsyncClient
    options = []

    async def streamed_handler(request):
        response = handler(request)
        if hasattr(response, '__await__'):
            response = await response
        # Real sockets and ASGITransport stream their bodies. Responses built
        # with json=/content= in fault fixtures are otherwise already consumed.
        if response.is_stream_consumed:
            response = httpx.Response(response.status_code, headers=response.headers,
                                      stream=httpx.ByteStream(response.content))
        return response

    def make_client(**kwargs):
        options.append(kwargs.copy())
        return original(transport=httpx.MockTransport(streamed_handler), **kwargs)

    monkeypatch.setattr(healthcheck.httpx, 'AsyncClient', make_client)
    return options


def test_health_only_is_partial_without_claiming_write_or_read(monkeypatch):
    requests = []

    def handler(request):
        requests.append(request)
        return httpx.Response(200, json={'status': 'ok', 'service': 'coagen'})

    options = mock_client(monkeypatch, handler)
    report = healthcheck.check_hub('https://example.invalid/coagen')
    assert report['overall'] == 'partial'
    assert check(report, 'connect')['status'] == 'pass'
    for name in ('authenticate', 'write', 'read', 'cleanup'):
        assert check(report, name)['status'] == 'skipped'
        assert check(report, name)['error_category'] == 'not_tested'
    assert len(requests) == 1
    assert requests[0].url.path == '/coagen/health'
    assert requests[0].method == 'GET'
    assert 'authorization' not in requests[0].headers
    assert options[0]['verify'] is True
    assert options[0]['trust_env'] is True
    assert options[0]['follow_redirects'] is False


@pytest.mark.parametrize('hub', [
    'http://example.invalid', 'https://name:private-password@example.invalid',
    'https://example.invalid/?secret=private-password',
])
def test_unsafe_hub_is_rejected_without_echoing_it(monkeypatch, hub):
    mock_client(monkeypatch, lambda request: pytest.fail('must not make a request'))
    report = healthcheck.check_hub(hub, 'private-admin-token')
    assert report['overall'] == 'fail'
    assert check(report, 'connect')['error_category'] == 'invalid_configuration'
    assert 'private' not in json.dumps(report)


@pytest.mark.parametrize('status', [401, 403])
def test_authentication_failure_is_sanitized(monkeypatch, status):
    def handler(request):
        if request.url.path == '/health':
            return httpx.Response(200, json={'status': 'ok', 'service': 'coagen'})
        return httpx.Response(status, text='private-admin-token and private-server-body')

    mock_client(monkeypatch, handler)
    report = healthcheck.check_hub('https://example.invalid', 'private-admin-token')
    assert report['overall'] == 'fail'
    assert check(report, 'authenticate')['status'] == 'fail'
    assert check(report, 'authenticate')['http_status'] == status
    assert check(report, 'write')['status'] == 'skipped'
    assert 'private' not in json.dumps(report)


@pytest.mark.parametrize('tls', [False, True])
def test_network_failure_never_reflects_exception_details(monkeypatch, tls):
    def handler(request):
        error = httpx.ConnectError('private-token https://name:password@example.invalid', request=request)
        if tls:
            error.__cause__ = ssl.SSLCertVerificationError('private certificate details')
        raise error

    mock_client(monkeypatch, handler)
    report = healthcheck.check_hub('https://example.invalid', 'private-admin-token')
    assert check(report, 'connect')['error_category'] == ('tls_error' if tls else 'network_error')
    assert report['overall'] == 'fail'
    assert 'private' not in json.dumps(report)


@pytest.mark.parametrize('response,category', [
    (httpx.Response(200, content=b'x' * 65537), 'response_too_large'),
    (httpx.Response(200, json={'status': 'ok', 'service': 'something-else'}), 'unexpected_response'),
    (httpx.Response(302, headers={'Location': 'https://unrelated.invalid'}), 'http_error'),
    (httpx.Response(200, headers={'Content-Encoding': 'gzip'}, content=b''), 'unexpected_encoding'),
])
def test_invalid_health_responses_fail(monkeypatch, response, category):
    mock_client(monkeypatch, lambda request: response)
    report = healthcheck.check_hub('https://example.invalid')
    assert check(report, 'connect')['error_category'] == category
    assert report['overall'] == 'fail'


def test_global_budget_stops_trickling_health_body(monkeypatch):
    class SlowBody(httpx.AsyncByteStream):
        async def __aiter__(self):
            while True:
                await asyncio.sleep(0.02)
                yield b' '

    mock_client(monkeypatch, lambda request: httpx.Response(200, stream=SlowBody()))
    started = time.monotonic()
    report = healthcheck.check_hub('https://example.invalid', timeout=1, total_timeout=0.1)
    assert time.monotonic() - started < 0.5
    assert check(report, 'connect')['error_category'] in ('timeout', 'budget_exhausted')
    assert check(report, 'connect')['http_status'] == 200


def test_unadvertised_response_size_is_bounded_during_stream(monkeypatch):
    chunks = []

    class LargeBody(httpx.AsyncByteStream):
        async def __aiter__(self):
            for _ in range(100):
                chunks.append(1)
                yield b'x' * 16384

    mock_client(monkeypatch, lambda request: httpx.Response(200, stream=LargeBody()))
    report = healthcheck.check_hub('https://example.invalid')
    assert check(report, 'connect')['error_category'] == 'response_too_large'
    assert len(chunks) == 5


def test_blocked_os_dns_cannot_hold_probe_shutdown_past_budget(monkeypatch):
    release = threading.Event()
    entered = threading.Event()
    # This regression targets an uncancellable resolver, not Windows CA-store
    # cold-start time or a developer machine's proxy. Prepare trusted TLS before
    # starting the probe budget so the injected DNS operation is actually reached.
    context = ssl.create_default_context()
    original_client = httpx.AsyncClient
    monkeypatch.setattr(healthcheck.httpx, 'AsyncClient',
                        lambda **kwargs: original_client(**{**kwargs, 'verify': context, 'trust_env': False}))

    def blocked_resolver(*args, **kwargs):
        entered.set()
        release.wait(3)
        raise socket.gaierror('private DNS detail')

    monkeypatch.setattr(socket, 'getaddrinfo', blocked_resolver)
    started = time.monotonic()
    try:
        # A short but non-racy budget gives the resolver worker time to start on
        # slower Windows CI hosts while still exercising the bounded shutdown.
        report = healthcheck.check_hub('https://coagen-check.invalid', timeout=0.5, total_timeout=1.0)
        assert entered.is_set()
        assert time.monotonic() - started < 1.8
        assert check(report, 'connect')['error_category'] in ('timeout', 'budget_exhausted')
        assert 'private' not in json.dumps(report)
    finally:
        release.set()


@pytest.fixture
def real_hub(monkeypatch, tmp_path):
    pytest.importorskip('fastapi')
    server_path = Path(__file__).resolve().parents[3] / 'apps' / 'coagen'
    monkeypatch.syspath_prepend(str(server_path))
    from app.server import create_app

    app = create_app(tmp_path / 'server', 'private-admin-token', disk_reserve_bytes=0,
                     max_packet_bytes=1024, max_room_bytes=4096, max_total_bytes=8192)
    upstream = httpx.ASGITransport(app=app)
    calls = []
    faults = {}

    async def handler(request):
        body = await request.aread()
        operation = None
        if request.url.path == '/api/exchange':
            operation = json.loads(body)['op']
        calls.append((request.method, request.url.path, operation))
        fault = faults.get(operation or request.url.path)
        if fault:
            result = fault(request)
            return await result if hasattr(result, '__await__') else result
        return await upstream.handle_async_request(request)

    mock_client(monkeypatch, handler)
    return app, calls, faults


@pytest.fixture
def budget_hub(monkeypatch):
    # Deadline tests must reach the injected network stall. ASGITransport runs
    # the real Hub's synchronous SQLite/fsync work on the client's event loop,
    # where asyncio cancellation cannot interrupt it. Use protocol-valid,
    # in-memory responses here; full_check above/below retains the real Hub.
    a = dict(room_id='a' * 32, session_id='b' * 32, peer_id='c' * 32,
             role='a', token='A' * 32, locator='007', expires_at=time.time() + 60)
    b = dict(a, peer_id='d' * 32, role='b', token='B' * 32)
    calls, faults, packet = [], {}, {}

    async def handler(request):
        body = await request.aread()
        path = request.url.path
        data = json.loads(body) if path == '/api/exchange' else None
        operation = data['op'] if data is not None else None
        calls.append((request.method, path, operation))
        fault = faults.get(operation or path)
        if fault:
            return await fault(request)
        if path == '/health':
            return httpx.Response(200, json={'status': 'ok', 'service': 'coagen'})
        if path == '/api/rooms':
            return httpx.Response(200, json=a)
        if path == '/api/join':
            return httpx.Response(200, json=b)
        if path == '/api/packets':
            message = BytesParser(policy=policy.default).parsebytes(
                b'Content-Type: ' + request.headers['content-type'].encode('ascii')
                + b'\r\nMIME-Version: 1.0\r\n\r\n' + body)
            fields = {part.get_param('name', header='content-disposition'):
                      part.get_payload(decode=True) for part in message.iter_parts()}
            packet['png'] = fields['file[]']
            descriptor = dict(json.loads(fields['ext']), sender_id=a['peer_id'],
                              size=len(packet['png']), consumed=False,
                              sha256=hashlib.sha256(packet['png']).hexdigest())
            return httpx.Response(200, json=descriptor)
        if path == '/api/packets/read':
            return httpx.Response(200, content=packet['png'])
        if path == '/api/exchange':
            value = ({'closed': True} if operation == 'close' else
                     {dict(ack='acked', consume='consumed')[operation]: data['message_ids']})
            return httpx.Response(200, json=value)
        raise AssertionError('Unexpected healthcheck request')

    mock_client(monkeypatch, handler)
    return calls, faults


def test_full_check_uses_one_small_encrypted_packet_and_removes_it(real_hub, monkeypatch, tmp_path):
    app, calls, _ = real_hub
    work = tmp_path / 'empty-client-directory'
    work.mkdir()
    monkeypatch.chdir(work)
    monkeypatch.setattr(subprocess, 'Popen', lambda *a, **kw: pytest.fail('healthcheck started a process'))
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert report['overall'] == 'pass', report
    assert all(item['status'] == 'pass' for item in report['checks'])
    assert report['temporary_resources'] == {
        'room_created': True, 'packet_created': True,
        'cleanup_confirmed': True, 'ttl_seconds': 60,
    }
    assert 48 <= check(report, 'write')['bytes'] <= 1024
    assert check(report, 'read')['bytes'] == check(report, 'write')['bytes']
    assert calls.count(('POST', '/api/packets', None)) == 1
    assert [op for _, _, op in calls if op] == ['ack', 'consume', 'close']
    with app.state.store.db() as db:
        packets = db.execute('SELECT * FROM packets').fetchall()
        room = db.execute('SELECT * FROM rooms').fetchone()
    assert len(packets) == 1
    assert packets[0]['size'] <= 1024
    assert packets[0]['object_name'] is None
    assert packets[0]['consumed_at'] is not None
    assert room['closed_at'] is not None
    assert room['expires_at'] - room['created_at'] == 60
    assert list(work.iterdir()) == []
    encoded = json.dumps(report)
    assert 'private' not in encoded
    assert room['room_id'] not in encoded


@pytest.mark.parametrize('fault,category', [
    (lambda request: httpx.Response(200, content=b'not-the-encrypted-png'), 'integrity_error'),
    (lambda request: httpx.Response(200, content=b'x' * 1025), 'response_too_large'),
])
def test_read_failure_still_closes_room(real_hub, fault, category):
    app, calls, faults = real_hub
    faults['/api/packets/read'] = fault
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert report['overall'] == 'fail'
    assert check(report, 'read')['error_category'] == category
    assert check(report, 'cleanup')['status'] == 'pass'
    assert ('POST', '/api/exchange', 'close') in calls
    with app.state.store.db() as db:
        assert db.execute('SELECT object_name FROM packets').fetchone()[0] is None


@pytest.mark.parametrize('operation', ['consume', 'close'])
def test_cleanup_failure_is_not_reported_as_success(real_hub, operation):
    _, calls, faults = real_hub
    faults[operation] = lambda request: httpx.Response(200, json={'private-body': 'private-token'})
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert report['overall'] == 'fail'
    assert check(report, 'cleanup')['status'] == 'fail'
    assert report['temporary_resources']['cleanup_confirmed'] is False
    assert ('POST', '/api/exchange', 'close') in calls
    assert 'private' not in json.dumps(report)


def test_cleanup_preserves_failed_http_status_when_close_succeeds(real_hub):
    _, calls, faults = real_hub
    faults['consume'] = lambda request: httpx.Response(503, text='private failure')
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert check(report, 'cleanup')['status'] == 'fail'
    assert check(report, 'cleanup')['http_status'] == 503
    assert ('POST', '/api/exchange', 'close') in calls


def test_forbidden_write_closes_created_room(real_hub):
    _, calls, faults = real_hub
    faults['/api/packets'] = lambda request: httpx.Response(403, text='private-token')
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert check(report, 'write')['http_status'] == 403
    assert check(report, 'read')['status'] == 'skipped'
    assert check(report, 'cleanup')['status'] == 'pass'
    assert ('POST', '/api/exchange', 'close') in calls


def test_join_failure_still_closes_created_room(real_hub):
    _, calls, faults = real_hub
    faults['/api/join'] = lambda request: httpx.Response(403, text='private-token')
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert check(report, 'authenticate')['http_status'] == 403
    assert check(report, 'write')['status'] == 'skipped'
    assert check(report, 'cleanup')['status'] == 'pass'
    assert ('POST', '/api/exchange', 'close') in calls


def test_join_network_failure_does_not_reuse_create_http_status(real_hub):
    _, _, faults = real_hub

    def failed_join(request):
        raise httpx.ConnectError('private-token', request=request)

    faults['/api/join'] = failed_join
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert check(report, 'authenticate')['error_category'] == 'network_error'
    assert check(report, 'authenticate')['http_status'] is None
    assert check(report, 'cleanup')['status'] == 'pass'


def test_malformed_created_room_retains_minimum_cleanup_credentials(real_hub):
    app, calls, faults = real_hub

    async def malformed_create(request):
        response = await httpx.ASGITransport(app=app).handle_async_request(request)
        data = json.loads(await response.aread())
        del data['session_id']
        return httpx.Response(200, json=data)

    faults['/api/rooms'] = malformed_create
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token')
    assert check(report, 'authenticate')['error_category'] == 'unexpected_response'
    assert check(report, 'cleanup')['status'] == 'pass'
    assert ('POST', '/api/exchange', 'close') in calls


def test_slow_ack_cannot_consume_all_room_close_budget(budget_hub):
    calls, faults = budget_hub
    entered = []

    async def blocked_ack(request):
        entered.append(True)
        await asyncio.sleep(5)
        return httpx.Response(200, json={'acked': []})

    faults['ack'] = blocked_ack
    started = time.monotonic()
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token', timeout=1, total_timeout=1.5)
    assert time.monotonic() - started < 2
    assert all(check(report, name)['status'] == 'pass' for name in ('connect', 'authenticate', 'write', 'read')), report
    assert entered == [True], report
    assert check(report, 'cleanup')['status'] == 'fail'
    assert check(report, 'cleanup')['error_category'] == 'timeout'
    assert ('POST', '/api/exchange', 'close') in calls


def test_slow_read_reserves_time_for_room_cleanup(budget_hub):
    calls, faults = budget_hub
    entered = []

    async def blocked_read(request):
        entered.append(True)
        await asyncio.sleep(5)
        return httpx.Response(200, content=b'late')

    faults['/api/packets/read'] = blocked_read
    started = time.monotonic()
    report = healthcheck.check_hub('http://127.0.0.1', 'private-admin-token', timeout=1, total_timeout=1)
    assert time.monotonic() - started < 1.5
    assert all(check(report, name)['status'] == 'pass' for name in ('connect', 'authenticate', 'write')), report
    assert entered == [True], report
    assert check(report, 'read')['error_category'] in ('timeout', 'budget_exhausted')
    assert check(report, 'cleanup')['status'] == 'pass'
    assert ('POST', '/api/exchange', 'close') in calls
