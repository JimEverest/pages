"""The human workflow shares eight digits, never an invitation file."""
import json
import io
import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import venv

import pytest

from coagen_client import cli


@pytest.fixture
def relay(monkeypatch):
    calls, launched = [], []
    member = dict(room_id='a'*32, session_id='b'*32, peer_id='c'*32,
                  role='a', token='MEMBER-TOKEN', locator='007', expires_at=2000000000,
                  lease_seconds=180)
    class FakeTransport:
        def __init__(self, *args): pass
        def request(self, path, **kwargs):
            calls.append((path, kwargs))
            return SimpleNamespace(json=lambda: dict(member))
        def close(self): pass
    monkeypatch.setattr(cli, 'Transport', FakeTransport)
    monkeypatch.setattr(cli, 'launch_session', lambda config: launched.append(config) or {'phase':'starting'})
    monkeypatch.setattr(cli.secrets, 'randbelow', lambda bound: 42)
    return calls, launched


def test_create_shows_eight_digits_without_invitation_file(tmp_path, relay, capsys):
    token = tmp_path/'admin'; token.write_text('private-admin-test')
    state = tmp_path/'state'
    assert cli.main(['create','--room-mode','basic','--hub','https://example.invalid','--state-dir',str(state),
                     '--owner-pid',str(os.getpid()),'--admin-token-file',str(token)]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out.get('pairing_code') == '00700042'
    assert 'invitation_file' not in out
    assert not (state/'invitation.json').exists()
    calls, launched = relay
    assert launched[0]['secret'] == '00700042'
    assert '00700042' not in json.dumps(calls)
    for file in state.rglob('*'):
        if file.is_file(): assert b'00700042' not in file.read_bytes()


def test_reserved_room_claim_reads_activation_from_stdin_without_admin_token(tmp_path, relay, capsys, monkeypatch):
    activation = 'aB_-0123456789' * 3 + 'A'
    assert len(activation) == 43
    monkeypatch.setattr(cli.sys, 'stdin', io.StringIO(activation + '\n'))
    token_file = tmp_path / 'must-not-read-admin-token'
    assert cli.main(['create', '--hub', 'https://example.invalid', '--reservation-code-stdin',
                     '--state-dir', str(tmp_path / 'a'), '--owner-pid', str(os.getpid()),
                     '--admin-token-file', str(token_file)]) == 0
    calls, launched = relay
    assert calls == [('/api/rooms/claim', {'json_body': {'activation_code': activation}})]
    assert launched[0]['secret'] == '00700042'
    assert activation not in json.dumps(launched)
    assert activation not in capsys.readouterr().out
    assert all(activation.encode() not in path.read_bytes() for path in (tmp_path / 'a').rglob('*') if path.is_file())


@pytest.mark.parametrize('activation', ['short', 'a' * 44, '中' * 43, ' ' * 43])
def test_invalid_activation_never_contacts_hub(tmp_path, relay, capsys, monkeypatch, activation):
    monkeypatch.setattr(cli.sys, 'stdin', io.StringIO(activation + '\n'))
    assert cli.main(['create', '--reservation-code-stdin', '--state-dir', str(tmp_path / 'a'),
                     '--owner-pid', str(os.getpid())]) == 1
    assert relay[0] == []
    assert activation not in capsys.readouterr().err


def test_activation_cannot_be_used_as_state_path(tmp_path, relay, capsys, monkeypatch):
    activation = 'a' * 43
    monkeypatch.setattr(cli.sys, 'stdin', io.StringIO(activation))
    assert cli.main(['create', '--reservation-code-stdin', '--state-dir', str(tmp_path / activation),
                     '--owner-pid', str(os.getpid())]) == 1
    assert relay[0] == []
    assert not (tmp_path / activation).exists()


def test_join_transmits_only_public_locator(tmp_path, relay, capsys):
    assert cli.main(['join','--hub','https://example.invalid','--code','00700042',
                     '--state-dir',str(tmp_path/'b'),'--owner-pid',str(os.getpid())]) == 0
    calls, launched = relay
    assert calls == [('/api/join', {'json_body': {'locator':'007'}})]
    assert launched[0]['secret'] == '00700042'
    assert '00700042' not in capsys.readouterr().out


@pytest.mark.parametrize('code',['1234567','123456789','１２３４５６７８','abcd5678','1234 5678'])
def test_invalid_code_never_contacts_hub(code, tmp_path, relay, capsys):
    assert cli.main(['join','--hub','https://example.invalid','--code',code,
                     '--state-dir',str(tmp_path/'b'),'--owner-pid',str(os.getpid())]) == 1
    assert relay[0] == []
    assert code not in capsys.readouterr().err


def test_legacy_invite_option_is_rejected():
    with pytest.raises(SystemExit):
        cli.parser().parse_args(['join','--invite-file','invitation.json','--state-dir','b'])


def test_prepare_is_local_and_has_usable_installation_and_process_information(monkeypatch, capsys):
    monkeypatch.setattr(cli, 'Transport', Mock(side_effect=AssertionError('no network')))
    assert cli.main(['prepare']) == 0
    out = json.loads(capsys.readouterr().out)
    assert Path(out['python']).is_file()
    assert out['version'] == cli.__version__ == '0.7.5'
    assert out['hub'].startswith('https://')
    assert out['state_dir']
    assert isinstance(out['ancestors'], list)
    assert 'token' not in out


def test_create_defaults_for_manual_cmd():
    args = cli.parser().parse_args(['create','--state-dir','a'])
    assert args.owner_pid is None
    assert args.hub == 'https://json-formatter.centralindia.cloudapp.azure.com/coagen'


@pytest.mark.parametrize('options', [[], ['-I'], ['-X', 'utf8'], ['-I', '-X', 'utf8']])
def test_manual_cmd_owner_skips_only_matching_venv_launcher(monkeypatch, options):
    shell = Mock(pid=120)
    shell.name.return_value = 'cmd.exe'
    launcher = Mock(pid=121)
    launcher.name.return_value = 'python.exe'
    launcher.exe.return_value = cli.sys.executable
    launcher.cmdline.return_value = [cli.sys.executable, *options, '-m', 'coagen_client', 'create']
    launcher.parent.return_value = shell
    monkeypatch.setattr(cli.psutil, 'Process', lambda pid: launcher)
    capture = Mock(return_value='shell-owner')
    monkeypatch.setattr(cli.Owner, 'capture', capture)
    assert cli.session_owner(None) == 'shell-owner'
    capture.assert_called_once_with(120)


def test_isolated_helper_ignores_workspace_shadow_module(tmp_path, monkeypatch):
    runtime = tmp_path / 'isolated runtime'
    venv.EnvBuilder(with_pip=False).create(runtime)
    python = runtime / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    sites = runtime / 'Lib/site-packages' if os.name == 'nt' else next((runtime / 'lib').glob('python*/site-packages'))
    # Minimal installed module records import identity and exits. No network,
    # real Coagen runtime, owner, credentials, or collaboration room is used.
    (sites / 'coagen_client.py').write_text(
        "import json,sys,os;from pathlib import Path\n"
        "value=json.loads(sys.stdin.readline());root=Path(value['state_dir'])\n"
        "(root/'trusted').write_text('installed')\n"
        "(root/'control.json').write_text(json.dumps({'pid':os.getpid()}))\n", encoding='utf-8')
    workspace = tmp_path / 'workspace'; workspace.mkdir()
    untrusted = workspace / 'shadow-ran'
    (workspace / 'coagen_client.py').write_text(
        "from pathlib import Path\nPath('shadow-ran').write_text('unsafe cwd import')\n", encoding='utf-8')
    state = tmp_path / 'state'; state.mkdir()
    monkeypatch.chdir(workspace)
    monkeypatch.setenv('PYTHONPATH', str(workspace))
    monkeypatch.setattr(cli.sys, 'executable', str(python))
    monkeypatch.setattr(cli.sys, 'flags', SimpleNamespace(isolated=1))
    result = cli.launch_session({'state_dir': str(state), 'member': {'room_id': 'test'}})
    assert result['phase'] == 'starting'
    assert (state / 'trusted').read_text() == 'installed'
    assert not untrusted.exists()


def test_launched_helper_is_reaped_without_blocking_its_live_owner(tmp_path, monkeypatch):
    """The parent must reap a dead helper even if no further child is spawned."""
    import subprocess
    import threading
    import time

    state = tmp_path / 'state'
    state.mkdir()
    release = state / 'release'
    child = (
        "import json,os,sys,time;from pathlib import Path\n"
        "root=Path(json.loads(sys.stdin.readline())['state_dir'])\n"
        "(root/'control.json').write_text(json.dumps({'pid':os.getpid()}))\n"
        "while not (root/'release').exists():time.sleep(.05)\n"
    )
    spawn = subprocess.Popen
    entered, reaped = threading.Event(), threading.Event()
    children = []

    def observed_spawn(_command, **kwargs):
        process = spawn([cli.sys.executable, '-c', child], **kwargs)
        children.append(process)
        wait = process.wait

        def observed_wait(*args, **options):
            entered.set()
            result = wait(*args, **options)
            reaped.set()
            return result

        process.wait = observed_wait
        return process

    monkeypatch.setattr(cli.subprocess, 'Popen', observed_spawn)
    try:
        started = time.monotonic()
        result = cli.launch_session({'state_dir': str(state), 'member': {'room_id': 'synthetic'}})
        assert result['phase'] == 'starting' and time.monotonic() - started < 5
        assert entered.wait(1), 'Launching parent did not retain a child waiter'
        assert not reaped.is_set(), 'Live helper must continue independently'
        release.touch()
        assert reaped.wait(5), 'Exited helper was not reaped without another Popen'
        assert children[0].returncode == 0
    finally:
        release.touch()
        for process in children:
            process.wait(timeout=10)


def test_does_not_adopt_unrelated_python_parent(monkeypatch):
    parent = Mock(pid=121)
    parent.name.return_value = 'python.exe'
    parent.exe.return_value = cli.sys.executable
    parent.cmdline.return_value = [cli.sys.executable, 'other_agent.py']
    monkeypatch.setattr(cli.psutil, 'Process', lambda pid: parent)
    with pytest.raises(ValueError, match='stable Agent owner PID'):
        cli.session_owner(None)


@pytest.mark.parametrize('failure', ['old-hub', 'helper'])
def test_created_room_is_retired_when_setup_cannot_complete(tmp_path, monkeypatch, relay, capsys, failure):
    if failure == 'helper':
        monkeypatch.setattr(cli, 'launch_session', Mock(side_effect=RuntimeError('private-data')))
    else:
        class LegacyTransport:
            def __init__(self, *args): pass
            def request(self, *args, **kwargs):
                return SimpleNamespace(json=lambda: {'room_id':'r', 'token':'member'})
            def close(self): pass
        monkeypatch.setattr(cli, 'Transport', LegacyTransport)
    client = Mock()
    client.__enter__ = Mock(return_value=client)
    client.__exit__ = Mock(return_value=False)
    monkeypatch.setattr(cli.httpx, 'Client', Mock(return_value=client))
    token = tmp_path/'admin'; token.write_text('admin')
    assert cli.main(['create', '--room-mode', 'basic', '--state-dir',str(tmp_path/'s'), '--owner-pid',str(os.getpid()),
                     '--admin-token-file',str(token)]) == 1
    client.post.assert_called_once()
    assert client.post.call_args.kwargs['json']['op'] == 'close'
    output = capsys.readouterr()
    assert 'private-data' not in output.err and '00700042' not in output.err
    assert output.out == ''
