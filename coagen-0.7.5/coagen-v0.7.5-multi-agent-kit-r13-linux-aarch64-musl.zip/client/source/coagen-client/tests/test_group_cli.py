import json
import os
from types import SimpleNamespace

import pytest
import httpx

from coagen_client import cli, mcp


@pytest.fixture
def relay(tmp_path, monkeypatch):
    calls, launched = [], []
    capabilities = {'group_protocol': 'coagen-group/1', 'room_names': True, 'max_initial_ttl_seconds': 21600}
    class Endpoint:
        def __init__(self, *args): pass
        def close(self): pass
        def capabilities(self): return capabilities
        def request(self, route, **kwargs):
            calls.append((route, kwargs))
            body = kwargs.get('json_body', {})
            return SimpleNamespace(json=lambda: dict(room_id='a' * 32, peer_id='b' * 32, session_id='c' * 32,
                token='synthetic', role='a', expires_at=2000000000, locator='007',
                label=body.get('label', ''), label_revision=1,
                room_mode='group' if body.get('room_mode') == 'group' or 'protocols' in body else 'basic',
                group_protocol='coagen-group/1'))
    monkeypatch.setattr(cli, 'Transport', Endpoint)
    monkeypatch.setattr(cli, 'launch_session', lambda config: launched.append(config) or {'phase': 'starting'})
    token = tmp_path / 'admin'; token.write_text('synthetic')
    return calls, launched, capabilities, token


def test_named_group_create_forwards_six_hour_and_protocol_options(tmp_path, relay, capsys):
    calls, launched, _, token = relay
    result = cli.main(['create', '--state-dir', str(tmp_path / 'state'), '--owner-pid', str(os.getpid()),
        '--admin-token-file', str(token), '--ttl', '21600', '--label', '研究组🧪',
        '--room-mode', 'group', '--max-members', '5', '--mode', 'brainstorm'])
    assert result == 0
    assert calls == [('/api/rooms', {'json_body': dict(ttl_seconds=21600, label='研究组🧪',
        room_mode='group', max_members=5, mode='brainstorm')})]
    assert launched[0]['member']['room_mode'] == 'group'
    created = json.loads(capsys.readouterr().out)
    assert len(created['pairing_code']) == 8
    assert created['label'] == '研究组🧪' and created['room_mode'] == 'group'


def test_join_adds_protocol_only_when_advertised(tmp_path, relay, capsys):
    calls, _, capabilities, _ = relay
    for number, supported in enumerate((True, False)):
        if not supported:
            capabilities.clear()
        assert cli.main(['join', '--state-dir', str(tmp_path / str(number)), '--owner-pid', str(os.getpid()),
                         '--code', '00700042']) == 0
    assert calls[0][1]['json_body'] == {'locator': '007', 'protocols': ['coagen-group/1']}
    assert calls[1][1]['json_body'] == {'locator': '007'}


@pytest.mark.parametrize('options', [['--label', 'bad\nlabel'], ['--ttl', '21601'], ['--max-members', '9']])
def test_invalid_create_parameters_never_start_remote_establishment(tmp_path, relay, options, capsys):
    calls, _, _, token = relay
    assert cli.main(['create', '--state-dir', str(tmp_path / 'state'), '--owner-pid', str(os.getpid()),
                     '--admin-token-file', str(token), *options]) == 1
    assert calls == []


def test_mcp_routes_target_and_explicit_collaboration_control(tmp_path, monkeypatch):
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    monkeypatch.setattr(bridge, '_state', lambda *_args, **_kwargs: tmp_path)
    seen = []
    monkeypatch.setattr(cli, 'call_local', lambda _state, operation: seen.append(operation) or {'ok': True})
    bridge.call('coagen_send', {'text': 'test', 'recipient_id': 'peer', 'request_id': 'send'})
    bridge.call('coagen_collaboration', {'action': 'advance', 'expected_revision': 2, 'request_id': 'control'})
    assert seen[0]['recipient_id'] == 'peer'
    assert seen[1] == {'op': 'collaboration', 'action': 'advance', 'expected_revision': 2, 'request_id': 'control'}


def test_health_discovery_timeout_cannot_mark_room_establishment_unknown(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    class Endpoint:
        def __init__(self, *_args): pass
        def close(self): pass
        def capabilities(self): raise httpx.ConnectTimeout('synthetic unavailable')
        def request(self, *_args, **_kwargs): pytest.fail('Room admission must not be attempted')
    monkeypatch.setattr(cli, 'Transport', Endpoint)
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
               'params': {'name': 'coagen_join', 'arguments': {'code': '00700042'}}}
    response = bridge.handle(request)['result']
    error = json.loads(response['content'][0]['text'])
    assert error['code'] == 'HUB_UNAVAILABLE' and error['outcome'] == 'not_started'
    assert json.loads((bridge.diagnostic_root / 'establishment.json').read_text())['pending'] is False


def test_explicit_basic_on_old_hub_omits_unsupported_extension(tmp_path, relay, capsys):
    calls, _, capabilities, token = relay
    capabilities.clear()
    assert cli.main(['create', '--state-dir', str(tmp_path / 'state'), '--owner-pid', str(os.getpid()),
                     '--admin-token-file', str(token), '--room-mode', 'basic']) == 0
    assert calls == [('/api/rooms', {'json_body': {'ttl_seconds': 3600}})]


def test_cli_preserves_legacy_short_ttl_for_expiry_checks(tmp_path, relay, capsys):
    calls, _, _, token = relay
    assert cli.main(['create', '--state-dir', str(tmp_path / 'state'), '--owner-pid', str(os.getpid()),
                     '--admin-token-file', str(token), '--ttl', '45', '--room-mode', 'basic']) == 0
    assert calls == [('/api/rooms', {'json_body': {'ttl_seconds': 45, 'room_mode': 'basic'}})]


def test_collaboration_tool_cannot_be_changed_to_another_local_operation(tmp_path, monkeypatch):
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    monkeypatch.setattr(bridge, '_state', lambda *_args, **_kwargs: tmp_path)
    seen = []
    monkeypatch.setattr(cli, 'call_local', lambda _state, operation: seen.append(operation) or {'ok': True})
    bridge.call('coagen_collaboration', {'op': 'stop', 'action': 'advance', 'expected_revision': 1, 'request_id': 'control'})
    assert seen == [{'op': 'collaboration', 'action': 'advance', 'expected_revision': 1, 'request_id': 'control'}]
