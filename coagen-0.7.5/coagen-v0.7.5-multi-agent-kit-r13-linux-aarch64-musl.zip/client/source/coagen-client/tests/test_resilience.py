"""0.7.4 resilience: network faults delay Coagen, they do not end sessions.

Offline only: mock transports, synthetic owners and temporary directories.
"""
import json
import os
import ssl
import time
from types import SimpleNamespace

import httpx
import pytest

from coagen_client import cli, mcp
from coagen_client.errors import CoagenError, classify_error
from coagen_client.lifecycle import Owner
from coagen_client.transport import HubError, Transport, authoritative_revocation

from test_group_runtime import team  # noqa: F401 - pytest fixture


def mock_transport(handler):
    transport = Transport('http://127.0.0.1:1', 'synthetic', 'room')
    transport.client.close()
    transport.client = httpx.Client(transport=httpx.MockTransport(handler))
    return transport


def test_idempotent_exchange_retries_once_on_a_dead_pooled_connection():
    calls = []
    def handler(request):
        calls.append(json.loads(request.content)['op'])
        if len(calls) == 1:
            raise httpx.RemoteProtocolError('Server disconnected without sending a response.')
        return httpx.Response(200, json={'ok': True})
    transport = mock_transport(handler)
    try:
        assert transport.exchange('heartbeat') == {'ok': True}
        assert calls == ['heartbeat', 'heartbeat']
    finally:
        transport.close()


@pytest.mark.parametrize('op', ['consume', 'signal', 'leave'])
def test_non_idempotent_exchange_is_never_sent_twice(op):
    calls = []
    def handler(request):
        calls.append(op)
        raise httpx.RemoteProtocolError('Server disconnected without sending a response.')
    transport = mock_transport(handler)
    try:
        with pytest.raises(httpx.RemoteProtocolError):
            transport.exchange(op)
        assert calls == [op]
    finally:
        transport.close()


def test_packet_upload_is_never_retried_by_the_transport():
    calls = []
    def handler(request):
        calls.append(request.url.path)
        raise httpx.ReadError('reset')
    transport = mock_transport(handler)
    try:
        with pytest.raises(httpx.ReadError):
            transport.send_packet({'room_id': 'room', 'message_id': 'a' * 32, 'sender_id': 's'}, b'png')
        assert len(calls) == 1
    finally:
        transport.close()


def test_long_poll_read_timeout_leaves_a_margin_beyond_the_hub_wait():
    seen = []
    def handler(request):
        seen.append(request.extensions['timeout'])
        return httpx.Response(200, json={'messages': []})
    transport = mock_transport(handler)
    try:
        transport.exchange('poll', wait_seconds=20, limit=10)
        transport.exchange('status')
        assert seen[0]['read'] == 35 and seen[1]['read'] == 25
    finally:
        transport.close()


def test_keepalive_outlasts_one_heartbeat_interval_and_is_configurable(monkeypatch):
    transport = Transport('http://127.0.0.1:1')
    assert transport.keepalive_seconds == 45
    transport.close()
    monkeypatch.setenv('COAGEN_HTTP_KEEPALIVE_SECONDS', '0')
    transport = Transport('http://127.0.0.1:1')
    assert transport.keepalive_seconds == 0
    transport.close()


def test_middlebox_error_page_is_not_a_hub_revocation():
    def html(request):
        return httpx.Response(403, text='<html>Access denied by proxy</html>', headers={'Content-Type': 'text/html'})
    def hub(request):
        return httpx.Response(410, json={'detail': {'code': 'MEMBER_INACTIVE', 'reason_code': 'MEMBER_INACTIVE'}})
    for handler, expected in ((html, False), (hub, True)):
        transport = mock_transport(handler)
        try:
            with pytest.raises(HubError) as rejected:
                transport.exchange('heartbeat')
            assert rejected.value.hub_origin is expected
            assert authoritative_revocation(rejected.value) is expected
        finally:
            transport.close()


def test_cut_short_tls_handshake_is_transient_but_certificate_failure_is_not():
    eof = httpx.ConnectError('handshake')
    eof.__cause__ = ssl.SSLEOFError(8, 'EOF occurred in violation of protocol')
    verify = httpx.ConnectError('verify')
    verify.__cause__ = ssl.SSLCertVerificationError(1, 'certificate verify failed')
    assert classify_error(eof, operation='heartbeat', stage='heartbeat').code == 'HUB_UNAVAILABLE'
    assert classify_error(verify, operation='heartbeat', stage='heartbeat').code == 'TLS_FAILED'


@pytest.mark.parametrize('failure', [
    lambda: httpx.ConnectError('ssl eof'),
    lambda: HubError(403, hub_origin=False),
    lambda: HubError(502, hub_origin=False),
    lambda: ValueError('garbled proxy response'),
])
def test_group_heartbeat_survives_non_authoritative_failures(team, monkeypatch, failure):
    relay, add, pair = team
    a, _ = add('a'), add('b'); pair()
    module = __import__('coagen_client.group_runtime', fromlist=['time'])
    clock = [100.0]
    original, requests = a.transport.exchange, []
    def exchange(op, **fields):
        requests.append(clock[0])
        if clock[0] < 140:
            raise failure()
        return original(op, **fields)
    a.transport.exchange = exchange
    monkeypatch.setattr(module, 'time', SimpleNamespace(monotonic=lambda: clock[0], time=time.time))
    monkeypatch.setattr(a, 'active', lambda: clock[0] < 200)
    monkeypatch.setattr(a.stop_event, 'wait', lambda seconds: clock.__setitem__(0, clock[0] + seconds))
    ended = []
    monkeypatch.setattr(a, 'shutdown', lambda reason: ended.append(reason))
    a.worker()
    assert ended != ['revoked'] and a.connection_recovery_blocked is False
    assert any(when >= 140 for when in requests)
    assert a.status()['connection']['state'] == 'ok'


def test_group_heartbeat_ends_only_on_the_hubs_own_rejection(team, monkeypatch):
    relay, add, pair = team
    a, _ = add('a'), add('b'); pair()
    def rejected(op, **fields):
        raise HubError(410, details={'code': 'MEMBER_INACTIVE'})
    a.transport.exchange = rejected
    ended = []
    monkeypatch.setattr(a, 'shutdown', lambda reason: ended.append(reason))
    a.worker()
    assert ended == ['revoked']


def test_operation_errors_keep_their_cause_across_the_helper_boundary(team):
    relay, add, pair = team
    a, _ = add('a'), add('b'); pair()
    def unavailable(op, **fields):
        raise httpx.ReadTimeout('timed out')
    a.transport.exchange = unavailable
    with pytest.raises(CoagenError) as caught:
        a.dispatch({'op': 'receive', 'wait': 0})
    assert caught.value.code == 'HUB_UNAVAILABLE'
    assert caught.value.cause and caught.value.cause['category'] == 'read_timeout'


def detachable(add, grace=600):
    runtime = add('a')
    runtime.resume_grace_seconds = grace
    runtime.httpd = SimpleNamespace(server_port=1)
    return runtime


def test_detach_requires_the_bound_instance_and_adopt_never_displaces_a_live_owner(team):
    relay, add, pair = team
    a = detachable(add)
    a.mcp_instance_id = 'f' * 32
    with pytest.raises(CoagenError) as wrong:
        a.dispatch({'op': 'detach', 'mcp_instance_id': 'e' * 32})
    assert wrong.value.code == 'INVALID_ARGUMENT' and a.detached is None
    owner = Owner.capture(os.getpid())
    with pytest.raises(CoagenError) as busy:
        a.dispatch({'op': 'adopt', 'owner_pid': owner.pid, 'owner_started_at': owner.started_at,
                    'mcp_instance_id': 'd' * 32})
    assert busy.value.code == 'SESSION_ALREADY_ACTIVE'
    value = a.dispatch({'op': 'detach', 'mcp_instance_id': 'f' * 32})
    assert value['detached']['reason'] == 'mcp_closed'
    assert json.loads((a.root / 'control.json').read_text())['detached']['reason'] == 'mcp_closed'
    resumed = a.dispatch({'op': 'adopt', 'owner_pid': owner.pid, 'owner_started_at': owner.started_at,
                          'mcp_instance_id': 'd' * 32})
    assert resumed['resumed']['identity_kept'] is True and a.detached is None and a.mcp_instance_id == 'd' * 32
    saved = json.loads((a.root / 'control.json').read_text())
    assert saved['mcp_instance_id'] == 'd' * 32 and saved['detached'] is None


def test_adopt_rejects_an_owner_that_is_not_running(team):
    relay, add, pair = team
    a = detachable(add)
    assert a._detach('owner_exited')
    with pytest.raises(CoagenError) as caught:
        a.dispatch({'op': 'adopt', 'owner_pid': os.getpid(), 'owner_started_at': 1.0, 'mcp_instance_id': 'c' * 32})
    assert caught.value.code == 'INVALID_ARGUMENT' and a.detached is not None


def test_detached_session_stays_active_until_grace_then_ends(team, monkeypatch):
    relay, add, pair = team
    a = detachable(add, grace=60)
    a.owner = Owner(a.owner.pid, 1.0)  # an owner that has exited
    assert a.active() and a.detached['reason'] == 'owner_exited'
    later = time.time() + 61
    monkeypatch.setattr('coagen_client.runtime.time.time', lambda: later)
    assert not a.active()
    assert a._end_reason() == 'owner_exited'


def test_without_grace_an_exited_owner_ends_the_session(team):
    relay, add, pair = team
    a = detachable(add, grace=0)
    a.owner = Owner(a.owner.pid, 1.0)
    assert not a.active() and a.detached is None


def test_basic_rooms_never_get_a_resume_grace(tmp_path):
    from coagen_client.runtime import SessionRuntime
    owner = Owner.capture(os.getpid())
    runtime = SessionRuntime({'state_dir': str(tmp_path), 'owner_pid': owner.pid, 'owner_started_at': owner.started_at,
                              'hub': 'http://127.0.0.1:1', 'secret': 'x', 'resume_grace_seconds': 3600,
                              'member': {'room_id': 'r', 'peer_id': 'a', 'role': 'a', 'token': 't',
                                         'session_id': 's', 'expires_at': time.time() + 300}})
    try:
        assert runtime.resume_grace_seconds == 0
    finally:
        runtime.transport.close()


@pytest.mark.parametrize(('value', 'expected'), [(None, 7200), ('0', 0), ('99999', 21600), ('bad', 7200), ('nan', 7200)])
def test_resume_grace_setting_is_bounded(monkeypatch, value, expected):
    if value is None:
        monkeypatch.delenv('COAGEN_RESUME_GRACE_SECONDS', raising=False)
    else:
        monkeypatch.setenv('COAGEN_RESUME_GRACE_SECONDS', value)
    assert cli.resume_grace_seconds() == expected


def test_watch_rides_out_a_transient_receive_failure(tmp_path, monkeypatch):
    bridge = mcp.McpServer(workspace=tmp_path, state_dir=None)
    bridge._resume_checked = True
    bridge.state_dir = tmp_path
    monkeypatch.setattr(bridge, '_check_state_binding', lambda path: None)
    calls = []
    def helper(_state, operation):
        calls.append(operation['op'])
        if operation['op'] == 'status':
            return {'phase': 'ready', 'incidents': []}
        raise CoagenError('HUB_UNAVAILABLE', operation='receive', stage='receive_poll',
                          retry={'retry_after_seconds': 1})
    monkeypatch.setattr(cli, 'call_local', helper)
    monkeypatch.setattr(mcp.local_ops, 'page_messages', lambda state, messages, **kw: {'messages': messages})
    response = bridge.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
                              'params': {'name': 'coagen_watch', 'arguments': {'wait_seconds': 1.5}}})
    assert not response['result'].get('isError')
    value = json.loads(response['result']['content'][0]['text'])
    assert value['messages'] == [] and value['network_degraded']['code'] == 'HUB_UNAVAILABLE'
    assert value['network_degraded']['automatic_recovery'] is True
    assert calls.count('receive') <= 2  # paced by retry_after, no tight loop
    # An explicit receive still reports the error to the caller.
    response = bridge.handle({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call',
                              'params': {'name': 'coagen_receive', 'arguments': {}}})
    assert response['result']['isError'] is True


def test_detached_session_ends_once_its_hub_lease_must_have_lapsed(team, monkeypatch):
    relay, add, pair = team
    a = detachable(add, grace=3600)
    a.member['lease_seconds'] = 180
    a.owner = Owner(a.owner.pid, 1.0)
    assert a.active()
    a.connection_health['last_success_at'] = a.detached['since']
    later = a.detached['since'] + 271
    monkeypatch.setattr('coagen_client.runtime.time.time', lambda: later)
    assert not a.active()


def test_a_new_session_does_not_inherit_the_previous_sessions_bridge_incidents(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    bridge = mcp.McpServer(workspace=tmp_path)
    bridge.diagnostics.record(CoagenError('RETRY_BUDGET_EXHAUSTED', operation='receive', stage='recovery'), key='receive')
    assert bridge._snapshot()['last_operation_error']['code'] == 'RETRY_BUDGET_EXHAUSTED'
    monkeypatch.setattr(cli, 'call_local', lambda state, op: {'room_id': 'r', 'peer_id': 'p', 'phase': 'ready',
                                                             'resumed': {'detached_seconds': 1}})
    monkeypatch.setattr(mcp.psutil, 'Process', lambda pid: SimpleNamespace(create_time=lambda: 1.0))
    bridge._adopt({'state_dir': str(tmp_path / 's'), 'session_id': 's'}, automatic=True)
    snapshot = bridge._snapshot()
    assert snapshot['last_operation_error'] is None
    assert all(item['status'] == 'resolved' for item in snapshot['incidents'])


def test_started_packet_transfer_is_not_cut_off_by_the_retry_window():
    """Intranet: a 7.5 MB packets/read took 23 s; the window must not truncate it."""
    seen = []
    def handler(request):
        seen.append((request.url.path, request.extensions['timeout']))
        if request.url.path.endswith('/packets/read'):
            return httpx.Response(200, content=b'\x89PNG' + b'0' * 64)
        return httpx.Response(200, json={'ok': True})
    transport = mock_transport(handler)
    try:
        with transport.operation_deadline(time.time() + 2):
            transport.read_packet('a' * 32)
            transport.send_packet({'room_id': 'room', 'message_id': 'b' * 32, 'sender_id': 's'}, b'png')
            transport.exchange('status')
        timeouts = {path.rsplit('/', 1)[-1]: value for path, value in seen}
        assert timeouts['read']['read'] == 25 and timeouts['packets']['read'] == 25
        assert timeouts['exchange']['read'] <= 2  # ordinary requests still obey the window
        with transport.operation_deadline(time.time() - 1):
            with pytest.raises(CoagenError):
                transport.read_packet('a' * 32)  # but a transfer never starts after it
        assert len(seen) == 3
    finally:
        transport.close()


@pytest.mark.parametrize('code', sorted(__import__('coagen_client.errors', fromlist=['CATALOG']).CATALOG))
def test_every_error_has_a_plain_language_explanation(code):
    report = CoagenError(code, operation='receive', stage='receive_poll').to_dict()
    explained = report['explain']
    for field in ('发生了什么', '可能的原因', '影响', 'Coagen 正在做什么', '你需要做什么', '事件编号'):
        assert explained[field], (code, field)
    assert '{op}' not in report['message_for_user'] and report['incident_id'] in report['message_for_user']


def test_explanation_names_the_real_cause_and_never_leaks_exception_text():
    error = httpx.ConnectError('SECRET-TOKEN-abcdefghijklmnopqrstuvwxyz0123456789')
    error.__cause__ = ssl.SSLEOFError(8, 'EOF occurred in violation of protocol')
    report = classify_error(error, operation='heartbeat', stage='heartbeat').to_dict()
    assert '握手' in report['message_for_user'] and '自动重试' in report['message_for_user']
    assert 'SECRET-TOKEN' not in json.dumps(report, ensure_ascii=False)


def test_a_request_that_never_connected_is_retried_even_when_not_idempotent(monkeypatch):
    """Intranet: join preflight and the first send failed on a 10 s connect timeout."""
    monkeypatch.setattr('coagen_client.transport.time.sleep', lambda seconds: None)
    calls = []
    def handler(request):
        calls.append(request.url.path)
        if len(calls) < 3:
            raise httpx.ConnectTimeout('slow TLS through an inspecting proxy')
        return httpx.Response(200, json={'ok': True})
    transport = mock_transport(handler)
    try:
        assert transport.request('/api/join', json_body={'locator': '007'}).json() == {'ok': True}
        assert len(calls) == 3
    finally:
        transport.close()


def test_connect_timeout_allows_a_slow_tls_handshake():
    from coagen_client.transport import CONNECT_TIMEOUT_SECONDS
    transport = Transport('http://127.0.0.1:1')
    try:
        assert CONNECT_TIMEOUT_SECONDS == 30 and transport.client.timeout.connect == 30
    finally:
        transport.close()


def test_group_send_uses_the_known_roster_when_the_refresh_fails(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    original = a.transport.exchange
    def flaky(op, **fields):
        if op == 'status':
            raise httpx.ConnectTimeout('slow TLS')
        return original(op, **fields)
    a.transport.exchange = flaky
    assert a.send({'text': 'still delivered', 'recipient_id': 'b', 'request_id': 'r1'})['state'] == 'sent'
