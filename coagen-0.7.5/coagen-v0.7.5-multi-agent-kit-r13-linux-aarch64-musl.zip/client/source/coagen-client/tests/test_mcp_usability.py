import json
import os
from pathlib import Path

import pytest

from coagen_client import mcp
from coagen_client.capsule import create_capsule, extract_capsule
from coagen_client.store import Store


@pytest.fixture(autouse=True)
def isolated_state(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))


def value(result):
    return json.loads(result['content'][0]['text'])


def server(tmp_path):
    return mcp.McpServer(workspace=tmp_path / 'workspace', owner_pid=os.getpid(),
                         state_dir=tmp_path / 'session')


def request(name, args):
    return {'id': 1, 'jsonrpc': '2.0', 'method': 'tools/call',
            'params': {'name': name, 'arguments': args}}


def test_readme_path_has_explicit_validation_before_helper(tmp_path, monkeypatch):
    srv = server(tmp_path)
    calls = []
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *a: calls.append(a) or {'state': 'sent'})
    result = srv.handle(request('coagen_send', {'readme_path': 'inline README body'}))
    error = value(result['result'])
    assert error['code'] == 'README_PATH_INVALID'
    assert error['stage'] == 'input'
    assert not calls


def test_readme_alias_and_text_xor(tmp_path, monkeypatch):
    srv = server(tmp_path)
    srv.workspace.mkdir()
    readme = srv.workspace / 'README.md'
    readme.write_text('中文 https://example.test/?a=1&b=2', encoding='utf-8')
    calls = []
    monkeypatch.setattr(mcp.cli, 'call_local', lambda p, a: calls.append(a) or {'state': 'sent'})
    for field in ('readme', 'readme_path'):
        value(srv.call('coagen_send', {field: str(readme)}))
        assert calls[-1]['readme'] == readme.read_text(encoding='utf-8')
    count = len(calls)
    result = srv.handle(request('coagen_send', {'text': 'summary', 'readme_path': str(readme)}))
    assert value(result['result'])['code'] == 'INPUT_TEXT_OR_README'
    assert len(calls) == count


def test_text_only_does_not_depend_on_chat_directory(tmp_path, monkeypatch):
    srv = server(tmp_path)
    other = tmp_path / 'other-chat'
    other.mkdir()
    monkeypatch.chdir(other)
    calls = []
    monkeypatch.setattr(mcp.cli, 'call_local', lambda p, a: calls.append(a) or {'state': 'sent'})
    srv.call('coagen_send', {'text': 'use text from any authorized task context'})
    assert calls[-1]['text'].startswith('use text')
    prepared = value(srv.call('coagen_prepare', {}))
    assert prepared['text_only_workspace_match_required'] is False
    assert prepared['attachment_roots'] == [str(srv.workspace)]
    assert prepared['runtime_instance_id'] == srv.instance_id


def test_relative_files_error_names_contract_without_echoing_content(tmp_path):
    srv = server(tmp_path)
    result = srv.handle(request('coagen_send', {'text': 'x', 'files': ['private-secret.md']}))
    error = value(result['result'])
    assert error['code'] == 'ATTACHMENT_PATH_INVALID'
    assert 'private-secret.md' not in json.dumps(error)


def test_compact_status_excludes_resolved_history(tmp_path, monkeypatch):
    srv = server(tmp_path)
    from coagen_client.errors import CoagenError
    active = CoagenError('HUB_UNAVAILABLE', operation='heartbeat').to_dict() | {'status': 'active'}
    old = CoagenError('INVALID_ARGUMENT', operation='send').to_dict() | {'status': 'resolved'}
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *a: {'phase': 'ready', 'incidents': [old, active]})
    compact = value(srv.call('coagen_status', {}))
    assert compact['incident_summary']['resolved'] == 1
    assert len(compact['incidents']) == 1
    assert compact['incidents'][0]['code'] == 'HUB_UNAVAILABLE'
    full = value(srv.call('coagen_status', {'detail': 'full'}))
    assert len(full['incidents']) == 2


def make_message(root, mid, text='hello', files=None):
    store = Store(root)
    folder = root / 'inbox' / mid
    raw = create_capsule(text, files or [], message_id=mid)
    extract_capsule(raw, folder)
    metadata = {'message_id': mid, 'sender_id': 'b' * 32, 'recipient_id': 'a' * 32,
                'room_id': 'c' * 32, 'expires_at': 9999999999}
    store.record_incoming(mid, metadata, folder)
    return store, folder


def test_paged_summary_preserves_cursor_after_consumed(tmp_path, monkeypatch):
    srv = server(tmp_path)
    store, first = make_message(srv.state_dir, '1' * 32, 'long body' * 500)
    make_message(srv.state_dir, '2' * 32, 'second')
    messages = [{'message_id': p.name, 'readme': (p/'README.md').read_text(),
                 'files': [], 'ext': {'large': 'x'*3000}} for p in (first, srv.state_dir/'inbox'/('2'*32))]
    monkeypatch.setattr(mcp.cli, 'call_local', lambda p,a: {'phase': 'ready'} if a['op']=='status' else {'messages': messages})
    page = value(srv.call('coagen_receive', {'max_messages': 1, 'summary': True}))
    assert page['has_more'] is True
    assert len(page['messages']) == 1
    assert len(page['messages'][0].get('preview', '')) <= 512
    assert 'readme' not in page['messages'][0]
    assert 'ext' not in page['messages'][0]
    cursor = page['next_cursor']
    store.set_incoming_state('1'*32, 'consumed')
    messages.pop(0)
    second = value(srv.call('coagen_receive', {'after_cursor': cursor, 'max_messages': 1}))
    assert second['messages'][0]['message_id'] == '2'*32
    assert second['next_cursor'] > cursor


def test_history_without_active_binding_is_metadata_only(tmp_path):
    root = mcp.cli.state_base()/'sessions'/('mcp-'+'a'*24)
    store = Store(root)
    store.audit('session', room='c'*32, result='started')
    (root/'control.json').write_text(json.dumps({'token': 'DO-NOT-RETURN', 'url': 'http://127.0.0.1:9/rpc'}))
    srv = mcp.McpServer(workspace=tmp_path)
    sessions = value(srv.call('coagen_sessions', {}))
    assert sessions['sessions'][0]['session_id'] == root.name
    history = value(srv.call('coagen_audit', {'session_id': root.name}))
    assert history['records'][0]['room'] == 'c'*32
    assert 'DO-NOT-RETURN' not in json.dumps([sessions, history])
    assert srv.state_dir is None
    assert value(srv.call('coagen_audit', {}))['phase'] == 'no_session'


def test_export_is_durable_and_idempotent_across_consume(tmp_path, monkeypatch):
    srv = server(tmp_path)
    srv.workspace.mkdir()
    source = srv.workspace/'evidence.txt'
    source.write_text('evidence')
    store, folder = make_message(srv.state_dir, '1'*32, 'Keep this result', [source])
    calls = []
    def consume(root, args):
        calls.append(args)
        assert args['op'] == 'consume'
        store.set_incoming_state(args['message_id'], 'consumed')
        return {'state': 'consumed', 'message_id': args['message_id']}
    monkeypatch.setattr(mcp.cli, 'call_local', consume)
    args = {'message_id': '1'*32, 'dest_dir': str(srv.workspace/'exports'), 'consume': True}
    result = value(srv.call('coagen_export', args))
    assert result['state'] == 'exported'
    assert result['consume_state'] == 'consumed'
    target = Path(result['path'])
    assert (target/'README.md').read_text() == 'Keep this result'
    assert (target/'files'/'evidence.txt').read_text() == 'evidence'
    again = value(srv.call('coagen_export', args))
    assert again['duplicate'] is True
    assert len(calls) == 1
    (target/'README.md').write_text('user modification')
    failure = srv.handle(request('coagen_export', args))
    assert value(failure['result'])['code'] == 'EXPORT_CONFLICT'


def test_export_pending_consume_can_resume_without_recopy(tmp_path, monkeypatch):
    srv = server(tmp_path)
    make_message(srv.state_dir, '1'*32)
    from coagen_client.errors import CoagenError
    def fail(*args):
        raise CoagenError('HUB_UNAVAILABLE', operation='consume', outcome='unknown')
    monkeypatch.setattr(mcp.cli, 'call_local', fail)
    args = {'message_id': '1'*32, 'dest_dir': str(srv.workspace/'exports'), 'consume': True}
    first = value(srv.call('coagen_export', args))
    assert first['consume_state'] == 'pending'
    assert (Path(first['path'])/'README.md').exists()
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *a: {'state':'consumed'})
    second = value(srv.call('coagen_export', args))
    assert second['consume_state'] == 'consumed'


def test_export_and_history_reject_escape_paths(tmp_path):
    srv = server(tmp_path)
    make_message(srv.state_dir, '1'*32)
    out = srv.handle(request('coagen_export', {'message_id':'1'*32, 'dest_dir':str(tmp_path/'outside')}))
    assert out['result']['isError'] is True
    history = srv.handle(request('coagen_audit', {'session_id':'../outside'}))
    assert history['result']['isError'] is True


def test_local_page_does_not_long_poll_before_returning(tmp_path, monkeypatch):
    srv = server(tmp_path)
    make_message(srv.state_dir, '1'*32)
    make_message(srv.state_dir, '2'*32)
    calls = []
    def local(p, a):
        calls.append(a)
        return {'phase': 'ready'} if a['op']=='status' else {'messages': [{'message_id':'2'*32, 'readme':'ready'}]}
    monkeypatch.setattr(mcp.cli, 'call_local', local)
    page = value(srv.call('coagen_watch', {'after_cursor':1, 'wait_seconds':20}))
    assert page['messages'][0]['message_id'] == '2'*32
    assert all(a.get('wait', 0)==0 for a in calls)


def test_tampered_export_journal_never_triggers_consume(tmp_path, monkeypatch):
    srv = server(tmp_path)
    make_message(srv.state_dir, '1'*32)
    args = {'message_id':'1'*32, 'dest_dir':str(srv.workspace/'exports')}
    initial = value(srv.call('coagen_export', args))
    journal = Path(initial['path'])/'.coagen-export.json'
    data = json.loads(journal.read_text())
    data['hashes'] = {}
    journal.write_text(json.dumps(data))
    calls = []
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *a: calls.append(a))
    result = srv.handle(request('coagen_export', {**args, 'consume':True}))
    assert value(result['result'])['code'] == 'EXPORT_CONFLICT'
    assert calls == []


def test_corrupt_history_entry_does_not_hide_other_sessions(tmp_path):
    root = mcp.cli.state_base()/'sessions'/'mcp-bad'
    Store(root).audit('session', result='started')
    (root/'stopped.json').write_text('{"status":[]}')
    other = mcp.cli.state_base()/'sessions'/'mcp-good'
    Store(other).audit('session', result='started')
    srv = mcp.McpServer(workspace=tmp_path)
    result = value(srv.call('coagen_sessions', {}))
    assert [r['session_id'] for r in result['sessions']] == ['mcp-good']


def test_export_returns_durable_receipt_on_local_consume_error(tmp_path, monkeypatch):
    srv = server(tmp_path)
    make_message(srv.state_dir, '1'*32)
    def fail(*a):
        raise OSError('private diagnostics must not leak')
    monkeypatch.setattr(mcp.cli, 'call_local', fail)
    result = value(srv.call('coagen_export', {'message_id':'1'*32, 'dest_dir':str(srv.workspace/'exports'), 'consume':True}))
    assert result['state'] == 'exported' and result['consume_state'] == 'pending'
    assert (Path(result['path'])/'README.md').exists()
    assert 'private diagnostics' not in json.dumps(result)
