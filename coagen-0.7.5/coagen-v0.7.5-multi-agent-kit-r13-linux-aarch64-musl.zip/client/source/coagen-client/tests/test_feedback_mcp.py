"""Bridge mirrors must follow authoritative helper incident resolution."""
import json
import os
import pytest
from coagen_client import mcp
from coagen_client.errors import CoagenError


@pytest.fixture
def server(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path/'local'))
    return mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid(), state_dir=tmp_path/'session')


def test_resolved_helper_incident_retires_bridge_mirror_only(server, monkeypatch):
    error = CoagenError('HUB_REJECTED', operation='send', stage='hub_upload', outcome='local_only')
    mirror = server.diagnostics.record(error, key='send:old')
    unrelated = server.diagnostics.record(CoagenError('SEND_OUTCOME_UNKNOWN', operation='send',
        stage='hub_upload', outcome='unknown'), key='send:unknown')
    helper = {'phase':'ready', 'last_operation_error':None, 'incidents':[mirror | {'status':'resolved'}]}
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *a: helper)
    value = json.loads(server.call('coagen_status', {'detail':'full'})['content'][0]['text'])
    records = {row['incident_id']:row for row in value['incidents']}
    assert records[mirror['incident_id']]['status'] == 'resolved'
    assert records[unrelated['incident_id']]['status'] == 'active'
    assert value['last_operation_error']['incident_id'] == unrelated['incident_id']
    stored = {row['incident_id']:row for row in server.diagnostics.snapshot()['incidents']}
    assert stored[mirror['incident_id']]['status'] == 'resolved'
    assert stored[unrelated['incident_id']]['status'] == 'active'


def test_notification_mirror_emits_resolution_once_and_never_resurrects(server, monkeypatch):
    server._notifications_initialized = True
    error = CoagenError('HUB_REJECTED', operation='send', stage='hub_upload', outcome='local_only')
    mirror = server.diagnostics.record(error, key='send:old')
    current = {'phase':'ready', 'incidents':[mirror]}
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *a: current)
    first = server.poll_notifications()
    assert any(n['params']['data']['event'] == 'coagen.incident' for n in first)
    current['incidents'] = [mirror | {'status':'resolved'}]
    second = server.poll_notifications()
    events = [n['params']['data']['event'] for n in second]
    assert events.count('coagen.incident_resolved') == 1
    assert 'coagen.incident' not in events
    assert not server.poll_notifications()
    assert server.diagnostics.snapshot()['last_operation_error'] is None
