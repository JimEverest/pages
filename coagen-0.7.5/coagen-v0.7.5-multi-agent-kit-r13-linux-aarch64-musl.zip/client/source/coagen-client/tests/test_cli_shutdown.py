import json

import httpx

from coagen_client.cli import call_local, prepare_state
from coagen_client.store import atomic_private_json


def test_status_handles_shutdown_between_control_read_and_connect(tmp_path, monkeypatch):
    control = tmp_path / 'control.json'
    atomic_private_json(control, {'url': 'http://127.0.0.1:54321/rpc', 'token': 'local-only'})

    def closing(*args, **kwargs):
        atomic_private_json(control, {'stopped': True, 'status': {'phase': 'owner_exited'}})
        raise httpx.ConnectError('closed')

    monkeypatch.setattr(httpx.Client, 'post', closing)
    assert call_local(tmp_path, {'op': 'status'}) == {'phase': 'owner_exited'}


def test_immutable_terminal_record_takes_priority_over_stale_live_control(tmp_path, monkeypatch):
    atomic_private_json(tmp_path / 'control.json', {'url': 'http://127.0.0.1:54321/rpc', 'token': 'local-only'})
    atomic_private_json(tmp_path / 'stopped.json', {'stopped': True, 'status': {'phase': 'expired'}})
    def unexpected(*args, **kwargs):
        raise AssertionError('No connection is needed after recorded termination.')
    monkeypatch.setattr(httpx.Client, 'post', unexpected)
    assert call_local(tmp_path, {'op': 'status'})['phase'] == 'expired'


def test_terminal_publication_between_read_and_connection_failure_is_observed(tmp_path, monkeypatch):
    atomic_private_json(tmp_path / 'control.json', {'url': 'http://127.0.0.1:54321/rpc', 'token': 'local-only'})
    def closing(*args, **kwargs):
        atomic_private_json(tmp_path / 'stopped.json', {'stopped': True, 'status': {'phase': 'owner_exited'}})
        raise httpx.ConnectError('closed')
    monkeypatch.setattr(httpx.Client, 'post', closing)
    assert call_local(tmp_path, {'op': 'status'})['phase'] == 'owner_exited'


def test_preparing_reused_owned_state_removes_previous_terminal_record(tmp_path):
    (tmp_path / '.coagen-owner').write_text('coagen-v1\n')
    atomic_private_json(tmp_path / 'stopped.json', {'stopped': True, 'status': {'phase': 'expired'}})
    prepare_state(tmp_path)
    assert not (tmp_path / 'stopped.json').exists()


def test_malformed_terminal_record_is_not_ignored_to_contact_the_helper(tmp_path, monkeypatch):
    from coagen_client.errors import CoagenError
    import pytest
    (tmp_path / 'stopped.json').write_text('{', encoding='utf-8')
    with pytest.raises(CoagenError) as caught:
        call_local(tmp_path, {'op': 'status'})
    assert caught.value.code == 'LOCAL_STORAGE_FAILED'


def test_terminal_record_wins_over_a_live_status_response(tmp_path, monkeypatch):
    from types import SimpleNamespace
    atomic_private_json(tmp_path / 'control.json', {'url': 'http://127.0.0.1:54321/rpc', 'token': 'local-only'})
    def closing(*args, **kwargs):
        atomic_private_json(tmp_path / 'stopped.json', {'stopped': True, 'status': {'phase': 'expired'}})
        return SimpleNamespace(raise_for_status=lambda: None, json=lambda: {'ok': True, 'data': {'phase': 'ready'}})
    monkeypatch.setattr(httpx.Client, 'post', closing)
    assert call_local(tmp_path, {'op': 'status'})['phase'] == 'expired'


def test_terminal_record_after_send_connection_loss_preserves_unknown_outcome(tmp_path, monkeypatch):
    import pytest
    from coagen_client.errors import CoagenError
    atomic_private_json(tmp_path / 'control.json', {'url': 'http://127.0.0.1:54321/rpc', 'token': 'local-only'})
    def closing(*args, **kwargs):
        atomic_private_json(tmp_path / 'stopped.json', {'stopped': True, 'status': {'phase': 'expired'}})
        raise httpx.ConnectError('PRIVATE-TRANSPORT-ERROR')
    monkeypatch.setattr(httpx.Client, 'post', closing)
    with pytest.raises(CoagenError) as caught:
        call_local(tmp_path, {'op': 'send'})
    assert caught.value.code == 'SESSION_EXPIRED'
    assert caught.value.outcome == 'unknown'
    assert 'PRIVATE-TRANSPORT-ERROR' not in str(caught.value)


def test_terminal_status_retains_a_later_diagnostic_read_failure(tmp_path):
    from coagen_client.cli import terminal_status
    atomic_private_json(tmp_path / 'stopped.json', {
        'stopped': True, 'status': {'phase': 'expired', 'diagnostic_write_failed': False}})
    (tmp_path / 'diagnostics.json').write_text('{', encoding='utf-8')
    assert terminal_status(tmp_path, 'stop')['diagnostic_write_failed'] is True
