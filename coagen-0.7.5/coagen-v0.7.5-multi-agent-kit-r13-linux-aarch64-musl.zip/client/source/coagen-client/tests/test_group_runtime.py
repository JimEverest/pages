"""Group sessions use independent, authenticated pairwise channels."""
import hashlib
import importlib
import json
import os
import time
from types import SimpleNamespace
from contextlib import nullcontext

import pytest

from coagen_client import mcp
from coagen_client.lifecycle import Owner
from coagen_client.transport import HubError


def group_class():
    spec = importlib.util.find_spec('coagen_client.group_runtime')
    assert spec is not None, 'GroupRuntime is not implemented'
    return importlib.import_module('coagen_client.group_runtime').GroupRuntime


class Relay:
    def __init__(self):
        self.peers, self.signals, self.packets, self.acked, self.consumed = {}, {}, {}, set(), set()
        self.revision = 1
        self.fail_recipient = None
        self.uploads = []

    def status(self):
        return dict(room_id='room', session_id='session', expires_at=time.time() + 3500,
                    room_mode='group', group_protocol='coagen-group/1', max_members=8,
                    leader_peer_id='a', label='研究组🧪', peers=list(self.peers.values()),
                    collaboration={'revision': self.revision, 'mode': 'vanilla', 'status': 'running'})

    def transport(self, identity):
        relay = self
        class Endpoint:
            api_prefix = '/api/team'
            def close(self): pass
            def operation_deadline(self, *_): return nullcontext()
            def exchange(self, operation, **fields):
                if operation in ('status', 'heartbeat'):
                    return relay.status()
                if operation == 'signal':
                    key = identity, fields['recipient_id'], fields['slot']
                    assert key not in relay.signals or relay.signals[key] == fields['payload']
                    relay.signals[key] = fields['payload']
                    return {'ok': True}
                if operation == 'signals':
                    return {'signals': [dict(peer_id=a, recipient_id=b, slot=s, payload=p)
                                        for (a, b, s), p in relay.signals.items() if b == identity]}
                if operation == 'poll':
                    return {'messages': [dict(metadata, size=len(data), sha256=hashlib.sha256(data).hexdigest())
                                         for mid, (metadata, data) in relay.packets.items()
                                         if metadata['recipient_id'] == identity and mid not in relay.acked]}
                if operation == 'ack':
                    relay.acked.update(fields['message_ids']); return {'ok': True}
                if operation == 'consume':
                    relay.consumed.update(fields['message_ids']); return {'ok': True}
                if operation == 'collaboration':
                    assert fields['expected_revision'] == relay.revision
                    relay.revision += 1
                    return relay.status()
                raise AssertionError(operation)
            def send_packet(self, metadata, png):
                assert metadata['sender_id'] == identity
                relay.uploads.append((dict(metadata), png))
                if relay.fail_recipient == metadata['recipient_id']:
                    raise HubError(503)
                prior = relay.packets.get(metadata['message_id'])
                if prior:
                    assert prior == (metadata, png)
                else:
                    if metadata['collaboration_revision'] != relay.revision:
                        raise HubError(409)
                    relay.packets[metadata['message_id']] = (dict(metadata), png)
                return {'message_id': metadata['message_id'], 'state': 'stored'}
            def read_packet(self, message_id):
                metadata, png = relay.packets[message_id]
                assert metadata['recipient_id'] == identity
                return png
        return Endpoint()


@pytest.fixture
def team(tmp_path):
    relay, runtimes = Relay(), []
    def add(identity, secret='00700042'):
        owner = Owner.capture(os.getpid())
        relay.peers[identity] = dict(peer_id=identity, role=chr(97 + len(relay.peers)), join_order=len(relay.peers))
        runtime = group_class()(dict(state_dir=str(tmp_path / identity), owner_pid=owner.pid,
            owner_started_at=owner.started_at, hub='http://127.0.0.1:1', secret=secret,
            member=dict(room_id='room', peer_id=identity, role=relay.peers[identity]['role'], token='synthetic',
                        session_id='session', expires_at=time.time() + 3600, room_mode='group',
                        group_protocol='coagen-group/1', max_members=8, leader_peer_id='a')))
        runtime.transport.close(); runtime.transport = relay.transport(identity)
        runtimes.append(runtime)
        return runtime
    def pair():
        for _ in range(5):
            for runtime in runtimes:
                runtime._pair(relay.status())
    yield relay, add, pair
    for runtime in runtimes:
        runtime.stop_event.set()
        runtime._close_crypto()


def test_mcp_exposes_group_name_six_hour_limit_and_collaboration_contract():
    tools = {item['name']: item['inputSchema']['properties'] for item in mcp.TOOLS}
    assert tools['coagen_create']['ttl']['maximum'] == 21600
    assert tools['coagen_create']['label']['maxLength'] == 128
    assert tools['coagen_create']['room_mode']['enum'] == ['basic', 'group']
    assert tools['coagen_send']['recipient_id']['type'] == 'string'
    assert tools['coagen_send']['broadcast']['type'] == 'boolean'
    assert tools['coagen_collaboration']['expected_revision']['type'] == 'integer'


def test_three_peers_use_three_separate_pairwise_ciphers_and_direct_unicode_delivery(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c')
    pair()
    assert all(peer.status()['phase'] == 'ready' for peer in (a, b, c))
    assert len({link.cipher.session_id for p in (a, b, c) for link in p.links.values()}) == 3
    sent = b.send({'text': '独立对等加密🧪', 'recipient_id': 'c', 'request_id': 'direct'})
    received = c.receive({})['messages']
    assert len(received) == 1 and '独立对等加密🧪' in received[0]['readme']
    assert received[0]['sender_id'] == 'b' and received[0]['recipient_id'] == 'c'
    assert not a.receive({})['messages']
    assert sent['state'] == 'sent'
    assert all('独立对等加密'.encode() not in png for _, png in relay.packets.values())
    c.consume(received[0]['message_id'])
    assert received[0]['message_id'] in relay.consumed


def test_group_requires_explicit_target_and_discovers_later_members(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    assert a.send({'text': 'one', 'request_id': 'one'})['state'] == 'sent'
    old_cipher = a.links['b'].cipher
    c = add('c'); pair()
    assert a.links['b'].cipher is old_cipher and a.links['c'].cipher is not old_cipher
    with pytest.raises(ValueError):
        a.send({'text': 'ambiguous', 'request_id': 'ambiguous'})
    assert c.status()['phase'] == 'ready'


def test_broadcast_retry_freezes_recipients_and_original_ciphertext(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c'); pair()
    relay.fail_recipient = 'c'
    partial = a.send({'text': 'frozen', 'broadcast': True, 'request_id': 'broadcast'})
    assert partial['state'] == 'partial' and len(partial['deliveries']) == 2
    failed_png = next(png for meta, png in relay.uploads if meta['recipient_id'] == 'c')
    d = add('d'); pair()
    relay.fail_recipient = None
    with a.store.db() as db:
        db.execute('UPDATE outgoing SET next_attempt_at=0')
    complete = a.retry_saved_packet('broadcast')
    assert complete['state'] == 'sent'
    assert {row['recipient_id'] for row in complete['deliveries']} == {'b', 'c'}
    assert sum(meta['recipient_id'] == 'b' for meta, _ in relay.uploads) == 1
    assert [png for meta, png in relay.uploads if meta['recipient_id'] == 'c'] == [failed_png, failed_png]
    assert not d.receive({})['messages']


def test_bad_new_member_does_not_destroy_existing_channel(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    add('c', secret='wrong-code'); pair()
    assert a.links['b'].cipher is not None and a.status()['phase'] == 'ready'
    assert a.send({'text': 'still healthy', 'recipient_id': 'b', 'request_id': 'healthy'})['state'] == 'sent'
    assert b.receive({})['messages']


def test_collaboration_control_is_explicit_and_updates_authenticated_revision(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    result = a.dispatch({'op': 'collaboration', 'action': 'pause', 'expected_revision': 1, 'request_id': 'pause'})
    assert result['collaboration']['revision'] == 2
    assert a.status()['collaboration']['revision'] == 2


def test_status_dispatch_refreshes_policy_and_keeps_cipher_after_leadership_change(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    cipher = a.links['b'].cipher
    relay.revision = 5
    result = a.dispatch({'op': 'status'})
    assert result['collaboration']['revision'] == 5
    assert a.links['b'].cipher is cipher


def test_departed_sender_pending_packet_remains_decryptable(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c'); pair()
    a.send({'text': 'before leave', 'recipient_id': 'b', 'request_id': 'departed'})
    del relay.peers['a']
    b._pair(relay.status())
    assert b.links['a'].state == 'left'
    assert 'before leave' in b.receive({})['messages'][0]['readme']
    with pytest.raises(ValueError):
        b.send({'text': 'after leave', 'recipient_id': 'a', 'request_id': 'left'})


def test_policy_rejected_unicast_raises_but_other_target_still_works(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c'); pair()
    original = b.transport.send_packet
    def policy(metadata, png):
        if metadata['recipient_id'] == 'c':
            raise HubError(403)
        return original(metadata, png)
    b.transport.send_packet = policy
    with pytest.raises(ValueError) as rejected:
        b.send({'text': 'not permitted', 'recipient_id': 'c', 'request_id': 'policy'})
    assert rejected.value.http_status == 403
    assert b.send({'text': 'permitted', 'recipient_id': 'a', 'request_id': 'allowed'})['state'] == 'sent'


def test_pairwise_metadata_tampering_is_rejected_before_business_delivery(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c'); pair()
    sent = a.send({'text': 'authenticated', 'recipient_id': 'c', 'request_id': 'auth'})
    metadata, png = relay.packets[sent['message_id']]
    metadata['collaboration_revision'] += 1
    with pytest.raises(ValueError):
        c.receive({})
    assert sent['message_id'] not in relay.acked
    assert c.store.pending() == []


def test_all_eight_members_pair_without_brand_or_leader_dependent_keys(team):
    relay, add, pair = team
    members = [add(identity) for identity in 'hgfedcba']
    pair()
    assert all(len(member.status()['ready_peer_ids']) == 7 for member in members)
    assert len({link.cipher.session_id for member in members for link in member.links.values()}) == 28


def test_close_destroys_every_pairwise_key_and_in_memory_room_secret(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c'); pair()
    a._close_crypto()
    assert a.secret is None
    for link in a.links.values():
        with pytest.raises(ValueError):
            link.cipher.confirmation()


def test_notification_poll_never_causes_a_group_hub_status_request(team):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    a.transport.exchange = lambda *args, **kwargs: pytest.fail('Local notification status contacted Hub')
    assert a.dispatch({'op': 'status', 'local_only': True})['phase'] == 'ready'


def test_unresolved_upload_blocks_new_message_only_to_its_affected_target(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c'); pair()
    relay.fail_recipient = 'b'
    with pytest.raises(ValueError):
        a.send({'text': 'uncertain', 'recipient_id': 'b', 'request_id': 'uncertain'})
    with pytest.raises(ValueError) as blocked:
        a.send({'text': 'duplicate risk', 'recipient_id': 'b', 'request_id': 'different-id'})
    assert blocked.value.code == 'PENDING_SEND'
    assert a.send({'text': 'other pair', 'recipient_id': 'c', 'request_id': 'safe-other'})['state'] == 'sent'


def test_exhausted_status_recovery_keeps_normal_heartbeat_cadence(team, monkeypatch):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    module = importlib.import_module('coagen_client.group_runtime')
    clock = [100.0]
    requests = []
    original = a.transport.exchange
    def exchange(op, **fields):
        requests.append((op, clock[0]))
        if clock[0] < 130:
            raise HubError(503)
        return original(op, **fields)
    a.transport.exchange = exchange
    monkeypatch.setattr(module, 'time', SimpleNamespace(monotonic=lambda: clock[0], time=time.time))
    monkeypatch.setattr(a, 'active', lambda: clock[0] < 135)
    monkeypatch.setattr(a.stop_event, 'wait', lambda seconds: clock.__setitem__(0, clock[0] + seconds))
    monkeypatch.setattr(a, 'shutdown', lambda *_: None)
    a.worker()
    assert any(op == 'heartbeat' and when >= 130 for op, when in requests)
    # 0.7.4: failures back off 2, 4, 8, 16 s (capped at the heartbeat
    # interval), renewing the lease sooner than a full interval but bounded.
    outage = [when for op, when in requests if when < 130]
    assert len(outage) <= 5
    gaps = [later - earlier for earlier, later in zip(outage, outage[1:])]
    assert gaps == sorted(gaps) and all(gap >= 2 for gap in gaps)
    assert a.last_heartbeat_at is not None
    assert a.status()['connection']['state'] == 'ok'


@pytest.mark.parametrize('change', ['room_id', 'session_id', 'legacy_plan'])
@pytest.mark.parametrize('operation', ['send', 'retry'])
def test_reused_state_never_reports_another_session_plan_as_delivered(team, change, operation):
    relay, add, pair = team
    a, b = add('a'), add('b'); pair()
    args = {'text': 'same content', 'request_id': 'fixed-task-id'}
    assert a.send(args)['state'] == 'sent'
    if change == 'legacy_plan':
        plan = a.store.group_plan('fixed-task-id')
        plan.pop('room_id', None); plan.pop('session_id', None)
        with a.store.db() as db:
            db.execute('UPDATE group_plans SET plan=? WHERE request_id=?', (json.dumps(plan), 'fixed-task-id'))
    else:
        a.member[change] = 'new-' + change
    with pytest.raises(ValueError) as conflict:
        a.send(args) if operation == 'send' else a.retry_saved_packet('fixed-task-id')
    assert conflict.value.code == 'REQUEST_CONFLICT'
    assert len(relay.uploads) == 1
