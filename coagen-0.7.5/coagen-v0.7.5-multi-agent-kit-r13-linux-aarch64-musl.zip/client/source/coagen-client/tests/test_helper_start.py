"""Helper startup: slow starts succeed, failures say exactly why, secrets never leak."""
import json
import os
import subprocess
import sys
import time

import pytest

from coagen_client import cli
from coagen_client.errors import CoagenError

SECRET = 'PAIRING-SECRET-77777777'
TOKEN = 'MemberTokenAbcdefGhijkl0123456789xyzQRS'


def fake_helper(monkeypatch, script):
    """Run `script` in place of the real helper, with the parent's real arguments."""
    spawn = subprocess.Popen

    def popen(command, **kwargs):
        assert command[command.index('_serve') + 1] == '--progress'
        return spawn([sys.executable, '-c', script, *command[command.index('_serve') + 1:]], **kwargs)
    monkeypatch.setattr(cli.subprocess, 'Popen', popen)


def config(tmp_path):
    state = tmp_path / 'state 状态'
    state.mkdir()
    return {'state_dir': str(state), 'secret': SECRET, 'member': {'room_id': 'room-x', 'token': TOKEN}}


PROGRESS = ("import json,sys,time\n"
            "args=dict(zip(sys.argv[1::2],sys.argv[2::2]));p=args['--progress'];t0=float(args['--spawned-at'])\n"
            "cfg=json.loads(sys.stdin.readline());stages=[]\n"
            "def mark(s):\n"
            "    stages.append({'stage':s,'t':round(time.time()-t0,3)});open(p,'w').write(json.dumps({'last_stage':s,'stages':stages}))\n")


def test_slow_start_within_the_deadline_succeeds(tmp_path, monkeypatch):
    monkeypatch.setenv('COAGEN_HELPER_START_TIMEOUT', '20')
    fake_helper(monkeypatch, PROGRESS + "mark('cli_imported');time.sleep(11);"
                "import pathlib;(pathlib.Path(cfg['state_dir'])/'control.json').write_text('{}');time.sleep(30)")
    started = time.monotonic()
    result = cli.launch_session(config(tmp_path))
    assert 10.5 < time.monotonic() - started < 20
    assert result['phase'] == 'starting' and result['helper_start_seconds'] > 10
    os.kill(result['helper_pid'], 9)


def test_early_exit_reports_exit_code_stage_and_redacted_stderr(tmp_path, monkeypatch):
    fake_helper(monkeypatch, PROGRESS + "mark('cli_imported');mark('config_read');"
                f"sys.stderr.write('boom while using {SECRET} and {TOKEN}\\n');sys.exit(3)")
    with pytest.raises(CoagenError) as caught:
        cli.launch_session(config(tmp_path))
    report = caught.value.to_dict()
    assert report['code'] == 'LOCAL_HELPER_EXITED'
    assert report['context']['exit_code'] == 3
    assert report['context']['last_stage'] == 'config_read'
    assert report['context']['stopped_by_parent'] is False
    assert any('boom while using' in line for line in report['context']['stderr_tail'])
    assert SECRET not in json.dumps(report) and TOKEN not in json.dumps(report)
    assert 'exit_code: 3' in report['facts'] and 'last_stage: config_read' in report['facts']


def test_timeout_stops_only_its_own_helper_and_names_the_slow_stage(tmp_path, monkeypatch):
    monkeypatch.setenv('COAGEN_HELPER_START_TIMEOUT', '5')
    fake_helper(monkeypatch, PROGRESS + "mark('cli_imported');mark('runtime_imported');time.sleep(120)")
    started = time.monotonic()
    with pytest.raises(CoagenError) as caught:
        cli.launch_session(config(tmp_path))
    assert 4.9 < time.monotonic() - started < 15
    context = caught.value.context
    assert caught.value.code == 'LOCAL_HELPER_START_TIMEOUT'
    assert context['stopped_by_parent'] is True and context['timeout_seconds'] == 5
    assert context['last_stage'] == 'runtime_imported' and 'runtime_imported' in context['stage_seconds']
    assert 'COAGEN_HELPER_START_TIMEOUT' in caught.value.to_dict()['next_action']


def test_spawn_failure_is_its_own_code(tmp_path, monkeypatch):
    monkeypatch.setattr(cli.sys, 'executable', str(tmp_path / 'missing-python'))
    with pytest.raises(CoagenError) as caught:
        cli.launch_session(config(tmp_path))
    report = caught.value.to_dict()
    assert report['code'] == 'LOCAL_HELPER_SPAWN_FAILED'
    assert report['cause']['category'] in ('file_not_found', 'process_spawn_failed', 'permission_denied')
    assert report['cause']['chain'][0]['type'] == 'FileNotFoundError'


def test_real_helper_initialization_failure_explains_itself(tmp_path, monkeypatch):
    """The actual `_serve` entry with an owner that has exited: the true reason reaches the host."""
    cfg = config(tmp_path)
    cfg.update(hub='http://127.0.0.1:9', owner_pid=os.getpid(), owner_started_at=1.0, agent_info=None,
               member={'room_id': 'room-x', 'token': TOKEN, 'room_mode': 'basic', 'expires_at': time.time() + 60})
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'appdata'))
    with pytest.raises(CoagenError) as caught:
        cli.launch_session(cfg)
    report = caught.value.to_dict()
    assert report['code'] == 'LOCAL_HELPER_EXITED'
    assert report['context']['last_stage'] == 'secure_directory'
    assert report['context']['helper_error']['code'] == 'INVALID_ARGUMENT'
    assert any('owning agent has already exited' in line for line in report['context']['stderr_tail'])
    assert TOKEN not in json.dumps(report)
    assert (tmp_path / 'state 状态' / 'helper-stderr.log').stat().st_size > 0


def test_cleanup_result_is_reported_not_assumed(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, 'launch_session', lambda config: (_ for _ in ()).throw(
        CoagenError('LOCAL_HELPER_START_TIMEOUT', stage='launch_helper', outcome='hub_accepted')))
    cfg = {'hub': 'http://127.0.0.1:9', 'member': {'room_id': 'r', 'token': 't', 'room_mode': 'group'}}
    with pytest.raises(CoagenError) as caught:
        cli.launch_or_close(cfg, 'join')
    cleanup = caught.value.to_dict()['context']['cleanup']
    assert caught.value.operation == 'join'
    assert cleanup['operation'] == 'leave' and cleanup['result'] == 'unconfirmed'
    assert cleanup['category'] == 'connection_refused'
