import httpx
import pytest

from coagen_client.transport import Transport


def test_json_response_is_bounded_before_buffering():
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    transport.client = httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, content=b'x' * (1024 * 1024 + 1))))
    with pytest.raises(ValueError, match='limit'):
        transport.exchange('status')
    transport.close()


def test_packet_response_is_bounded_before_png_parser():
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    transport.client = httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, content=b'x' * (17 * 1024 * 1024))))
    with pytest.raises(ValueError, match='limit'):
        transport.read_packet('message')
    transport.close()


def test_download_checks_session_while_streaming():
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    class Body(httpx.SyncByteStream):
        def __iter__(self):
            yield b'x' * 65536
            yield b'y' * 65536
    transport.client = httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, stream=Body())))
    calls = []
    def guard():
        calls.append(1)
        if len(calls) >= 2:
            raise ValueError('expired')
    transport.check_active = guard
    with pytest.raises(ValueError, match='expired'):
        transport.read_packet('message')
    transport.close()
