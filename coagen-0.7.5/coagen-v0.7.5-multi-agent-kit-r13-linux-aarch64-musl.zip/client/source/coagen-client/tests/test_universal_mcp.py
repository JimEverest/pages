"""Vendor-neutral stdio ownership and optional display metadata contracts."""
import io
import json
import os
import threading
from unittest.mock import Mock

import pytest

from coagen_client import cli, mcp


@pytest.fixture(autouse=True)
def isolated_diagnostics(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    monkeypatch.delenv('COAGEN_AGENT_NAME', raising=False)
    monkeypatch.delenv('COAGEN_AGENT_VERSION', raising=False)


def initialize(server, info):
    return server.handle({'id': 1, 'method': 'initialize', 'params': {'clientInfo': info}})


def prepare(server):
    return json.loads(server.call('coagen_prepare', {})['content'][0]['text'])


def test_default_owner_is_mcp_instance_without_vendor_discovery(monkeypatch, tmp_path):
    monkeypatch.setattr(mcp, 'discover_owner_pid', Mock(side_effect=AssertionError('No vendor discovery')))
    first = mcp.McpServer(workspace=tmp_path)
    second = mcp.McpServer(workspace=tmp_path)
    assert first.owner_pid == second.owner_pid == os.getpid()
    assert prepare(first)['binding_scope'] == 'mcp_instance'
    assert first.diagnostic_root != second.diagnostic_root
    assert first.state_dir is None and second.state_dir is None


def test_initialize_reports_unicode_future_agent_without_brand_gate(tmp_path):
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    assert 'error' not in initialize(server, {'name': '未来 Agent 🦊', 'version': 'next/whatever'})
    assert prepare(server)['agent_info'] == {
        'name': '未来 Agent 🦊', 'version': 'next/whatever', 'client_version': cli.__version__}
    assert prepare(server)['agent_info_self_reported'] is True
    assert prepare(server)['binding_scope'] == 'explicit_owner'


def test_missing_identity_is_null_and_explicit_overrides_environment_and_client_info(monkeypatch, tmp_path):
    assert prepare(mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid()))['agent_info']['version'] is None
    monkeypatch.setenv('COAGEN_AGENT_NAME', 'Environment Agent')
    monkeypatch.setenv('COAGEN_AGENT_VERSION', 'env-version')
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid(), agent_name='Explicit Agent')
    initialize(server, {'name': 'Client Agent', 'version': 'client-version'})
    assert prepare(server)['agent_info'] == {
        'name': 'Explicit Agent', 'version': 'env-version', 'client_version': cli.__version__}


@pytest.mark.parametrize('info', [[], '', 0, {'name': 'x\ncommand'}, {'version': 'x\x7f'}, {'name': 3},
                                {'name': 'x' * 129}, {'version': 'x' * 65}, {'name': '\ud800'}])
def test_invalid_client_metadata_is_rejected_without_reflection(info, tmp_path):
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    result = initialize(server, info)
    assert result['error']['code'] == -32602
    assert 'command' not in json.dumps(result)


def test_create_and_join_receive_resolved_metadata(monkeypatch, tmp_path):
    function = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'create', function)
    monkeypatch.setattr(cli, 'join', function)
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    initialize(server, {'name': 'Future Agent', 'version': 'beta'})
    server.call('coagen_create', {'state_dir': str(tmp_path / 'a')})
    assert function.call_args.args[0].agent_info == prepare(server)['agent_info']
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    initialize(server, {'name': 'Future Agent', 'version': 'beta'})
    server.call('coagen_join', {'code': '00700042', 'state_dir': str(tmp_path / 'b')})
    assert function.call_args.args[0].agent_info == prepare(server)['agent_info']


def test_stdio_eof_calls_disconnect_cleanup_once(monkeypatch, tmp_path):
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    server.close = Mock()
    monkeypatch.setattr(mcp.sys, 'stdin', io.StringIO(''))
    monkeypatch.setattr(mcp.sys, 'stdout', io.StringIO())
    mcp.serve_stdio(server)
    server.close.assert_called_once_with()


def test_disconnect_cleanup_is_bounded_even_if_local_helper_hangs(monkeypatch, tmp_path):
    server = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid(), state_dir=tmp_path / 'state')
    started, unblock, completed = threading.Event(), threading.Event(), threading.Event()
    def blocked(*args, **kwargs):
        started.set()
        unblock.wait(10)
    monkeypatch.setattr(cli, 'call_local', blocked)
    worker = threading.Thread(target=lambda: (server.close(), completed.set()), daemon=True)
    worker.start()
    try:
        assert started.wait(1)
        assert completed.wait(5), 'MCP disconnect must not wait for a stalled IPC request'
    finally:
        unblock.set()
        worker.join(1)


def test_create_join_and_mcp_cli_accept_optional_identity():
    for operation, extra in [('mcp', []), ('create', ['--state-dir', 'state']), ('join', ['--state-dir', 'state'])]:
        args = cli.parser().parse_args([operation, *extra, '--agent-name', '未来 Agent', '--agent-version', 'beta'])
        assert args.agent_name == '未来 Agent' and args.agent_version == 'beta'


def test_default_instance_cannot_adopt_another_instances_explicit_state(tmp_path):
    state = tmp_path / 'state'
    state.mkdir()
    (state / 'control.json').write_text(json.dumps({
        'url': 'http://127.0.0.1:1/rpc', 'token': 'not-for-this-instance',
        'owner_pid': os.getpid(), 'mcp_instance_id': 'another-instance'}), encoding='utf-8')
    with pytest.raises(ValueError, match='instance'):
        mcp.McpServer(workspace=tmp_path, state_dir=state)


def test_replaced_state_cannot_be_used_or_stopped_by_another_instance(monkeypatch, tmp_path):
    server = mcp.McpServer(workspace=tmp_path)
    state = tmp_path / 'state'
    state.mkdir()
    server.state_dir = state
    (state / 'control.json').write_text(json.dumps({'owner_pid': 1, 'mcp_instance_id': 'other'}), encoding='utf-8')
    helper = Mock(side_effect=AssertionError('Must not access another MCP instance'))
    monkeypatch.setattr(cli, 'call_local', helper)
    with pytest.raises(ValueError, match='instance'):
        server.call('coagen_status', {})
    server.close()
    helper.assert_not_called()


def test_stdio_saturated_queue_does_not_keep_disconnected_host_alive(monkeypatch):
    release, finished = threading.Event(), threading.Event()
    server = Mock()
    server.poll_notifications.return_value = []
    server.handle.side_effect = lambda _: release.wait(12) or None
    incoming = io.StringIO(''.join(json.dumps({'id': n, 'method': 'ping'}) + '\n' for n in range(100)))
    output = io.StringIO()
    monkeypatch.setattr(mcp.sys, 'stdin', incoming)
    monkeypatch.setattr(mcp.sys, 'stdout', output)
    thread = threading.Thread(target=lambda: (mcp.serve_stdio(server), finished.set()), daemon=True)
    thread.start()
    try:
        assert finished.wait(7), 'A full request queue must not prevent bounded disconnection'
        assert 'queue capacity' in output.getvalue()
        server.close.assert_called_once_with()
    finally:
        release.set()
        thread.join(2)


def test_stdio_entry_honors_hub_environment_unless_hub_is_explicit(monkeypatch, tmp_path):
    """install-mcp and host descriptors set COAGEN_MCP_HUB; the CLI default must not mask it."""
    seen = []
    monkeypatch.setattr(mcp, 'serve_stdio', lambda server: seen.append(server.hub))
    monkeypatch.setenv('COAGEN_MCP_HUB', 'http://127.0.0.1:9')
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'state'))
    assert cli.main(['mcp', '--workspace', str(tmp_path)]) == 0
    assert cli.main(['mcp', '--workspace', str(tmp_path), '--hub', 'https://example.test/coagen']) == 0
    monkeypatch.delenv('COAGEN_MCP_HUB')
    assert cli.main(['mcp', '--workspace', str(tmp_path)]) == 0
    assert seen == ['http://127.0.0.1:9', 'https://example.test/coagen', cli.DEFAULT_HUB]
