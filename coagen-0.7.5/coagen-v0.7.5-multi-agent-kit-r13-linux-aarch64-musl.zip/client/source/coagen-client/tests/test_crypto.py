"""Behavior and upstream compatibility checks for the client-only crypto boundary."""
import pickle

import pytest
from spake2.test.test_compat import SPAKE2 as UpstreamVectors

from coagen_client.crypto import CryptoError, Pairing, ReplayError, StateError


CONTEXT = {"server_session_id": "session-1", "peer_a": "opaque-a", "peer_b": "opaque-b"}


def pair(secret_a="test-invite", secret_b="test-invite", room_a="room-1", room_b="room-1", context_b=None):
    a = Pairing(secret_a, room_a, "A", context=CONTEXT)
    b = Pairing(secret_b, room_b, "B", context=CONTEXT if context_b is None else context_b)
    first, second = a.start(), b.start()
    return a.finish(second), b.finish(first)


def confirmed():
    a, b = pair()
    a.verify_confirmation(b.confirmation())
    b.verify_confirmation(a.confirmation())
    return a, b


def test_upstream_asymmetric_compatibility_vectors():
    UpstreamVectors("test_asymmetric").test_asymmetric()


def test_confirmed_bidirectional_unicode_and_binary_roundtrip():
    a, b = confirmed()
    assert a.session_id == b.session_id
    data = "协作任务".encode() + bytes(range(256))
    metadata = {"message_id": "m1", "expires_at": 2000000000}
    ab = a.encrypt(data, sequence=1, metadata=metadata)
    ba = b.encrypt(data, sequence=1, metadata=metadata)
    assert ab != ba and data not in ab
    assert b.decrypt(ab, sequence=1, metadata=metadata) == data
    assert a.decrypt(ba, sequence=1, metadata=metadata) == data


def test_both_directions_require_confirmation_before_data():
    a, _ = pair()
    with pytest.raises(StateError):
        a.encrypt(b"text", sequence=1, metadata={})
    with pytest.raises(StateError):
        a.decrypt(bytes(16), sequence=1, metadata={})


@pytest.mark.parametrize("changes", [{"secret_b": "wrong"}, {"room_b": "other"}, {"context_b": {**CONTEXT, "peer_a": "attacker"}}, {"context_b": {**CONTEXT, "server_session_id": "other"}}])
def test_wrong_secret_room_or_peer_context_cannot_confirm(changes):
    a, b = pair(**changes)
    with pytest.raises(CryptoError):
        a.verify_confirmation(b.confirmation())
    with pytest.raises(StateError):
        a.encrypt(b"text", sequence=1, metadata={})


def test_reflected_confirmation_and_data_rejected():
    a, b = pair()
    with pytest.raises(CryptoError):
        a.verify_confirmation(a.confirmation())
    a, b = confirmed()
    packet = a.encrypt(b"x", sequence=1, metadata={})
    with pytest.raises(CryptoError):
        a.decrypt(packet, sequence=1, metadata={})


def test_ciphertext_metadata_sequence_and_session_tampering_rejected():
    a, b = confirmed()
    metadata = {"message_id": "m1"}
    packet = a.encrypt(b"task", sequence=7, metadata=metadata)
    with pytest.raises(CryptoError):
        b.decrypt(packet[:-1] + bytes([packet[-1] ^ 1]), sequence=7, metadata=metadata)
    with pytest.raises(CryptoError):
        b.decrypt(packet, sequence=7, metadata={"message_id": "m2"})
    with pytest.raises(CryptoError):
        b.decrypt(packet, sequence=8, metadata=metadata)
    _, other = confirmed()
    with pytest.raises(CryptoError):
        other.decrypt(packet, sequence=7, metadata=metadata)
    assert b.decrypt(packet, sequence=7, metadata=metadata) == b"task"


def test_replay_and_nonce_reuse_rejected_but_out_of_order_delivery_allowed():
    a, b = confirmed()
    first = a.encrypt(b"first", sequence=1, metadata={})
    second = a.encrypt(b"second", sequence=2, metadata={})
    with pytest.raises(ReplayError):
        a.encrypt(b"changed", sequence=1, metadata={})
    assert b.decrypt(second, sequence=2, metadata={}) == b"second"
    assert b.decrypt(first, sequence=1, metadata={}) == b"first"
    with pytest.raises(ReplayError):
        b.decrypt(first, sequence=1, metadata={})


def test_repeated_handshake_methods_and_wrong_sides_rejected():
    a, b = Pairing("secret", "r", "A"), Pairing("secret", "r", "B")
    first, second = a.start(), b.start()
    with pytest.raises(StateError):
        a.start()
    with pytest.raises(CryptoError):
        b.finish(second)
    a.finish(second)
    with pytest.raises(StateError):
        a.finish(second)


@pytest.mark.parametrize("data", [b"", b"B", b"B" + bytes(32), b"B" + b"\xff" * 32, b"B" + bytes(4096)])
def test_malformed_group_messages_rejected(data):
    a = Pairing("secret", "room", "A")
    a.start()
    with pytest.raises(CryptoError):
        a.finish(data)


@pytest.mark.parametrize("sequence", [0, -1, 2**64, True, "1"])
def test_invalid_sequence_rejected(sequence):
    a, _ = confirmed()
    with pytest.raises(CryptoError):
        a.encrypt(b"x", sequence=sequence, metadata={})


@pytest.mark.parametrize("metadata", [{"x": float("nan")}, {"x": b"bytes"}, {1: "non-string-key"}, {"x": "z" * 16384}], ids=["nan", "bytes", "key", "size"])
def test_invalid_metadata_rejected(metadata):
    a, _ = confirmed()
    with pytest.raises(CryptoError):
        a.encrypt(b"x", sequence=1, metadata=metadata)


def test_secrets_not_in_repr_and_crypto_state_not_serializable():
    p = Pairing("do-not-show-this-secret", "r", "A")
    assert "do-not-show-this-secret" not in repr(p)
    a, _ = confirmed()
    with pytest.raises(TypeError):
        pickle.dumps(p)
    with pytest.raises(TypeError):
        pickle.dumps(a)


def test_close_drops_data_access():
    a, _ = confirmed()
    a.close()
    with pytest.raises(StateError):
        a.encrypt(b"x", sequence=1, metadata={})
    with pytest.raises(StateError):
        a.confirmation()


def test_confirmation_retries_return_identical_bytes():
    a, b = pair()
    assert a.confirmation() == a.confirmation()
    a.verify_confirmation(b.confirmation())
    assert a.confirmation() == a.confirmation()


def test_version_mismatch_cannot_complete_pairing(monkeypatch):
    import coagen_client.crypto as crypto
    a = Pairing("secret", "room", "A", context=CONTEXT)
    monkeypatch.setattr(crypto, "PROTOCOL", "coagen/obsolete")
    b = Pairing("secret", "room", "B", context=CONTEXT)
    first, second = a.start(), b.start()
    left, right = a.finish(second), b.finish(first)
    with pytest.raises(CryptoError):
        left.verify_confirmation(right.confirmation())


def test_receive_capacity_and_plaintext_limits_are_bounded(monkeypatch):
    import coagen_client.crypto as crypto
    a, b = confirmed()
    monkeypatch.setattr(crypto, "MAX_PLAINTEXT_BYTES", 32)
    with pytest.raises(CryptoError):
        a.encrypt(bytes(33), sequence=1, metadata={})
    first = a.encrypt(bytes(32), sequence=1, metadata={})
    second = a.encrypt(b"x", sequence=2, metadata={})
    assert b.decrypt(first, sequence=1, metadata={}) == bytes(32)
    monkeypatch.setattr(crypto, "MAX_MESSAGES", 1)
    with pytest.raises(StateError):
        b.decrypt(second, sequence=2, metadata={})
    with pytest.raises(StateError):
        a.encrypt(b"x", sequence=3, metadata={})
