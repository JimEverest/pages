"""Windows owner identity must use the kernel termination state, not PID visibility."""
import ctypes
from ctypes import wintypes
import os
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import Mock

import psutil
import pytest

from coagen_client import lifecycle
from coagen_client.lifecycle import Owner


@pytest.fixture
def windows_owner(monkeypatch):
    pid, started = 12345, 1700000000.0
    process = Mock()
    process.is_running.return_value = True
    process.status.return_value = psutil.STATUS_RUNNING
    process.create_time.return_value = started
    monkeypatch.setattr(lifecycle.psutil, 'Process', Mock(return_value=process))
    monkeypatch.setattr(lifecycle, 'os', SimpleNamespace(name='nt'), raising=False)
    kernel = SimpleNamespace(OpenProcess=Mock(return_value=77),
                             GetProcessTimes=Mock(),
                             WaitForSingleObject=Mock(return_value=258),
                             CloseHandle=Mock(return_value=1))

    def process_times(_handle, creation, _exit, _kernel, _user):
        value = int((started + 11644473600) * 10000000)
        output = ctypes.cast(creation, ctypes.POINTER(wintypes.FILETIME)).contents
        output.dwLowDateTime = value & 0xffffffff
        output.dwHighDateTime = value >> 32
        return 1

    kernel.GetProcessTimes.side_effect = process_times
    monkeypatch.setattr(ctypes, 'WinDLL', Mock(return_value=kernel), raising=False)
    return Owner(pid, started), kernel, process


def test_signaled_owner_is_dead_even_while_psutil_reports_running(windows_owner):
    owner, kernel, _ = windows_owner
    kernel.WaitForSingleObject.return_value = 0
    assert owner.alive() is False
    kernel.WaitForSingleObject.assert_called_once_with(77, 0)
    kernel.CloseHandle.assert_called_once_with(77)


def test_live_owner_uses_same_handle_identity_and_nonblocking_wait(windows_owner):
    owner, kernel, _ = windows_owner
    assert owner.alive() is True
    kernel.OpenProcess.assert_called_once_with(0x00100000 | 0x1000, False, owner.pid)
    assert kernel.GetProcessTimes.call_args.args[0] == 77
    kernel.WaitForSingleObject.assert_called_once_with(77, 0)
    kernel.CloseHandle.assert_called_once_with(77)


def test_pid_reuse_cannot_match_the_new_live_process(windows_owner):
    owner, kernel, _ = windows_owner
    assert Owner(owner.pid, owner.started_at + 100).alive() is False
    kernel.CloseHandle.assert_called_once_with(77)


@pytest.mark.parametrize('created', [float('nan'), float('inf'), None, '1700000000'])
def test_invalid_instance_timestamp_is_never_alive(windows_owner, created):
    owner, _, _ = windows_owner
    assert Owner(owner.pid, created).alive() is False


@pytest.mark.parametrize('failure', ['access_denied', 'times_failed', 'wait_failed',
                                    'unexpected_wait', 'times_exception', 'wait_exception'])
def test_native_failure_is_conservatively_dead_and_closes_handle(windows_owner, failure):
    owner, kernel, _ = windows_owner
    if failure == 'access_denied':
        kernel.OpenProcess.return_value = 0
    elif failure == 'times_failed':
        kernel.GetProcessTimes.side_effect = None
        kernel.GetProcessTimes.return_value = 0
    elif failure == 'wait_failed':
        kernel.WaitForSingleObject.return_value = 0xffffffff
    elif failure == 'unexpected_wait':
        kernel.WaitForSingleObject.return_value = 0x80
    elif failure == 'times_exception':
        kernel.GetProcessTimes.side_effect = OSError('test-only API failure')
    else:
        kernel.WaitForSingleObject.side_effect = OSError('test-only API failure')
    assert owner.alive() is False
    if failure == 'access_denied':
        kernel.CloseHandle.assert_not_called()
    else:
        kernel.CloseHandle.assert_called_once_with(77)


def test_non_windows_keeps_pid_instance_and_zombie_checks(monkeypatch):
    monkeypatch.setattr(lifecycle, 'os', SimpleNamespace(name='posix'), raising=False)
    process = Mock()
    process.is_running.return_value = True
    process.status.return_value = psutil.STATUS_RUNNING
    process.create_time.return_value = 100.0
    monkeypatch.setattr(lifecycle.psutil, 'Process', Mock(return_value=process))
    assert Owner(123, 100.0).alive() is True
    assert Owner(123, 101.0).alive() is False
    process.status.return_value = psutil.STATUS_ZOMBIE
    assert Owner(123, 100.0).alive() is False


@pytest.mark.skipif(os.name != 'nt', reason='Real Windows kernel process state')
def test_real_windows_owner_exit_is_immediate_with_stale_psutil_view(monkeypatch):
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'])
    try:
        owner = Owner.capture(child.pid)
        assert owner.alive() is True
        assert Owner(owner.pid, owner.started_at + 100).alive() is False
    finally:
        child.terminate()
        child.wait(timeout=10)
    stale = Mock()
    stale.is_running.return_value = True
    stale.status.return_value = psutil.STATUS_RUNNING
    stale.create_time.return_value = owner.started_at
    monkeypatch.setattr(lifecycle.psutil, 'Process', Mock(return_value=stale))
    # The actual terminated child handle remains retained by Popen. No retry.
    assert owner.alive() is False
