import hashlib
import io
import json
from pathlib import Path
import stat
import warnings
import zipfile

import pytest

from coagen_client import capsule


def manifest_for(files=None, directories=None):
    return {"version": 1, "message_id": "message-1", "kind": "message", "ext": {},
            "files": files or [], "directories": directories or []}


def archive(entries, *, manifest=None, compression=zipfile.ZIP_STORED):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=compression) as output:
        output.writestr("README.md", "Synthetic message")
        if manifest is not False:
            output.writestr("manifest.json", json.dumps(manifest or manifest_for()))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            for name, data in entries:
                output.writestr(name, data)
    return stream.getvalue()


def test_capsule_text_and_unicode_files_and_folders_roundtrip(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    document = source / "笔记.txt"
    document.write_text("合成数据\n", encoding="utf-8")
    folder = source / "project"
    (folder / "nested").mkdir(parents=True)
    (folder / "empty").mkdir()
    (folder / "nested" / "data.bin").write_bytes(bytes(range(256)))
    data = capsule.create_capsule("# Task\nRead this safely.", [document, folder],
                                  message_id="message-1", kind="result", ext={"score": 6})
    assert all(x.compress_type == zipfile.ZIP_STORED for x in zipfile.ZipFile(io.BytesIO(data)).infolist())
    inspected = capsule.inspect_capsule(data)
    assert inspected["manifest"]["message_id"] == "message-1"
    output = capsule.extract_capsule(data, tmp_path / "received")
    assert output["readme"] == "# Task\nRead this safely."
    assert output["manifest"]["ext"] == {"score": 6}
    names = {x["name"]: x for x in output["files"]}
    assert set(names) == {"笔记.txt", "project/nested/data.bin"}
    assert Path(names["笔记.txt"]["path"]).read_text(encoding="utf-8") == "合成数据\n"
    assert Path(names["project/nested/data.bin"]["path"]).read_bytes() == bytes(range(256))
    assert (tmp_path / "received" / "files" / "project" / "empty").is_dir()
    assert document.exists() and (folder / "nested" / "data.bin").exists()


def test_empty_capsule_is_supported(tmp_path):
    data = capsule.create_capsule("", [], message_id="empty")
    result = capsule.extract_capsule(data, tmp_path / "out")
    assert result["files"] == [] and result["readme"] == ""


@pytest.mark.parametrize("path", ["../escape", "/absolute", "files/../escape", "files/a\\b", "files/C:evil",
                                 "files/NUL.txt", "files/trailing. ", "files//double", "files/./dot"])
def test_unsafe_archive_paths_rejected_before_destination_created(tmp_path, path):
    destination = tmp_path / "out"
    with pytest.raises(ValueError):
        capsule.extract_capsule(archive([(path, b"bad")]), destination)
    assert not destination.exists()
    assert sorted(x.name for x in tmp_path.iterdir()) == []


def test_hash_mismatch_rejected_without_writes(tmp_path):
    record = {"name": "files/a.txt", "size": 4, "sha256": "0" * 64}
    data = archive([("files/a.txt", b"data")], manifest=manifest_for([record]))
    with pytest.raises(ValueError, match="hash"):
        capsule.extract_capsule(data, tmp_path / "out")
    assert not (tmp_path / "out").exists()


@pytest.mark.parametrize("entries,metadata", [([], False), ([("README.md", b"duplicate")], None),
                                            ([("extra.txt", b"unknown")], None),
                                            ([], {"version": 1})])
def test_missing_duplicate_unknown_entries_or_schema_rejected(tmp_path, entries, metadata):
    with pytest.raises(ValueError):
        capsule.extract_capsule(archive(entries, manifest=metadata), tmp_path / "out")
    assert not (tmp_path / "out").exists()


def test_symlink_zip_entry_rejected(tmp_path):
    symlink = zipfile.ZipInfo("files/link")
    symlink.create_system = 3
    symlink.external_attr = (stat.S_IFLNK | 0o777) << 16
    data = archive([(symlink, b"target")])
    with pytest.raises(ValueError):
        capsule.extract_capsule(data, tmp_path / "out")


def test_compressed_archive_is_rejected(tmp_path):
    data = archive([], compression=zipfile.ZIP_DEFLATED)
    with pytest.raises(ValueError, match="compression"):
        capsule.extract_capsule(data, tmp_path / "out")


def test_case_collisions_and_file_directory_conflicts_rejected(tmp_path):
    content = b"data"
    for names in [["files/a", "files/A"], ["files/a", "files/a/b"]]:
        files = [{"name": name, "size": 4, "sha256": hashlib.sha256(content).hexdigest()} for name in names]
        with pytest.raises(ValueError):
            capsule.extract_capsule(archive([(name, content) for name in names], manifest=manifest_for(files)), tmp_path / "out")


def test_existing_destination_is_never_overwritten(tmp_path):
    target = tmp_path / "out"
    target.mkdir()
    marker = target / "keep.txt"
    marker.write_text("keep")
    data = capsule.create_capsule("readme", [], message_id="m1")
    with pytest.raises(ValueError):
        capsule.extract_capsule(data, target)
    assert marker.read_text() == "keep"


def test_source_symlink_rejected(tmp_path):
    document = tmp_path / "data"
    document.write_text("data")
    link = tmp_path / "link"
    try:
        link.symlink_to(document)
    except OSError:
        pytest.skip("symlink privilege not available on this platform")
    with pytest.raises(ValueError, match="link"):
        capsule.create_capsule("readme", [link], message_id="m1")


def test_duplicate_source_basenames_rejected(tmp_path):
    for directory in ("one", "two"):
        (tmp_path / directory).mkdir()
        (tmp_path / directory / "same.txt").write_text(directory)
    with pytest.raises(ValueError):
        capsule.create_capsule("readme", [tmp_path / "one" / "same.txt", tmp_path / "two" / "same.txt"], message_id="m1")


def test_size_and_entry_limits_apply_to_create_and_extract(tmp_path, monkeypatch):
    source = tmp_path / "file.bin"
    source.write_bytes(b"x" * 1024)
    data = capsule.create_capsule("readme", [source], message_id="m1")
    monkeypatch.setattr(capsule, "MAX_RAW_BYTES", 512)
    with pytest.raises(ValueError, match="size"):
        capsule.create_capsule("readme", [source], message_id="m1")
    with pytest.raises(ValueError, match="size"):
        capsule.extract_capsule(data, tmp_path / "out")
    monkeypatch.setattr(capsule, "MAX_RAW_BYTES", 8 * 1024 * 1024)
    monkeypatch.setattr(capsule, "MAX_ENTRIES", 2)
    with pytest.raises(ValueError, match="entries"):
        capsule.create_capsule("readme", [source], message_id="m1")
    with pytest.raises(ValueError, match="entries"):
        capsule.extract_capsule(data, tmp_path / "out")


def test_invalid_metadata_and_corrupt_zip_are_rejected(tmp_path):
    for ext in ([1], {"number": float("nan")}, {"bad": "\ud800"}):
        with pytest.raises(ValueError):
            capsule.create_capsule("readme", [], message_id="m1", ext=ext)
    with pytest.raises(ValueError):
        capsule.extract_capsule(b"not a zip", tmp_path / "out")


def test_nested_source_symlink_rejected(tmp_path):
    folder = tmp_path / "folder"
    folder.mkdir()
    target = tmp_path / "outside.txt"
    target.write_text("must not be included")
    try:
        (folder / "link.txt").symlink_to(target)
    except OSError:
        pytest.skip("symlink privilege not available on this platform")
    with pytest.raises(ValueError, match="link"):
        capsule.create_capsule("readme", [folder], message_id="m1")


def test_manifest_missing_file_and_unsafe_directory_rejected(tmp_path):
    record = {"name": "files/missing", "size": 0, "sha256": hashlib.sha256(b"").hexdigest()}
    for manifest in (manifest_for([record]), manifest_for(directories=["files/../escape"])):
        with pytest.raises(ValueError):
            capsule.extract_capsule(archive([], manifest=manifest), tmp_path / "out")
    assert list(tmp_path.iterdir()) == []


def test_partial_extraction_failure_cleans_only_new_destination(tmp_path, monkeypatch):
    existing = tmp_path / "keep.txt"
    existing.write_text("untouched")
    data = capsule.create_capsule("message", [], message_id="m1")
    def fail_replace(*_args):
        raise OSError("injected write failure")
    monkeypatch.setattr(capsule.os, "replace", fail_replace)
    with pytest.raises(OSError, match="injected"):
        capsule.extract_capsule(data, tmp_path / "out")
    assert existing.read_text() == "untouched"
    assert list(tmp_path.iterdir()) == [existing]


def test_nonfinite_or_duplicate_manifest_json_rejected(tmp_path):
    for manifest_json in ('{"version":1,"version":1}',
                          json.dumps(manifest_for()).replace('"ext": {}', '"ext": {"x":1e999}')):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w") as output:
            output.writestr("README.md", "message")
            output.writestr("manifest.json", manifest_json)
        with pytest.raises(ValueError):
            capsule.extract_capsule(stream.getvalue(), tmp_path / "out")
