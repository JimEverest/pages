import os
import json
import time
from contextlib import nullcontext
from unittest.mock import Mock

import pytest

from coagen_client.lifecycle import Owner
from coagen_client.runtime import SessionRuntime


@pytest.fixture
def runtime(tmp_path):
    owner = Owner.capture(os.getpid())
    item = SessionRuntime(dict(state_dir=str(tmp_path), owner_pid=owner.pid,
        owner_started_at=owner.started_at, hub='http://127.0.0.1:1', secret='00700042',
        member=dict(room_id='room', peer_id='a', role='a', token='test-token',
                    session_id='session', expires_at=time.time()+3600)))
    item.transport.close()
    item.transport = Mock()
    item.transport.operation_deadline.side_effect = lambda _deadline: nullcontext()
    return item


def test_status_exposes_heartbeat_notification_without_secret(runtime):
    runtime.pending_count = 3
    runtime.last_heartbeat_at = 123
    status = runtime.status()
    assert status['pending_count'] == 3
    assert status['has_pending'] is True
    assert status['last_heartbeat_at'] == 123
    assert '00700042' not in str(status)


def test_pairing_has_bounded_deadline_after_peer_joins(runtime):
    runtime.pairing_started_at = time.monotonic() - 121
    state = dict(peers=[{'role':'a','peer_id':'a'},{'role':'b','peer_id':'b'}])
    with pytest.raises(ValueError, match='timed out'):
        runtime._pair(state)
    runtime.transport.exchange.assert_not_called()


def test_heartbeat_updates_hint_without_polling_or_reading_packets(runtime):
    runtime.phase = 'ready'
    runtime.transport.exchange.return_value = {'pending_count':2,'has_pending':True}
    runtime.active = Mock(side_effect=[True,False])
    runtime.stop_event.wait = Mock()
    runtime.shutdown = Mock()
    runtime.worker()
    runtime.transport.exchange.assert_called_once_with('heartbeat')
    runtime.transport.read_packet.assert_not_called()
    assert runtime.status()['pending_count'] == 2


def test_heartbeat_persists_non_secret_observability_snapshot(runtime, monkeypatch):
    writes = []
    monkeypatch.setattr('coagen_client.runtime.atomic_private_json',
                        lambda path, value: writes.append((path.name, value)))
    runtime.phase = 'ready'
    runtime.transport.exchange.return_value = {'pending_count': 1, 'has_pending': True}
    runtime.active = Mock(side_effect=[True, False])
    runtime.stop_event.wait = Mock()
    runtime.shutdown = Mock()
    runtime.worker()
    name, value = next(item for item in writes if item[0] == 'heartbeat.json')
    assert value['pending_count'] == 1
    assert value['has_pending'] is True
    assert 'secret' not in json.dumps(value).lower()
