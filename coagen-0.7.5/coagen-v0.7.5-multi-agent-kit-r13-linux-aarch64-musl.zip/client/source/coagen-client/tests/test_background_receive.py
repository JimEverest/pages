"""Offline inbox prefetch tests. No model, real Hub or room is used."""
import hashlib
import json
import os
import threading
import time
from unittest.mock import Mock

import httpx
import pytest

from coagen_client.capsule import create_capsule
from coagen_client.carrier import pack_png
from coagen_client.crypto import Pairing
from coagen_client.lifecycle import Owner
from coagen_client.runtime import SessionRuntime


@pytest.fixture
def inbox(tmp_path):
    owner = Owner.capture(os.getpid())
    runtime = SessionRuntime({'state_dir': str(tmp_path), 'owner_pid': owner.pid,
        'owner_started_at': owner.started_at, 'hub': 'http://127.0.0.1:1', 'secret': 'test-secret',
        'member': {'room_id': 'room', 'peer_id': 'B', 'role': 'b', 'token': 'test',
                   'session_id': 'server', 'expires_at': time.time() + 300}})
    a, b = Pairing('test-secret', 'room', 'A'), Pairing('test-secret', 'room', 'B')
    ah, bh = a.start(), b.start()
    sender, runtime.cipher = a.finish(bh), b.finish(ah)
    sender.verify_confirmation(runtime.cipher.confirmation())
    runtime.cipher.verify_confirmation(sender.confirmation())
    runtime.phase, runtime.other = 'ready', 'A'
    runtime.transport.close()

    class Hub:
        def __init__(self):
            self.messages, self.calls, self.downloads = [], [], []
        def add(self, number):
            message_id = f'{number:032x}'
            metadata = {'room_id': 'room', 'message_id': message_id, 'sender_id': 'A', 'recipient_id': 'B',
                        'expires_at': time.time() + 200, 'sequence': number, 'crypto_session_id': sender.session_id}
            png = pack_png(sender.encrypt(create_capsule('中文私人正文', [], message_id=message_id),
                                          sequence=number, metadata=metadata))
            self.messages.append(({**metadata, 'size': len(png), 'sha256': hashlib.sha256(png).hexdigest()}, png))
            return message_id
        def exchange(self, op, **kwargs):
            self.calls.append(op)
            if op == 'poll':
                return {'messages': [row for row, _ in self.messages[:10]]}
            if op == 'ack':
                self.messages = [(row, png) for row, png in self.messages if row['message_id'] not in kwargs['message_ids']]
            if op == 'heartbeat':
                return {'pending_count': len(self.messages)}
            return {}
        def read_packet(self, message_id):
            self.downloads.append(message_id)
            return next(png for row, png in self.messages if row['message_id'] == message_id)

    runtime.transport = Hub()
    yield runtime
    runtime.stop_event.set()
    runtime.cipher.close()
    sender.close()


def test_background_prefetch_downloads_acks_and_preserves_business_for_foreground(inbox):
    mid = inbox.transport.add(1)
    result = inbox.dispatch({'op': 'receive', 'wait': 0, 'prefetch': True})
    assert result['fetched_count'] == 1
    assert '中文私人正文' not in json.dumps(result, ensure_ascii=False)
    assert inbox.store.incoming(mid)['state'] == 'received'
    assert 'ack' in inbox.transport.calls and 'consume' not in inbox.transport.calls
    status = inbox.status()
    assert status['local_inbox_count'] == 1 and status['has_unprocessed'] is True
    assert inbox.receive({'wait': 0})['messages'][0]['readme'] == '中文私人正文'
    assert inbox.transport.downloads == [mid]


def test_new_messages_are_not_starved_by_existing_unconsumed_inbox(inbox):
    first = inbox.transport.add(1)
    inbox.receive({'wait': 0})
    second = inbox.transport.add(2)
    result = inbox.dispatch({'op': 'receive', 'prefetch': True})
    assert result['fetched_count'] == 1
    assert {row['message_id'] for row in inbox.store.pending()} == {first, second}
    assert inbox.status()['local_inbox_count'] == 2
    assert inbox.transport.downloads == [first, second]


def test_heartbeat_schedules_prefetch_without_waiting_for_download(inbox):
    inbox.transport.add(1)
    inbox.active = Mock(side_effect=[True, False])
    inbox.stop_event.wait = Mock()
    inbox.shutdown = Mock()
    inbox.worker()
    assert inbox.prefetch_event.is_set()
    assert inbox.transport.calls == ['heartbeat']
    assert inbox.transport.downloads == []


def test_background_thread_receives_while_no_mcp_request_is_running(inbox):
    mid = inbox.transport.add(1)
    thread = threading.Thread(target=inbox.inbox_worker, daemon=True)
    thread.start()
    inbox.prefetch_event.set()
    deadline = time.monotonic() + 3
    try:
        while inbox.store.incoming(mid) is None and time.monotonic() < deadline:
            time.sleep(.02)
        assert inbox.store.incoming(mid)['state'] == 'received'
        assert inbox.status()['has_unprocessed'] is True
    finally:
        inbox.stop_event.set()
        thread.join(timeout=2)
    assert not thread.is_alive()


def test_background_receive_backs_off_and_recovers_instead_of_blocking(inbox, monkeypatch):
    """A long outage delays background receive; it never disables it (0.7.4)."""
    mid = inbox.transport.add(1)
    real_exchange = inbox.transport.exchange
    polls, waits = [], []
    clock = [time.time()]
    def flaky(op, **kwargs):
        if op == 'poll':
            polls.append(clock[0])
            if len(polls) <= 6:
                raise httpx.ReadTimeout('do-not-log-private-network-details')
        return real_exchange(op, **kwargs)
    inbox.transport.exchange = flaky
    monkeypatch.setattr('coagen_client.store.time.time', lambda: clock[0])
    original_wait = inbox.stop_event.wait
    def advance(timeout):
        if timeout >= 1:
            waits.append(timeout)
            clock[0] += timeout
        return original_wait(.005)
    monkeypatch.setattr(inbox.stop_event, 'wait', advance)
    thread = threading.Thread(target=inbox.inbox_worker, daemon=True)
    thread.start()
    inbox.prefetch_event.set()
    deadline = time.monotonic() + 5
    try:
        while inbox.store.incoming(mid) is None and time.monotonic() < deadline:
            assert inbox.background_receive_blocked is False
            time.sleep(.01)
        assert inbox.store.incoming(mid) is not None, (polls, waits, inbox.background_receive_state, {k: inbox.status()['last_operation_error'].get(k) for k in ('code','retry','details','stage')})
        assert inbox.store.incoming(mid)['state'] == 'received'
        assert len(polls) == 7
        # Backoff grows and stays bounded; a spent incident waits for its cooldown.
        assert waits == sorted(waits) and max(waits) <= 60 and waits[0] >= 2
        while inbox.background_receive_state == 'fetching' and time.monotonic() < deadline:
            time.sleep(.01)
        status = inbox.status()
        assert status['background_receive']['state'] == 'idle'
        assert 'do-not-log' not in json.dumps(status)
    finally:
        inbox.stop_event.set()
        thread.join(timeout=2)


def test_authenticated_heartbeat_can_extend_active_deadline_only(inbox):
    old = inbox.deadline.expires_at
    inbox._update_room_deadline({'room_id': 'room', 'session_id': 'server', 'expires_at': old + 120})
    assert inbox.deadline.expires_at == old + 120
    assert inbox.deadline.remaining() > 400
    with pytest.raises(ValueError):
        inbox._update_room_deadline({'room_id': 'different', 'session_id': 'server', 'expires_at': old + 300})
    inbox.stop_event.set()
    with pytest.raises(ValueError):
        inbox._update_room_deadline({'room_id': 'room', 'session_id': 'server', 'expires_at': old + 300})
    assert inbox.deadline.expires_at == old + 120


@pytest.mark.parametrize('phase', ['expired', 'closed', 'revoked', 'owner_exited', 'pairing_failed'])
def test_terminal_phase_cannot_be_extended_even_with_active_process(inbox, phase):
    original = inbox.deadline.expires_at
    inbox.phase = phase
    with pytest.raises(ValueError):
        inbox._update_room_deadline({'room_id': 'room', 'session_id': 'server', 'expires_at': original + 120})
    assert inbox.deadline.expires_at == original


def test_batch_keeps_packets_already_stored_when_a_later_download_fails(inbox):
    first, second = inbox.transport.add(1), inbox.transport.add(2)
    real = inbox.transport.read_packet
    def slow_second(message_id):
        if message_id == second:
            raise httpx.ReadTimeout('slow link')
        return real(message_id)
    inbox.transport.read_packet = slow_second
    result = inbox.dispatch({'op': 'receive', 'wait': 0})
    assert [row['message_id'] for row in result['messages']] == [first]
    assert inbox.store.incoming(second) is None and inbox.prefetch_event.is_set()
    inbox.transport.read_packet = real
    assert inbox.dispatch({'op': 'receive', 'wait': 0, 'prefetch': True})['fetched_count'] == 1
    assert inbox.store.incoming(second)['state'] == 'received'
