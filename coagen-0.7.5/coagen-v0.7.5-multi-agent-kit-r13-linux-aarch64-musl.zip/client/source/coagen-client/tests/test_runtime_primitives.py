import os
import json
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import psutil

from coagen_client.lifecycle import Owner, Deadline
from coagen_client.runtime import DEFAULT_HEARTBEAT_INTERVAL_SECONDS
from coagen_client.store import Store, remove_owned_tree
from coagen_client.transport import validate_hub


def _owner_exit_sample(owner, process, started):
    row = {'elapsed_ms': round((time.monotonic() - started) * 1000, 3)}
    if os.name == 'nt':
        try:
            import ctypes
            from ctypes import wintypes
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            wait = kernel.WaitForSingleObject
            wait.argtypes, wait.restype = [wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD
            get_exit = kernel.GetExitCodeProcess
            get_exit.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            get_exit.restype = wintypes.BOOL
            # Use only this test's retained child handle, not a process lookup.
            handle = int(process._handle)
            row['native_wait_zero'] = wait(handle, 0)
            code = wintypes.DWORD()
            if get_exit(handle, ctypes.byref(code)):
                row['native_exit_code'] = code.value
            else:
                row['native_exit_error'] = ctypes.get_last_error()
        except Exception as error:
            row['native_error'] = type(error).__name__
    try:
        row['owner_alive'] = owner.alive()
        fresh = psutil.Process(owner.pid)
        row['psutil_create_time'] = fresh.create_time()
        row['same_create_time'] = abs(fresh.create_time() - owner.started_at) < 0.001
        row['psutil_is_running'] = fresh.is_running()
        row['psutil_status'] = fresh.status()
    except Exception as error:
        row['psutil_error'] = type(error).__name__
    return row


def _owner_exit_diagnostics(owner, process):
    started = time.monotonic()
    deadline = started + 0.250
    done, cancel = threading.Event(), threading.Event()
    rows, errors = [], []
    def collect():
        try:
            for offset in (0, 0.010, 0.050, 0.100, 0.200):
                if cancel.wait(max(0, started + offset - time.monotonic())):
                    break
                if time.monotonic() >= deadline:
                    break
                rows.append(_owner_exit_sample(owner, process, started))
        except Exception as error:
            errors.append(type(error).__name__)
        finally:
            done.set()
    threading.Thread(target=collect, daemon=True).start()
    complete = done.wait(max(0, deadline - time.monotonic()))
    cancel.set()
    report = {'pid': process.pid, 'owner_started_at': owner.started_at,
              'popen_exit_code': process.returncode, 'sample_window_ms': 250,
              'diagnostic_complete': complete, 'samples': list(rows)}
    if errors:
        report['diagnostic_error'] = errors[0]
    return report


def _assert_owner_exited(owner, process):
    # This first observation remains the assertion; later samples never retry it.
    first_alive = owner.alive()
    if first_alive:
        try:
            report = _owner_exit_diagnostics(owner, process)
        except Exception as error:
            report = {'diagnostic_error': type(error).__name__}
        assert not first_alive, json.dumps({**report, 'first_owner_alive': True}, sort_keys=True)


def test_owner_exit_diagnostics_cannot_turn_the_initial_failure_into_success(monkeypatch):
    owner = SimpleNamespace(pid=123, started_at=100.0, alive=Mock(side_effect=[True, False]))
    process = SimpleNamespace(pid=123, returncode=1)
    monkeypatch.setattr(sys.modules[__name__], '_owner_exit_diagnostics',
                        lambda *_: {'samples': [{'owner_alive': False}]}, raising=False)
    with pytest.raises(AssertionError) as caught:
        _assert_owner_exited(owner, process)
    assert json.loads(str(caught.value).splitlines()[0])['first_owner_alive'] is True
    assert owner.alive.call_count == 1


def test_owner_exit_diagnostic_failure_preserves_the_original_assertion(monkeypatch):
    owner = SimpleNamespace(pid=123, started_at=100.0, alive=lambda: True)
    process = SimpleNamespace(pid=123, returncode=1)
    def broken(*_):
        raise PermissionError('PRIVATE-DIAGNOSTIC-CONTENT')
    monkeypatch.setattr(sys.modules[__name__], '_owner_exit_diagnostics', broken, raising=False)
    with pytest.raises(AssertionError) as caught:
        _assert_owner_exited(owner, process)
    report = json.loads(str(caught.value).splitlines()[0])
    assert report['first_owner_alive'] is True
    assert report['diagnostic_error'] == 'PermissionError'
    assert 'PRIVATE-DIAGNOSTIC-CONTENT' not in str(caught.value)


def test_owner_exit_success_does_not_run_diagnostics(monkeypatch):
    probe = Mock(side_effect=AssertionError('Diagnostic must not run on success.'))
    monkeypatch.setattr(sys.modules[__name__], '_owner_exit_diagnostics', probe, raising=False)
    _assert_owner_exited(SimpleNamespace(alive=lambda: False), SimpleNamespace())
    probe.assert_not_called()


def test_owner_exit_diagnostics_cannot_wait_for_a_blocked_sampler(monkeypatch):
    release, finished = threading.Event(), threading.Event()
    def blocked(*_):
        try:
            release.wait(2)
            return {}
        finally:
            finished.set()
    monkeypatch.setattr(sys.modules[__name__], '_owner_exit_sample', blocked, raising=False)
    owner = SimpleNamespace(pid=123, started_at=100.0)
    process = SimpleNamespace(pid=123, returncode=1)
    started = time.monotonic()
    try:
        report = _owner_exit_diagnostics(owner, process)
        assert time.monotonic() - started < 1
        assert report['sample_window_ms'] == 250
        assert report['diagnostic_complete'] is False
    finally:
        release.set()
        assert finished.wait(1)


def test_owner_binds_process_instance_and_detects_exit():
    process = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(60)'])
    try:
        owner = Owner.capture(process.pid)
        assert owner.alive()
        assert not Owner(process.pid, owner.started_at + 100).alive()
    finally:
        process.terminate()
        process.wait(timeout=10)
    _assert_owner_exited(owner, process)


def test_deadline_uses_monotonic_limit_even_if_wall_clock_moves_back():
    clock = [10.0]
    deadline = Deadline(110, now=100, monotonic=lambda: clock[0])
    assert deadline.active()
    clock[0] = 21
    assert not deadline.active()


def test_deadline_update_preserves_monotonic_anchor_and_cannot_revive():
    clock = [10.0]
    deadline = Deadline(110, now=100, monotonic=lambda: clock[0])
    clock[0] = 15
    deadline.update(120)
    assert deadline.remaining() == 15
    clock[0] = 31
    with pytest.raises(ValueError):
        deadline.update(200)
    assert deadline.expires_at == 120


def test_default_heartbeat_interval_is_thirty_seconds():
    assert DEFAULT_HEARTBEAT_INTERVAL_SECONDS == 30


def test_hub_refuses_credentials_query_and_cleartext_remote():
    assert validate_hub('https://example.com/coagen/') == 'https://example.com/coagen'
    assert validate_hub('http://127.0.0.1:8123') == 'http://127.0.0.1:8123'
    for url in ['http://example.com', 'https://user:secret@example.com',
                'https://example.com/?key=secret', 'file:///tmp/test', 'https://example.com/#x']:
        with pytest.raises(ValueError):
            validate_hub(url)


def test_durable_inbox_is_recorded_before_ack_and_consumption_is_idempotent(tmp_path):
    store = Store(tmp_path)
    message_id = 'a' * 32
    directory = tmp_path / 'inbox' / message_id
    directory.mkdir(parents=True)
    (directory / 'README.md').write_text('received')
    store.record_incoming(message_id, {'sender_id': 'peer', 'size': 8}, directory)
    assert store.incoming(message_id)['state'] == 'received'
    assert store.pending()[0]['message_id'] == message_id
    store.set_incoming_state(message_id, 'consuming')
    remove_owned_tree(tmp_path / 'inbox', directory)
    store.set_incoming_state(message_id, 'consumed')
    assert store.pending() == []
    assert Store(tmp_path).incoming(message_id)['state'] == 'consumed'


def test_cleanup_will_not_delete_root_or_unowned_directory(tmp_path):
    owned = tmp_path / 'inbox'; owned.mkdir()
    outside = tmp_path / 'important'; outside.mkdir()
    (outside / 'keep.txt').write_text('keep')
    for path in [owned, outside, tmp_path]:
        with pytest.raises(ValueError):
            remove_owned_tree(owned, path)
    assert (outside / 'keep.txt').read_text() == 'keep'


def test_store_sequence_and_outbox_retry_survive_reopening(tmp_path):
    store = Store(tmp_path)
    first = store.next_sequence('session')
    assert Store(tmp_path).next_sequence('session') == first + 1
    store.save_outgoing('req1', {'message_id': 'm', 'sequence': first}, b'ciphertext')
    loaded = Store(tmp_path).outgoing('req1')
    assert loaded['bytes'] == b'ciphertext'
    store.mark_sent('req1')
    assert not loaded['path'].exists()
    assert store.outgoing('req1')['state'] == 'sent'


def test_loopback_control_server_never_resolves_host_names(monkeypatch):
    """HTTPServer.server_bind's getfqdn() hung helpers on macOS; the control server must not call it."""
    import socket
    from http.server import BaseHTTPRequestHandler
    from coagen_client.runtime import LoopbackHTTPServer

    def forbidden(*_args, **_kwargs):
        raise AssertionError('reverse DNS lookup during helper startup')
    monkeypatch.setattr(socket, 'getfqdn', forbidden)
    server = LoopbackHTTPServer(('127.0.0.1', 0), BaseHTTPRequestHandler)
    try:
        assert server.server_name == '127.0.0.1'
        assert server.server_port == server.server_address[1] > 0
    finally:
        server.server_close()
