import io
import json
import os
import threading

import pytest

from coagen_client import mcp
from coagen_client.errors import CoagenError


@pytest.fixture
def server(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid(), state_dir=tmp_path / 'state')
    bridge.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize'})
    bridge.handle({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
    return bridge


def test_notification_contract_is_metadata_only_and_does_not_claim_model_wakeup(server, monkeypatch):
    state = {'phase': 'ready', 'local_inbox_count': 1, 'has_unprocessed': True,
             'local_unprocessed_count': 1, 'inbox_revision': 'a' * 64,
             'readme': 'DO-NOT-LOG-BODY', 'token': 'DO-NOT-LOG-TOKEN', 'incidents': []}
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *_: state)
    notices = server.poll_notifications()
    assert len(notices) == 1
    assert notices[0]['method'] == 'notifications/message'
    assert notices[0]['params']['data']['event'] == 'coagen.inbox_changed'
    assert notices[0]['params']['data']['model_wakeup_guaranteed'] is False
    assert 'DO-NOT-LOG' not in json.dumps(notices)
    assert server.poll_notifications() == []
    state.update(local_inbox_count=0, local_unprocessed_count=0, has_unprocessed=False, inbox_revision='b' * 64)
    assert len(server.poll_notifications()) == 1


def test_logging_capability_level_filter_and_invalid_level(server, monkeypatch):
    initialized = server.handle({'jsonrpc': '2.0', 'id': 2, 'method': 'initialize'})
    assert initialized['result']['capabilities']['logging'] == {}
    level = {'jsonrpc': '2.0', 'id': 3, 'method': 'logging/setLevel', 'params': {'level': 'error'}}
    assert server.handle(level)['result'] == {}
    assert server.handle({**level, 'params': {'level': 'bogus'}})['error']['code'] == -32602
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *_: {'phase': 'ready', 'local_inbox_count': 1,
        'local_unprocessed_count': 1, 'has_unprocessed': True, 'inbox_revision': 'a' * 64})
    assert server.poll_notifications() == []


def test_notification_errors_and_resolution_are_deduplicated(server, monkeypatch):
    error = CoagenError('HUB_UNAVAILABLE', operation='receive', stage='receive_poll').to_dict()
    error['status'] = 'active'
    state = {'phase': 'ready', 'incidents': [error]}
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *_: state)
    notices = server.poll_notifications()
    assert notices[0]['params']['data']['code'] == 'HUB_UNAVAILABLE'
    assert server.poll_notifications() == []
    error['status'] = 'resolved'
    resolved = server.poll_notifications()
    assert resolved[0]['params']['data']['event'] == 'coagen.incident_resolved'
    assert server.poll_notifications() == []


def test_prepare_exposes_notification_support_and_host_wakeup_boundary(server):
    payload = json.loads(server.call('coagen_prepare', {})['content'][0]['text'])
    assert payload['notifications']['protocol'] == 'notifications/message'
    assert payload['notifications']['model_wakeup_guaranteed'] is False


def test_stdio_emits_notification_while_waiting_for_next_request(server, monkeypatch):
    delivered = threading.Event()
    class Output(io.StringIO):
        def write(self, value):
            result = super().write(value)
            if 'notifications/message' in value:
                delivered.set()
            return result
    class Input:
        def __iter__(self):
            yield '{"jsonrpc":"2.0","id":1,"method":"initialize"}\n'
            yield '{"jsonrpc":"2.0","method":"notifications/initialized"}\n'
            assert delivered.wait(3), 'No asynchronous MCP notification while input was idle'
            yield '{"jsonrpc":"2.0","id":2,"method":"ping"}\n'
    output = Output()
    monkeypatch.setattr(mcp.sys, 'stdin', Input())
    monkeypatch.setattr(mcp.sys, 'stdout', output)
    monkeypatch.setattr(mcp.cli, 'call_local', lambda *_: {'phase': 'ready', 'local_inbox_count': 1,
        'local_unprocessed_count': 1, 'inbox_revision': 'a' * 64, 'has_unprocessed': True})
    mcp.serve_stdio(server)
    messages = [json.loads(line) for line in output.getvalue().splitlines()]
    assert {item['id'] for item in messages if 'id' in item} == {1, 2}
    assert sum(item.get('method') == 'notifications/message' for item in messages) == 1


@pytest.mark.parametrize('failure', [ValueError, TypeError])
@pytest.mark.parametrize('level', mcp.LOG_LEVELS)
def test_notification_worker_failure_remains_visible_and_does_not_restart(server, monkeypatch, failure, level):
    server.handle({'jsonrpc': '2.0', 'id': 7, 'method': 'logging/setLevel', 'params': {'level': level}})
    recorded = threading.Event()
    calls = []
    original = server.diagnostics.record
    def record(*args, **kwargs):
        result = original(*args, **kwargs)
        if kwargs.get('key') == 'notification_worker':
            recorded.set()
        return result
    def poll():
        calls.append('poll')
        raise failure('SECRET-LOCAL-STATE-MUST-NOT-LEAK')
    class Input:
        def __iter__(self):
            assert recorded.wait(3), 'Notification failure was silently lost'
            yield json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
                              'params': {'name': 'coagen_prepare', 'arguments': {}}}) + '\n'
    output = io.StringIO()
    monkeypatch.setattr(server, 'poll_notifications', poll)
    monkeypatch.setattr(server.diagnostics, 'record', record)
    monkeypatch.setattr(mcp.sys, 'stdin', Input())
    monkeypatch.setattr(mcp.sys, 'stdout', output)
    mcp.serve_stdio(server)
    assert calls == ['poll']
    assert 'SECRET' not in output.getvalue()
    response = next(json.loads(line) for line in output.getvalue().splitlines() if '"id": 1' in line)
    value = json.loads(response['result']['content'][0]['text'])
    incident = value['last_operation_error']
    assert incident['code'] == 'NOTIFICATION_FAILED'
    assert incident['stage'] == 'notification_monitor'
    assert incident['recovery'] == 'user_intervention'
    notices = [json.loads(line) for line in output.getvalue().splitlines()
               if json.loads(line).get('method') == 'notifications/message']
    assert len(notices) == int(mcp.LOG_LEVELS.index(level) <= mcp.LOG_LEVELS.index('error'))
