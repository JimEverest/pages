"""Offline regressions from the 2026-10-01 three-host collaboration reports."""
import hashlib
import json
import httpx
import pytest
from coagen_client.errors import CoagenError, classify_error
from coagen_client.transport import HubError, Transport
from coagen_client.diagnostics import Diagnostics
from coagen_client.capsule import create_capsule, inspect_capsule
from coagen_client.store import Store
from test_recovery_runtime import runtime, fail, allow_retry
from test_group_runtime import team


def test_allowlisted_hub_reason_survives_transport_and_error_roundtrip():
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    transport.client = httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(409, json={
        'detail': {'code': 'COLLAB_REVISION_MISMATCH', 'message': 'SECRET-CONTENT',
                   'expected_revision': 4, 'current_revision': 5,
                   'collaboration': {'revision': 5, 'mode': 'brainstorm', 'phase': 'review', 'secret': 'SECRET'},
                   'allowed_actions': ['refresh_status', 'SECRET'], 'token': 'SECRET'}})))
    try:
        with pytest.raises(HubError) as caught:
            transport.exchange('collaboration')
        value = classify_error(caught.value, operation='collaboration', stage='hub_exchange').to_dict()
        value = CoagenError.from_dict(value).to_dict()
        assert value['details']['reason_code'] == 'COLLAB_REVISION_MISMATCH'
        assert value['details']['current_revision'] == 5
        assert value['details']['collaboration']['phase'] == 'review'
        assert 'SECRET' not in json.dumps(value)
    finally:
        transport.close()


def test_rejected_retry_is_not_budget_exhaustion_and_preserves_original_reason(runtime):
    def rejected(metadata, png):
        runtime.transport.uploads.append((metadata, png))
        raise HubError(409, details={'code': 'CONTRIBUTION_ALREADY_COMPLETED', 'current_revision': 7})
    runtime.transport.send_packet = rejected
    first = fail(runtime, {'op': 'send', 'request_id': 'reject', 'text': 'one'}, 'HUB_REJECTED')
    runtime.store = Store(runtime.root)
    runtime.blocked_send_requests.clear()
    second = fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'reject'}, 'RETRY_NOT_ALLOWED')
    assert second.stage == 'retry_precondition'
    assert second.to_dict()['details']['reason_code'] == 'CONTRIBUTION_ALREADY_COMPLETED'
    assert second.to_dict()['details']['original_incident_id'] == first.incident_id
    assert second.retry['attempts_used'] == 1
    assert len(runtime.transport.uploads) == 1


def test_saved_manifest_receipt_does_not_reread_attachment_on_retry(runtime, tmp_path):
    attachment = tmp_path / 'attachment.txt'
    attachment.write_bytes(b'original')
    runtime.transport.fail_upload = True
    fail(runtime, {'op': 'send', 'request_id': 'files', 'text': 'one', 'files': [str(attachment)]}, 'SEND_OUTCOME_UNKNOWN')
    attachment.unlink()
    runtime.transport.fail_upload = False
    allow_retry(runtime)
    result = runtime.dispatch({'op': 'retry_saved_packet', 'request_id': 'files'})
    assert result['files_count'] == 1
    assert result['files'] == [{'name': 'files/attachment.txt', 'size': 8, 'sha256': hashlib.sha256(b'original').hexdigest()}]
    assert result['recipient_id'] == 'offline-b'
    assert result['delivery_request_id'] == result['parent_request_id'] == 'files'


def test_group_receipts_explain_parent_and_child_request_ids(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c')
    pair()
    result = a.dispatch({'op': 'send', 'request_id': 'parent', 'text': 'hello', 'broadcast': True})
    for delivery in result['deliveries']:
        assert delivery['parent_request_id'] == 'parent'
        assert delivery['delivery_request_id'].startswith('group:')
        assert delivery['files_count'] == 0


def test_later_success_resolves_settled_send_errors_but_not_unknown(runtime):
    runtime.diagnostics.record(CoagenError('INVALID_ARGUMENT', operation='send', stage='encode_capsule'), key='old-input')
    runtime.diagnostics.record(CoagenError('SEND_OUTCOME_UNKNOWN', operation='send', stage='hub_upload', outcome='unknown'), key='unknown')
    runtime.dispatch({'op': 'send', 'request_id': 'good', 'text': 'hello'})
    incidents = runtime.status()['incidents']
    assert next(i for i in incidents if i['code'] == 'INVALID_ARGUMENT')['status'] == 'resolved'
    assert next(i for i in incidents if i['code'] == 'SEND_OUTCOME_UNKNOWN')['status'] == 'active'


def test_capsule_ampersand_is_preserved_and_invalid_kind_reports_specific_field(runtime):
    text = 'see https://example.com/s?ss=abc&checkin=2026-10-04&checkout=2026-10-05 & 中文'
    assert inspect_capsule(create_capsule(text, [], message_id='test'))['readme'] == text
    result = runtime.dispatch({'op': 'send', 'request_id': 'ampersand', 'text': text})
    assert result['state'] == 'sent'
    error = fail(runtime, {'op': 'send', 'request_id': 'bad-kind', 'text': text, 'kind': 'a&b'}, 'INVALID_ARGUMENT')
    assert error.to_dict()['details']['field'] == 'kind'
    assert error.to_dict()['details']['reason'] == 'invalid_kind'


def test_upload_recording_failure_is_hub_accepted_and_retry_does_not_upload(runtime, monkeypatch):
    original = runtime.store.set_upload_outcome
    monkeypatch.setattr(runtime.store, 'set_upload_outcome', lambda *a, **k: (_ for _ in ()).throw(OSError('secret')))
    error = fail(runtime, {'op': 'send', 'request_id': 'accepted', 'text': 'one'}, 'LOCAL_STORAGE_FAILED')
    assert error.to_dict()['delivery_outcome'] == 'hub_accepted'
    assert error.to_dict()['local_recording_outcome'] == 'failed'
    monkeypatch.setattr(runtime.store, 'set_upload_outcome', original)
    result = runtime.dispatch({'op': 'retry_saved_packet', 'request_id': 'accepted'})
    assert result['state'] == 'sent'
    assert len(runtime.transport.uploads) == 1


def test_message_status_does_not_probe_unsupported_old_hub(runtime):
    calls = []
    runtime.transport.exchange = lambda op, **fields: calls.append(op) or {}
    fail(runtime, {'op': 'message_status', 'message_ids': ['a'*32]}, 'HUB_FEATURE_UNAVAILABLE')
    assert calls == ['status']


def test_message_status_forwards_supported_readonly_query(runtime):
    calls = []
    def exchange(op, **fields):
        calls.append((op, fields))
        return {'message_status_supported': True} if op == 'status' else {'messages': [{'message_id': 'a'*32, 'state': 'acked'}]}
    runtime.transport.exchange = exchange
    result = runtime.dispatch({'op': 'message_status', 'message_ids': ['a'*32]})
    assert result['messages'][0]['state'] == 'acked'
    assert calls[-1] == ('message_status', {'message_ids': ['a'*32]})


@pytest.mark.parametrize('body', [b'x'*17000, b'not JSON', b'{"detail": "SECRET"}',
    b'{"detail":{"code":"SECRET","current_revision":true,"allowed_actions":[{},"SECRET"]}}'])
def test_unstructured_or_oversized_error_body_is_not_reflected(body):
    transport = Transport('http://127.0.0.1:1')
    transport.client.close()
    transport.client = httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(409, content=body)))
    try:
        with pytest.raises(HubError) as caught:
            transport.exchange('status')
        report = classify_error(caught.value, operation='status', stage='hub_exchange').to_dict()
        assert 'SECRET' not in json.dumps(report)
        assert 'reason_code' not in report['details']
    finally:
        transport.close()


def test_confirmed_rejection_allows_corrected_new_request_but_old_id_stays_frozen(runtime):
    original_upload = runtime.transport.send_packet
    runtime.transport.send_packet = lambda *a: (_ for _ in ()).throw(HubError(409))
    fail(runtime, {'op': 'send', 'request_id': 'rejected', 'text': 'old'}, 'HUB_REJECTED')
    runtime.transport.send_packet = original_upload
    assert runtime.dispatch({'op': 'send', 'request_id': 'corrected', 'text': 'new'})['state'] == 'sent'
    fail(runtime, {'op': 'send', 'request_id': 'rejected', 'text': 'new'}, 'REQUEST_CONFLICT')


def test_group_other_recipient_success_does_not_resolve_policy_incident(team):
    relay, add, pair = team
    a, b, c = add('a'), add('b'), add('c')
    pair()
    upload = a.transport.send_packet
    def rejected_b(metadata, png):
        if metadata['recipient_id'] == 'b':
            raise HubError(403, details={'code': 'LEADER_RECIPIENT_REQUIRED'})
        return upload(metadata, png)
    a.transport.send_packet = rejected_b
    fail(a, {'op': 'send', 'request_id': 'rejected-b', 'recipient_id': 'b', 'text': 'one'}, 'HUB_REJECTED')
    a.dispatch({'op': 'send', 'request_id': 'good-c', 'recipient_id': 'c', 'text': 'two'})
    assert a.status()['last_operation_error']['code'] == 'HUB_REJECTED'
    a.transport.send_packet = upload
    a.dispatch({'op': 'send', 'request_id': 'fixed-b', 'recipient_id': 'b', 'text': 'three'})
    assert a.status()['last_operation_error'] is None


@pytest.mark.parametrize('reason', ['MESSAGE_ID_PAYLOAD_CONFLICT', 'MESSAGE_SEQUENCE_CONFLICT'])
def test_payload_conflict_recovery_does_not_suggest_fresh_business_send(runtime, reason):
    runtime.transport.send_packet = lambda *args: (_ for _ in ()).throw(HubError(409, details={'code': reason}))
    first = fail(runtime, {'op': 'send', 'request_id': 'conflict', 'text': 'one'}, 'HUB_REJECTED')
    assert first.to_dict()['details']['new_request_after_correction'] is False
    second = fail(runtime, {'op': 'retry_saved_packet', 'request_id': 'conflict'}, 'RETRY_NOT_ALLOWED')
    assert second.to_dict()['details']['new_request_after_correction'] is False
    assert second.to_dict()['details']['reason_code'] == reason
