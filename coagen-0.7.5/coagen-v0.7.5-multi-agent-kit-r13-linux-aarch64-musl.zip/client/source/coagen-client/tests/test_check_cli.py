import json
import sys
from types import SimpleNamespace

import pytest

from coagen_client.cli import main


@pytest.mark.parametrize(('overall', 'exit_code'), [('pass',0),('fail',1),('partial',2)])
def test_check_reports_distinct_exit_status_and_does_not_start_session(monkeypatch, capsys, overall, exit_code):
    received = []
    def check(hub, **kwargs):
        received.append((hub,kwargs))
        return {'overall':overall,'checks':[]}
    monkeypatch.setitem(sys.modules, 'coagen_client.healthcheck', SimpleNamespace(check_hub=check))
    assert main(['check','--hub','https://example.com/coagen']) == exit_code
    assert json.loads(capsys.readouterr().out)['overall'] == overall
    assert received == [('https://example.com/coagen',{'admin_token':None,'timeout':8,'total_timeout':30})]


def test_check_credential_file_is_consumed_without_secret_in_output(tmp_path, monkeypatch, capsys):
    token_file = tmp_path/'token.txt';token_file.write_text('PRIVATE-CLI-TEST-TOKEN')
    output = tmp_path/'report.json'
    def check(hub, **kwargs):
        assert kwargs['admin_token'] == 'PRIVATE-CLI-TEST-TOKEN'
        return {'overall':'pass','checks':[{'name':'write','status':'pass'}]}
    monkeypatch.setitem(sys.modules, 'coagen_client.healthcheck', SimpleNamespace(check_hub=check))
    result = main(['check','--hub','https://example.com/coagen','--admin-token-file',str(token_file),
                   '--output',str(output)])
    captured=capsys.readouterr()
    assert result==0
    assert 'PRIVATE-CLI-TEST-TOKEN' not in captured.out+captured.err+output.read_text()
    assert json.loads(output.read_text())['overall']=='pass'
