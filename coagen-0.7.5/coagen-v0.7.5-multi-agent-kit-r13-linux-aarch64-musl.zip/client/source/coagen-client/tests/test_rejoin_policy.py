"""Room lifetime and explicit fresh-membership recovery contracts."""
import json
import os
from unittest.mock import Mock

import pytest

from coagen_client import cli, mcp
from coagen_client.errors import CoagenError, classify_error, safe_details
from coagen_client.transport import HubError


def test_cli_new_room_defaults_to_rejoinable_group():
    args = cli.parser().parse_args(['create', '--state-dir', 'state'])
    assert cli.room_options(args) == {
        'ttl_seconds': 3600, 'room_mode': 'group', 'max_members': 8, 'mode': 'vanilla'}
    legacy = cli.parser().parse_args(['create', '--state-dir', 'state', '--room-mode', 'basic'])
    assert cli.room_options(legacy) == {'ttl_seconds': 3600, 'room_mode': 'basic'}


def test_default_create_requires_group_capability_before_post(tmp_path, monkeypatch):
    credential = tmp_path / 'admin'
    credential.write_text('synthetic-local-test-token')
    endpoint = Mock()
    endpoint.capabilities.return_value = {}
    endpoint.request.return_value.json.return_value = {
        'room_id': 'room', 'locator': '007', 'token': 'synthetic'}
    monkeypatch.setattr(cli, 'Transport', Mock(return_value=endpoint))
    monkeypatch.setattr(cli, 'launch_session', Mock(return_value={'phase': 'starting'}))
    args = cli.parser().parse_args(['create', '--state-dir', str(tmp_path / 's'),
        '--owner-pid', str(os.getpid()), '--admin-token-file', str(credential)])
    with pytest.raises(CoagenError) as caught:
        cli.create(args)
    assert caught.value.code == 'HUB_FEATURE_UNAVAILABLE'
    endpoint.request.assert_not_called()


@pytest.mark.parametrize(('reason', 'mode', 'allowed', 'code'), [
    ('MEMBER_INACTIVE', 'group', True, 'MEMBERSHIP_REVOKED'),
    ('BASIC_SESSION_ENDED', 'basic', False, 'ROOM_CLOSED'),
    ('ROOM_CLOSED', 'group', False, 'ROOM_CLOSED'),
    ('ROOM_EXPIRED', 'group', False, 'ROOM_EXPIRED'),
])
def test_typed_410_distinguishes_membership_from_room(reason, mode, allowed, code):
    report = classify_error(HubError(410, details={'reason_code': reason,
        'room_mode': mode, 'rejoin_allowed': allowed,
        'allowed_actions': ['join_again_explicitly'] if allowed else ['inspect_room'],
        'message': 'PRIVATE-TEXT'}), operation='join', stage='hub_establish').to_dict()
    assert report['code'] == code
    assert report['http_status'] == 410
    assert report['details']['reason_code'] == reason
    assert report['details']['room_mode'] == mode
    assert report['details']['rejoin_allowed'] is allowed
    assert report['details']['allowed_actions'] == (['join_again_explicitly'] if allowed else ['inspect_room'])
    assert 'PRIVATE-TEXT' not in json.dumps(report)


def test_untyped_410_never_promises_room_reentry():
    report = classify_error(HubError(410), operation='join', stage='hub_establish').to_dict()
    assert report['code'] == 'SESSION_REVOKED'
    assert 'rejoin_allowed' not in report['details']
    assert report['recovery'] == 'stop_operation'


def test_untrusted_rejoin_metadata_and_capacity_wait_are_bounded():
    assert safe_details({'reason_code': [], 'rejoin_allowed': True}) == {}
    assert 'rejoin_allowed' not in safe_details({'reason_code': 'PRIVATE', 'rejoin_allowed': True})
    details = safe_details({'reason_code': 'ROOM_CAPACITY_REACHED', 'room_mode': 'group',
        'rejoin_allowed': True, 'retry_after_seconds': 180,
        'allowed_actions': ['wait_for_member_slot', 'PRIVATE-ACTION']})
    assert details['retry_after_seconds'] == 180
    assert details['allowed_actions'] == ['wait_for_member_slot']
    for invalid in (-1, float('inf'), 21601, True, '180'):
        assert 'retry_after_seconds' not in safe_details({**details, 'retry_after_seconds': invalid})


def test_incomplete_terminal_cleanup_cannot_be_bypassed_by_join(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    bridge.state_dir = tmp_path / 'old'
    monkeypatch.setattr(cli, 'call_local', Mock(return_value={'phase': 'stopped', 'cleanup_state': 'incomplete'}))
    join = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'join', join)
    with pytest.raises(CoagenError) as caught:
        bridge.call('coagen_join', {'code': '00700042'})
    assert caught.value.code == 'CLEANUP_INCOMPLETE'
    join.assert_not_called()


@pytest.mark.parametrize('pid_exists', [False, True])
def test_unreachable_helper_only_allows_fresh_join_when_pid_confirmed_gone(tmp_path, monkeypatch, pid_exists):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    bridge = mcp.McpServer(workspace=tmp_path)
    old = bridge.state_dir = tmp_path / 'old'
    old.mkdir()
    control = old / 'control.json'
    original = json.dumps({'pid': 12345, 'owner_pid': bridge.owner_pid,
                          'mcp_instance_id': bridge.instance_id, 'token': 'SYNTHETIC-IPC'})
    control.write_text(original, encoding='utf-8')
    monkeypatch.setattr(cli, 'call_local', Mock(side_effect=CoagenError('LOCAL_HELPER_UNAVAILABLE')))
    monkeypatch.setattr(mcp.psutil, 'pid_exists', Mock(return_value=pid_exists))
    join = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'join', join)
    if pid_exists:
        with pytest.raises(CoagenError) as caught:
            bridge.call('coagen_join', {'code': '00700042'})
        assert caught.value.code == 'LOCAL_HELPER_UNAVAILABLE'
        join.assert_not_called()
    else:
        result = json.loads(bridge.call('coagen_join', {'code': '00700042'})['content'][0]['text'])
        assert bridge.state_dir != old
        assert result['previous_session']['helper_exited'] is True
        assert result['previous_session']['state_preserved'] is True
        join.assert_called_once()
    assert control.read_text(encoding='utf-8') == original


@pytest.mark.parametrize('phase', ['starting', 'waiting_for_peer', 'pairing', 'ready'])
def test_join_cannot_overwrite_existing_active_binding(tmp_path, monkeypatch, phase):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    bridge.state_dir = tmp_path / 'existing'
    monkeypatch.setattr(cli, 'call_local', Mock(return_value={'phase': phase}))
    join = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'join', join)
    result = bridge.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
        'params': {'name': 'coagen_join', 'arguments': {'code': '00700042'}}})['result']
    assert result.get('isError') is True
    assert json.loads(result['content'][0]['text'])['code'] == 'SESSION_ALREADY_ACTIVE'
    join.assert_not_called()
    assert bridge.state_dir == tmp_path / 'existing'


@pytest.mark.parametrize('phase', ['stopped', 'revoked', 'expired', 'owner_exited', 'pairing_failed', 'closed'])
def test_terminal_binding_can_join_with_new_membership(tmp_path, monkeypatch, phase):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    bridge = mcp.McpServer(workspace=tmp_path, owner_pid=os.getpid())
    old = bridge.state_dir = tmp_path / 'old'
    monkeypatch.setattr(cli, 'call_local', Mock(return_value={'phase': phase}))
    join = Mock(return_value={'phase': 'starting'})
    monkeypatch.setattr(cli, 'join', join)
    bridge.call('coagen_join', {'code': '00700042'})
    assert bridge.state_dir != old
    assert join.call_args.args[0].state_dir == str(bridge.state_dir)


def test_mcp_schema_documents_group_default():
    create = next(tool for tool in mcp.TOOLS if tool['name'] == 'coagen_create')
    props = create['inputSchema']['properties']
    assert props['room_mode']['default'] == 'group'
    assert props['max_members']['default'] == 8
    assert props['mode']['default'] == 'vanilla'
