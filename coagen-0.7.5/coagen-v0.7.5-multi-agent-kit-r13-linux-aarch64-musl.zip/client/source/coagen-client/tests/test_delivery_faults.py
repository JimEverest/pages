import hashlib
import os
from pathlib import Path
import time

import httpx
import pytest

from coagen_client.capsule import create_capsule
from coagen_client.carrier import pack_png
from coagen_client.crypto import Pairing
from coagen_client.lifecycle import Owner
from coagen_client.runtime import SessionRuntime
from coagen_client.store import Store


@pytest.fixture
def receiver(tmp_path):
    owner = Owner.capture(os.getpid())
    runtime = SessionRuntime({'state_dir': str(tmp_path), 'owner_pid': owner.pid,
        'owner_started_at': owner.started_at, 'hub': 'http://127.0.0.1:1', 'secret': 'test-secret',
        'member': {'room_id': 'room', 'peer_id': 'B', 'role': 'b', 'token': 'test',
                   'session_id': 'server', 'expires_at': time.time() + 300}})
    a, b = Pairing('test-secret', 'room', 'A'), Pairing('test-secret', 'room', 'B')
    ah, bh = a.start(), b.start()
    sender, runtime.cipher = a.finish(bh), b.finish(ah)
    sender.verify_confirmation(runtime.cipher.confirmation())
    runtime.cipher.verify_confirmation(sender.confirmation())
    runtime.phase, runtime.other = 'ready', 'A'
    metadata = {'room_id': 'room', 'message_id': 'a' * 32, 'sender_id': 'A', 'recipient_id': 'B',
                'expires_at': time.time() + 60, 'sequence': 1, 'crypto_session_id': sender.session_id}
    capsule = create_capsule('Fault test', [], message_id=metadata['message_id'])
    png = pack_png(sender.encrypt(capsule, sequence=1, metadata=metadata))
    record = {**metadata, 'size': len(png), 'sha256': hashlib.sha256(png).hexdigest()}
    runtime.transport.close()
    class FakeHub:
        fail_ack = False
        acked = False
        def exchange(self, op, **kwargs):
            if op == 'poll':
                assert isinstance(kwargs['wait_seconds'], int)
                return {'messages': [] if self.acked else [record]}
            if op == 'ack':
                if self.fail_ack:
                    self.fail_ack = False
                    raise httpx.ReadError('lost ACK response')
                self.acked = True
            return {}
        def read_packet(self, message_id):
            return png
    runtime.transport = FakeHub()
    runtime.transport.encrypt_for_test = sender.encrypt
    yield runtime, metadata
    runtime.cipher.close(); sender.close()


def test_disk_failure_after_extract_can_retry_without_decrypting_twice(receiver, monkeypatch):
    runtime, metadata = receiver
    original = runtime.store.record_incoming
    def fail_once(*args):
        monkeypatch.setattr(runtime.store, 'record_incoming', original)
        raise OSError('disk full')
    monkeypatch.setattr(runtime.store, 'record_incoming', fail_once)
    with pytest.raises(OSError):
        runtime.receive({'wait': 0})
    result = runtime.receive({'wait': 0})
    assert result['messages'][0]['message_id'] == metadata['message_id']
    assert runtime.pending_clear == {}


def test_cached_delivery_repairs_lost_ack(receiver):
    runtime, metadata = receiver
    runtime.transport.fail_ack = True
    with pytest.raises(httpx.ReadError):
        runtime.receive({'wait': 0})
    assert runtime.receive({'wait': 0})['messages'][0]['message_id'] == metadata['message_id']
    assert runtime.transport.acked


def test_cached_packet_expiry_cleans_plaintext_without_redelivery(receiver):
    runtime, metadata = receiver
    message = runtime.receive({'wait': 0})['messages'][0]
    row = runtime.store.incoming(metadata['message_id'])
    row['metadata']['expires_at'] = time.time() - 10
    import json
    with runtime.store.db() as db:
        db.execute('UPDATE incoming SET metadata=? WHERE message_id=?',
                   (json.dumps(row['metadata']), metadata['message_id']))
    assert runtime.receive({'wait': 0})['messages'] == []
    assert not Path(message['path']).exists()


@pytest.mark.parametrize('field', ['room_id', 'crypto_session_id'])
@pytest.mark.parametrize('operation', ['send', 'retry'])
def test_basic_saved_request_cannot_cross_room_or_crypto_session(receiver, field, operation):
    runtime, _ = receiver
    args = {'text': 'fixed content', 'request_id': 'fixed-task-id'}
    _, fingerprint = runtime._capsule(args, 'f' * 32)
    metadata = {'room_id': runtime.member['room_id'], 'message_id': 'f' * 32,
                'sender_id': runtime.member['peer_id'], 'recipient_id': runtime.other,
                'crypto_session_id': runtime.cipher.session_id}
    metadata[field] = 'another-session'
    runtime.store.save_outgoing('fixed-task-id', metadata, b'original-sent-png', fingerprint=fingerprint)
    runtime.store.mark_sent('fixed-task-id')
    with pytest.raises(ValueError) as conflict:
        runtime.send(args) if operation == 'send' else runtime.retry_saved_packet('fixed-task-id')
    assert conflict.value.code == 'REQUEST_CONFLICT'


def test_store_connections_close_after_transaction(tmp_path):
    store = Store(tmp_path)
    with store.db() as db:
        assert db.execute('SELECT 1').fetchone()[0] == 1
    import sqlite3
    with pytest.raises(sqlite3.ProgrammingError):
        db.execute('SELECT 1')


def test_untrusted_relay_message_id_cannot_choose_filesystem_path(receiver):
    runtime, metadata = receiver
    original = runtime.transport.exchange
    def poisoned(op, **kwargs):
        result = original(op, **kwargs)
        if op == 'poll':
            record = result['messages'][0]
            bad = {**metadata, 'message_id': '../../outside-state', 'sequence': 2}
            capsule = create_capsule('must never be written outside inbox', [], message_id='safe-inner-id')
            png = pack_png(runtime.transport.encrypt_for_test(capsule, sequence=2, metadata=bad))
            record.update(bad, sha256=hashlib.sha256(png).hexdigest(), size=len(png))
            runtime.transport.read_packet = lambda _mid: png
        return result
    runtime.transport.exchange = poisoned
    with pytest.raises(ValueError, match='message identifier'):
        runtime.receive({'wait': 0})
    assert not (runtime.root.parent / 'outside-state').exists()
    assert list((runtime.root / 'inbox').iterdir()) == []
