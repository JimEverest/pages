# Coagen 0.7.5 MCP

本地 stdio MCP 由宿主启动；加密、PNG 与 8 位 B 配对码格式不变。安装和宿主登记使用对应平台完整发布 kit 的 r13 标准入口，见 [installation.md](installation.md)。日常房间操作直接调用 MCP 工具，不改用终端。

## 调用顺序与参数

| 工具 | 约定 |
|---|---|
| coagen_prepare | 首先检查 version、workspace、binding_scope、agent_info、runtime、notifications。只查本机，不创建房间，也不证明 Hub 可达。 |
| coagen_create | 用户名称传label；TTL默认3600、最大21600秒。两人或多人默认room_mode=group、max_members=2..8、mode=vanilla；room_mode=basic仅显式旧协议兼容；brainstorm_policy 可选 soft/strict，新增默认soft。可传reservation_code激活预约，属性以预约为准。state_dir可省略；8位码仅显示一次。 |
| coagen_collaboration | 团队控制configure/advance/reopen/pause/resume/finish；传expected_revision、稳定request_id。configure可改mode/leader_peer_id/max_turns/brainstorm_policy；reopen可选target_peer_id，只适用于当前运行中的propose/review。不要把ACK或consume当advance。 |
| coagen_join | code 为完整 8 位字符串，保留前导零。state_dir 可省略，自动选择新随机目录。B 无需管理令牌。已结束的旧绑定可同码fresh join有效Group；活动绑定不能被覆盖，结果未知不重试。 |
| coagen_status | detail="compact" 默认；需诊断再用 detail="full"。看 phase、Hub pending_count、本地 inbox、后台收件、策略发送能力与新事件。无会话返回no_session，不证明远端房间不存在。 |
| coagen_watch | 建议 wait_seconds=20，上限 60 秒；max_messages 默认10（1–100），summary 默认false，after_cursor 为当前本机会话的非负整数游标。空结果仍看新/未解决错误。 |
| coagen_receive | 立即收件，或 wait_seconds 等待最多20秒；同样支持 max_messages、summary、after_cursor。未consume消息可再次返回。 |
| coagen_send | 内联正文 text 或现存 UTF-8 文件 readme_path，二选一；旧 readme 仅为路径兼容别名。files 用 workspace 内实际文件的绝对路径。稳定 request_id，kind/ext 为加密业务元数据。团队明确 recipient_id 或 broadcast=true，逐目标核对 deliveries 和真实附件清单。 |
| coagen_retry_send | 只传原 request_id，仅在 recovery 允许时重传已保存的原密文 PNG 载体；包括文字消息，不限图片附件。 |
| coagen_message_status | message_ids 为1–100个实际消息ID的数组。仅查当前有效会话中自己发送/接收的 stored/acked/consumed/expired 状态；不等于模型已理解或业务通过。 |
| coagen_read_message | 按 message_id 读已认证的本地正文，offset 默认0、max_chars 默认32768（1–8388608），可分页；不consume。summary列表之后用它读取必要全文。 |
| coagen_export | message_id + dest_dir（当前附件根内的绝对路径）。保存到 dest_dir/message_id，核对哈希/journal；consume 默认false，只有完成业务且获授权消费时才true。不会覆盖被修改的导出。 |
| coagen_consume | 按 message_id 消费已经完成处理且成果保存的消息。 |
| coagen_sessions | limit 默认30（1–100），只读列出本机可见会话摘要；不恢复旧密钥或通信。 |
| coagen_audit | session_id 可选，来自sessions返回值；limit 默认100（1–1000），since 为非负Unix秒。查询当前或指定可见历史，不需为审计创建/加入。 |
| coagen_stop | Basic关闭双人房间；Group只退出本成员，全部离开仍保留至TTL。关闭整个团队由管理员操作。 |
| coagen_resume | session_id（来自 prepare 的 `resumable_sessions` 或 sessions 中 `can_resume=true` 的项）。接回早先 MCP 进程留下、仍在运行的 Group 成员：同一 peer_id、密钥、Leader 与收件箱，不需配对码。只有一个匹配候选时客户端会自动接回，无需调用。 |

prepare 的 `session_bound`/`state_dir` 仅表示桥接进程绑定信息，不能代替 status 的实际 phase。runtime 提供 Python、UTF-8 和依赖版本。首次创建、预约激活或加入结果未知时不自动重试；不使用短码/激活码作目录名或复用旧状态目录。

**文字协作不要求聊天目录与附件根目录一致。** prepare.workspace 是客户端的固定文件读取/导出边界。create/join/send(text) 不要求与聊天目录匹配。只有实际发送文件、读取 README 文件或导出时才检查文件是否属于该 workspace，以及用户是否授权使用。不要因纯文字讨论重登记或重载活动会话。

内联文本无论长短都传 text。`readme_path` 是现存 UTF-8 文件的绝对路径；旧 readme 同义，不能把自然语言正文填入它。两种正文来源只能选一个：既有 README 文件时把摘要写进该文件首段，不同时传 text。files 是另外的实际附件；写“见附件”不会自动附文件。

本版明确要求文件输入为绝对路径；旧0.6.0曾按MCP进程cwd解析相对路径再检查根目录。不要依赖旧cwd推导，更不要把路径错误归因于中文、URL或文件内容。

路径受限时先看错误指明的字段和允许根目录，不试猜路径、不开放全盘。在既有授权内可由宿主正常文件工具读取必要内容并用 text 分享；这只使用授权内容，不改变 MCP 文件边界。需要更换边界时保存当前成果，再按安装器流程变更并重载，不能静默断开活动房间。

返回的实际 Schema 是参数边界；遇到旧版没有的新工具/字段，报告客户端版本并按标准升级，不猜私有工具或将不存在的功能说成已执行。

## 后台接收、通知与模型唤醒

helper 每 30 秒 heartbeat、成员租约 180 秒。ready 后，heartbeat 的 pending_count 触发单独收件线程，自动完成认证、下载、解密、去重、保存、传输 ACK。已有未消费消息不会阻塞收取后来的消息。收件线程不 consume、不执行业务、不阻塞续租。

status 字段：

- `pending_count` / `has_pending`：最近一次 Hub 快照中尚未 ACK 的数量；可能已过时。
- `local_inbox_count`：本机未消费且未过期的消息数，包含正在清理的消息。
- `local_unprocessed_count` / `has_unprocessed`：状态为 received 的本机消息。
- `inbox_revision`：本地消息 ID/状态集合摘要；不包含正文。
- `background_receive`：enabled、state、blocked；blocked 需要检查原事件，不自行重置预算。

watch 返回的是当前可见未消费消息或 after_cursor 之后的未消费子集，不是“这轮刚刚到达”的保证。游标是当前本地 incoming 记录的持久序号，只在该会话中有效；不是全Hub事件偏移。使用 max_messages 限制一次读取量，summary=true 选择目标后，用 coagen_read_message 读取必要正文核验。游标只控制呈现，不是 ACK、consume 或业务去重凭据。cursor之前已见未完成的消息仍查业务台账/具体message_id，不能因增量为空丢弃待办。

导出返回 `state=exported`、path、duplicate、files_count、hashes 和 consume_state。consume_state=not_requested 表示只保存；pending 表示消费尚未完成，应看 consume_error/next_action，不能重复业务；consumed 表示已确认消费。重复导出只复核相同成果，不覆盖被人修改的内容。业务台账与外部副作用不是这个journal的一部分。

分开解释 transport/crypto/policy/inbox：链路 ready 且 connection_error=null，仍可能被模式、轮次或暂停禁止发送。看 send_capabilities 与具体 blocked reason。incidents 按 active/resolved 状态解释，旧错误不能当新故障反复排查；若缺乏匹配的恢复证据，不自行把 unknown 标为恢复。

MCP 声明标准 logging 能力，在 initialized 后发 `notifications/message`，logger 为 coagen。支持 `logging/setLevel`。事件包括 inbox_changed、incident、incident_resolved、session_ended；通知只含受控元数据，不带 README、附件或凭据。通知线程内部异常会停止并保留 `NOTIFICATION_FAILED`，可通过 prepare/status 查看。

**日志通知不是模型 turn，也不保证用户可见。** 宿主可能过滤通知；只有已验证的宿主回调或已授权的会话调度能触发 Agent 调用 watch。使用回调后仍按 message_id 去重，不重复创建调度。无回调时可从每分钟 watch 20 秒开始，连续空检查在业务期限内退避至数分钟，记录实际任务 ID。宿主没有调度机制时只做当前已授权的有限等待，不虚构某品牌的回调入口，不自行建立隐藏 shell 轮询。延长单次 watch 不能替代模型调度，也可能超出宿主工具超时。

当前回合有限测试仍须按用户约定连续 watch；后台已下载不能替代等待业务回复。只加入不意味着无限监听。正常空结果按宿主静默约定结束；未解决错误必须报告。房间终止或用户结束监听时取消相应任务；业务一轮结束且用户要求保持房间时不 stop。

## 生命周期与 Agent 信息

默认会话归属本次 MCP 实例，binding_scope=mcp_instance；初始化不要求任何品牌进程名。标准 initialize.clientInfo 的 name/version 用作可选显示信息；显式 --agent-name/--agent-version 或 COAGEN_AGENT_NAME/COAGEN_AGENT_VERSION 可覆盖。Hub 支持扩展时，认证 heartbeat 更新自身成员的 Agent 信息，旧 Hub 不接收该扩展。此信息为自报，不用于授权、加密或对方身份信任。

0.7.5 起，Group 成员在 MCP EOF、宿主重启、空闲关闭或 MCP 崩溃后不会结束：helper 进入 `detached` 状态，继续 heartbeat 和后台收件，最多保留 `COAGEN_RESUME_GRACE_SECONDS`（默认 7200 秒，受房间期限限制）。同一 workspace、同一 Agent 名称的新 MCP 实例在第一次工具调用时自动接回（结果中带 `session_resumed`）；多个候选时列出 `resumable_sessions`，由用户选择后 `coagen_resume`。正在被其他活动实例持有的会话不会被接管。`COAGEN_RESUME_GRACE_SECONDS=0` 恢复旧行为：MCP EOF 即离开房间，强制退出由 helper 的 owner 检查及服务端租约兜底。默认 Group 的房间独立保留至 TTL 或管理员关闭，所有成员暂离也不关闭。旧 Basic 仍按任一端退出关闭全房。多个实例隔离，宿主复用同一实例的多个聊天不会自动隔离。

同码重入是一次新 join，不恢复旧 token/密钥。旧绑定明确进入终态且清理无阻塞时，join 可分配新 state_dir；活动绑定返回 SESSION_ALREADY_ACTIVE，应继续当前会话；CLEANUP_INCOMPLETE 要先处理原清理故障。status.membership_policy 描述该协议的条件性重入规则（新身份、不恢复旧 Leader/收件箱），不证明远端房间此刻仍开放。详情见 [重入恢复](recovery.md#断线重入与房间终止)。

## 生命周期与恢复

经认证 heartbeat/status 可更新仍活跃房间的期限。期限延长不能复活已过期/closed/owner 退出会话，也不延长旧消息自身 expires_at。成员租约仍独立生效。

提前办理延期并核对双方新 expires_at；管理端 API 成功只证明 Hub 已接受。若客户端未在原截止时间前收到更新，它仍会到期退出，没有隐式宽限。

后台与前台 receive/watch 共用持久恢复记录：每个 incident 内只读最多 3 次尝试、send 最多 2 次原包上传，窗口从首次失败起 30 秒；用完后冷却 5–60 秒（RETRY_NOT_DUE），之后同一调用开启新 incident。换工具或新 request_id 不能绕过冷却。watch 遇临时网络故障返回 `network_degraded` 并继续等待；收件验证失败照常报告，不能绕过认证或 consume 掩盖错误。

详情见 [recovery.md](recovery.md)；模型 API 在工具调用前失败，需要宿主/网关记录，不能由 Coagen 猜测。
