# Coagen 0.7.5：双人和团队自然语言流程

日常业务只调用 MCP。安装和明确要求的人工 CLI 见 [installation.md](installation.md)。A/B 是创建与加入角色，业务收发完全双向；双方都有自己独立的本机权限与任务范围。

## 准备

给两端：

> 使用 Coagen skill 和 MCP，先调用 coagen_prepare，核对客户端为 0.7.5、binding_scope 和实际文件边界 workspace。文字讨论不要求 workspace 与聊天目录一致。只检查本机准备状态，先不创建或加入。MCP 不可用时说明实际问题，不改用终端。

prepare 成功只说明本机工具能工作。没有管理员令牌的 B 不需要复制长期令牌；只加入时不用它。

## A 创建，B 加入

给 A：

> 为本次 A/B 协作创建一小时房间，使用本机默认管理员令牌文件。把 8 位配对码只显示一次给我；不要记录长期令牌。先等待 B，尚未 ready 时只按约定有限检查状态。

A调用create，可省略state_dir。新房间默认room_mode=group、mode=vanilla；只有A/B两人也保持Group，按需求max_members=2。用户手动把完整短码交给B，不复制邀请文件或状态目录。用户指定名称时必须传label，例如“创建test one，120分钟”对应label="test one"、ttl=7200；90分钟是5400秒，最大6小时是21600秒。默认仍为一小时。成功后核对返回名称与expires_at。

管理端已预约时，给 A：

> 使用 Coagen MCP，以我提供的 43 字符一次性预约激活码作为 reservation_code 调用一次 coagen_create。不要读取管理员令牌；不要把激活码写到路径、日志或后续报告。成功后只显示一次新的 8 位 B 配对码。失败或结果未知时按标准流程报告，不重复激活。

预约激活码不是 B 配对码；只在预约有效期内使用。预约房间的期限由管理端决定，create 的 ttl 不覆盖它。用户把随后生成的 8 位码转交 B。

给 B：

> 使用 Coagen MCP 加入本次房间，配对码是【完整8位码】。以结构化 code 参数交给 coagen_join，让客户端生成新随机状态目录。仅用此码加入，不把码放进目录名或报告。等到 ready 后报告结果。

B 首先 prepare，然后执行一次 join；只有 ready 才收发。本版首次 join 不需要强制传 state_dir；显式新目录仍可用。短码前导零必须保留。发生错误时立即按 [recovery.md](recovery.md) 报告并执行标准恢复，不重复猜码、未知结果的join 或 create。已确认断线后的新加入按下节办理。

## 重启后回到原房间

> 我已经重启，请通过 Coagen MCP 继续先前的 Group 房间，使用我原先提供的配对码。如果没有活动绑定且旧身份已结束，明确 join 一次并建立新身份；不要另建房间。就绪后请仍在线成员发送当前 context_revision、已决定事项、未决问题和待办的最小摘要，不重做已经完成的任务。结果未知、旧房间已关闭或已到期时如实报告。

若房间满员，旧崩溃进程的租约可能尚未释放。只在明确拒绝、还有等待预算时等返回的间隔，最多再尝试一次；不要让全员退出。原Leader离开导致暂停时，需管理员显式选择新Leader；同名Agent不能继承权限。

## 选择监听方式

当前回合有限测试：

> 在当前回合持续调用 coagen_watch(wait_seconds=20)，总共最多 10 分钟，直到任务完成或房间失效。空结果后继续约定的等待，不要只说“正在监听”就结束。仅处理本次授权业务；有错误马上报告阶段和恢复结果，按标准流程处理。

持续协作：

> 为本次已授权协作注册宿主已支持的会话级收件任务，可从每分钟 coagen_watch(wait_seconds=20) 开始，连续空检查在业务 deadline 内退避。确认实际任务 ID。只处理当前授权房间和业务范围；纯文字不绑定聊天目录。正常空结果安静完成，新错误及真实恢复要报告。房间终止或我结束监听时取消任务；无法注册时如实说明，不伪称后台模型已经运行。

Claude Code 支持该功能的会话可使用 /loop；Codex 使用自己的调度工具。本版 helper 会在 heartbeat 发现待取消息后后台下载、认证、去重、ACK；业务仍待 Agent 调用 watch/receive。标准 MCP 日志通知不保证触发模型。只有实际验证的宿主回调可替代重复任务，不同时建立重复监听。只要求加入时，不自动注册无限调度。20 秒保留宿主余量，工具实际最大允许 60 秒。

## 发送、核对与消费

A 的任务示例：

> 给 B 发送任务 README 和当前 workspace 中的授权数据文件，说明要检查的字段、输出文件和验收条件。使用稳定 request_id，成功后报告 message_id，最多等待回复两分钟。

B 的处理示例：

> 对收到的 message_id 去重；先读 README 和清单，只在本机用户授权范围内执行。把必要成果保存到指定目录，发送关联原 message_id 的回复，确认后 consume。

A 的验收示例：

> 独立核对 B 的业务结论和附件内容/哈希，通过后发一次业务 ACK，保存成果并 consume。纯 ACK 不再 ACK。

重复 receive/watch 可能返回尚未 consume 的本地消息，先查看处理记录。业务副作用结果未知时报告 execution_unknown，不能重做。上传成功只表示 Hub 接受，业务 ACK 才表达相应的业务确认。

最简单的文字发送：

```json
{"text":"请核对这两个候选方案的差异，按当前 context_revision 返回。没有附件。","kind":"task","request_id":"compare-context-1"}
```

只有一个对端时可以省略 recipient_id；多人必须补齐实际目标。发送已有文件型 README 时改用 readme_path="实际 workspace 内的 UTF-8 文件绝对路径"，去掉 text；不要把正文填到 readme/readme_path。files 中单独列出需要传输的实际附件绝对路径，成功后核对实际附件数/清单。

Leader 开始前发一条简短 canonical brief，含 deliverable、context_revision、分工、业务 deadline；成员最后用 final_handoff 交已知/未核/成果，详见[收口模板](collaboration-practice.md)。协议 ACK/consume 状态可用 coagen_message_status 查询，无需为了问“收到没”形成 ACK 循环。

## send 失败的唯一恢复入口

出现 pending/unknown 发送时，暂停新的业务。读取结构化错误和一次可用状态核对；仅在 recovery 允许时调用 `coagen_retry_send(request_id=原ID)`。它重传已保存的原密文，最多额外一次，窗口最多 30 秒。不能把 send 当作自由重试入口，不能改 ASCII、换正文/附件、换 request_id 或重建房间。

同 request_id 不同内容返回冲突。额度耗尽时报告事件 ID、影响和明确下一步。保存失败时不要先 consume；consume 失败不能触发业务重做。完整规则与告警去重见 [recovery.md](recovery.md)。

以上禁止换 ID 的规则针对 pending/unknown。not_started 的输入错误或 Hub 确定拒绝，先修正已确认原因；原请求明确未接受、策略已经允许且任务授权仍适用时，可按返回 recovery 创建新请求。不要用删 URL 的 &、改 ASCII 或换收件人来试错，更不能用新 ID 绕过未解除的禁发条件。

## 中文与文件双向验收

仅在已授权的新测试房间中执行：

1. 两端 prepare 0.7.5、ready，记录实际版本和平台。
2. A 发送中文正文，例如“中文往返：你好，Coagen。é”，附带中文文件名的 UTF-8 文本，注明附件 SHA-256 与预期内容。
3. B 核对解密正文和附件内容/哈希，以中文正文及 UTF-8 结果附件回复；A 再独立核对。
4. 验证一条未 consume 消息再次返回时不重复执行业务；处理并保存后 consume，确认不再作为待处理消息出现。
5. 报告真实 message_id、结果和限制；任一错误均按统一流程报告，不改 ASCII 后假称中文验收通过。

后台接收专项验收：B 暂不调用 watch/receive，A 发送两条间隔跨过 heartbeat 的消息；确认 B 的 local_inbox_count 依次增加，即使第一条尚未 consume，第二条仍收到。Hub ACK 不等于业务完成；B 恢复 watch 后逐条核对并显式 consume。若宿主展示 notification，记录实际事件；没有模型唤醒时如实报告，不算业务自动执行通过。

离线 smoke 的 raw UTF-8 ping 只检查 MCP 文本通道；不能替代上述真实加密 A/B 收发验收。

## 保存与结束

用 coagen_export(message_id, dest_dir) 将所需已验证成果保存到当前授权 workspace 内，核对 journal、清单和哈希。可显式选择 consume；导出并消费的阶段结果需要分别确认，不能把保存失败报告成业务完成。业务台账仍需记录处理结论；journal 不替代外部副作用的幂等。业务任务完成不自动关闭房间，尤其用户明确要求保持打开时。

MCP 已无活动绑定时，可用 coagen_sessions 找历史，再指定会话调用 coagen_audit；不为了读历史而 create/join。历史元数据不含旧密钥，也不保证已经过期清理的明文仍可找回。

整个协作结束时先确认成果保存，再按授权stop并取消watcher。Basic任一端stop关闭双人房间；Group只离开当前成员，关闭整个团队使用管理员控制。stopping或cleanup_incomplete必须报告实际状态，不保证瞬时安全擦除。不要直接删状态目录代替协议清理。

## 多人团队示例

给创建者：

> 使用Coagen MCP创建名为“产品评审”的两小时团队，room_mode=group，max_members=8，默认vanilla。记录自己为Leader，把入群码只显示一次。等待两名获授权成员加入，核对每条目标链路ready后开始；不要把一次工具返回等同于三方业务都已执行。

给任何加入者：

> 使用Coagen MCP加入我提供完整8位码的团队。核对实际成员、自己的peer_id、Leader和当前模式；只在分配的本机权限内协作。发消息时明确目标peer_id；需要所有当前成员时才使用broadcast=true。每次业务处理按message_id去重，完成并保存成果后consume。

切换模式：

> 先读取当前collaboration revision，将本团队切换为round-robin，设置max_turns=12。只有当前发言者发送这一轮的业务消息，完成后显式advance；ACK、心跳和consume不推进轮次。到预算或finish时结束本轮业务，保持房间打开。

模式含义、Leader转移和失败恢复见[团队协作](collaboration.md)。多人模式的入群、路由和控制由Hub/MCP提供，模型是否再次运行取决于宿主已验证的回调或已授权的调度；不能声称宿主会自动唤醒。
