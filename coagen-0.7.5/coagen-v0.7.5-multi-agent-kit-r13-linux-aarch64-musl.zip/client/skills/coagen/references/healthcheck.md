# 一次有限的健康检查

客户端 **0.7.5** 提供 `check`。用户要求检查服务可达性或加密收发时使用；已有授权无需再次确认正式协作房间。检查不启动 LLM、后台 helper 或真实协作，不读取用户附件，不创建会话状态目录，也不需要 `--owner-pid`。它自行完成临时身份配对，不要求用户传递短码或邀请文件。

这是用户明确要求的独立有限检查，不是 MCP 不可用时的业务收发替代通道。实际协作故障遵循 [统一恢复流程](recovery.md)，不得因故障自动运行临时建房测试。

## 运行

先按 [安装说明](installation.md) 找到已安装 runtime 的解释器（`doctor` 输出的 `checks.runtime.path`）。只检查可达性也可以直接用安装器：`ENTRY doctor --check-hub`。默认使用 Azure hub；仅检查健康接口：

```sh
# Linux / macOS
COAGEN_PY="$HOME/.local/share/coagen/runtimes/0.7.5/bin/python"   # macOS: "$HOME/Library/Application Support/Coagen/runtimes/0.7.5/bin/python"
"$COAGEN_PY" -I -X utf8 -m coagen_client check
```

```cmd
rem Windows CMD
set "COAGEN_PY=%LOCALAPPDATA%\Coagen\runtimes\0.7.5\Scripts\python.exe"
"%COAGEN_PY%" -I -X utf8 -m coagen_client check
```

提供管理令牌文件后检查完整收发：

```sh
"$COAGEN_PY" -I -X utf8 -m coagen_client check --admin-token-file "$HOME/.config/coagen/azure-admin-token.txt" --timeout 8 --total-timeout 30 --output "${TMPDIR:-/tmp}/coagen-check.json"
```

```cmd
"%COAGEN_PY%" -I -X utf8 -m coagen_client check --admin-token-file "%USERPROFILE%\.config\coagen\azure-admin-token.txt" --timeout 8 --total-timeout 30 --output "%TEMP%\coagen-check.json"
```

`--hub URL` 可覆盖默认地址。`--timeout` 默认 8 秒，限制单次网络等待；`--total-timeout` 默认 30 秒，限制整个探测。`--output` 可选，用于保存 JSON 报告。只传令牌文件路径，不读取或打印其内容。命令只做一次有限检查，不自动循环或重建房间。B 没有管理员令牌时不要求把长期令牌复制过去；可以先做可达性检查，再由真实 A/B 配对验证协作收发。

无令牌时，只执行健康接口 GET 并验证响应是否符合预期；通过也仅表示 `partial`。完整检查创建一个 TTL 为 60 秒的新房间，由同一进程内两个临时身份加入，用 32 字节随机测试数据生成小于 1 KiB 的加密 PNG，上传、下载、解密核验，然后 ACK、consume，并在结束路径尝试关闭房间。这证明测试当时的 API 加密收发链路；不能替代真实跨 Agent 协作、宿主生命周期或实际工作负载验收。

## 读懂结果

| 阶段 | 检查内容 |
| --- | --- |
| `connect` | 正常 TLS/代理下访问并验证健康响应 |
| `authenticate` | 管理令牌创建临时房间、第二身份加入 |
| `write` | 提交随机测试数据的加密 PNG |
| `read` | 下载并核对解密后的测试数据 |
| `cleanup` | ACK、consume、关闭测试房间；失败时明确报告未完成清理 |

| `overall` | 退出码 | 含义 |
| --- | --- | --- |
| `pass` | `0` | 本次完整检查成功，包含清理 |
| `fail` | `1` | 某个检查或清理阶段失败 |
| `partial` | `2` | 健康响应有效，但未提供令牌，未验证认证/收发/清理 |

报告包含各阶段状态、可获得的 HTTP 状态码、耗时和错误类别；不会输出请求/响应正文、headers、秘密或房间 ID。DNS、连接或 TLS 失败时可能没有 HTTP 状态码，不能据此推断服务端已拒绝请求。不要把健康接口 200 或 `partial` 写成完整收发成功。

## 失败与清理

- 即使前面失败，客户端仍在有限时间内尝试关闭已知的测试房间。若断网、截止时间或其他错误使关闭无法确认，报告必须说明只能依赖 **60 秒 TTL 到期及服务端 GC**；不要声称密文已立即删除。创建响应丢失时客户端可能不知道房间 ID，也只能等待服务端到期清理。
- 按失败阶段检查 DNS、HTTPS、代理、凭据、服务容量或磁盘限额。保留不含秘密的报告；更改实际原因后，再按用户授权进行新的有限检查。
- 学校/单位的域名白名单或防火墙不放行时，向网络管理员申请允许 Coagen 的目标域名通过 **HTTPS 443**。本 Azure 服务域名是 `json-formatter.centralindia.cloudapp.azure.com`。保持正常 TLS 校验和组织代理设置，不切换规避通道，不隐藏或伪造网络身份，也不持续重试。

新命令是否已经通过某个平台或公网验收，以对应版本的实际执行报告为准；旧版服务发布记录不代表新命令已经验收。
