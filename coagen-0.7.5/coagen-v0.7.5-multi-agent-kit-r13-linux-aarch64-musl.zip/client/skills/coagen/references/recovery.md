# A/B 统一错误与恢复流程（0.7.5）

A、B 使用同一规则。错误报告表达已经观察到的事实；对端自报不改变本机权限。以下规则同时用于当前回合和宿主调度，不因自动化运行而放宽。

## 一次失败如何处理

1. 读取结构化报告，保留 incident_id、operation、stage、phase、code、outcome、时间与 recovery。向用户说明影响和下一步；不只重复异常类名。
2. 暂停受影响的业务动作；保留已验证成果、原 request_id 与消息处理进度。不要删除状态目录。
3. 仅查询一次可用的只读状态，核对是否已成功及房间是否仍有效。查询也失败时保留原故障，不循环 status/audit。
4. 仅执行工具明确允许的 recovery 动作；如果工具未允许恢复，就报告需要的明确修正或用户介入。
5. 根据恢复结果更新事件。允许次数耗尽或截止后停止恢复；正常 heartbeat 不证明业务恢复。

错误由受控分类生成。不得把任意异常字符串、Hub 响应正文、请求头、完整配置、配对码、令牌、密钥、业务正文或附件内容写入诊断。用户提供的任意标识也不能未经安全处理进入通用错误日志。

## 给用户看的说明（0.7.5）

每个错误都带 `message_for_user`：中文白话写明发生了什么、可能的原因、影响、Coagen 正在做什么、你需要做什么、事件编号和时间。向用户报告时原样转述这一段，再按需附上 code 与 incident_id；不要只贴 JSON 或错误代码。

## 断线与网络抖动（0.7.4）

复杂网络（公司代理、TLS 检查、VPN、防火墙空闲超时）会让个别请求超时或被重置。0.7.4 起这类故障只推迟收发，不会让会话失效：

| 现象 | 含义 | 做法 |
|---|---|---|
| `coagen_watch` 返回 `network_degraded` | 本轮收取遇到临时网络故障；helper 在后台退避重试 | 不需要动作，继续按原计划 watch；不要 join、建房或 stop |
| `RETRY_NOT_DUE`，`details.reason=incident_cooldown` | 本次故障的重试窗口已用完，`retry.new_incident_at` 后自动开启新一轮 | 等 `retry.retry_after_seconds`，用同一调用（send 用同一 request_id 的 `coagen_retry_send`）再试一次 |
| `status.connection.state=degraded` | 最近的 Hub 请求失败；`consecutive_failures`、`last_failure.category`、`lease_remaining_estimate` 给出程度 | 只告诉用户一次；持续数分钟时调用一次 `coagen_network_check` |
| `status.hub_refresh.ok=false` | status 无法即时刷新，显示的是最后已知状态 | 同上；不是会话结束 |
| `coagen_network_check` 出现 `tls_inspection_possible` 或 `slow_stages` | 证书不是常见公共 CA 签发，或握手/请求超过 3 秒 | 告诉用户可请网络团队对 Hub 主机免除 TLS 检查、放宽长连接空闲超时；不要关闭证书校验 |
| prepare/status 含 `session_resumed` | 宿主重启前的成员已被新 MCP 实例接回，身份、密钥、Leader 与收件箱都保留 | 继续 watch，处理期间到达的消息；不再 join |
| prepare 含 `resumable_sessions` 且有多个 | 同一 workspace 有多个可接回的成员 | 请用户选择，调用 `coagen_resume(session_id)` |

会话真正结束只有这些情况：Hub 本身拒绝（成员被移除、租约在 180 秒内一直没有续上、房间关闭或到期）、显式 `coagen_stop`、MCP 退出后超过 `COAGEN_RESUME_GRACE_SECONDS` 仍没有新实例接回。此时 status 是终止阶段，才按下文“断线重入”办理。

可调设置（写在 MCP 配置的 env 中）：`COAGEN_RESUME_GRACE_SECONDS`（默认 7200，0 表示 MCP 退出即离开房间）、`COAGEN_AUTO_RESUME`（默认 1；0 时只列出候选、由 `coagen_resume` 显式接回）、`COAGEN_HTTP_KEEPALIVE_SECONDS`（默认 45，复用 HTTPS 连接，减少经过代理时的重复握手）。

## 读懂错误：cause、context、日志（0.7.3）

每个错误都带三类证据，先读它们再判断，不要靠猜：

- `cause`：失败**层**（network / tls / hub / filesystem / storage / process）、**类别**（如 `dns_failed`、`connect_timeout`、`connection_refused`、`connection_reset`、`proxy_failed`、`tls_certificate_verify_failed`、`read_timeout`、`http_server_error`、`permission_denied`、`file_in_use`、`disk_full`、`sqlite_busy`）、`chain`（异常类型链，含 errno / WinError / OpenSSL 原因，只取操作系统与库生成的字段）、`request`（方法、URL、耗时）、`proxy_environment`（只列变量名）和具体 `checks`。
- `context`：发生位置的事实，例如 helper 的 `last_stage`、`stage_seconds`、`exit_code`、`stopped_by_parent`、`stderr_tail`（已脱敏）、`cleanup`（失败后 leave 是否被 Hub 确认）。
- `log_file` / `coagen_prepare.logs.directory`：本机私有 JSON 日志（MCP、helper、CLI 各自一份），记录每次工具调用、Hub 请求失败与慢请求、helper 启动阶段和所有 incident。

网络类错误调用一次 `coagen_network_check`：依次检查 DNS、直连 TCP、TLS 证书、通过客户端代理设置的 HTTP `/health`，并给出第一个失败层。直连失败而 HTTP 通过说明需要代理且代理可用。

### 本地 helper 启动失败

| code | 含义 | 下一步（最多一次） |
|---|---|---|
| `LOCAL_HELPER_START_TIMEOUT` | helper 在 `context.timeout_seconds` 内没有就绪，父进程已结束它；`last_stage`/`stage_seconds` 指出慢在哪一段 | 慢机器（导入或安全扫描慢）在 MCP 配置 env 中设置 `COAGEN_HELPER_START_TIMEOUT`（秒，最大 600），宿主正常重载一次后，用同一配对码再加入一次 |
| `LOCAL_HELPER_EXITED` | helper 在就绪前退出；`exit_code`、`helper_error`、`stderr_tail` 给出原因 | 先修正报告的原因（例如 owner 已退出、目录权限），再加入一次 |
| `LOCAL_HELPER_SPAWN_FAILED` | 无法启动 helper 进程 | 检查 runtime Python 是否存在、是否被应用控制拦截；修复 runtime 后再试 |
| `LOCAL_HELPER_UNAVAILABLE` | 已运行的 helper 无法联系；`context.helper_alive`、`stderr_tail` 说明它是否已退出 | 确认 helper 已退出后才可按授权同码重新加入；不要替换 owner |

这些错误的 `outcome` 都是 `hub_accepted`：Hub 已接受加入，但本地没有建立会话。`context.cleanup.result` 为 `confirmed` 表示该成员已离开房间；`unconfirmed` 时旧成员位置在约 180 秒租约后释放，满员时等待后再加入。

## 结果状态

| outcome | 能确认什么 | 不能据此声称 |
|---|---|---|
| not_started | 该阶段尚未开始，例如输入检查失败 | 之前所有任务均未执行 |
| local_only | 已完成的动作限定本机，例如已准备缓存包 | Hub 已接收或对端已处理 |
| unknown | 请求可能已经产生远端作用，当前证据不足 | 未发送、可直接换 ID 重做 |
| hub_accepted | Hub 接受该业务包已有成功证据 | 对端已下载、业务成功或成果已保存 |

`local_only` 本身不能解释拒绝原因；只有明确的 Hub 拒绝响应才能确认该次上传未被接受。群发须逐目标判断，不能以某个目标拒绝覆盖已成功目标。`delivery_outcome` 与本地诊断/记账结果分别看：上传已确认而审计落盘失败，不应重新上传；上传未知而日志成功，也不等于未送达。

consume 必须分别说明本地清理与远端消费是否已经确认。传输 ACK 与业务 ACK 不同，成功上传不能替代业务验收。出现 execution_unknown 时保留已有处理记录，不因再收到同一消息重做副作用。

客户端进入终态不代表本地清理和状态写入都已确认。检查返回的 `cleanup_state`、`control_write_state` 及原错误；未完成、失败或未确认时如实报告，不能宣称全部清理或持久化成功。旧成员终态不恢复为 ready；有效 Group 可按下节建立新成员身份，这不等于恢复旧 token。不能因清理问题新建房间、复制旧密钥、直接删除目录或绕过 `LOCAL_STORAGE_FAILED` 返回的恢复动作。

## 断线重入与房间终止

HTTP 410 可能表示旧成员被撤销，也可能表示房间已经结束。0.7.1 起使用受控 code/details 区分；不只凭状态码让所有成员退出重建。

| 已确认状态 | 标准动作 | 不能做什么 |
|---|---|---|
| MCP 重启，无活动绑定；原 Group 房间仍有效且用户授权继续 | 使用原配对码显式 `coagen_join` 一次，省略 state_dir 生成新目录，随后在既定预算内等待配对 | 复用旧 state_dir、复制旧密钥、把新身份叫作旧会话恢复 |
| `MEMBERSHIP_REVOKED`，`details.reason_code=MEMBER_INACTIVE`、`room_mode=group`、`rejoin_allowed=true`，允许 `join_again_explicitly` | 保留旧会话审计和业务进度；已有继续授权时同码显式新加入一次 | 重试旧 token、把旧 Leader 权限继承给同名新成员 |
| `ROOM_UNAVAILABLE`，`details.reason_code=ROOM_CAPACITY_REACHED`，允许 `wait_for_member_slot` | 说明旧租约可能尚未释放或其他成员占满。按 `details.retry_after_seconds` 等待；在用户预算和剩余 TTL 内最多再尝试一次。到时没有空位就报告 | 反复 join、关闭其他成员、声称租约倒计时保证有空位 |
| `SESSION_ALREADY_ACTIVE` | 读取当前绑定状态并继续该协作；只有明确结束该成员的授权才 stop | 用 create/join 覆盖活动会话 |
| `CLEANUP_INCOMPLETE` | 旧绑定清理尚未完成；按原故障的明确恢复动作处理并保存诊断，再评估能否新加入 | 丢弃旧绑定、删目录或用另一工具绕过本地清理失败 |
| `ROOM_CLOSED` / `ROOM_EXPIRED`，或 `rejoin_allowed=false` | 报告房间已关闭/到期；如需新房间按用户授权另办，并保存最小交接 | 同码复活、让管理员延期已终止房间 |
| 旧版仅返回 `SESSION_REVOKED` / HTTP 410，缺少明确原因 | 如实报告原因未区分，查询一次可用只读状态或由管理员核对；保留房间，不自动重建 | 假定可重入、假定所有成员都已掉线 |
| join 返回 `SESSION_OUTCOME_UNKNOWN` / `ESTABLISHMENT_BLOCKED` 或连接中断导致结果未知 | 停止重复加入，保留该次建立结果与诊断；按明确 recovery 处理 | 另开工具、换 state_dir 或重启进程绕过未知结果保护 |

Group 的 stop/EOF/成员租约失效只撤销该成员。所有成员离开后，房间仍保留至 TTL 或管理员关闭；Basic 的任一端退出仍会关闭全房。明确的管理员关闭和到期不会因新 join 恢复，旧 Basic 不能原地转换为新协议。

`status.membership_policy.same_code_rejoin_while_room_open` 描述协议条件，不证明 Hub 此刻仍开放该房间。实际加入结果、认证状态和 typed error 的 `details.rejoin_allowed` 才用于判断当前阶段；不能拿本地策略摘要覆盖远端的关闭/到期响应。

一次重入建立新 peer_id 和新 PAKE 密钥。新成员拿不到旧 peer 的收件历史，旧 Leader 权限也不转移。配对就绪后由仍在线且获授权的成员定向发送 [最小上下文](collaboration-practice.md#成员重入后的最小上下文交接)；其他成员可继续已有协作，不需要全员重进。若原 Leader 不在线、受控协作 paused，管理员必须显式 configure 选择新的活跃 Leader。没有现存授权记录或摘要副本时，报告 context_missing，不编造历史、不自动重执行业务。

## 恢复预算

| 操作 | 允许预算 | 约束 |
|---|---|---|
| 可重试的只读操作 | 每个 incident 最多 3 次尝试，窗口从首次失败起 30 秒；之后冷却 5–60 秒自动开启新 incident | 只有 recovery 允许时执行；受本次用户总等待时限、房间剩余 TTL/租约限制 |
| 已保存但上传不确定的 send | 每个 incident 最多 2 次上传，窗口 30 秒；冷却后可再用同一 request_id 重传 | 用 coagen_retry_send 和原 request_id；同 message_id、序号和 PNG 字节，Hub 按 message_id 幂等接受 |
| create / 预约 claim / join 结果未知 | 不自动重试 | 丢失响应可能已激活/占用房间或加入位置；不得新建、重复激活、猜码或重复加入。已确认断线/满员拒绝的新加入仅按上一节有界办理 |
| consume | 仅程序明确允许的同 message_id 有界恢复 | 所需成果先保存；不因清理失败重做业务 |
| heartbeat | 既有固定周期续租 | 与业务恢复预算分开；不授权修复失败的业务 |

预算绑定事件/逻辑操作，跨工具调用保留。未知结果的重新 send、换新 ID、改正文、重启工具或改时间参数不能重置恢复额度。`recovery` 是允许动作，`retry` 中的 remaining_attempts/deadline 等字段是实际可用范围；表中是上限，不保证每次故障都可以重试。PNG 是任意正文和附件的密文容器，并不是截图专用格式。

后台收取和前台 receive/watch 使用同一恢复记录与操作锁。后台收取失败后按 retry_after 或 2 秒起翻倍（最多 60 秒）退避重试，`background_receive.state=retry_wait` 和 `next_retry_in` 显示等待；它仅收取并 ACK，不执行任务或 consume。不能另开 shell receive 绕过。

30 秒限制再次发起恢复的截止时间，结合剩余期限约束 HTTP 各阶段的超时和分块读取检查；它不是操作系统强制在第 30 秒中断所有 I/O 的承诺。发送重试默认至少间隔 1 秒；只读两次恢复默认分别间隔 1 秒、2 秒。有效 Retry-After 可要求更久等待，不能越过原预算。返回 RETRY_NOT_DUE / wait_retry 时仅按 retry.retry_after_seconds 等到允许时间；提前重复调用不会增加可用次数或重置截止时间。

新的 pending/unknown 发送未解决时，暂停对该成员的新业务发送，先用 `coagen_retry_send` 解决它（冷却期间等待，不换 ID）。成功记录重复查询可返回同一 message_id；同 ID 不同正文或附件为请求冲突。

## 确定拒绝和结果未知：不同恢复路径

| 已确认结果 | 可以做什么 | request_id 纪律 |
|---|---|---|
| 本地输入检查失败，not_started，尚未创建上传包 | 按字段级错误修正真实参数，如把内联正文改放 text；保持用户原意与文件范围 | 根据工具返回判断原 ID 是否已占用；不要假定所有本地失败都可直接复用 |
| Hub 明确拒绝，已知未接受 | 读稳定 reason code 与当前 policy；修正被确认的问题。授权允许的 Leader 控制变更成功后，重新评估任务是否仍需要发送 | 原请求保持被拒记录，缓存重传不会改变权限。原因已解除、无未知交付且仍获授权时，按 recovery 用新 request_id 创建新的有效请求；关联原请求，不改 ID 绕过尚未解除的限制 |
| 网络超时/连接丢失，unknown/pending | 一次状态核对；仅在 recovery 允许时重传原缓存包 | 始终原 request_id、原密文与原目标；不改正文、不重复外部副作用 |
| 群发部分成功 | 保存逐目标成功/拒绝/未知状态，先解决未知项 | 已成功目标不重发；不扩大当时目标集。没有未知项且确定失败原因已解除后，才按明确返回的恢复路径处理失败目标 |

不要把所有 4xx 都当作永久错误：429 有自己的有界 Retry-After 规则。也不要把 5xx 自动当成可安全新发；结果是否未知、是否有缓存及预算，由工具决定。

`RETRY_NOT_ALLOWED` 表示原请求不允许缓存重传，查看保留的原始拒绝原因；`RETRY_BUDGET_EXHAUSTED` 才表示允许的恢复次数/期限已用尽。`retry_precondition` 是恢复前置条件，不代表磁盘写入失败。读 recovery 的 allowed/attempts/reason 等实际字段，不能根据“一共允许两次”就对所有错误再调一次。

确定拒绝不是自动切模式的授权。只有既有任务确实授权本端控制协作时，才可按权限明确 configure/reopen 并记录变化；普通成员请求 Leader 处理。新的有效请求必须基于已改变的状态，不是试错更换正文、字符、收件人或令牌。

## 决策表

| 观测 | 标准动作 | 禁止动作 |
|---|---|---|
| MCP 不存在、权限拒绝、宿主无法启动 | 报告实际组件；提供一次性登记/重载建议 | 用终端替代业务 MCP、自行改权限 |
| no_session | 查历史用 coagen_sessions / 指定会话 audit；新协作按已有创建/加入授权执行 | 为查审计而建房，从无绑定推断远端房间已消失、恢复旧密钥 |
| starting / waiting_for_peer / pairing | 按既定等待预算检查 status；ready 后才收发 | 重复 join、把正常等待当作错误 |
| 正常空 watch，无未解决事件 | 有限等待或按已注册任务安静结束 | 把空结果说成对端出错 |
| 编码、README、路径或输入错误 | 查看字段、期望格式和 allowed root；not_started 时按已确认原因修正。readme_path/readme 是路径，内联正文用 text | 改 ASCII、删除 URL 的 &、自动 HTML 转义、换目录/工具盲试 |
| 临时连接错误或可重试 Hub 5xx | 只执行 recovery 允许的幂等恢复；watch 中出现时按 `network_degraded` 继续等待 | 无限轮询、把网络问题解释成错码、为此重新 join 或建房 |
| Hub 429 | 仅在程序允许且有效 Retry-After 不越预算时等待 | 持续重试、推断管理令牌失效 |
| create/join 响应丢失 | 报告结果未知，保留已知关联信息 | 再创建、再 join、使用另一配对码 |
| send 响应丢失 | 状态核对；允许时 coagen_retry_send 原 request_id | 新 ID、新正文、重新执行业务 |
| 重复 message_id | 查已保存处理进度；完成的业务不重做 | 以重复投递为新的执行授权 |
| consume 结果未知 | 已保存成果后，按原 message_id 恢复并报告确认范围 | 重做任务、删除未保存成果 |
| 认证失败、房间占用或明确关闭/到期 | 停止业务并报告可确认原因，取消无效房间调度 | 猜码、换令牌、自动重建/延期 |
| TLS、代理或组织网络限制 | 说明可确认层次和正常网络检查建议 | 关闭 TLS、换代理/通道反复探测 |
| 解密、哈希、GCM 或解包验证失败 | 停止处理该数据并保留安全诊断；既有终止清理规则照常 | 绕过校验、运行附件、consume 伪装处理成功 |
| 保存/写盘失败 | 暂停依赖该保存结果的 consume，报告缺失成果 | 扩大删除范围或声称已保存 |
| stopping / cleanup_incomplete | 有限确认停止状态及允许的清理结果 | 当作 ready 继续发任务、直接删目录 |
| 对端未回复/本端发现租约失效 | 报告本端观察及最后成功收发时间 | 推断对端模型拒绝、崩溃或具体网络故障 |
| 模型 API/网关拒绝 | 使用宿主已有脱敏记录，标记该回合未推进 | 把它冒充 Coagen Hub 错误、改 prompt/模型/代理试探 |
| NOTIFICATION_FAILED | 报告 MCP 通知线程已停止，保留 prepare/status 中的事件，按已有授权显式 watch | 把没有通知当作没有消息、静默重启房间、承诺模型已被唤醒 |

Hub 只返回“关闭或过期”时不能自行判断关闭者或具体原因。HTTP 状态只在实际取得时报告；没有状态不等于服务器拒绝。错误码为工具返回的稳定大写 code；不要从异常文字猜出另一错误码。

常用 code：`INVALID_UTF8` / `INVALID_ARGUMENT` 是本机输入问题；`SEND_OUTCOME_UNKNOWN` / `PENDING_SEND` 使用允许的缓存恢复；`REQUEST_CONFLICT` 表示同 ID 不同内容；`RETRY_BUDGET_EXHAUSTED` 停止自动恢复（0.7.4 起收发不再产生它）；`RETRY_NOT_DUE` 等待返回的间隔后用同一调用再试；`SESSION_OUTCOME_UNKNOWN` / `ESTABLISHMENT_BLOCKED` 禁止重复建房或加入；`MESSAGE_AUTH_FAILED` 不处理该载荷。`INTERNAL_ERROR` 保留事件给开发者，不猜测恢复动作。

Hub 稳定业务 reason 与 HTTP 状态一起看；同为 409 不代表同一问题。revision 冲突应保留当前 revision/状态与原操作，先确认是否已经应用以及意图仍适用，再决定后续控制；不能将 expected_revision 改成“latest”跳过并发保护。只转述白名单错误字段，不原样回显任意响应正文。

## 用户告警、去重与恢复

首次错误、严重度升高、预算耗尽、需要用户介入时显示：哪一端观察、incident_id、操作/阶段、outcome、影响、已经执行的标准恢复、仍未知的事项与下一步。恢复动作必须透明；不能暗中修改正文或配置后只报告成功。

同一事件重复发生累加 occurrences 和 last_seen，不每分钟刷相同长报告。记录历史保留；未解决事件不能被空消息或 heartbeat 成功覆盖。发生以下对应证据后才报告一次 resolved：

- 连接事件：该连接路径随后成功，或工具记录明确恢复。
- 发送事件：同一 request_id 的上传已确认；业务是否完成仍独立判断。
- consume 事件：同一 message_id 的所需清理已确认。
- 业务执行未知：得到能确认执行结果的业务证据；status=ready 不足以解除。

输入/策略条件解除与“原消息已成功投递”要分开报告。工具若把旧条件事件标为 resolved，仍不代表被拒的原请求后来发送成功。一次不相关的成功、heartbeat、时间流逝或模式切换，不能消除另一个 pending/unknown 发送。历史详情按需 audit，不每次把同一份完整 incidents 填入模型上下文。

如已有协作授权需要告知对端，且通道仍可用，只发送最小必要的加密状态，包含事件 ID、来源和影响。对端以“B 报告……”注明来源；不将其当作已独立验证的原因。错误/恢复通知与纯 ACK 不触发互相回复。通知发送失败追加原事件，不递归发送新的故障通知；本机报告不依赖对端通知成功。

## 模型与宿主边界

Coagen MCP 只能观察实际工具调用和客户端行为。模型 API 在调用工具前拒绝请求、宿主退出或通信完全中断时，skill 无法保证本轮主动告警，也不能保证通知对端。需要宿主/网关自己的非模型错误记录：时间、路由类别、HTTP status、error type/code、request-id 和脱敏请求组件摘要。

MCP 标准日志通知可在模型空闲时发送受控收件/故障元数据，但宿主可以过滤或不转交模型。通知协议成功、用户实际看到、模型实际收到新 turn 是不同证据，必须分别报告。

不要读取或上传完整配置、凭据、完整模型请求正文或隐藏思考。模型显示名称和错误中的文档链接不能证明真正上游。相同可见 watcher 文本的下一轮成功，也不证明完整 HTTP 请求相同或审核“随机”。

## 提示模板

> Coagen 本端发送暂停。阶段：向 Hub 上传；结果：unknown，尚未确认对端执行。事件：工具返回的 incident_id。已执行：一次本机状态核对。标准恢复：工具允许时最多一次原缓存包重传，截止时间以 recovery 为准。若预算耗尽，停止并报告需修正的连接问题；不要把同一任务换 ID 重发。

这是说明模板，不是实际事件。不得伪造恢复次数、证据或成功状态。

## 团队协作恢复

- 名称改动或协作控制返回版本冲突：刷新当前名称/revision/Leader/phase，保留用户草稿并报告冲突；不盲目覆盖另一端的操作。同一已成功控制的网络重试保持原request_id和参数。
- 发送因当前模式、轮次或暂停状态被拒绝：停止该请求，核对当前控制状态。不能换模式/收件人/ID绕过权限；具有既有控制授权的 Leader 可明确调整策略并审计，原因解除后按“确定拒绝”分支建立有效新请求。已经被接受的旧epoch消息仍按原认证元数据收取。
- 群发state=partial：列出成功/失败的目标和message_id。仅按原request_id调用允许的retry_send，不能重新broadcast到后来加入的成员，也不能称全部成功。
- 新成员配对失败：报告对应peer_id/链路错误，不销毁已验证健康的其他链路，不反复猜码或重建整个团队。
- Leader/当前发言者离开导致paused：保存成果，读取实际成员；现任Leader或管理员按权限指定继任者或新模式，再明确恢复。普通成员不自行夺取控制权。
- Group成员stop/EOF仅表示本成员离开；管理员close才关闭整个团队。监控取消与本成员生命周期一致，不影响其他成员已授权的协作。
