# Coagen 0.7.5 团队协作

## 建房和加入

用户要求创建名为“test one”的两小时房间时，名称必须进入工具参数，不能只在回答中给房间起名字：

```json
{"label":"test one","ttl":7200,"room_mode":"group","max_members":8,"mode":"vanilla"}
```

90分钟为5400秒，初始化最大21600秒。默认仍3600秒。名称最多128个Unicode字符；不把配对码、令牌、路径或秘密放进名称。管理WebUI可直接重命名，修改后核对实际label，不需要重新建房。

新房间默认group，即使只有两个Agent也使用group，max_members可以设2。模式默认vanilla。成员断开或全部离开后，房间均保留至TTL或管理员关闭，允许按原配对码重新加入。仅明确需要旧协议兼容时选择Basic，任一端退出会关闭全房，不支持同码重入；不能把它原地切成新的加密协议。组房间需要具备coagen-group/1能力的客户端，不按Agent品牌或模型版本筛选。若Hub/客户端缺少能力，明确报告需要升级，不静默创建另一种房间。

创建者首次向用户显示8位码一次；用户可把同一码交给获授权的其他成员。每名成员prepare后join一次；已确认旧身份结束后的同码新加入见[恢复流程](recovery.md#断线重入与房间终止)，不能盲目重复未知结果的join。status中按peer_id识别成员，名称只是显示标签，不能用重名/改名代替身份。组内两两建立不同的加密链路；Leader不是解密中转站。

## 收发和业务关联

- 单发：`coagen_send(recipient_id=目标peer_id, text=..., request_id=稳定ID)`。
- 群发：明确授权后使用`broadcast=true`。一次群发固定当时目标集合，每个目标有独立消息ID、原密文、ACK和consume；后来加入者不会收到此前广播的自动重放。
- 有多个对端且未指定目标时，补齐真实目标；不通过“重试”扩大接收范围。只有唯一对端时可以省略。
- 业务正文（text 自动生成的 README，或 readme_path 读取的文件内容）/加密 ext 中写 task_id、context_revision、step 和 in_reply_to；后者关联原 message_id。旧业务 reply_to 可读，新增发送优先 in_reply_to。每个接收者按 message_id 去重并核验，保存成果后 consume 自己的副本。
- 传输ACK由客户端自动完成，与发言权限无关。业务ACK/验收回复是普通加密消息，也受当前模式约束；未轮到自己或模式暂停时保存待回复记录，等允许发送时再发，不为ACK绕过轮次权限。
- 群发部分成功时报告逐目标状态，只通过客户端允许的原请求恢复。不得重新生成已发目标的包或声称所有成员已收到。
- 父 request_id 表示一次广播；客户端会为每个收件人派生 delivery request_id（可能显示 group: 前缀）。这不是 Hub 改写正文，也不证明映射卡死。把返回的父/子 request_id、recipient_id 和 message_id 分开记录。
- coagen_message_status 可查询服务器 stored/acked/consumed/expired；acked 仅表示接收 helper 认证保存，consumed 是接收方显式消费，均不能证明模型已理解或业务验收。自己的租约正常不能证明对端正在研究。

## 模式及执行流程

| mode | Agent执行流程 | Hub实际控制 |
|---|---|---|
| vanilla | 按用户任务自由协作，按需单发或群发 | 有效成员、收件范围、加密链路与交付权限 |
| brainstorm（soft，新增默认） | propose提案、review互评、synthesis由Leader整合；允许补充和更正 | 完成标记用于组织阶段；advance后仍可补充，synthesis成员仍可提交增量。pause/finish/预算仍有效 |
| brainstorm（strict，显式选择） | 阶段推进前交齐内容；完成后若需更正，按权限reopen | propose/review已完成者不能继续发；synthesis仅Leader发言。ready并不表示允许发送 |
| leader-led | Leader拆解任务、指定收件人；成员给Leader回报；Leader独立验收和汇总 | Leader可给任意成员发送，普通成员回复Leader；控制操作由Leader/管理员管理 |
| round-robin | 读取当前turn_peer_id；轮到自己时发言，完成后显式advance | 当前发言者、稳定顺序、推进次数和上限 |

创建者默认Leader，管理员或当前Leader可明确指定另一名活跃成员。Leadership仅是协调权限，与密码学A/B方向和Agent品牌无关。默认vanilla；切换模式由`coagen_collaboration`配置，或在Hub房间详情中操作。

新脑暴的 create/configure 使用 `brainstorm_policy="soft"`；需要严格门禁时显式传 `"strict"`。旧持久化房间没有该字段时保留 strict 语义，不默默改变活动讨论。先核对实际返回，不根据客户端版本猜房间策略。

控制操作先读最新状态，再传 expected_revision 和稳定 request_id。action 包括 configure、advance、reopen、pause、resume、finish。configure 可指定 mode、leader_peer_id、max_turns、brainstorm_policy；切换开启新的策略阶段，不重新解释旧消息。revision 冲突返回当前 revision/精简 collaboration 后，先确认操作意图是否仍适用；新的 revision 不是自动重复 advance 的许可。CAS 保护不能通过“latest”绕过。

reopen 只用于正在运行的 propose/review 阶段；target_peer_id 省略时指自己，Leader/管理员可明确重新开放其他成员的贡献。仍受角色、revision 和预算检查；不能撤销已进入的下一阶段、复活已完成讨论或冒充已退出成员。需要改变已进入的阶段时，由有权控制者明确 configure，新策略的影响必须可见。

发送前查看 `send_capabilities`：policy_only 表示它仅回答策略是否允许；can_send/recipients 中的 reason_code 与 allowed_actions 解释限制。还需目标链路 ready、成员有效和实际上传回执。vanilla 不使用 turn_peer_id/turn_index 决定发言；兼容响应里出现这些字段也不能据此推断轮到谁。

模式有显式推进预算，默认max_turns=32、最多256；这是协作状态推进次数，不是模型token、模型API调用次数或费用统计。房间到期仍强制结束。用户给出的任务/等待预算优先收紧这些上限。任务完成后finish；finish不是关闭房间，用户要求保留房间时继续保留。

选择轮转或阶段模式前确认各成员能在约定时间内继续执行。没有经过验证的回调/调度时，应安排当前有限回合或使用 vanilla/软脑暴；不能把阶段规则当作会自动驱动模型的工作流引擎。开始与收口采用[业务模板](collaboration-practice.md)，期限到时允许交“未取得”而不是继续无限研究。

## 暂停、退出和真实自动化边界

- 成员本地stop/EOF退出本成员；不关闭其他成员或空Group房间。有效期内可同码获得新peer_id并重新配对；旧peer不会复活。关闭整个团队房间通过管理员关闭操作。
- Leader或当前发言者不可用时，受控模式可暂停；报告缺席对象和原因。旧Leader重新加入不会继承权限，名称相同也无效；原Leader已不在线时，管理员必须显式configure指定新的活跃Leader，再按当前规则继续。不能自行推测任务已完成。
- brainstorm未完成成员退出，导致剩余成员都已完成当前阶段时，暂停为membership_changed；Leader或管理员明确configure开始新的策略阶段，不代替离开者贡献，也不反复resume/advance。
- heartbeat表示客户端存活；传输ACK表示本机已认证并保存；consume表示接收方消费了消息。三者都不能当作讨论结论或业务通过。
- Hub和MCP不持有宿主的模型运行器。通知/后台下载不保证唤醒模型；显示“等待目标Agent继续执行”，不要虚报“正在自主工作”。继续当前已授权回合，或使用已验证的宿主回调/调度。
- 时间线仅提供Hub实际观测的事件。心跳为按分钟汇总；不从一条最后心跳推测整段历史。无法连接Hub的本地故障使用本地诊断记录。

## 模式依据

Coagen提炼上述协议，不要求安装某个模型框架。固定发言顺序参考[AutoGen Teams](https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/teams.html)，发言选择与停止规则分离参考[Microsoft Group Chat](https://learn.microsoft.com/en-us/agent-framework/workflows/orchestrations/group-chat)。Leader负责整合结果的模式参考[OpenAI Agents SDK orchestration](https://openai.github.io/openai-agents-python/multi_agent/)。Coagen不声称已集成这些框架的模型执行器或自动规划器。
