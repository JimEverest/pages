# 安装与准备：客户端与 Skill 0.7.5（安装器 r13）

使用用户指定、已核对 SHA-256 的**对应平台**完整套件，按其中 `INSTALL_FOR_AGENT.md` 执行。源码目录不是发布包；不要读源码临时拼装安装命令，也不要因为 MCP 暂不可用而改用终端完成房间操作。

## 选择套件

| 本机 | 套件 | 入口 |
|---|---|---|
| Linux x86_64 / ARM64，glibc ≥ 2.17 | `coagen-v0.7.5-multi-agent-kit-r13-linux-x86_64-glibc.zip` / `…-linux-aarch64-glibc.zip` | `sh install.sh` |
| Linux musl ≥ 1.2（Alpine） | `…-linux-x86_64-musl.zip` / `…-linux-aarch64-musl.zip` | `sh install.sh` |
| macOS 11+ Apple Silicon | `…-macos-arm64.zip` | `sh install.sh` |
| Windows 10/11 x64 | `…-windows-x86_64.zip` | `INSTALL.cmd` |
| 以上平台且允许访问 PyPI | `…-online.zip`（依赖在线下载、逐一哈希校验） | 同上 |

需要已有 64 位标准 CPython 3.11–3.14；套件不含 Python，也不会自行安装。暂不支持：Intel Mac（cryptography 50.0.1 无 macOS x86_64 wheel）、Windows ARM64 原生 Python（改用 x64 Python 与 Windows x64 套件）、free-threaded / PyPy、32 位。拿错平台包时，安装器在写入前报告 `KIT_PLATFORM_MISMATCH` 和正确文件名。

## 标准流程

以 `ENTRY` 代表 `sh 解压目录/install.sh`（Linux/macOS）或 `解压目录\INSTALL.cmd`（Windows）：

```sh
ENTRY install --host auto --workspace ~/CoagenWork            # 预览，零写入
ENTRY install --host auto --workspace ~/CoagenWork --apply    # 应用
ENTRY doctor  --host auto --workspace ~/CoagenWork --check-hub
```

- workspace 是附件/导出的固定根目录，写入宿主配置后不随聊天变化；未指定时用 `~/CoagenWork`（Windows `%USERPROFILE%\CoagenWork`），不要用临时聊天目录。纯文字协作不要求聊天目录与它一致。
- runtime：Linux `~/.local/share/coagen/runtimes/0.7.5`，macOS `~/Library/Application Support/Coagen/runtimes/0.7.5`，Windows `%LOCALAPPDATA%\Coagen\runtimes\0.7.5`。每个版本一个目录，旧版保留。
- 离线套件默认 `--source offline`：禁止访问任何包索引，只使用包内哈希锁定的 wheel；`--source online` 才联网，仍强制同一哈希锁。
- `awaiting_host_prepare` / `awaiting_host_registration` 只说明本机准备完成，不能报告“已接通”。
- 不能运行 `install.sh` / `INSTALL.cmd` 时，按套件内 `MANUAL_INSTALL.md`：优先 `python -I -X utf8 解压目录/coagen_install.py …`（同一安装器、同样参数）；仍失败时才执行其中的逐步手工流程，并在报告中注明“手工安装”。没有 CPython 3.11–3.14 的环境无法运行 Coagen，任何安装方式都不能绕过。

## Skill 与 MCP 登记

完整 Skill 写入公共目录 `~/.agents/skills/coagen`，并按所选宿主复制到兼容目录（Claude Code `~/.claude/skills/coagen`，WorkBuddy `~/.workbuddy/skills/coagen`）。不要手工覆盖整个 skills 文件夹。

五种已知预设（claude、codex、workbuddy、zcode、dsh）只合并 `coagen` 一项，保留其他 MCP 和用户设置，原文件有备份与回执。其他宿主使用 `--host generic`（或任意名称），报告给出可直接粘贴的 `mcpServers` 片段、`command/args/env`、`skill_path`、`host_requirements`；按宿主公开的用户级 MCP 配置入口登记，不猜私有配置、不改信任缓存。宿主需要具备：本地 stdio MCP、允许子进程、本机回环、Hub HTTPS、Skill 或等价指引加载。缺哪一项就如实报告哪一项。

## 原生验收

多数宿主只在新会话或重启时加载 MCP 配置。先保存活动协作成果，再让宿主正常重新加载；在新会话中原生调用 `coagen_prepare`，核对 `version=0.7.5`、`workspace`、`binding_scope=mcp_instance`，并确认 Skill 被列出（Claude Code `/coagen`，Codex `$coagen`）。工具缺失时按宿主公开入口重载一次；仍缺失就报告待用户重启或授权，停止。终端 smoke、`doctor`、配置文件存在都不能替代原生 prepare。prepare 不证明 Hub 可达；`doctor --check-hub` 检查网络；加密协作需要真实或隔离房间。

**WorkBuddy**：MCP“重连”可能继续使用进程内旧配置；没有可见重载入口时请用户正常退出并重启。自定义连接器的允许状态可能绑定配置指纹，runtime 路径变化后需要在界面中重新允许，不能修改信任数据库。

## 升级、失败与回滚

- 升级：使用新版本套件重复标准流程，沿用原 workspace。旧 runtime 保留，配置与 Skill 先备份再替换。重启后旧会话内存密钥不会恢复；有效 Group 可用原配对码重新加入。
- 失败：按输出的 `code` 与 `next_action` 修正一个已确认原因后最多再执行一次；同样错误再次出现即停止。只读诊断用 `ENTRY diagnose --report 报告路径`。不要打印配置正文、不要换底层写入方法、不要反复重装。
- 中断或损坏：未完成的 runtime 自动移到 `.coagen-retired/` 后重建；已损坏的同版本 runtime 返回 `RUNTIME_BROKEN`，加 `--replace-runtime` 执行一次。
- 回滚：`ENTRY rollback --report 报告路径` 预览，确认后 `--apply`，恢复本次安装写入的配置与 Skill；之后被改动的内容不会被覆盖。runtime 不删除。

## 管理令牌、预约与 owner

直接创建默认读取 `~/.config/coagen/azure-admin-token.txt`（Windows `%USERPROFILE%\.config\coagen\azure-admin-token.txt`）。Agent 只需知道凭据已配置，不读出或贴出长期令牌。加入方只需 8 位码。创建方若获得管理端 43 字符一次性预约激活码，可用 `coagen_create(reservation_code=...)`，不需要管理员令牌；激活码不得写入 MCP 配置或路径。安装与 prepare 不读取任何长期凭据。

默认 MCP 实例持有会话，不识别品牌进程；显式 owner/适配器校验失败时报告，不绑定无关 PID。不把长期凭据、配对码、激活码、state_dir 或业务正文写入 MCP 配置。`COAGEN_MCP_HUB` 可在 MCP 配置的 env 中指定其他 Hub（显式 `--hub` 优先）。

## 明确授权的人工 CLI

只有用户明确要求人工 CLI 时使用；MCP 不可用时不自动降级。使用已安装 runtime 的解释器和新的专用状态目录：

```sh
"$HOME/.local/share/coagen/runtimes/0.7.5/bin/python" -I -X utf8 -m coagen_client join --state-dir "$HOME/coagen-state-$(date +%s)"
```

```cmd
"%LOCALAPPDATA%\Coagen\runtimes\0.7.5\Scripts\python.exe" -I -X utf8 -m coagen_client join --state-dir "%COAGEN_STATE%"
```

在隐藏输入提示中输入 8 位码，保留前导零。预约激活用 `create --reservation-code-stdin`。状态目录不能包含配对码/激活码，不放进 Git、同步盘或业务附件，不经用户创建的符号链接或 junction（系统级别名如 macOS `/var` 不受影响）。

失败按 [统一恢复流程](recovery.md) 处理，不试错重装、换网络或重复建房。
