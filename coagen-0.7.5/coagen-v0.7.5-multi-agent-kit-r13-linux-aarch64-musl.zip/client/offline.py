"""Coagen client runtime builder shared by the offline and online installers.

Run with the target CPython: ``python -I -X utf8 offline.py new RUNTIME``.
Every command prints one final JSON line; failures carry a stable ``code``.
Offline mode never consults a package index. Online mode downloads only the
exact hash-locked files named in requirements-lock.txt.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
LOCK = ROOT / 'requirements-lock.txt'
MARKER = '.coagen-runtime.json'


def _locked_version():
    for line in LOCK.read_text(encoding='utf-8').splitlines():
        if line.startswith('coagen-client=='):
            return line.split('==', 1)[1].split()[0].strip()
    raise ValueError('requirements-lock.txt has no coagen-client pin')


VERSION = _locked_version()


class BundleError(ValueError):
    def __init__(self, code, message, **details):
        super().__init__(message)
        self.report = {'ok': False, 'code': code, 'reason': message, **details}


def require(condition, code, message, **details):
    if not condition:
        raise BundleError(code, message, **details)


def platform_module():
    """The platform rules ship beside this file; the source tree keeps them in coagen-setup."""
    module = sys.modules.get('coagen_platform')
    if module:
        return module
    here = Path(__file__).resolve().parent
    for path in (ROOT / 'coagen_platform.py', here / 'coagen_platform.py', here.parent / 'coagen-setup/coagen_platform.py'):
        if path.is_file():
            spec = importlib.util.spec_from_file_location('coagen_platform', path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            sys.modules['coagen_platform'] = module
            return module
    raise BundleError('BUNDLE_FILE_MISSING', 'coagen_platform.py is missing from the bundle')


def manifest():
    return json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))


def verify():
    value = manifest()
    require(value.get('version') == VERSION, 'BUNDLE_VERSION_MISMATCH', 'Bundle version mismatch')
    for relative, digest in value['files'].items():
        path = (ROOT / relative).resolve()
        require(path.is_relative_to(ROOT), 'INVALID_MANIFEST_PATH', 'Invalid manifest path')
        require(path.is_file(), 'BUNDLE_FILE_MISSING', 'Missing bundle file: ' + relative, file=relative)
        require(hashlib.sha256(path.read_bytes()).hexdigest() == digest,
                'BUNDLE_CHECKSUM_MISMATCH', 'Bundle checksum mismatch: ' + relative, file=relative)
    return value


def environment(source):
    """Fail before any write when this interpreter cannot use the bundle."""
    platforms = platform_module()
    facts = platforms.identity()
    targets = manifest().get('targets', [])
    failure = platforms.support(facts, targets, source=source)
    if failure:
        raise BundleError(failure['code'], failure['reason'], next_action=failure['next_action'],
                          detected=failure['detected'])
    return facts


def pip_wheel():
    wheels = sorted((ROOT / 'tools').glob('pip-*-py3-none-any.whl'))
    require(len(wheels) == 1, 'BUNDLE_FILE_MISSING', 'The bundled pip wheel is missing')
    return wheels[0]


def child_env(source):
    # Ignore user/global pip configuration and any PIP_* overrides. Offline mode
    # additionally drops proxy variables: it has no reason to open a connection.
    env = {key: value for key, value in os.environ.items()
           if not key.upper().startswith('PIP_') and key.upper() not in ('PYTHONPATH', 'PYTHONHOME')}
    if source == 'offline':
        env = {key: value for key, value in env.items() if not key.lower().endswith('_proxy')}
        env['PIP_NO_INDEX'] = '1'
    env.update(PIP_CONFIG_FILE=os.devnull, PIP_DISABLE_PIP_VERSION_CHECK='1', PYTHONUTF8='1',
               PIP_NO_INPUT='1')
    return env


def run(args, code, message, source, timeout):
    try:
        result = subprocess.run([str(value) for value in args], capture_output=True, timeout=timeout,
                                env=child_env(source), stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise BundleError(code, message + ' (timed out after %d seconds)' % timeout) from None
    except OSError as error:
        raise BundleError(code, message + ' (%s)' % type(error).__name__) from None
    if result.returncode:
        # pip messages name packages and tags, not secrets; keep a short tail.
        tail = result.stderr.decode('utf-8', 'replace').strip().splitlines()[-6:]
        raise BundleError(code, message, exit_code=result.returncode, detail=tail)
    return result.stdout.decode('utf-8', 'replace')


def pip_command(python, source, index_url=None):
    command = [python, '-I', '-X', 'utf8', pip_wheel() / 'pip', '--isolated', '--disable-pip-version-check',
               '--no-input', 'install', '--no-cache-dir', '--only-binary=:all:', '--require-hashes',
               '--no-warn-script-location', '--find-links', ROOT / 'wheels', '-r', LOCK]
    if source == 'offline':
        command.insert(command.index('--find-links'), '--no-index')
    elif index_url:
        command[command.index('--find-links'):command.index('--find-links')] = ['--index-url', index_url]
    return command


def resolve(python, source, index_url=None):
    """Resolve the complete locked set for this interpreter without writing anything.

    --target sidesteps PEP 668 "externally managed" refusals for the base
    interpreter; --dry-run never creates it.
    """
    with tempfile.TemporaryDirectory(prefix='coagen-resolve-') as scratch:
        run([*pip_command(python, source, index_url), '--dry-run', '--ignore-installed',
             '--target', Path(scratch) / 'never-created'],
            'DEPENDENCY_RESOLUTION_FAILED', 'Locked dependencies are not installable for this interpreter' +
            (' from the bundled wheelhouse' if source == 'offline' else ' from the package index'), source, 240)


def install_into(python, source, index_url=None):
    run(pip_command(python, source, index_url), 'DEPENDENCY_INSTALL_FAILED', 'Dependency installation failed', source, 300)
    run([python, '-I', '-X', 'utf8', pip_wheel() / 'pip', '--isolated', '--disable-pip-version-check', 'check'],
        'DEPENDENCY_CHECK_FAILED', 'pip check reported an inconsistent environment', source, 60)
    output = run([python, '-I', '-X', 'utf8', ROOT / 'offline.py', 'smoke'], 'RUNTIME_SMOKE_FAILED',
                 'The installed client did not pass the local MCP smoke test', source, 60)
    return json.loads(output.strip().splitlines()[-1])


def write_marker(runtime, value):
    path = Path(runtime) / MARKER
    stage = path.with_name(path.name + '.tmp')
    stage.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(stage, path)


def new(runtime, source, index_url=None):
    """Create a fresh versioned runtime; the marker records an interrupted attempt."""
    started = time.monotonic()
    verify()
    facts = environment(source)
    platforms = platform_module()
    runtime = Path(runtime).expanduser().absolute()
    require(not os.path.lexists(runtime), 'RUNTIME_EXISTS',
            'The runtime destination already exists; the installer decides whether to reuse or replace it.')
    # Every wheel, hash, ABI and platform tag is checked before the first write.
    resolve(Path(sys.executable), source, index_url)
    runtime.parent.mkdir(parents=True, exist_ok=True)
    runtime.mkdir()
    base = {'format': 1, 'client_version': VERSION, 'source': source, 'target': facts['target'],
            'python': facts['python']['version'], 'abi': facts['python']['abi'],
            'base_executable': getattr(sys, '_base_executable', sys.executable),
            'lock_sha256': hashlib.sha256(LOCK.read_bytes()).hexdigest()}
    write_marker(runtime, {**base, 'state': 'installing'})
    # --without-pip: Debian/Ubuntu split ensurepip into python3-venv; the
    # bundled, hash-verified pip wheel replaces it on every platform.
    run([sys.executable, '-I', '-X', 'utf8', '-m', 'venv', '--without-pip', runtime],
        'PYTHON_VENV_FAILED', 'python -m venv could not create the runtime', source, 120)
    python = platforms.venv_python(runtime)
    require(python.is_file(), 'PYTHON_VENV_FAILED', 'The new runtime has no interpreter')
    smoke = install_into(python, source, index_url)
    write_marker(runtime, {**base, 'state': 'ready'})
    return {'ok': True, 'status': 'created', 'runtime': str(runtime), 'python': str(python),
            'target': facts['target'], 'source': source, 'network_used': source == 'online',
            'smoke': smoke, 'elapsed_ms': round((time.monotonic() - started) * 1000)}


def upgrade(source, index_url=None):
    verify()
    environment(source)
    require(sys.prefix != sys.base_prefix, 'SYSTEM_PYTHON_REFUSED',
            'Run upgrade with the dedicated runtime interpreter, not a system Python.')
    resolve(Path(sys.executable), source, index_url)
    smoke = install_into(Path(sys.executable), source, index_url)
    return {'ok': True, 'status': 'upgraded', 'python': sys.executable, 'smoke': smoke}


def smoke():
    import coagen_client
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    import httpx  # noqa: F401
    import psutil  # noqa: F401
    import spake2  # noqa: F401
    require(coagen_client.__version__ == VERSION, 'RUNTIME_VERSION_MISMATCH',
            'Installed client version is not ' + VERSION)
    secret, nonce = AESGCM.generate_key(bit_length=256), os.urandom(12)
    aead = AESGCM(secret)
    require(aead.decrypt(nonce, aead.encrypt(nonce, b'offline-smoke', None), None) == b'offline-smoke',
            'RUNTIME_SMOKE_FAILED', 'Encryption dependency test failed')
    messages = [
        {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize',
         'params': {'protocolVersion': '2024-11-05', 'capabilities': {},
                    'clientInfo': {'name': 'Coagen offline standard MCP harness', 'version': '1'}}},
        {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
        {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'},
        {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call',
         'params': {'name': 'coagen_prepare', 'arguments': {}}},
        # A raw non-ASCII ID is echoed by ping. This checks stdin and stdout
        # preservation without a room, credentials, helper, or network request.
        {'jsonrpc': '2.0', 'id': '离线检查-中文-é', 'method': 'ping'},
    ]
    # Prepare also opens a private diagnostic journal. Keep the smoke
    # journal isolated from the user's real Coagen sessions and incidents.
    with tempfile.TemporaryDirectory(prefix='coagen-offline-smoke-') as scratch:
        result = subprocess.run(
            [sys.executable, '-I', '-X', 'utf8', '-m', 'coagen_client', 'mcp', '--workspace', str(ROOT)],
            input='\n'.join(json.dumps(item, ensure_ascii=False) for item in messages) + '\n',
            text=True, encoding='utf-8', capture_output=True, timeout=25,
            env=dict(os.environ, LOCALAPPDATA=scratch, PYTHONUTF8='1'))
    require(result.returncode == 0, 'RUNTIME_SMOKE_FAILED', 'MCP child failed; check the installed interpreter.')
    replies = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    require(len(replies) == 4, 'RUNTIME_SMOKE_FAILED', 'Unexpected MCP replies')
    by_id = {reply['id']: reply['result'] for reply in replies}
    require(by_id[1]['serverInfo']['version'] == VERSION, 'RUNTIME_SMOKE_FAILED', 'MCP version mismatch')
    required = {'coagen_prepare', 'coagen_create', 'coagen_join', 'coagen_status',
                'coagen_watch', 'coagen_receive', 'coagen_send', 'coagen_retry_send', 'coagen_consume',
                'coagen_audit', 'coagen_stop'}
    require(required <= {item['name'] for item in by_id[2]['tools']}, 'RUNTIME_SMOKE_FAILED', 'Missing MCP tools')
    require(not by_id[3].get('isError'), 'RUNTIME_SMOKE_FAILED', 'MCP prepare failed')
    prepared = by_id[3].get('structuredContent') or json.loads(by_id[3]['content'][0]['text'])
    require(prepared.get('binding_scope') == 'mcp_instance', 'RUNTIME_SMOKE_FAILED',
            'MCP must support unbranded instance ownership')
    require(by_id.get('离线检查-中文-é') == {}, 'RUNTIME_SMOKE_FAILED', 'MCP raw UTF-8 round trip failed')
    return {'ok': True, 'local_check': 'pass', 'version': VERSION, 'dependencies': 'pass',
            'mcp_initialize': 'pass', 'mcp_tools': 'pass', 'mcp_prepare': 'pass',
            'mcp_raw_utf8': 'pass', 'mcp_instance_owner': 'pass',
            'network_used': False, 'host_registration_tested': False}


def skills(agent):
    """Standalone bundle helper: copy only the Skill. The complete kit uses its installer."""
    verify()
    platforms = platform_module()
    require(isinstance(agent, str) and bool(agent.strip()), 'INVALID_ARGUMENT', 'Use a non-empty Agent name or generic.')
    agent = agent.strip().casefold()
    # Names select optional legacy layout presets, never admission. Unknown
    # hosts receive the shared skill without guessing a vendor-specific path.
    destinations = [Path.home() / '.agents' / 'skills' / 'coagen']
    if agent in ('claude', 'both'):
        destinations.append(Path.home() / '.claude' / 'skills' / 'coagen')
    if agent in ('codex', 'both'):
        legacy = Path.home() / '.codex' / 'skills' / 'coagen'
        if legacy.exists():
            destinations.append(legacy)
    installed = []
    for target in destinations:
        require(not any(platforms.untrusted_link(p) for p in (target, *target.parents)),
                'LINKED_PATH', 'Linked skill paths require manual review')
        backup = None
        if target.exists():
            backup = Path.home() / '.coagen-backups' / str(time.time_ns()) / target.parent.parent.name / 'coagen'
            shutil.copytree(target, backup)
        shutil.copytree(ROOT / 'skills' / 'coagen', target, dirs_exist_ok=True)
        installed.append({'target': str(target), 'backup': str(backup) if backup else None})
    return {'ok': True, 'skills': installed,
            'next_action': 'Restart the Agent. MCP registration is a separate step; see README-B.md.'}


def main(argv=None):
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    commands.add_parser('verify')
    commands.add_parser('smoke')
    commands.add_parser('platform')
    for name in ('new', 'upgrade'):
        sub = commands.add_parser(name)
        if name == 'new':
            sub.add_argument('runtime')
        sub.add_argument('--source', choices=('offline', 'online'), default='offline')
        sub.add_argument('--index-url', help='Online only: an explicit package index; hashes are still enforced')
    sub = commands.add_parser('skills')
    sub.add_argument('agent')
    args = parser.parse_args(argv)
    try:
        if getattr(args, 'index_url', None) and args.source != 'online':
            raise BundleError('INVALID_ARGUMENT', '--index-url requires --source online')
        if args.action == 'verify':
            verify()
            result = {'ok': True, 'bundle': 'verified', 'version': VERSION}
        elif args.action == 'smoke':
            result = smoke()
        elif args.action == 'platform':
            facts = platform_module().identity()
            result = {'ok': True, 'identity': facts, 'bundle_targets': manifest().get('targets', []),
                      'offline_support': platform_module().support(facts, manifest().get('targets', [])) or 'supported'}
        elif args.action == 'new':
            result = new(args.runtime, args.source, args.index_url)
        elif args.action == 'upgrade':
            result = upgrade(args.source, args.index_url)
        else:
            result = skills(args.agent)
    except BundleError as error:
        result = error.report
    except (OSError, ValueError, KeyError) as error:
        result = {'ok': False, 'code': 'LOCAL_IO_ERROR', 'reason': type(error).__name__}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get('ok') else 1


if __name__ == '__main__':
    raise SystemExit(main())
