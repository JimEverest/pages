@echo off
setlocal DisableDelayedExpansion
if /I "%~1"=="upgrade" goto upgrade
if /I "%~1"=="new" goto new
echo Usage:
echo   install.cmd upgrade "C:\path\to\existing-venv\Scripts\python.exe"
echo   install.cmd new "C:\path\to\python.exe" "C:\path\to\new-venv"
echo Stop existing Coagen sessions and close their Agents before upgrading.
exit /b 2
:upgrade
if "%~2"=="" exit /b 2
"%~2" "%~dp0offline.py" upgrade
exit /b %errorlevel%
:new
if "%~2"=="" exit /b 2
if "%~3"=="" exit /b 2
"%~2" "%~dp0offline.py" new "%~3"
exit /b %errorlevel%
