@echo off
setlocal DisableDelayedExpansion
if "%~1"=="" goto usage
if "%~2"=="" goto local
if /I "%~2"=="local" goto local
if /I "%~2"=="hub" goto hub
if /I "%~2"=="full" goto full
:usage
echo Usage: check.cmd "C:\path\to\venv\Scripts\python.exe" [local^|hub^|full]
echo Local is offline. Hub/full contact Azure; full needs the local admin token.
exit /b 2
:local
"%~1" "%~dp0offline.py" verify
if errorlevel 1 exit /b 1
"%~1" "%~dp0offline.py" smoke
exit /b %errorlevel%
:hub
"%~1" -m coagen_client check
exit /b %errorlevel%
:full
"%~1" -m coagen_client check --admin-token-file "%USERPROFILE%\.config\coagen\azure-admin-token.txt"
exit /b %errorlevel%
