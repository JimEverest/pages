@echo off
setlocal DisableDelayedExpansion
if "%~1"=="" goto usage
if "%~2"=="" goto usage
"%~1" "%~dp0offline.py" skills "%~2"
exit /b %errorlevel%
:usage
echo Usage: install-skills.cmd "C:\path\to\venv\Scripts\python.exe" claude
echo        install-skills.cmd "C:\path\to\venv\Scripts\python.exe" codex
echo        install-skills.cmd "C:\path\to\venv\Scripts\python.exe" both
echo        install-skills.cmd "C:\path\to\venv\Scripts\python.exe" generic
echo        install-skills.cmd "C:\path\to\venv\Scripts\python.exe" "Any Agent Name"
exit /b 2
