# Coagen 0.7.5 底层 runtime 包（套件内 `client/` 目录）

标准安装请使用套件根目录的 `install.sh`（Linux/macOS）或 `INSTALL.cmd`（Windows），并阅读 `INSTALL_FOR_AGENT.md`：它在本目录之上增加了平台检查、版本化 runtime、宿主配置合并、Skill 分发、报告、诊断与回滚。只有用户明确要求“只装 Python 环境、自己登记 MCP”时才直接使用本目录。无法运行入口脚本时，请改用套件根目录的 `MANUAL_INSTALL.md`（经过 CI 实测的逐步流程）。

## 内容

- `wheels/`：Coagen 客户端（含 MCP Server、helper、CLI）和本平台全部锁定依赖；`online` 套件中只有客户端 wheel。
- `tools/pip-*.whl`：固定版本的 pip，用于不带 pip 的虚拟环境，不依赖系统 ensurepip / python3-venv。
- `requirements-lock.txt`：全部依赖的精确版本与 SHA-256；安装时 `--require-hashes` 强制校验。
- `coagen_platform.py`：平台识别与支持矩阵；`offline.py`：创建、升级、自检。
- `skills/coagen/`：完整 Skill；`source/coagen-client/`：客户端源码快照；`manifest.json`：本目录所有文件的 SHA-256 与平台 `targets`。

## 命令（使用目标 CPython 3.11–3.14 运行）

```sh
python3 -I client/offline.py platform                                   # 只读：本机 target、本包是否匹配
python3 -I -X utf8 client/offline.py new ~/.local/share/coagen/runtimes/0.7.5   # 新建 runtime（离线）
python3 -I -X utf8 client/offline.py new 目标目录 --source online               # 在线，仍校验哈希
目标目录/bin/python -I -X utf8 client/offline.py smoke                  # 本机 MCP 自检（Windows: Scripts\python.exe）
```

`new` 的顺序：校验 manifest → 检查平台与 Python → 用基础解释器对整套锁定依赖做只读解析（错误架构、缺少 wheel 在此失败，未写任何文件）→ 创建目录并写入 `installing` 标记 → `venv --without-pip` → 用内置 pip 安装 → `pip check` → MCP initialize / tools/list / coagen_prepare / UTF-8 自检 → 标记 `ready`。失败输出一行 JSON，含 `code` 与原因。中途中断留下 `installing` 标记，标准安装器会把它移到 `.coagen-retired/` 后重建；直接使用本目录时请换一个新目标目录。

离线模式命令行含 `--no-index`，并清除所有 `PIP_*` 与代理环境变量，因此不会访问网络。

Windows 用户也可使用 `install.cmd new "C:\path\python.exe" "目标目录"`、`check.cmd`、`install-skills.cmd`（与旧版用法相同）。

## 登记 MCP

```json
{"mcpServers": {"coagen": {"type": "stdio", "command": "目标目录/bin/python",
  "args": ["-I", "-X", "utf8", "-m", "coagen_client", "mcp", "--workspace", "/绝对/稳定/工作目录"],
  "env": {"PYTHONUTF8": "1"}}}}
```

按宿主公开文档登记后，在宿主新会话中原生调用 `coagen_prepare` 验收。本包不含 Python 本体、Agent 软件、管理员令牌或会话数据。
